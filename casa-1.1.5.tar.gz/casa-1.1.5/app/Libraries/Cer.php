<?php

declare(strict_types=1);

namespace App\Libraries;

/**
 * Cer — CoreNet Environment Resolver (CES 11.5).
 *
 * Pembungkus TIPIS di atas konstanta path bawaan CI4 (ROOTPATH/APPPATH/
 * WRITEPATH) dan kontrak Multi-Endpoint (11.5.2) serta Session per Endpoint
 * (11.5.3). DILARANG menghitung path atau menebak endpoint di tempat lain —
 * satu-satunya sumber kebenaran ada di sini (butir 1.7 "satu cara untuk satu
 * hal").
 */
final class Cer
{
    public const ENDPOINT_MEMBER = 'member';
    public const ENDPOINT_ADMIN  = 'admin';

    private static ?string $endpoint = null;

    /* ------------------------------------------------------------ Path (11.5.1) */

    public static function root(string $sub = ''): string
    {
        return rtrim(ROOTPATH, '/\\') . ($sub !== '' ? DIRECTORY_SEPARATOR . ltrim($sub, '/\\') : '');
    }

    public static function writable(string $sub = ''): string
    {
        return rtrim(WRITEPATH, '/\\') . ($sub !== '' ? DIRECTORY_SEPARATOR . ltrim($sub, '/\\') : '');
    }

    public static function uploads(string $sub = ''): string
    {
        return self::writable('uploads' . ($sub !== '' ? DIRECTORY_SEPARATOR . ltrim($sub, '/\\') : ''));
    }

    /* -------------------------------------------------- Multi-Endpoint (11.5.2) */

    /**
     * Endpoint aktif berdasarkan HTTP_HOST. Default MEMBER: keliru menaruh
     * permintaan di area admin jauh lebih berbahaya daripada sebaliknya.
     * HTTP_HOST hanya DICOCOKKAN, tidak pernah dicetak (anti host-injection).
     */
    public static function endpoint(): string
    {
        if (self::$endpoint !== null) {
            return self::$endpoint;
        }
        if (is_cli()) {
            return self::$endpoint = self::ENDPOINT_MEMBER;
        }

        $host = self::hostOnly((string) ($_SERVER['HTTP_HOST'] ?? ''));

        // Portal terpadu (single-URL): bila `app.adminURL` KOSONG, tak ada host
        // admin terpisah → seluruh host dianggap MEMBER, dan fungsi admin diakses
        // owner lewat portal member (lihat AdminAuthFilter + BaseController::adminView).
        // adminHost DIBACA LANGSUNG dari env — JANGAN lewat adminUrl() yang jatuh
        // balik ke baseUrl (itu membuat host sendiri salah dikenali sebagai admin).
        $adminUrlEnv = (string) (env('app.adminURL') ?: '');
        $adminHost   = $adminUrlEnv !== ''
            ? self::hostOnly((string) parse_url($adminUrlEnv, PHP_URL_HOST))
            : '';

        return self::$endpoint = ($adminHost !== '' && $host === $adminHost)
            ? self::ENDPOINT_ADMIN
            : self::ENDPOINT_MEMBER;
    }

    public static function isAdmin(): bool  { return self::endpoint() === self::ENDPOINT_ADMIN; }
    public static function isMember(): bool { return self::endpoint() === self::ENDPOINT_MEMBER; }

    /** Paksa endpoint tertentu — hanya untuk CLI/cron dan pengujian. */
    public static function forceEndpoint(string $endpoint): void
    {
        self::$endpoint = in_array($endpoint, [self::ENDPOINT_MEMBER, self::ENDPOINT_ADMIN], true)
            ? $endpoint
            : self::ENDPOINT_MEMBER;
    }

    public static function baseUrl(): string
    {
        return rtrim((string) (config('App')->baseURL ?: 'http://localhost/'), '/') . '/';
    }

    public static function adminUrl(): string
    {
        $url = (string) (env('app.adminURL') ?: '');
        return $url !== '' ? rtrim($url, '/') . '/' : self::baseUrl();
    }

    /** URL dasar untuk endpoint yang sedang aktif. */
    public static function currentBaseUrl(): string
    {
        return self::isAdmin() ? self::adminUrl() : self::baseUrl();
    }

    /* --------------------------------------------- Session per Endpoint (11.5.3) */

    /** Nama cookie sesi yang WAJIB dipakai endpoint aktif. */
    public static function sessionCookieName(): string
    {
        return self::isAdmin()
            ? (string) (env('session.cookieAdmin')  ?: 'casa_admin_sid')
            : (string) (env('session.cookieMember') ?: 'casa_member_sid');
    }

    private static function hostOnly(string $host): string
    {
        $host = strtolower(trim($host));
        if ($host === '') {
            return '';
        }
        $pos = strrpos($host, ':');
        if ($pos !== false && !str_contains($host, ']')) {
            $host = substr($host, 0, $pos);
        }
        return $host;
    }
}
