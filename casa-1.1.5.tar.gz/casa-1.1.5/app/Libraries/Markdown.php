<?php

declare(strict_types=1);

namespace App\Libraries;

/**
 * Markdown — perender subset Markdown untuk konten panduan (CES 1.7).
 *
 * Konten panduan disimpan sebagai berkas .md agar dapat disunting tanpa
 * menyentuh kode PHP. Perender ini sengaja dibatasi pada sintaks yang benar-
 * benar dipakai dokumentasi CoreNet: judul, penekanan, daftar, tabel, kutipan,
 * blok kode, tautan, gambar, dan garis pemisah.
 *
 * KEAMANAN: seluruh masukan di-escape LEBIH DULU, baru pola Markdown diubah
 * menjadi HTML. Dengan begitu HTML mentah di dalam berkas .md tidak pernah
 * dieksekusi — mencegah XML/script injection bila kelak konten disunting
 * lewat panel admin.
 */
final class Markdown
{
    /** Opsi render aktif (imgDir, imgUrl). Berlaku selama satu permintaan. */
    private static array $opt = [];

    /**
     * @param array{imgDir?:string,imgUrl?:string} $opt Lokasi & URL gambar panduan.
     */
    public static function render(string $md, array $opt = []): string
    {
        self::$opt = $opt;

        $md = str_replace(["\r\n", "\r"], "\n", $md);

        // 1) Amankan blok kode lebih dulu agar isinya tidak ikut diproses.
        //
        // Penanda memakai \x02 (STX), BUKAN \x00. trim() PHP secara bawaan
        // membuang byte NUL, sehingga penanda ber-NUL akan terpotong menjadi
        // teks biasa, gagal dikenali, lalu membuat penunjuk baris tidak pernah
        // maju — permintaan menggantung sampai batas waktu eksekusi.
        $blok = [];
        $md   = preg_replace_callback('/```[a-z]*\n(.*?)```/s', static function (array $m) use (&$blok): string {
            $blok[] = $m[1];

            return "\x02BLOK" . (count($blok) - 1) . "\x02";
        }, $md) ?? $md;

        $html  = '';
        $baris = explode("\n", $md);
        $n     = count($baris);
        $i     = 0;

        while ($i < $n) {
            $l = rtrim($baris[$i]);

            // blok kode tersimpan
            if (preg_match('/^\x02BLOK(\d+)\x02$/', trim($l), $m)) {
                $html .= '<pre class="bg-body-tertiary p-3 rounded small"><code>'
                    . esc(rtrim($blok[(int) $m[1]])) . '</code></pre>';
                $i++;
                continue;
            }

            // garis pemisah
            if (preg_match('/^(-{3,}|\*{3,})$/', trim($l))) {
                $html .= '<hr>';
                $i++;
                continue;
            }

            // judul — dukung penanda anchor eksplisit opsional "{#id-slug}" di akhir
            // baris (ditulis sendiri oleh pemanggil, mis. ReportService), BUKAN HTML
            // mentah — tetap lolos esc() seperti teks judul lainnya. Dipakai supaya
            // tabel ringkasan bisa menaut langsung ke detail temuan di bawahnya.
            if (preg_match('/^(#{1,6})\s+(.*?)(?:\s*\{#([a-z0-9-]+)\})?$/', $l, $m)) {
                $tingkat = strlen($m[1]);
                $kelas   = match ($tingkat) {
                    1       => 'h4 mt-0 mb-3',
                    2       => 'h6 text-primary mt-4 mb-2',
                    default => 'h6 mt-3 mb-2',
                };
                $tag = $tingkat === 1 ? 'h2' : ($tingkat === 2 ? 'h3' : 'h4');
                $id  = isset($m[3]) && $m[3] !== '' ? ' id="' . $m[3] . '"' : '';
                $html .= "<{$tag}{$id} class=\"{$kelas}\">" . self::inline($m[2]) . "</{$tag}>";
                $i++;
                continue;
            }

            // tabel
            if (str_starts_with(trim($l), '|') && $i + 1 < $n && preg_match('/^\s*\|[\s:|-]+\|\s*$/', $baris[$i + 1])) {
                $kepala = self::selTabel($l);
                $i     += 2;
                $isi    = [];
                while ($i < $n && str_starts_with(trim($baris[$i]), '|')) {
                    $isi[] = self::selTabel($baris[$i]);
                    $i++;
                }
                $html .= '<div class="table-responsive"><table class="table table-sm align-middle"><thead><tr>';
                foreach ($kepala as $c) {
                    $html .= '<th>' . self::inline($c) . '</th>';
                }
                $html .= '</tr></thead><tbody>';
                foreach ($isi as $row) {
                    $html .= '<tr>';
                    foreach ($row as $c) {
                        $html .= '<td>' . self::inline($c) . '</td>';
                    }
                    $html .= '</tr>';
                }
                $html .= '</tbody></table></div>';
                continue;
            }

            // kutipan
            if (str_starts_with(trim($l), '>')) {
                $teks = [];
                while ($i < $n && str_starts_with(trim($baris[$i]), '>')) {
                    $teks[] = ltrim(ltrim(trim($baris[$i]), '>'));
                    $i++;
                }
                $html .= '<div class="alert alert-warning py-2 small"><i class="bi bi-exclamation-triangle me-1"></i>'
                    . self::inline(implode(' ', $teks)) . '</div>';
                continue;
            }

            // daftar berurut
            if (preg_match('/^\s*\d+\.\s+/', $l)) {
                $html .= '<ol>';
                while ($i < $n && preg_match('/^\s*\d+\.\s+(.*)$/', rtrim($baris[$i]), $m)) {
                    $html .= '<li class="mb-1">' . self::inline($m[1]) . '</li>';
                    $i++;
                }
                $html .= '</ol>';
                continue;
            }

            // daftar tak berurut
            if (preg_match('/^\s*[-*]\s+/', $l)) {
                $html .= '<ul>';
                while ($i < $n && preg_match('/^\s*[-*]\s+(.*)$/', rtrim($baris[$i]), $m)) {
                    $html .= '<li class="mb-1">' . self::inline($m[1]) . '</li>';
                    $i++;
                }
                $html .= '</ul>';
                continue;
            }

            // paragraf
            if (trim($l) === '') {
                $i++;
                continue;
            }
            $par = [];
            while ($i < $n && trim($baris[$i]) !== ''
                && ! preg_match('/^(#{1,6}\s|\s*[-*]\s|\s*\d+\.\s|>|\||\x02BLOK)/', rtrim($baris[$i]))
                && ! preg_match('/^(-{3,}|\*{3,})$/', trim($baris[$i]))) {
                $par[] = trim($baris[$i]);
                $i++;
            }
            if ($par !== []) {
                $html .= '<p>' . self::inline(implode(' ', $par)) . '</p>';

                continue;
            }

            // Pengaman: baris yang tidak cocok pola mana pun — misalnya diawali
            // '|' tetapi bukan tabel yang sah — akan membuat penunjuk baris tidak
            // pernah maju, sehingga permintaan menggantung sampai batas waktu.
            // Perlakukan sebagai paragraf biasa dan pastikan selalu maju.
            $html .= '<p>' . self::inline(trim($l)) . '</p>';
            $i++;
        }

        return $html;
    }

    /**
     * Render satu gambar panduan.
     *
     * Bila berkasnya belum tersedia, JANGAN keluarkan tag <img>. Sebuah <img>
     * yang menunjuk berkas tak ada memicu permintaan HTTP yang gagal, dan setiap
     * permintaan gagal tetap melewati seluruh kerangka kerja untuk menghasilkan
     * halaman 404 — beberapa gambar saja sudah membuat artikel terasa berat,
     * terutama di jaringan seluler. Keterangan teks dipakai sebagai gantinya,
     * dan gambar muncul otomatis begitu berkasnya diletakkan di folder _img.
     */
    private static function gambar(string $alt, string $src): string
    {
        $nama = basename(str_replace('\\', '/', $src));
        $dir  = (string) (self::$opt['imgDir'] ?? '');
        $url  = (string) (self::$opt['imgUrl'] ?? '');

        if ($dir !== '' && $url !== '' && preg_match('/^[A-Za-z0-9._-]+$/', $nama) === 1
            && is_file(rtrim($dir, '/\\') . DIRECTORY_SEPARATOR . $nama)) {
            return '<img src="' . $url . rawurlencode($nama) . '" alt="' . $alt
                . '" class="img-fluid rounded border my-2" loading="lazy">';
        }

        return '<span class="d-inline-block text-muted small border rounded px-2 py-1 my-1">'
            . '<i class="bi bi-image me-1"></i>' . ($alt !== '' ? $alt : 'gambar') . '</span>';
    }

    /** @return string[] */
    private static function selTabel(string $baris): array
    {
        $b = trim(trim($baris), '|');

        return array_map('trim', explode('|', $b));
    }

    /** Format inline. Escape dulu, baru ubah pola — HTML mentah tak pernah aktif. */
    private static function inline(string $t): string
    {
        $t = esc($t);

        // gambar sebelum tautan (sintaksnya bertumpuk)
        $t = preg_replace_callback(
            '/!\[([^\]]*)\]\(([^)\s]+)\)/',
            static fn (array $m): string => self::gambar($m[1], $m[2]),
            $t
        ) ?? $t;
        $t = preg_replace('/\[([^\]]+)\]\(([^)\s]+)\)/', '<a href="$2">$1</a>', $t) ?? $t;

        $t = preg_replace('/`([^`]+)`/', '<code>$1</code>', $t) ?? $t;
        $t = preg_replace('/\*\*([^*]+)\*\*/', '<strong>$1</strong>', $t) ?? $t;
        $t = preg_replace('/(?<![\w*])\*([^*\n]+)\*(?![\w*])/', '<em>$1</em>', $t) ?? $t;

        return $t;
    }
}
