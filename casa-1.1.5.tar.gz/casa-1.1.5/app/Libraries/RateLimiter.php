<?php

declare(strict_types=1);

namespace App\Libraries;

use Config\Database;

/**
 * RateLimiter — pembatas percobaan login (port core/RateLimiter).
 *
 * Dua batas: per-identitas (email, ketat) & per-IP (longgar, sebab satu kantor
 * berbagi IP). Berbasis tabel `login_attempts` — tahan restart, berlaku lintas
 * proses (penting di shared hosting yang tak punya memori bersama).
 */
final class RateLimiter
{
    private const MAX_PER_IDENTIFIER = 5;
    private const MAX_PER_IP         = 15;
    private const WINDOW_MINUTES     = 15;

    public static function tooMany(string $identifier, string $ip, string $scope): bool
    {
        $db = Database::connect();
        $byId = (int) ($db->query(
            'SELECT COUNT(*) n FROM login_attempts WHERE identifier=? AND scope=? AND attempted_at > (NOW() - INTERVAL ? MINUTE)',
            [$identifier, $scope, self::WINDOW_MINUTES]
        )->getRowArray()['n'] ?? 0);
        if ($byId >= self::MAX_PER_IDENTIFIER) {
            return true;
        }
        $byIp = (int) ($db->query(
            'SELECT COUNT(*) n FROM login_attempts WHERE ip=? AND scope=? AND attempted_at > (NOW() - INTERVAL ? MINUTE)',
            [$ip, $scope, self::WINDOW_MINUTES]
        )->getRowArray()['n'] ?? 0);

        return $byIp >= self::MAX_PER_IP;
    }

    public static function hit(string $identifier, string $ip, string $scope): void
    {
        Database::connect()->query(
            'INSERT INTO login_attempts (identifier, scope, ip, attempted_at) VALUES (?, ?, ?, NOW())',
            [$identifier, $scope, $ip]
        );
    }

    public static function clear(string $identifier, string $ip, string $scope): void
    {
        Database::connect()->query(
            'DELETE FROM login_attempts WHERE scope=? AND (identifier=? OR ip=?)',
            [$scope, $identifier, $ip]
        );
    }

    public static function retryAfter(string $identifier, string $ip, string $scope): int
    {
        $oldest = Database::connect()->query(
            'SELECT MIN(attempted_at) o FROM login_attempts WHERE scope=? AND (identifier=? OR ip=?) AND attempted_at > (NOW() - INTERVAL ? MINUTE)',
            [$scope, $identifier, $ip, self::WINDOW_MINUTES]
        )->getRowArray()['o'] ?? null;
        if ($oldest === null) {
            return 0;
        }
        $elapsed = (time() - strtotime((string) $oldest)) / 60;

        return max(1, (int) ceil(self::WINDOW_MINUTES - $elapsed));
    }

    public static function prune(int $olderThanDays = 7): int
    {
        $db = Database::connect();
        $db->query('DELETE FROM login_attempts WHERE attempted_at < (NOW() - INTERVAL ? DAY)', [$olderThanDays]);

        return $db->affectedRows();
    }
}
