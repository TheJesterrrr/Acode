<?php

declare(strict_types=1);

namespace App\Libraries;

/**
 * Phone — normalisasi nomor Indonesia (port core/Phone). Disimpan bentuk 62xxxx
 * (satu bentuk kanonis → pencarian/pesan WA konsisten). 08xx & +62 & 62 diterima.
 */
final class Phone
{
    private const COUNTRY_CODE = '62';

    public static function normalize(string $raw): string
    {
        $digits = preg_replace('/\D+/', '', $raw) ?? '';
        if ($digits === '') {
            return '';
        }
        if (str_starts_with($digits, '0')) {
            return self::COUNTRY_CODE . substr($digits, 1);
        }
        if (str_starts_with($digits, self::COUNTRY_CODE)) {
            return $digits;
        }
        if (str_starts_with($digits, '8')) {
            return self::COUNTRY_CODE . $digits;
        }

        return $digits;
    }

    public static function format(string $stored): string
    {
        if ($stored === '' || ! str_starts_with($stored, self::COUNTRY_CODE)) {
            return $stored;
        }
        $local = '0' . substr($stored, strlen(self::COUNTRY_CODE));
        $parts = str_split($local, 4);

        return implode('-', $parts);
    }

    public static function waLink(string $stored, string $message = ''): string
    {
        $url = 'https://wa.me/' . $stored;
        if ($message !== '') {
            $url .= '?text=' . rawurlencode($message);
        }

        return $url;
    }

    public static function isValid(string $raw): bool
    {
        $n = self::normalize($raw);

        return preg_match('/^62[8]\d{7,12}$/', $n) === 1;
    }
}
