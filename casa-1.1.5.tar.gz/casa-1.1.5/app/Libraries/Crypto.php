<?php

declare(strict_types=1);

namespace App\Libraries;

use RuntimeException;

/**
 * Crypto — enkripsi simetris AES-256-GCM untuk data yang HARUS dapat dibaca
 * kembali (password VPN, kredensial CHR, token agent, IPsec secret, dan nilai
 * `settings.is_secret`). Password akun TIDAK memakai ini (password_hash bcrypt).
 *
 * Tata letak blob: IV(12) || TAG(16) || CIPHERTEXT. GCM mengautentikasi:
 * ciphertext yang diubah membuat dekripsi gagal, bukan menghasilkan sampah.
 *
 * Kunci 32-byte dibaca dari berkas DI LUAR document root (path via .env
 * `encryption.keyPath`), agar dump basis data yang bocor tetap tak terbaca.
 */
final class Crypto
{
    private const CIPHER  = 'aes-256-gcm';
    private const IV_LEN  = 12;
    private const TAG_LEN = 16;

    private static ?string $key = null;

    private static function key(): string
    {
        if (self::$key !== null) {
            return self::$key;
        }

        $path = (string) (env('encryption.keyPath') ?: '');
        if ($path === '') {
            throw new RuntimeException('encryption.keyPath belum diatur di .env.');
        }

        // Path relatif SELALU diukur dari akar proyek, bukan direktori kerja.
        // CI4 menjalankan aplikasi dengan CWD = public/, sehingga 'writable/casa.key'
        // tanpa penyesuaian ini akan dicari di public/writable/ dan gagal.
        if (! preg_match('#^([A-Za-z]:[\\\\/]|/)#', $path)) {
            $path = rtrim(ROOTPATH, '/\\') . DIRECTORY_SEPARATOR . ltrim($path, '/\\');
        }

        if (! is_readable($path)) {
            throw new RuntimeException('Berkas kunci enkripsi tidak dapat dibaca: ' . $path);
        }

        $key = (string) file_get_contents($path);
        if (strlen($key) !== 32) {
            throw new RuntimeException('Kunci enkripsi harus tepat 32 byte.');
        }

        return self::$key = $key;
    }

    public static function encrypt(string $plain): string
    {
        $iv  = random_bytes(self::IV_LEN);
        $tag = '';
        $cipher = openssl_encrypt($plain, self::CIPHER, self::key(), OPENSSL_RAW_DATA, $iv, $tag, '', self::TAG_LEN);
        if ($cipher === false) {
            throw new RuntimeException('Enkripsi gagal.');
        }

        return $iv . $tag . $cipher;
    }

    public static function decrypt(string $blob): string
    {
        if (strlen($blob) < self::IV_LEN + self::TAG_LEN) {
            throw new RuntimeException('Ciphertext tidak sah.');
        }
        $iv     = substr($blob, 0, self::IV_LEN);
        $tag    = substr($blob, self::IV_LEN, self::TAG_LEN);
        $cipher = substr($blob, self::IV_LEN + self::TAG_LEN);

        $plain = openssl_decrypt($cipher, self::CIPHER, self::key(), OPENSSL_RAW_DATA, $iv, $tag);
        if ($plain === false) {
            throw new RuntimeException('Dekripsi gagal — data mungkin telah diubah.');
        }

        return $plain;
    }

    public static function encryptText(string $plain): string
    {
        return base64_encode(self::encrypt($plain));
    }

    public static function decryptText(string $encoded): string
    {
        $blob = base64_decode($encoded, true);
        if ($blob === false) {
            throw new RuntimeException('Data terenkripsi tidak sah.');
        }

        return self::decrypt($blob);
    }

    public static function generateKey(): string
    {
        return random_bytes(32);
    }
}
