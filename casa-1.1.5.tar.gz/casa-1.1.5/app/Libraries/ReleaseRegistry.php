<?php

declare(strict_types=1);

namespace App\Libraries;

/**
 * ReleaseRegistry — baca katalog rilis dari `writable/releases/` (console
 * owner). Sumber tunggal dipakai dua arah: `DownloadController` (manusia
 * mengunduh manual dari hub) DAN `InstanceSyncService` (instance produk cek
 * versi terbaru lewat sync lisensi yang sudah ada — lihat UpdateCheckService
 * di sisi instance). Nama berkas divalidasi ketat (anti path-traversal),
 * sama seperti `DownloadController::NAME_RE`.
 */
final class ReleaseRegistry
{
    private const NAME_RE = '/^casa-[A-Za-z0-9._-]+\.(tar\.gz|zip|exe)$/';

    public static function dir(): string
    {
        return rtrim(WRITEPATH, '/\\') . DIRECTORY_SEPARATOR . 'releases';
    }

    /** Rilis VPS (.tar.gz) berversi tertinggi, atau null bila tak ada. */
    public static function latestVps(): ?array
    {
        $best = null;
        foreach (glob(self::dir() . DIRECTORY_SEPARATOR . 'casa-*.tar.gz') ?: [] as $path) {
            $name = basename($path);
            if (! is_file($path) || ! preg_match(self::NAME_RE, $name) || ! preg_match('/(\d+\.\d+\.\d+)/', $name, $m)) {
                continue;
            }
            $ver = $m[1];
            if ($best === null || version_compare($ver, $best['version'], '>')) {
                $best = [
                    'version' => $ver,
                    'file'    => $name,
                    'size'    => (int) (filesize($path) ?: 0),
                    'sha256'  => (string) (hash_file('sha256', $path) ?: ''),
                ];
            }
        }

        return $best;
    }

    /** Path absolut berkas rilis — null bila nama tak sah atau berkas tak ada (anti path-traversal). */
    public static function path(string $file): ?string
    {
        if (! preg_match(self::NAME_RE, $file)) {
            return null;
        }
        $path = self::dir() . DIRECTORY_SEPARATOR . $file;

        return is_file($path) ? $path : null;
    }
}
