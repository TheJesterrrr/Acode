<?php

declare(strict_types=1);

namespace App\Libraries;

use finfo;
use RuntimeException;

/**
 * Upload — penerimaan berkas unggahan yang aman (port core/Upload lama).
 *
 * Empat aturan yang harus dipenuhi bersama:
 *  1. Jenis ditentukan dari ISI (finfo), bukan nama/ekstensi kiriman.
 *  2. Nama berkas DIBUAT ULANG acak — mematikan path traversal & nama ganda.
 *  3. Disimpan di writable/uploads (di luar document root); disajikan lewat
 *     controller yang memeriksa kepemilikan.
 *  4. Ukuran dibatasi di tingkat aplikasi (pesan galat berguna).
 */
final class Upload
{
    private const IMAGE_TYPES = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp',
    ];

    /**
     * Terima gambar dan simpan. Kembalikan path RELATIF terhadap uploads,
     * mis. 'proofs/2026/07/ab12….jpg'.
     *
     * @throws UploadException
     */
    public static function image(string $field, string $subdir, int $maxBytes = 2_097_152): string
    {
        $file = service('request')->getFile($field);

        if ($file === null || ! $file->isValid()) {
            throw new UploadException('Berkas tidak sah atau gagal diunggah.');
        }
        if ($file->getSize() <= 0) {
            throw new UploadException('Berkas kosong.');
        }
        if ($file->getSize() > $maxBytes) {
            throw new UploadException('Ukuran berkas melebihi ' . self::humanSize($maxBytes) . '.');
        }
        if (! $file->hasMoved() && ! is_uploaded_file($file->getTempName())) {
            throw new UploadException('Berkas tidak sah.');
        }

        // Jenis dari ISI berkas, bukan dari kiriman.
        $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file->getTempName()) ?: '';
        if (! isset(self::IMAGE_TYPES[$mime])) {
            throw new UploadException('Jenis berkas tidak didukung. Gunakan JPG, PNG, atau WEBP.');
        }
        $ext = self::IMAGE_TYPES[$mime];

        $rel = trim($subdir, '/') . '/' . date('Y/m');
        $dir = Cer::uploads($rel);
        if (! is_dir($dir) && ! @mkdir($dir, 0770, true) && ! is_dir($dir)) {
            throw new UploadException('Tidak dapat menyiapkan folder unggahan.');
        }

        $name = bin2hex(random_bytes(16)) . '.' . $ext;
        $file->move($dir, $name);

        return $rel . '/' . $name;
    }

    public static function present(string $field): bool
    {
        $file = service('request')->getFile($field);

        return $file !== null && $file->getError() !== UPLOAD_ERR_NO_FILE;
    }

    /** Path absolut sebuah berkas uploads. Divalidasi terhadap traversal. */
    public static function path(string $relative): string
    {
        if ($relative === '' || str_contains($relative, '..') || str_starts_with($relative, '/')) {
            throw new RuntimeException('Jalur berkas tidak sah: ' . $relative);
        }

        return Cer::uploads($relative);
    }

    public static function delete(string $relative): void
    {
        $path = self::path($relative);
        if (is_file($path)) {
            @unlink($path);
        }
    }

    public static function mimeOf(string $relative): string
    {
        $mime = (new finfo(FILEINFO_MIME_TYPE))->file(self::path($relative));

        return is_string($mime) ? $mime : 'application/octet-stream';
    }

    private static function humanSize(int $bytes): string
    {
        return $bytes >= 1_048_576
            ? round($bytes / 1_048_576, 1) . ' MB'
            : round($bytes / 1024) . ' KB';
    }
}
