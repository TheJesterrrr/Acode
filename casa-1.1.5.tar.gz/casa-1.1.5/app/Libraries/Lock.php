<?php

declare(strict_types=1);

namespace App\Libraries;

/**
 * Lock — kunci berbasis berkas via flock() (port core/Lock).
 *
 * Menjaga satu pekerjaan (cron) tidak berjalan dua kali bersamaan. flock()
 * dilepas OS saat proses berakhir bagaimana pun caranya — kunci macet mustахil,
 * tidak seperti kolom `is_running` di DB. Atomik di tingkat kernel (tidak ada
 * jeda "cek lalu buat" yang bisa disusupi). TIDAK menunggu: yang kalah mundur.
 */
final class Lock
{
    /** @var array<string,resource> */
    private static array $handles = [];

    public static function acquire(string $name): bool
    {
        if (isset(self::$handles[$name])) {
            return true;
        }

        $path   = self::path($name);
        $handle = @fopen($path, 'c'); // 'c': buat bila belum ada, jangan kosongkan
        if ($handle === false) {
            log_message('error', 'Tidak dapat membuka berkas kunci: ' . $path);

            return false;
        }
        if (! flock($handle, LOCK_EX | LOCK_NB)) {
            fclose($handle);

            return false;
        }

        ftruncate($handle, 0);
        fwrite($handle, sprintf("pid=%d\nsince=%s\n", getmypid(), date('c')));
        fflush($handle);
        self::$handles[$name] = $handle;

        return true;
    }

    public static function release(string $name): void
    {
        if (! isset(self::$handles[$name])) {
            return;
        }
        $handle = self::$handles[$name];
        flock($handle, LOCK_UN);
        fclose($handle);
        unset(self::$handles[$name]);
        // Berkas sengaja tidak dihapus (mencegah dua proses memegang nama sama).
    }

    /** Jalankan $fn di bawah kunci; null bila kunci tidak didapat. */
    public static function run(string $name, callable $fn): mixed
    {
        if (! self::acquire($name)) {
            return null;
        }
        try {
            return $fn();
        } finally {
            self::release($name);
        }
    }

    private static function path(string $name): string
    {
        $dir = Cer::writable('locks');
        if (! is_dir($dir)) {
            @mkdir($dir, 0770, true);
        }
        $safe = preg_replace('/[^a-z0-9_-]/i', '', $name) ?: 'lock';

        return $dir . DIRECTORY_SEPARATOR . $safe . '.lock';
    }
}
