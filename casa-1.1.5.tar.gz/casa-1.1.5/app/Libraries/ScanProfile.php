<?php

declare(strict_types=1);

namespace App\Libraries;

/**
 * ScanProfile — kedalaman (depth) pemindaian yang dihormati Adapter aktif.
 *
 * Depth dipilih per-Assessment: Light / Standard / Deep. Makin dalam = makin
 * banyak port & template diperiksa = makin lama. Worker menetapkan depth per
 * task lewat setDepth() sebelum menjalankan Adapter; Adapter membaca rate/
 * concurrency/timeout + port-range + severity Nuclei dari sini.
 *
 * Kompatibel mundur: bila depth runtime tak diset, dibaca dari .env
 * `scan.intensity` (gentle|normal|aggressive) → light|standard|deep.
 */
final class ScanProfile
{
    /** @var array<string,array{rate:int,conc:int,timeout:int,nmap:string,naabu:string,nuclei:string}> */
    private const DEPTH = [
        'light'    => ['rate' => 20,  'conc' => 5,  'timeout' => 8, 'nmap' => '--top-ports 100',  'naabu' => '-top-ports 100',  'nuclei' => 'high,critical'],
        'standard' => ['rate' => 60,  'conc' => 15, 'timeout' => 8, 'nmap' => '--top-ports 1000', 'naabu' => '-top-ports 1000', 'nuclei' => 'medium,high,critical'],
        'deep'     => ['rate' => 150, 'conc' => 40, 'timeout' => 6, 'nmap' => '-p-',              'naabu' => '-p -',            'nuclei' => 'low,medium,high,critical'],
    ];

    private static ?string $runtime = null;

    /** @var list<string> Header kustom "Name: Value" untuk task yang sedang berjalan. */
    private static array $headers = [];

    /** Setel depth untuk task yang sedang dijalankan (dipanggil worker). */
    public static function setDepth(?string $depth): void
    {
        self::$runtime = in_array($depth, ['light', 'standard', 'deep'], true) ? $depth : null;
    }

    /**
     * Setel header kustom untuk task yang sedang berjalan (dipanggil worker tiap
     * task, seperti setDepth). Dipakai mis. kepatuhan bug bounty:
     * `X-Request-Purpose: Research`, `X-Bugcrowd-Ninja: <user>`. Menerima string
     * multi-baris ("Name: Value" per baris) atau array. WAJIB dipanggil tiap task
     * (termasuk kosong) agar header task sebelumnya tak bocor ke task berikutnya.
     *
     * @param null|string|list<string> $h
     */
    public static function setHeaders(null|string|array $h): void
    {
        $lines    = is_array($h) ? $h : (preg_split('/\r\n|\r|\n/', (string) $h) ?: []);
        $clean    = [];
        foreach ($lines as $line) {
            // Buang CR/LF & kontrol (anti header/CRLF-injection), rapikan.
            $line = trim(preg_replace('/[\x00-\x1F\x7F]/', '', (string) $line) ?? '');
            if ($line === '' || ! str_contains($line, ':')) {
                continue;
            }
            [$name] = explode(':', $line, 2);
            if (trim($name) === '') {
                continue;
            }
            $clean[] = $line;
        }
        self::$headers = $clean;
    }

    /** @return list<string> Header aktif ("Name: Value"). */
    public static function headers(): array
    {
        return self::$headers;
    }

    /** True bila ada header kustom aktif. */
    public static function hasHeaders(): bool
    {
        return self::$headers !== [];
    }

    /**
     * Rakit argumen flag berulang utk tool yg pakai "-H 'Name: Value'" (httpx,
     * nuclei, katana, ffuf, feroxbuster, dalfox, …). Kembalikan string berawalan
     * spasi (siap disambung ke $cmd), atau '' bila tak ada header.
     */
    public static function headerArgs(string $flag = '-H'): string
    {
        $s = '';
        foreach (self::$headers as $h) {
            $s .= ' ' . $flag . ' ' . escapeshellarg($h);
        }

        return $s;
    }

    /** Header digabung satu string (mis. arjun --headers, hakrawler -h) → escaped arg, atau ''. */
    public static function headerJoinedArg(string $flag, string $sep = "\n"): string
    {
        if (self::$headers === []) {
            return '';
        }

        return ' ' . $flag . ' ' . escapeshellarg(implode($sep, self::$headers));
    }

    /** Depth aktif. Default 'standard'. */
    public static function depth(): string
    {
        if (self::$runtime !== null) {
            return self::$runtime;
        }
        $map = ['gentle' => 'light', 'normal' => 'standard', 'aggressive' => 'deep'];
        $i   = strtolower((string) (env('scan.intensity') ?: ''));

        return $map[$i] ?? 'standard';
    }

    /** @return array{rate:int,conc:int,timeout:int,nmap:string,naabu:string,nuclei:string} */
    private static function cur(): array
    {
        return self::DEPTH[self::depth()] ?? self::DEPTH['standard'];
    }

    public static function rate(): int         { return self::cur()['rate']; }
    public static function concurrency(): int  { return self::cur()['conc']; }
    public static function timeout(): int      { return self::cur()['timeout']; }

    /** Argumen port untuk nmap (mis. '--top-ports 1000' / '-p-'). */
    public static function nmapPorts(): string    { return self::cur()['nmap']; }

    /** Argumen port untuk naabu (mis. '-top-ports 1000' / '-p -'). */
    public static function naabuPorts(): string   { return self::cur()['naabu']; }

    /** Daftar severity Nuclei sesuai depth (mis. 'medium,high,critical'). */
    public static function nucleiSeverity(): string { return self::cur()['nuclei']; }

    public static function label(): string { return self::depth(); }
}
