<?php

declare(strict_types=1);

namespace App\Libraries;

use Config\Database;
use Throwable;

/**
 * CasaLog — log diagnostik berkode (CASA-Exxx), dibatasi 100 baris terakhir.
 *
 * Tujuan: saat ada masalah (scan macet, worker berhenti, tool hilang, dsb),
 * pengguna cukup lihat KODE-nya di Engine Health / halaman Mission, lalu buka
 * artikel Panduan yang sesuai — tak perlu menebak-nebak dari pesan error
 * mentah. Log ini SENGAJA kecil & auto-prune (bukan log penuh seperti `task`)
 * supaya tak pernah jadi sumber disk penuh (lihat panduan Disk Penuh dari
 * File Sementara Scan — kelas masalah yang sama, solusinya di sini dicegah
 * dari awal, bukan cuma didokumentasikan).
 */
final class CasaLog
{
    private const MAX_ROWS = 100;

    /** Katalog kode → [label ringkas, slug artikel Panduan]. Satu sumber kebenaran. */
    public const CODES = [
        'CASA-E001' => ['Task scan crash/timeout — disapu otomatis', 'mission-nyangkut'],
        'CASA-E002' => ['Worker terhambat lama — kemungkinan proses macet menyandera lock', 'mission-diam-proses-macet'],
        'CASA-E003' => ['Worker tak pernah berjalan — cron belum terpasang', 'worker-tidak-jalan'],
        'CASA-E004' => ['Gagal membuat PDF laporan', 'pdf-gagal'],
        'CASA-E005' => ['Tool belum terpasang/hilang — task dilewati', 'tool-hilang-setelah-update-os'],
        'CASA-E006' => ['Ruang disk server menipis', 'disk-penuh-file-sementara'],
        'CASA-E007' => ['Web server mendekati batas proses (berisiko 502/503)', 'web-overload-502-503'],
        'CASA-E008' => ['Sinkronisasi lisensi gagal', 'lisensi-sync-gagal-diam'],
        'CASA-E009' => ['Base URL kemungkinan tak sesuai lagi', 'base-url-rusak-ip-berubah'],
        'CASA-E010' => ['Database mendekati batas koneksi', 'database-koneksi-penuh'],
        'CASA-E011' => ['Potensi akses SSH bermasalah', 'ssh-terkunci-sendiri'],
        'CASA-E012' => ['Sertifikat TLS mendekati/sudah kedaluwarsa', 'sertifikat-tls-kadaluwarsa'],
        'CASA-E013' => ['Bounty Scan dibatasi sesuai aturan program (info)', 'bounty-scan-lambat-terbatas'],
        'CASA-E014' => ['Import XML Burp gagal', 'import-burp-xml-gagal'],
        'CASA-E015' => ['Hasil fuzzing seragam dirangkum (bukan error, sekadar info)', null],
        'CASA-E016' => ['Tool dilewati gate — tak relevan dengan target (info)', null],
        'CASA-E000' => ['Audit infrastruktur berjalan — semua normal (info)', 'cek-tool-cli'],
    ];

    /** Catat satu event. $level: error|warning|info. Aman dipanggil di mana saja — gagal diam-diam, tak pernah mengganggu alur utama. */
    public static function log(string $code, string $message, ?int $missionId = null, ?int $taskId = null, string $level = 'error'): void
    {
        try {
            $db = Database::connect();
            $db->table('event_log')->insert([
                'code'       => $code,
                'level'      => $level,
                'message'    => mb_substr($message, 0, 255),
                'mission_id' => $missionId,
                'task_id'    => $taskId,
            ]);
            // Prune: simpan cuma MAX_ROWS baris terakhir, hapus sisanya.
            $count = (int) ($db->table('event_log')->countAllResults(false) ?: 0);
            if ($count > self::MAX_ROWS) {
                $cutoff = $db->query('SELECT id FROM event_log ORDER BY id DESC LIMIT 1 OFFSET ' . (self::MAX_ROWS - 1))->getRowArray();
                if ($cutoff !== null) {
                    $db->table('event_log')->where('id <', (int) $cutoff['id'])->delete();
                }
            }
        } catch (Throwable $e) {
            // Logging tak boleh pernah menjatuhkan alur utama (scan/report/dll).
        }
    }

    /** Label ringkas utk sebuah kode, atau kode itu sendiri bila tak dikenal. */
    public static function label(string $code): string
    {
        return self::CODES[$code][0] ?? $code;
    }

    /** Slug artikel Panduan yang relevan utk sebuah kode, atau null. */
    public static function guideSlug(string $code): ?string
    {
        return self::CODES[$code][1] ?? null;
    }

    /** @return array<int,array<string,mixed>> 100 event terakhir, terbaru dulu. */
    public static function recent(int $limit = 100): array
    {
        try {
            return Database::connect()->table('event_log')->orderBy('id', 'DESC')->limit($limit)->get()->getResultArray();
        } catch (Throwable $e) {
            return [];
        }
    }
}
