<?php

declare(strict_types=1);

namespace App\Libraries;

use RuntimeException;

/** UploadException — berkas unggahan ditolak; pesan aman ditampilkan ke pengguna. */
final class UploadException extends RuntimeException
{
}
