<?php

declare(strict_types=1);

namespace App\Libraries;

/**
 * ToolLabel — menyembunyikan identitas tool pihak ketiga di luar OWNER console.
 *
 * Keputusan pemilik (2026-08-08): nama/daftar tool yang dipakai CASA adalah
 * rahasia dagang. Hanya OWNER console (pemegang license.privateKey) yang boleh
 * melihat nama tool asli. Di instance PRODUK (pelanggan) semua nama tool diganti
 * label KAPABILITAS generik, sehingga tool = implementation detail.
 *
 * Dipakai di seluruh view/laporan yang menampilkan kode tool (mission task,
 * finding, policy, report). Sumber kebenaran tetap di kode adapter; ini murni
 * lapisan penyajian.
 */
final class ToolLabel
{
    /** Peta kode tool → label kapabilitas (dipakai HANYA di mode produk). */
    private const CAP = [
        'httpx'      => 'HTTP Probing',
        'nuclei'     => 'Vulnerability Assessment',
        'subfinder'  => 'Subdomain Discovery',
        'amass'      => 'Subdomain Discovery',
        'naabu'      => 'Port Scanning',
        'testssl'    => 'TLS/SSL Assessment',
        'katana'     => 'Web Crawling',
        'gau'        => 'URL Discovery',
        'ffuf'       => 'Content Discovery',
        'dalfox'     => 'XSS Assessment',
        'sqlmap'     => 'SQL Injection Assessment',
        'idor'       => 'Access Control Testing',
        'dnsx'       => 'DNS Resolution',
        'gowitness'  => 'Screenshotting',
        'whatweb'    => 'Fingerprinting',
        'wafw00f'    => 'WAF Detection',
        'nikto'      => 'Web Server Assessment',
        'arjun'      => 'Parameter Discovery',
        'trufflehog' => 'Secret Scanning',
        'gitleaks'   => 'Secret Scanning',
        'trivy'      => 'Dependency & Container Scanning',
        'waybackurls' => 'URL Discovery',
        'hakrawler'  => 'Web Crawling',
        'feroxbuster' => 'Content Discovery',
        'nmap'       => 'Service Detection',
        'wpscan'     => 'CMS Assessment',
    ];

    private const FALLBACK = 'Assessment Capability';

    /** Apakah instance ini OWNER console (boleh lihat nama tool asli). */
    public static function isOwner(): bool
    {
        return (string) (env('license.privateKey') ?: '') !== '';
    }

    /**
     * Label yang aman ditampilkan untuk sebuah kode tool.
     * Owner → kode asli; Produk → label kapabilitas generik. Kode kosong → ''.
     */
    public static function show(?string $code): string
    {
        $code = strtolower(trim((string) $code));
        if ($code === '') {
            return '';
        }
        if (self::isOwner()) {
            return $code;
        }

        return self::CAP[$code] ?? self::FALLBACK;
    }

    /**
     * Label KAPABILITAS sebuah kode tool — SELALU label fungsional, tak peduli
     * owner/produk. Dipakai untuk LOGIKA (scoping template, dedupe workflow),
     * bukan tampilan. Untuk tampilan pakai show().
     */
    public static function capability(?string $code): string
    {
        $code = strtolower(trim((string) $code));

        return $code !== '' ? (self::CAP[$code] ?? self::FALLBACK) : '';
    }

    /**
     * Daftar label unik untuk sekumpulan kode (mis. Allowed policy).
     * Di mode produk, beberapa tool bisa memetakan ke kapabilitas yang sama →
     * di-dedup agar tidak berulang. @param array<int,string> $codes
     * @return array<int,string>
     */
    public static function showListDedup(array $codes): array
    {
        $out = [];
        foreach ($codes as $code) {
            $lab = self::show(is_string($code) ? $code : (string) $code);
            if ($lab !== '' && ! in_array($lab, $out, true)) {
                $out[] = $lab;
            }
        }

        return $out;
    }
}
