<?php

declare(strict_types=1);

namespace App\Commands;

use App\Modules\Cron\Services\CronRunner;
use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;

/**
 * CasaCron — titik masuk penjadwal (Spark Command, CES 13.9).
 *
 * Satu baris crontab cPanel:
 *   * * * * * cd /home/user/app && php spark casa:cron >> /dev/null 2>&1
 *
 * Tanpa argumen → jalankan job yang jatuh tempo. Dengan nama → paksa satu job.
 */
final class CasaCron extends BaseCommand
{
    protected $group       = 'CoreNet';
    protected $name        = 'casa:cron';
    protected $description  = 'Jalankan job terjadwal CASA yang jatuh tempo (atau satu job bila disebut).';
    protected $usage       = 'casa:cron [job]';
    protected $arguments   = ['job' => 'Opsional: nama job tertentu. Kosongkan untuk menjalankan semua job yang jatuh tempo.'];

    public function run(array $params): int
    {
        // Permintaan pembaruan feed on-demand dari portal (web tak boleh shell →
        // ditunda ke sini, konteks CLI yang bebas SELinux).
        $s = new \App\Modules\Setting\Services\SettingService();
        if ((string) $s->get('feed.sync_requested', '') !== '') {
            $s->set('feed.sync_requested', '');
            $r = (new \App\Modules\Feed\Services\FeedSyncService())->sync();
            CLI::write('feed on-demand: ' . ($r['message'] ?? ($r['error'] ?? '?')), ! empty($r['ok']) ? 'green' : 'yellow');
        }

        $runner = new CronRunner();
        $job    = $params[0] ?? null;

        if ($job !== null) {
            CLI::write($runner->runOne($job), 'yellow');

            return EXIT_SUCCESS;
        }

        $lines = $runner->runDue(static fn (string $line) => CLI::write($line, 'green'));
        if ($lines === []) {
            CLI::write('Tidak ada job yang jatuh tempo.', 'dark_gray');
        }

        return EXIT_SUCCESS;
    }
}
