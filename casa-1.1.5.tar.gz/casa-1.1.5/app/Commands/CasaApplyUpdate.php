<?php

declare(strict_types=1);

namespace App\Commands;

use App\Libraries\Lock;
use App\Modules\Setting\Services\SettingService;
use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;

/**
 * CasaApplyUpdate — terapkan paket rilis yang sudah diunduh lewat menu
 * "Update Aplikasi" (Lisensi & Aktivasi). SENGAJA semi-otomatis (keputusan
 * pemilik): unduh dilakukan dari web (LicenseSyncService::downloadUpdate),
 * tapi MENIMPA kode yang sedang berjalan wajib dipicu manusia lewat CLI —
 * bukan satu klik web — supaya ada jeda sebelum proses PHP yang jalan
 * ditimpa sendiri filenya.
 *
 * Urutan (tiap langkah menghentikan proses bila gagal, TIDAK lanjut diam-diam):
 *   1. Verifikasi checksum paket (sidecar .sha256 dari proses unduh).
 *   2. WAJIB backup dulu: tar app/ + dump database → writable/backups/.
 *   3. Ekstrak paket (menimpa app/ & public/ bila ada di paket).
 *   4. `php spark migrate --all` di PROSES BARU (bukan in-process — class PHP
 *      yang sudah ter-load di proses ini bisa jadi versi lama walau filenya
 *      sudah ditimpa; proses baru menjamin baca kode yang benar-benar baru).
 *   5. Sinkronkan label versi tampilan ke Config\Edition::$version yang baru.
 *
 * Pemakaian: cd /var/www/casa && php spark casa:apply-update casa-1.2.0.tar.gz
 */
final class CasaApplyUpdate extends BaseCommand
{
    protected $group       = 'CoreNet';
    protected $name        = 'casa:apply-update';
    protected $description  = 'Terapkan paket update yang sudah diunduh (writable/releases/pending/) — backup dulu, lalu ekstrak + migrate.';
    protected $usage       = 'casa:apply-update <file>';
    protected $arguments   = ['file' => 'Nama berkas di writable/releases/pending/, mis. casa-1.2.0.tar.gz'];

    public function run(array $params): int
    {
        $file = (string) ($params[0] ?? '');
        if ($file === '' || ! preg_match('/^casa-[A-Za-z0-9._-]+\.tar\.gz$/', $file)) {
            CLI::error('Sebutkan nama berkas yang valid, mis. casa-1.2.0.tar.gz');

            return EXIT_ERROR;
        }

        $pendingDir = rtrim(WRITEPATH, '/\\') . DIRECTORY_SEPARATOR . 'releases' . DIRECTORY_SEPARATOR . 'pending';
        $pkg        = $pendingDir . DIRECTORY_SEPARATOR . $file;
        $sidecar    = $pkg . '.sha256';
        if (! is_file($pkg)) {
            CLI::error("Berkas tak ditemukan: {$pkg}");
            CLI::write('Unduh dulu lewat menu "Update Aplikasi" di Lisensi & Aktivasi.', 'yellow');

            return EXIT_ERROR;
        }

        // --- 1. Checksum ------------------------------------------------------
        $expected = is_file($sidecar) ? trim((string) file_get_contents($sidecar)) : '';
        $actual   = (string) (hash_file('sha256', $pkg) ?: '');
        if ($expected === '' || ! hash_equals($expected, $actual)) {
            CLI::error('Checksum tak cocok/tak ada sidecar .sha256 — berkas mungkin rusak. Unduh ulang lewat web.');

            return EXIT_ERROR;
        }
        CLI::write('Checksum OK.', 'green');

        $root = dirname(rtrim(APPPATH, '/\\')); // folder induk app/ — akar instalasi.
        preg_match('/(\d+\.\d+\.\d+)/', $file, $m);
        $targetVersion = $m[1] ?? '?';
        $curVersion    = config(\App\Modules\Licensing\Config\Edition::class)->version;

        $result = Lock::run('casa-apply-update', function () use ($pkg, $root, $curVersion, $targetVersion): int {
            return $this->apply($pkg, $root, $curVersion, $targetVersion);
        });

        if ($result === null) {
            CLI::error('Proses apply-update lain sedang berjalan. Coba lagi beberapa saat.');

            return EXIT_ERROR;
        }

        return $result;
    }

    private function apply(string $pkg, string $root, string $curVersion, string $targetVersion): int
    {
        CLI::write("Menerapkan update {$curVersion} -> {$targetVersion} ...", 'cyan');

        // --- 2. Backup WAJIB ---------------------------------------------------
        $backupDir = rtrim(WRITEPATH, '/\\') . DIRECTORY_SEPARATOR . 'backups';
        if (! is_dir($backupDir) && ! @mkdir($backupDir, 0770, true)) {
            CLI::error("Tak dapat membuat folder backup: {$backupDir}");

            return EXIT_ERROR;
        }
        $stamp      = date('Ymd-His');
        $appBackup  = $backupDir . DIRECTORY_SEPARATOR . "pre-update-{$curVersion}-{$stamp}-app.tar.gz";
        $dbBackup   = $backupDir . DIRECTORY_SEPARATOR . "pre-update-{$curVersion}-{$stamp}-db.sql.gz";

        if (! function_exists('exec')) {
            CLI::error('Fungsi exec() tak tersedia di PHP CLI ini — backup otomatis tak bisa jalan, update DIBATALKAN (backup wajib).');

            return EXIT_ERROR;
        }

        CLI::write('Backup app/ ...', 'yellow');
        exec('tar -czf ' . escapeshellarg($appBackup) . ' -C ' . escapeshellarg($root) . ' app public 2>&1', $out1, $code1);
        if ($code1 !== 0 || ! is_file($appBackup)) {
            CLI::error('Backup app/ GAGAL — update dibatalkan. Output: ' . implode("\n", $out1));

            return EXIT_ERROR;
        }
        CLI::write("Backup app/ OK -> {$appBackup}", 'green');

        CLI::write('Backup database ...', 'yellow');
        $host = (string) (env('database.default.hostname') ?: 'localhost');
        $db   = (string) (env('database.default.database') ?: '');
        $user = (string) (env('database.default.username') ?: '');
        $pass = (string) (env('database.default.password') ?: '');
        $port = (string) (env('database.default.port') ?: '3306');
        if ($db === '' || $user === '') {
            CLI::error('Kredensial database tak lengkap di .env — update dibatalkan (backup DB wajib).');

            return EXIT_ERROR;
        }
        $dumpCmd = sprintf(
            'mysqldump --host=%s --port=%s --user=%s --password=%s %s 2>/tmp/casa-update-dbdump.err | gzip > %s',
            escapeshellarg($host),
            escapeshellarg($port),
            escapeshellarg($user),
            escapeshellarg($pass),
            escapeshellarg($db),
            escapeshellarg($dbBackup)
        );
        exec($dumpCmd, $out2, $code2);
        if ($code2 !== 0 || ! is_file($dbBackup) || (int) (filesize($dbBackup) ?: 0) < 50) {
            $err = is_file('/tmp/casa-update-dbdump.err') ? (string) file_get_contents('/tmp/casa-update-dbdump.err') : '';
            CLI::error('Backup database GAGAL — update dibatalkan. ' . $err);

            return EXIT_ERROR;
        }
        CLI::write("Backup database OK -> {$dbBackup}", 'green');

        // --- 3. Ekstrak paket ---------------------------------------------------
        // --strip-components=1 WAJIB: paket rilis dibungkus satu folder atas
        // (`casa-X.Y.Z/app/...`, lihat build/package.sh — bungkus ini dibutuhkan
        // install.sh fresh-install). Tanpa strip, ekstrak ke $root akan membuat
        // `$root/casa-X.Y.Z/...` dan TAK PERNAH menimpa `$root/app` yang berjalan —
        // update seolah "sukses" (tar & migrate exit 0) tapi kode lama tetap. Dengan
        // strip-1, isi dalam bungkus (app/, public/, vendor/, ...) mendarat tepat di $root.
        CLI::write('Mengekstrak paket update (menimpa app/ & public/) ...', 'yellow');
        exec('tar -xzf ' . escapeshellarg($pkg) . ' --strip-components=1 -C ' . escapeshellarg($root) . ' 2>&1', $out3, $code3);
        if ($code3 !== 0) {
            CLI::error('Ekstrak GAGAL: ' . implode("\n", $out3));
            CLI::write("Instance mungkin dalam kondisi campuran — pulihkan dari {$appBackup} bila perlu.", 'red');

            return EXIT_ERROR;
        }
        CLI::write('Ekstrak OK.', 'green');

        // --- 4. Migrate di PROSES BARU -------------------------------------------
        CLI::write('Menjalankan migrasi (proses baru) ...', 'yellow');
        exec('cd ' . escapeshellarg($root) . ' && php spark migrate --all 2>&1', $out4, $code4);
        CLI::write(implode("\n", $out4));
        if ($code4 !== 0) {
            CLI::error("Migrasi GAGAL (exit {$code4}). File sudah tertimpa — database BELUM tentu konsisten.");
            CLI::write("Pulihkan dari backup bila perlu: {$appBackup} + {$dbBackup}", 'red');

            return EXIT_ERROR;
        }
        CLI::write('Migrasi OK.', 'green');

        // --- 5. Sinkronkan label versi tampilan ----------------------------------
        try {
            $editionFile = $root . '/app/Modules/Licensing/Config/Edition.php';
            $src         = is_file($editionFile) ? (string) file_get_contents($editionFile) : '';
            if (preg_match("/public string \\\$version = '([^']+)'/", $src, $vm)) {
                (new SettingService())->set('app.version', $vm[1]);
                CLI::write("Label versi tampilan disetel ke {$vm[1]}.", 'green');
            }
        } catch (\Throwable $e) {
            CLI::write('Tak dapat menyetel label versi tampilan (non-fatal): ' . $e->getMessage(), 'yellow');
        }

        // Bersihkan paket pending — backup lama sudah aman di writable/backups/.
        @unlink($pkg);
        @unlink($pkg . '.sha256');

        CLI::write("Selesai — {$curVersion} -> {$targetVersion}. Disarankan: sudo systemctl restart php-fpm (bersihkan opcache).", 'cyan');

        return EXIT_SUCCESS;
    }
}
