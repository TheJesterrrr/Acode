<?php

declare(strict_types=1);

namespace App\Commands;

use App\Modules\ToolManager\Services\ToolManagerService;
use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;

/**
 * CasaToolsDetect — self-heal katalog tool: tandai 'installed' setiap tool yang
 * binernya SUDAH ADA di tools.dir namun status DB-nya belum 'installed'. Berguna
 * setelah install native/manual atau install sebagian, agar scanner tak kosong.
 *
 *   cd /var/www/casa && php spark casa:tools-detect
 */
final class CasaToolsDetect extends BaseCommand
{
    protected $group       = 'CoreNet';
    protected $name        = 'casa:tools-detect';
    protected $description = 'Deteksi biner tool yang sudah ada → tandai terpasang (self-heal).';

    public function run(array $params): int
    {
        $n = (new ToolManagerService())->detectInstalled();
        CLI::write($n > 0 ? "Tool ditandai terpasang: {$n}" : 'Tak ada tool baru untuk ditandai (semua sudah sesuai).', $n > 0 ? 'green' : 'yellow');

        return EXIT_SUCCESS;
    }
}
