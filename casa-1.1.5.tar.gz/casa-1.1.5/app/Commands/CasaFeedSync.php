<?php

declare(strict_types=1);

namespace App\Commands;

use App\Modules\Feed\Services\FeedSyncService;
use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;

/**
 * CasaFeedSync — perbarui konten deteksi (nuclei-templates/aturan) dari Detection
 * Feed owner. Dijadwalkan di instance pelanggan (VPS):
 *   0 4 * * * cd /var/www/casa && php spark casa:feed-sync >/dev/null 2>&1
 */
final class CasaFeedSync extends BaseCommand
{
    protected $group       = 'CoreNet';
    protected $name        = 'casa:feed-sync';
    protected $description  = 'Sinkron Detection Feed owner → perbarui template/aturan deteksi.';

    public function run(array $params): int
    {
        $r = (new FeedSyncService())->sync();
        CLI::write(($r['ok'] ?? false) ? ('Feed: ' . ($r['message'] ?? 'ok')) : ('Feed dilewati/gagal: ' . ($r['error'] ?? '?')), ($r['ok'] ?? false) ? 'green' : 'yellow');

        return EXIT_SUCCESS;
    }
}
