<?php

declare(strict_types=1);

namespace App\Commands;

use App\Modules\Adapter\Services\AdapterFactory;
use App\Modules\ToolManager\Models\ToolInstallModel;
use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;

/**
 * CasaAdapterTest — diagnostik dev: jalankan satu Adapter terhadap target dan
 * tampilkan ringkasan findings/assets. Bukan bagian alur produksi (lewati Policy);
 * hanya untuk verifikasi Adapter. Contoh: `php spark casa:adapter-test dnsx example.com`.
 */
final class CasaAdapterTest extends BaseCommand
{
    protected $group       = 'CoreNet';
    protected $name        = 'casa:adapter-test';
    protected $description  = 'Uji satu Adapter terhadap target (diagnostik dev).';
    protected $usage       = 'casa:adapter-test <code> <target>';

    public function run(array $params): int
    {
        $code   = (string) ($params[0] ?? '');
        $target = (string) ($params[1] ?? '');
        if ($code === '' || $target === '') {
            CLI::error('Pakai: casa:adapter-test <code> <target>');

            return EXIT_ERROR;
        }
        $adapter = AdapterFactory::forCode($code);
        if ($adapter === null) {
            CLI::error("Tak ada Adapter untuk '{$code}'.");

            return EXIT_ERROR;
        }

        $bin = '';
        if (! AdapterFactory::isBuiltin($code)) {
            $inst = (new ToolInstallModel())->where('tool_code', $code)->first();
            $bin  = (string) ($inst['bin_path'] ?? ('/opt/casa-tools/' . $code));
        }

        CLI::write("Menjalankan {$code} → {$target} (bin: {$bin}) …", 'yellow');
        $t0  = microtime(true);
        $res = $adapter->run($bin, $target);
        $dt  = round(microtime(true) - $t0, 1);

        $f = $res['findings'] ?? [];
        $a = $res['assets'] ?? [];
        CLI::write("Selesai {$dt}s — findings=" . count($f) . " assets=" . count($a), 'green');
        foreach (array_slice($f, 0, 5) as $i => $x) {
            CLI::write('  F' . ($i + 1) . " [{$x['severity']}] {$x['title']} — " . ($x['asset'] ?? ''));
        }
        foreach (array_slice($a, 0, 5) as $i => $x) {
            CLI::write('  A' . ($i + 1) . " {$x['type']}: {$x['value']}");
        }
        if ($f === [] && $a === []) {
            CLI::write('  (tak ada hasil — cek raw: ' . mb_substr((string) ($res['raw'] ?? ''), 0, 120) . ')', 'light_gray');
        }

        return EXIT_SUCCESS;
    }
}
