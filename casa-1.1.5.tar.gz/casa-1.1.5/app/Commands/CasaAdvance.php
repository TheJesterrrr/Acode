<?php

declare(strict_types=1);

namespace App\Commands;

use App\Modules\Mission\Services\MissionService;
use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;

/**
 * CasaAdvance — majukan status mission (executing→validating→report, dst)
 * TANPA menunggu/menahan kunci `casa-work` (CasaWork::run). advanceAll() hanya
 * baca progres task + transisi state; tak pernah menjalankan tool pemindaian,
 * jadi aman dipanggil kapan pun meski worker utama sedang sibuk memproses
 * batch mission lain (kunci flock khusus menjaga "satu tool satu waktu", bukan
 * state mission — lihat CasaWork.php).
 *
 * Berguna saat mission A sudah selesai semua task-nya tapi worker masih
 * memproses batch panjang mission B (runPending() menahan kunci sampai
 * ≤20 task batch-nya tuntas, baru advanceAll() terpanggil) — mission A jadi
 * menunggu tanpa perlu.
 *
 *   cd /var/www/casa && php spark casa:advance
 */
final class CasaAdvance extends BaseCommand
{
    protected $group       = 'CoreNet';
    protected $name        = 'casa:advance';
    protected $description = 'Majukan status semua mission aktif yang task-nya sudah tuntas, tanpa menunggu kunci worker.';

    public function run(array $params): int
    {
        (new MissionService())->advanceAll();
        CLI::write('casa:advance — mission aktif dimajukan (yang task-nya sudah tuntas).', 'green');

        return EXIT_SUCCESS;
    }
}
