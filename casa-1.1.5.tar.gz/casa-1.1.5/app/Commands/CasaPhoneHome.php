<?php

declare(strict_types=1);

namespace App\Commands;

use App\Modules\Licensing\Services\PhoneHomeService;
use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;

/**
 * CasaPhoneHome — kirim telemetri ringkas ke console owner (env phonehome.url).
 * Dijadwalkan harian di instance pelanggan:
 *   0 3 * * * cd /var/www/casa && php spark casa:phonehome >/dev/null 2>&1
 */
final class CasaPhoneHome extends BaseCommand
{
    protected $group       = 'CoreNet';
    protected $name        = 'casa:phonehome';
    protected $description  = 'Kirim telemetri ringkas instance ke console owner (monitoring lisensi).';

    public function run(array $params): int
    {
        $ok = (new PhoneHomeService())->send();
        CLI::write($ok ? 'phone-home terkirim.' : 'phone-home dilewati/gagal (phonehome.url kosong?).', $ok ? 'green' : 'yellow');

        return EXIT_SUCCESS;
    }
}
