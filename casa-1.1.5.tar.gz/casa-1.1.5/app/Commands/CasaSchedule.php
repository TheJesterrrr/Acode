<?php

declare(strict_types=1);

namespace App\Commands;

use App\Modules\Automation\Services\ScheduleService;
use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;

/**
 * CasaSchedule — meluncurkan Mission dari jadwal yang jatuh tempo (Automation,
 * Master Plan §12 #20). Dijadwalkan seperti cron (tiap menit cukup; hanya jadwal
 * jatuh tempo yang berjalan):
 *   * * * * * cd /var/www/casa && php spark casa:schedule >> /dev/null 2>&1
 */
final class CasaSchedule extends BaseCommand
{
    protected $group       = 'CoreNet';
    protected $name        = 'casa:schedule';
    protected $description  = 'Luncurkan Mission dari jadwal pemindaian yang jatuh tempo.';

    public function run(array $params): int
    {
        $s = (new ScheduleService())->runDue();
        CLI::write("casa:schedule — launched={$s['launched']} failed={$s['failed']}.", 'green');

        return EXIT_SUCCESS;
    }
}
