<?php

declare(strict_types=1);

namespace App\Commands;

use App\Modules\Licensing\Services\LicenseSyncService;
use App\Modules\Setting\Services\SettingService;
use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;

/**
 * CasaSync — tarik lisensi terbaru dari console owner & aktivasi lokal.
 * Dijadwalkan harian di instance pelanggan (VPS):
 *   30 3 * * * cd /var/www/casa && php spark casa:sync >/dev/null 2>&1
 * Aman dijalankan berulang; offline/tak dikonfigurasi → dilewati dengan pesan.
 */
final class CasaSync extends BaseCommand
{
    protected $group       = 'CoreNet';
    protected $name        = 'casa:sync';
    protected $description  = 'Sinkron lisensi dari console owner (aktivasi otomatis sesuai langganan).';

    public function run(array $params): int
    {
        $res = (new LicenseSyncService())->sync();
        if (! empty($res['ok'])) {
            $msg = ($res['community'] ?? false) ? 'Community (tak ada langganan aktif).' : ('Lisensi: ' . ($res['tier'] ?? '?') . (isset($res['exp']) && $res['exp'] ? ' s/d ' . $res['exp'] : ''));
            CLI::write('Sinkron OK — ' . $msg, 'green');
            // Dibaca InfraAuditJob (CASA-E008) utk mendeteksi sinkron yang diam-diam
            // berhenti sukses — bukan sekadar satu kegagalan sesaat.
            (new SettingService())->set('license.last_sync_ok_at', date('Y-m-d H:i:s'));
        } else {
            $err = (string) ($res['error'] ?? 'tidak diketahui');
            CLI::write('Sinkron dilewati/gagal — ' . $err, 'yellow');
            \App\Libraries\CasaLog::log('CASA-E008', 'Sinkronisasi lisensi gagal: ' . $err, null, null, 'warning');
        }

        return EXIT_SUCCESS;
    }
}
