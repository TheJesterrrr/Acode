<?php

declare(strict_types=1);

namespace App\Commands;

use App\Modules\Licensing\Services\LicenseKeyService;
use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use Throwable;

/**
 * CasaLicense — util lisensi. OWNER: `keygen` (buat pasangan kunci sekali),
 * `sign <tier> <days> [customer]` (terbitkan license key, butuh env
 * license.privateKey). MEMBER/instance: `activate <token>`, `status`.
 */
final class CasaLicense extends BaseCommand
{
    protected $group       = 'CoreNet';
    protected $name        = 'casa:license';
    protected $description  = 'Kelola license key: keygen | sign <tier> <days> [customer] | activate <token> | status';
    protected $usage       = 'casa:license <sub> [args]';

    public function run(array $params): int
    {
        $svc = new LicenseKeyService();
        $sub = (string) ($params[0] ?? 'status');

        try {
            return match ($sub) {
                'keygen'   => $this->keygen($svc),
                'sign'     => $this->sign($svc, $params),
                'activate' => $this->activate($svc, $params),
                'status'   => $this->status($svc),
                default    => $this->bad(),
            };
        } catch (Throwable $e) {
            CLI::error($e->getMessage());

            return EXIT_ERROR;
        }
    }

    private function keygen(LicenseKeyService $svc): int
    {
        $kp = $svc->generateKeypair();
        CLI::write('== Ed25519 keypair (SIMPAN AMAN) ==', 'yellow');
        CLI::write('PUBLIC  (tempel ke Config\Edition::$licensePublicKey):', 'green');
        CLI::write($kp['public']);
        CLI::write('PRIVATE (taruh di .env owner: license.privateKey=...):', 'red');
        CLI::write($kp['private']);

        return EXIT_SUCCESS;
    }

    private function sign(LicenseKeyService $svc, array $p): int
    {
        $priv = (string) (env('license.privateKey') ?: '');
        if ($priv === '') {
            CLI::error('env license.privateKey kosong (mode owner saja).');

            return EXIT_ERROR;
        }
        $token = $svc->sign([
            'tier'     => (string) ($p[1] ?? 'pro'),
            'days'     => (int) ($p[2] ?? 0),
            'customer' => (string) ($p[3] ?? ''),
        ], $priv);
        CLI::write('== LICENSE KEY (kirim ke pelanggan) ==', 'yellow');
        CLI::write($token, 'green');

        return EXIT_SUCCESS;
    }

    private function activate(LicenseKeyService $svc, array $p): int
    {
        $token = (string) ($p[1] ?? '');
        if ($token === '') {
            CLI::error('Sertakan token: casa:license activate <token>');

            return EXIT_ERROR;
        }
        $payload = $svc->activate($token);
        CLI::write('Aktivasi berhasil: tier=' . ($payload['tier'] ?? '?') . ' exp=' . ($payload['exp'] ?? '∞') . ' cust=' . ($payload['cust'] ?? '-'), 'green');

        return EXIT_SUCCESS;
    }

    private function status(LicenseKeyService $svc): int
    {
        $e = $svc->effective();
        CLI::write('Lisensi instance:', 'yellow');
        CLI::write('  tier    : ' . $e['tier']);
        CLI::write('  aktif   : ' . ($e['active'] ? 'ya' : 'tidak') . ($e['expired'] ? ' (KEDALUWARSA)' : ''));
        CLI::write('  customer: ' . ($e['customer'] ?? '-'));
        CLI::write('  exp     : ' . ($e['exp'] ?? '∞'));

        return EXIT_SUCCESS;
    }

    private function bad(): int
    {
        CLI::error('Sub perintah: keygen | sign | activate | status');

        return EXIT_ERROR;
    }
}
