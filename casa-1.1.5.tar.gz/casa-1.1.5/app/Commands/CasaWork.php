<?php

declare(strict_types=1);

namespace App\Commands;

use App\Libraries\Lock;
use App\Modules\Engine\Services\EngineService;
use App\Modules\Mission\Services\MissionService;
use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;

/**
 * CasaWork — worker `casad` (Spark Command, CES 13.9). Memproses antrean `task`
 * dan memajukan mission aktif. Dijadwalkan seperti cron:
 *   * * * * * cd /var/www/casa && php spark casa:work >> /dev/null 2>&1
 * Untuk lab, dapat dijalankan manual: `php spark casa:work`.
 */
final class CasaWork extends BaseCommand
{
    protected $group       = 'CoreNet';
    protected $name        = 'casa:work';
    protected $description  = 'Worker casad: proses antrean task lalu majukan mission (plan→exec→validate→report).';
    protected $usage       = 'casa:work [limit]';
    protected $arguments   = ['limit' => 'Opsional: maksimum task diproses (default 20).'];

    public function run(array $params): int
    {
        $limit = isset($params[0]) ? max(1, (int) $params[0]) : 20;

        // KUNCI SATU-INSTANCE (flock). Cron menjadwalkan casa:work tiap menit; tanpa
        // kunci, worker baru bisa tumpang-tindih dengan yang lama → DUA tool berat
        // berjalan berbarengan → lonjakan RAM (pemicu crash). Dengan kunci, worker
        // kedua mundur (loser backs off) dan task tetap diproses SATU per SATU →
        // menjaga invarian "satu tool satu waktu" bersama urutan tool-major di
        // MissionService. flock dilepas OS saat proses berakhir, jadi tak macet.
        $n = Lock::run('casa-work', function () use ($limit): int {
            $engine  = new EngineService();
            $mission = new MissionService();

            $count = $engine->runPending($limit);
            $mission->advanceAll();

            return $count;
        });

        // Denyut worker → Engine Health membaca cron_logs (job LIKE '%work%').
        // Tanpa ini, status worker SELALU "Belum jalan" walau worker sehat.
        $this->heartbeat($n);

        if ($n === null) {
            // Lock gagal didapat 3x berturut-turut (≥3 menit, cron tiap menit) →
            // kemungkinan besar proses tool nyangkut menyandera lock (lihat
            // CasaLog::CODES['CASA-E002']), bukan sekadar tumpang-tindih wajar
            // sesaat. Jangan log tiap tick (spam) — cukup sekali per ~30 menit.
            $streak = (int) (cache()->get('casa_work_skip_streak') ?? 0) + 1;
            cache()->save('casa_work_skip_streak', $streak, 3600);
            if ($streak >= 3 && ! cache()->get('casa_work_e002_logged')) {
                \App\Libraries\CasaLog::log('CASA-E002', "Worker gagal dapat lock {$streak}x berturut-turut (≥{$streak} menit) — kemungkinan proses tool macet menyandera writable/locks/casa-work.lock");
                cache()->save('casa_work_e002_logged', true, 1800);
            }
            CLI::write('casa:work — worker lain masih berjalan; dilewati.', 'yellow');

            return EXIT_SUCCESS;
        }
        cache()->delete('casa_work_skip_streak');
        cache()->delete('casa_work_e002_logged');

        CLI::write("casa:work — {$n} task diproses; mission dimajukan.", 'green');

        return EXIT_SUCCESS;
    }

    /**
     * Catat denyut worker ke cron_logs (job='casa:work') agar Engine Health tahu
     * worker hidup. UPSERT satu baris — tak membengkak walau jalan tiap menit.
     * Ditulis tiap tick (termasuk saat lock dilewati): yang penting cron memang
     * menyala. Dibungkus try/catch — denyut tak boleh menjatuhkan worker.
     */
    private function heartbeat(?int $n): void
    {
        try {
            $db  = \Config\Database::connect();
            $now = date('Y-m-d H:i:s');
            $msg = $n === null ? 'tick — instance lain memproses' : "tick — {$n} task diproses";
            $row = $db->table('cron_logs')->where('job', 'casa:work')->orderBy('id', 'DESC')->get(1)->getRowArray();
            if ($row !== null) {
                $db->table('cron_logs')->where('id', (int) $row['id'])->update(['status' => 'ok', 'message' => $msg, 'duration_ms' => 0, 'ran_at' => $now]);
            } else {
                $db->table('cron_logs')->insert(['job' => 'casa:work', 'status' => 'ok', 'message' => $msg, 'duration_ms' => 0, 'ran_at' => $now]);
            }
        } catch (\Throwable $e) {
            // Denyut gagal tak boleh menghentikan pemrosesan task.
        }
    }
}
