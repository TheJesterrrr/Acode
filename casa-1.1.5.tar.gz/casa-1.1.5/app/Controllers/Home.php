<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Libraries\Cer;
use CodeIgniter\HTTP\ResponseInterface;

/**
 * Home — titik masuk root '/'. Mengarahkan ke portal yang sesuai endpoint.
 */
final class Home extends BaseController
{
    public function index(): ResponseInterface
    {
        if (Cer::isAdmin()) {
            return (int) session()->get('admin_id') > 0
                ? redirect()->to(Cer::adminUrl() . 'casaadmin')
                : redirect()->to(Cer::adminUrl() . 'login');
        }

        return (int) session()->get('member_id') > 0
            ? redirect()->to(Cer::baseUrl() . 'member')
            : redirect()->to(Cer::baseUrl() . 'login');
    }
}
