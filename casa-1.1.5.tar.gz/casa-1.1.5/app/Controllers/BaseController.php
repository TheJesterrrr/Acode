<?php

declare(strict_types=1);

namespace App\Controllers;

use CodeIgniter\Controller;
use CodeIgniter\HTTP\CLIRequest;
use CodeIgniter\HTTP\IncomingRequest;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;

/**
 * BaseController — induk seluruh controller (CES 13.2 thin controller).
 *
 * HANYA menyediakan pembacaan input yang seragam dan respons AJAX. DILARANG
 * menaruh logika bisnis atau kueri di sini maupun di turunannya — itu tugas
 * Service (13.4) dan Model (13.3).
 */
abstract class BaseController extends Controller
{
    protected $request;

    /** @var list<string> Helper yang selalu dimuat. */
    protected $helpers = ['casa', 'form', 'url'];

    protected $session;

    public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger)
    {
        parent::initController($request, $response, $logger);
        $this->session = session();
    }

    /** Render halaman member dengan kerangka (nav, bell) terisi. */
    protected function memberView(string $view, array $data, string $active): string
    {
        $shell = (new \App\Modules\Dashboard\Services\ShellService())
            ->member((int) $this->session->get('member_id'), $active);

        return view($view, $data + ['shell' => $shell, 'title' => ($data['title'] ?? 'CoreNet') . ' — CoreNet']);
    }

    /** Render halaman admin dengan kerangka terisi. */
    protected function adminView(string $view, array $data, string $active): string
    {
        $svc = new \App\Modules\Dashboard\Services\ShellService();
        // Unified portal: di instance PRODUK, Owner-member yang mengakses fungsi
        // admin (grup Pengaturan) dilayani dalam SHELL MEMBER — satu portal.
        if (! $this->isOwnerConsole()
            && (int) $this->session->get('admin_id') === 0
            && (int) $this->session->get('member_id') > 0
            && (string) $this->session->get('team_role') === 'owner') {
            $shell               = $svc->member((int) $this->session->get('member_id'), $active);
            $shell['is_member']  = true;
        } else {
            $shell = $svc->admin((int) $this->session->get('admin_id'), $active);
        }

        return view($view, $data + ['shell' => $shell, 'title' => ($data['title'] ?? 'CoreNet') . ' — Admin']);
    }

    /** Respons AJAX berhasil. */
    protected function ok(array $data = []): ResponseInterface
    {
        return $this->response->setJSON(['ok' => true, 'csrf' => csrf_hash()] + $data);
    }

    /** Respons AJAX gagal — pesan WAJIB dapat dipahami pengguna (CES 2.4). */
    protected function fail(string $message, int $code = 422): ResponseInterface
    {
        return $this->response
            ->setStatusCode($code)
            ->setJSON(['ok' => false, 'error' => $message]);
    }

    /** True bila instance ini = console OWNER (memegang private key lisensi). */
    protected function isOwnerConsole(): bool
    {
        return (string) (env('license.privateKey') ?: '') !== '';
    }

    /** Halaman owner-only: 404 di instance pelanggan (produk). */
    protected function requireOwnerConsole(): void
    {
        if (! $this->isOwnerConsole()) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
    }

    /** Peran member aktif (Team/RBAC): owner | analyst | viewer. Default owner. */
    protected function memberRole(): string
    {
        $r = (string) $this->session->get('team_role');

        return $r !== '' ? $r : 'owner';
    }

    /** Tolak aksi TULIS untuk peran viewer. Kembalikan response bila ditolak, null bila boleh. */
    protected function denyViewer(): ?ResponseInterface
    {
        if ($this->memberRole() === 'viewer') {
            return $this->fail('Peran Viewer hanya dapat melihat (read-only). Hubungi owner akun untuk akses tulis.', 403);
        }

        return null;
    }

    /** Wajib peran owner (mis. kelola tim). Kembalikan response bila ditolak, null bila boleh. */
    protected function requireOwnerRole(): ?ResponseInterface
    {
        if ($this->memberRole() !== 'owner') {
            return $this->fail('Hanya owner akun yang dapat melakukan aksi ini.', 403);
        }

        return null;
    }
}
