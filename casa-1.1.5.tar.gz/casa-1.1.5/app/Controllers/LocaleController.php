<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Filters\LocaleFilter;
use CodeIgniter\HTTP\RedirectResponse;

/**
 * LocaleController — ganti bahasa tampilan (ID/EN) dari toggle di topbar.
 * Disimpan di session (per-browser, CES "chrome UI dulu" — lihat LocaleFilter)
 * lalu kembali ke halaman asal, supaya toggle terasa instan tanpa pindah halaman.
 */
final class LocaleController extends BaseController
{
    public function set(string $lang): RedirectResponse
    {
        if (in_array($lang, LocaleFilter::SUPPORTED, true)) {
            $this->session->set(LocaleFilter::SESSION_KEY, $lang);
        }

        $kembali = (string) ($this->request->getServer('HTTP_REFERER') ?: site_url());

        return redirect()->to($kembali);
    }
}
