<?php

declare(strict_types=1);

namespace App\Filters;

use App\Libraries\Cer;
use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

/**
 * MemberAuthFilter — mewajibkan sesi member aktif (CES 13.7).
 *
 * Endpoint yang di-filter WAJIB berada di host member. Bila sesi tidak ada,
 * arahkan ke /login (permintaan biasa) atau kembalikan 401 (permintaan AJAX).
 */
final class MemberAuthFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $session = session();

        if ((int) $session->get('member_id') > 0 && Cer::isMember()) {
            return null;
        }

        if ($request->isAJAX()) {
            return service('response')
                ->setStatusCode(ResponseInterface::HTTP_UNAUTHORIZED)
                ->setJSON(['ok' => false, 'error' => 'Sesi berakhir. Silakan masuk kembali.']);
        }

        return redirect()->to(Cer::baseUrl() . 'login');
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        return null;
    }
}
