<?php

declare(strict_types=1);

namespace App\Filters;

use App\Libraries\Cer;
use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Config\Services;

/**
 * EndpointContextFilter — menerapkan kontrak endpoint (CES 11.5.3).
 *
 * Berjalan lebih dulu dari filter lain. Menetapkan nama cookie sesi sesuai
 * endpoint (member vs admin) SEBELUM sesi dimulai, sehingga cookie admin
 * tidak pernah terkirim ke host member.
 */
final class EndpointContextFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $sessionConfig = config('Session');
        $sessionConfig->cookieName = Cer::sessionCookieName();

        // Simpan endpoint aktif agar mudah dibaca lapisan lain.
        $request->endpoint = Cer::endpoint();

        return null;
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        return null;
    }
}
