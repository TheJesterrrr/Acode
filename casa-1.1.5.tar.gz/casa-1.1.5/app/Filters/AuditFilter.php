<?php

declare(strict_types=1);

namespace App\Filters;

use App\Modules\Audit\Services\AuditService;
use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

/**
 * AuditFilter — mencatat aksi yang mengubah data ke audit log (CES 2.6, 13.7).
 *
 * Dipasang pada rute sebagai `audit:NAMA_AKSI`. Hanya aksi yang berhasil
 * (status < 400) yang dicatat. Delegasi ke AuditService (menutup AUD-1).
 *
 * Catatan cakupan: filter ini mencatat JEJAK request tingkat kasar (siapa,
 * kapan, aksi apa, dari IP mana). Perubahan nilai before/after yang rinci tetap
 * dicatat di dalam Service masing-masing (mis. TopupService) yang memang tahu
 * data lamanya — filter tidak menggantikannya, melainkan melengkapinya.
 */
final class AuditFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        return null;
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        $status = $response->getStatusCode();
        $action = $arguments[0] ?? 'HTTP_ACTION';
        // CI4 4.5+ getMethod() mengembalikan huruf besar ('POST'); normalkan
        // agar cocok — jika tidak, tak ada aksi yang pernah tercatat.
        $method = strtolower($request->getMethod());

        if ($status < 400 && in_array($method, ['post', 'put', 'patch', 'delete'], true)) {
            (new AuditService())->log((string) $action, 'http', null, null, [
                'method' => strtoupper($method),
                'path'   => (string) $request->getUri()->getPath(),
                'status' => $status,
            ]);
        }

        return $response;
    }
}
