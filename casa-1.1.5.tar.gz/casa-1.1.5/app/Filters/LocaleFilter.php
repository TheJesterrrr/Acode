<?php

declare(strict_types=1);

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

/**
 * LocaleFilter — bahasa tampilan (ID/EN) seluruh app, SATU sumber untuk semua
 * halaman (bukan cuma Report & Panduan yang tadinya punya bahasa sendiri-
 * sendiri via ?lang=). Dipilih via toggle di topbar, disimpan di session
 * (per-browser — bukan per-akun, sesuai keputusan pemilik), dipakai `lang()`
 * helper CodeIgniter di seluruh view lewat $request->setLocale().
 *
 * HARUS berjalan SETELAH 'endpoint' (yang menata nama cookie sesi) supaya
 * session() di sini membaca cookie yang benar.
 */
final class LocaleFilter implements FilterInterface
{
    public const SESSION_KEY = 'casa_lang';
    public const SUPPORTED   = ['id', 'en'];
    public const DEFAULT     = 'id';

    public function before(RequestInterface $request, $arguments = null)
    {
        $lang = (string) (session()->get(self::SESSION_KEY) ?: self::DEFAULT);
        if (! in_array($lang, self::SUPPORTED, true)) {
            $lang = self::DEFAULT;
        }
        $request->setLocale($lang);

        return null;
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        return null;
    }
}
