<?php

declare(strict_types=1);

namespace App\Filters;

use App\Libraries\Cer;
use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

/**
 * AdminAuthFilter — mewajibkan sesi admin aktif pada host admin (CES 13.7).
 */
final class AdminAuthFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $session = session();

        if ((int) $session->get('admin_id') > 0 && Cer::isAdmin()) {
            return null;
        }

        // Unified portal: di instance PRODUK (tanpa private key), Owner-member
        // boleh mengakses fungsi admin instance (License/AI/Engine/dll.) langsung
        // dari portal member — tanpa host/login admin terpisah.
        if ((string) (env('license.privateKey') ?: '') === ''
            && (int) $session->get('member_id') > 0
            && (string) $session->get('team_role') === 'owner') {
            return null;
        }

        if ($request->isAJAX()) {
            return service('response')
                ->setStatusCode(ResponseInterface::HTTP_UNAUTHORIZED)
                ->setJSON(['ok' => false, 'error' => 'Sesi berakhir. Silakan masuk kembali.']);
        }

        return redirect()->to(Cer::adminUrl() . 'login');
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        return null;
    }
}
