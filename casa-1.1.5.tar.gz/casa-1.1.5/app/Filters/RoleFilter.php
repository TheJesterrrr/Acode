<?php

declare(strict_types=1);

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

/**
 * RoleFilter — otorisasi berbasis peran (RBAC, CES 13.7).
 *
 * Dipakai sebagai `role:owner`. Berjalan SETELAH AdminAuthFilter, jadi sesi
 * admin dipastikan ada. Peran 'owner' mencakup 'operator'; kebalikannya tidak.
 */
final class RoleFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $required = $arguments[0] ?? 'operator';
        $role     = (string) session()->get('admin_role');

        $granted = $required === 'operator'
            ? in_array($role, ['operator', 'owner'], true)
            : $role === 'owner';

        if ($granted) {
            return null;
        }

        if ($request->isAJAX()) {
            return service('response')
                ->setStatusCode(ResponseInterface::HTTP_FORBIDDEN)
                ->setJSON(['ok' => false, 'error' => 'Anda tidak memiliki akses ke tindakan ini.']);
        }

        return service('response')
            ->setStatusCode(ResponseInterface::HTTP_FORBIDDEN)
            ->setBody(view('errors/html/error_403'));
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        return null;
    }
}
