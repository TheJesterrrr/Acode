<?php

declare(strict_types=1);

/**
 * Chrome (EN) — app "chrome" text: sidebar, topbar, shared labels. NOT
 * per-module business content (reports, mission notes, etc.) — out of scope
 * for this phase of the language toggle (owner decision: "Chrome UI first").
 */
return [
    // Menu groups
    'groupNavigation' => 'NAVIGATION',
    'groupAccount'    => 'ACCOUNT',
    'groupSettings'   => 'SETTINGS',
    'groupMain'       => 'MAIN',
    'groupAiSecurity' => 'AI & SECURITY',
    'groupSystem'     => 'SYSTEM',

    // Member sidebar — Hub
    'dashboard'        => 'Dashboard',
    'subscriptionCoins' => 'Subscription & Coins',
    'downloadApp'      => 'Download App',
    'userGuide'        => 'User Guide',
    'myAccount'        => 'My Account',

    // Member sidebar — Bug Bounty
    'programs'       => 'Programs',
    'reconMonitor'   => 'Recon Monitor',
    'bountyScan'     => 'Bounty Scan',
    'findings'       => 'Findings',
    'submissions'    => 'Submissions',
    'import'         => 'Import',
    'reports'        => 'Reports',

    // Member sidebar — Pentest
    'newAssessment'    => 'New Assessment',
    'scanTemplates'    => 'Scan Templates',
    'missions'         => 'Missions',
    'projects'         => 'Projects',
    'attackSurface'    => 'Attack Surface',
    'vulnerabilities'  => 'Vulnerabilities',
    'compliance'       => 'Compliance',

    // Member sidebar — Settings/Account
    'licenseActivation' => 'License & Activation',
    'releaseApp'     => 'Release Manager',
    'tools'             => 'Tools',
    'aiSettings'        => 'AI Settings',
    'engineHealth'      => 'Engine Health',
    'integrations'      => 'Integrations',
    'settings'          => 'Settings',
    'auditLog'          => 'Audit Log',
    'team'              => 'Team',

    // Mode switch
    'portalMode'   => 'Portal mode',
    'pentestMode'  => 'Pentest',
    'bountyMode'   => 'Bounty',
    'plan'         => 'Plan',
    'yourPlan'     => 'Your subscription plan',

    // Admin sidebar
    'analytics'      => 'Analytics',
    'customers'      => 'Customers',
    'plansPricing'   => 'Plans & Pricing',
    'toolManager'    => 'Tool Manager',
    'detectionFeed'  => 'Detection Feed',
    'monitoring'     => 'Monitoring',
    'cronHistory'    => 'Cron History',
    'broadcast'      => 'Broadcast',
    'guide'          => 'Guide',
    'ownerLabel'     => 'Owner',
    'adminLabel'     => 'Admin',

    // Topbar
    'menu'                => 'Menu',
    'searchPlaceholder'   => 'Search asset, finding, mission…',
    'searchComingSoon'    => 'Search (coming soon)',
    'toggleTheme'         => 'Toggle theme',
    'lightDark'           => 'Light/Dark',
    'notifications'       => 'Notifications',
    'logOut'              => 'Log out',
    'language'            => 'Language',

    // Shell / identity
    'customer'        => 'Customer',
    'member'          => 'Member',

    // Generic
    'close' => 'Close',
];
