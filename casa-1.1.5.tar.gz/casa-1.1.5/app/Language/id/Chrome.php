<?php

declare(strict_types=1);

/**
 * Chrome (ID) — teks "kerangka" aplikasi: sidebar, topbar, label bersama.
 * BUKAN konten bisnis per-modul (laporan, catatan mission, dll) — itu di luar
 * cakupan toggle bahasa tahap ini (lihat keputusan pemilik: "Chrome UI dulu").
 */
return [
    // Grup menu
    'groupNavigation' => 'NAVIGASI',
    'groupAccount'    => 'AKUN',
    'groupSettings'   => 'PENGATURAN',
    'groupMain'       => 'UTAMA',
    'groupAiSecurity' => 'AI & KEAMANAN',
    'groupSystem'     => 'SISTEM',

    // Menu sidebar member — Hub
    'dashboard'        => 'Dashboard',
    'subscriptionCoins' => 'Langganan & Koin',
    'downloadApp'      => 'Unduh Aplikasi',
    'userGuide'        => 'Panduan Penggunaan',
    'myAccount'        => 'Akun Saya',

    // Menu sidebar member — Bug Bounty
    'programs'       => 'Program',
    'reconMonitor'   => 'Monitor Recon',
    'bountyScan'     => 'Bounty Scan',
    'findings'       => 'Temuan',
    'submissions'    => 'Submission',
    'import'         => 'Import',
    'reports'        => 'Laporan',

    // Menu sidebar member — Pentest
    'newAssessment'    => 'Assessment Baru',
    'scanTemplates'    => 'Template Scan',
    'missions'         => 'Mission',
    'projects'         => 'Project',
    'attackSurface'    => 'Attack Surface',
    'vulnerabilities'  => 'Vulnerability',
    'compliance'       => 'Compliance',

    // Menu sidebar member — Pengaturan/Akun
    'licenseActivation' => 'Lisensi & Aktivasi',
    'releaseApp'     => 'Rilis Aplikasi',
    'tools'             => 'Tools',
    'aiSettings'        => 'Pengaturan AI',
    'engineHealth'      => 'Engine Health',
    'integrations'      => 'Integrasi',
    'settings'          => 'Pengaturan',
    'auditLog'          => 'Log Audit',
    'team'              => 'Tim',

    // Mode switch
    'portalMode'   => 'Mode portal',
    'pentestMode'  => 'Pentest',
    'bountyMode'   => 'Bounty',
    'plan'         => 'Plan',
    'yourPlan'     => 'Paket langganan Anda',

    // Menu sidebar admin
    'analytics'      => 'Analitik',
    'customers'      => 'Pelanggan',
    'plansPricing'   => 'Paket & Harga',
    'toolManager'    => 'Tool Manager',
    'detectionFeed'  => 'Detection Feed',
    'monitoring'     => 'Monitoring',
    'cronHistory'    => 'Riwayat Cron',
    'broadcast'      => 'Broadcast',
    'guide'          => 'Panduan',
    'ownerLabel'     => 'Owner',
    'adminLabel'     => 'Admin',

    // Topbar
    'menu'                => 'Menu',
    'searchPlaceholder'   => 'Cari aset, temuan, mission…',
    'searchComingSoon'    => 'Pencarian (segera hadir)',
    'toggleTheme'         => 'Ganti tema',
    'lightDark'           => 'Terang/Gelap',
    'notifications'       => 'Notifikasi',
    'logOut'              => 'Keluar',
    'language'            => 'Bahasa',

    // Shell / identitas
    'customer'        => 'Pelanggan',
    'member'          => 'Member',

    // Umum
    'close' => 'Tutup',
];
