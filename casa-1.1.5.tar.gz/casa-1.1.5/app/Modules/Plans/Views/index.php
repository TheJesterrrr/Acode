<?= $this->extend('layouts/admin') ?>
<?= $this->section('content') ?>
<?php /** @var array $packages */ ?>
<div class="casa-page-head">
  <h1 class="h4 mb-0"><i class="bi bi-tags me-1"></i>Plans &amp; Pricing</h1>
  <button class="btn btn-outline-warning btn-sm" id="restoreBtn"><i class="bi bi-arrow-counterclockwise me-1"></i>Restore default plans</button>
</div>

<?php if ($packages === []): ?>
  <div class="alert alert-warning"><i class="bi bi-exclamation-triangle me-1"></i>Belum ada paket koin — portal member tak bisa topup. Klik <b>Restore default plans</b> atau tambah paket di bawah.</div>
<?php endif; ?>

<div class="row g-3">
  <div class="col-lg-7">
    <div class="casa-card p-0 h-100">
      <div class="p-3 border-bottom" style="border-color:var(--casa-card-brd)!important"><h2 class="h6 mb-0">Paket koin (topup member)</h2></div>
      <div class="table-responsive"><table class="table align-middle mb-0">
        <thead><tr><th class="ps-3">Paket</th><th>Harga</th><th>Koin</th><th>Bonus</th><th>Status</th><th class="pe-3"></th></tr></thead>
        <tbody>
          <?php foreach ($packages as $p): ?>
            <tr>
              <td class="ps-3"><?= esc($p['label']) ?></td>
              <td class="small">Rp <?= number_format((int) $p['price_rp'], 0, ',', '.') ?></td>
              <td class="small"><?= number_format((int) $p['coin_amount'], 0, ',', '.') ?></td>
              <td class="small text-success">+<?= number_format((int) $p['bonus_coin'], 0, ',', '.') ?></td>
              <td><span class="badge text-bg-<?= $p['is_active'] ? 'success' : 'secondary' ?>"><?= $p['is_active'] ? 'aktif' : 'nonaktif' ?></span></td>
              <td class="pe-3 text-end text-nowrap">
                <button class="btn btn-sm btn-outline-primary js-edit" data-p='<?= esc(json_encode($p), 'attr') ?>'><i class="bi bi-pencil"></i></button>
                <button class="btn btn-sm btn-outline-secondary js-tg" data-id="<?= (int) $p['id'] ?>"><?= $p['is_active'] ? 'off' : 'on' ?></button>
                <button class="btn btn-sm btn-outline-danger js-del" data-id="<?= (int) $p['id'] ?>"><i class="bi bi-trash"></i></button>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table></div>
    </div>
  </div>
  <div class="col-lg-5">
    <div class="casa-card p-4 h-100">
      <h2 class="h6 mb-3" id="formTitle">Tambah paket</h2>
      <form id="pkgForm">
        <input type="hidden" name="id" id="f_id" value="">
        <div class="mb-2"><label class="form-label small">Label</label><input name="label" id="f_label" class="form-control" required></div>
        <div class="row g-2">
          <div class="col-6 mb-2"><label class="form-label small">Harga (Rp)</label><input name="price_rp" id="f_price" type="number" class="form-control" required></div>
          <div class="col-6 mb-2"><label class="form-label small">Koin</label><input name="coin_amount" id="f_coin" type="number" class="form-control" required></div>
          <div class="col-6 mb-2"><label class="form-label small">Bonus koin</label><input name="bonus_coin" id="f_bonus" type="number" class="form-control" value="0"></div>
          <div class="col-6 mb-2"><label class="form-label small">Urutan</label><input name="sort_order" id="f_sort" type="number" class="form-control" value="1"></div>
        </div>
        <button class="btn btn-primary" id="pkgBtn"><i class="bi bi-save me-1"></i>Save</button>
        <button class="btn btn-link btn-sm" type="button" id="resetBtn">reset</button>
        <span id="pkgMsg" class="small ms-2"></span>
      </form>
    </div>
  </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('page_scripts') ?>
<script>
const BASE = '<?= esc(site_url('casaadmin/plans')) ?>';
function resetForm(){ ['id','label','price','coin','bonus','sort'].forEach(k=>{const el=document.getElementById('f_'+k); if(el) el.value = (k==='sort'?'1':(k==='id'||k==='label'?'':'0'));}); document.getElementById('f_bonus').value='0'; document.getElementById('formTitle').textContent='Tambah paket'; }
document.getElementById('resetBtn').addEventListener('click', resetForm);
document.querySelectorAll('.js-edit').forEach(b => b.addEventListener('click', () => {
  const p = JSON.parse(b.dataset.p);
  document.getElementById('f_id').value=p.id; document.getElementById('f_label').value=p.label;
  document.getElementById('f_price').value=p.price_rp; document.getElementById('f_coin').value=p.coin_amount;
  document.getElementById('f_bonus').value=p.bonus_coin; document.getElementById('f_sort').value=p.sort_order;
  document.getElementById('formTitle').textContent='Edit paket'; window.scrollTo(0,0);
}));
document.getElementById('pkgForm').addEventListener('submit', async (e)=>{ e.preventDefault();
  const b=document.getElementById('pkgBtn'), m=document.getElementById('pkgMsg'); b.disabled=true;
  const d=await casaPost(BASE+'/save', new FormData(e.target)); b.disabled=false;
  if(d.ok){ location.reload(); } else { m.className='small ms-2 text-danger'; m.textContent=d.error||'Gagal.'; }
});
document.querySelectorAll('.js-tg').forEach(x=>x.addEventListener('click', async ()=>{ await casaPost(BASE+'/'+x.dataset.id+'/toggle',{}); location.reload(); }));
document.querySelectorAll('.js-del').forEach(x=>x.addEventListener('click', async ()=>{ if(confirm('Hapus paket?')){ await casaPost(BASE+'/'+x.dataset.id+'/delete',{}); location.reload(); } }));
document.getElementById('restoreBtn').addEventListener('click', async ()=>{ if(confirm('Pulihkan 5 paket koin default?')){ const d=await casaPost(BASE+'/restore',{}); if(d.ok) location.reload(); } });
</script>
<?= $this->endSection() ?>
