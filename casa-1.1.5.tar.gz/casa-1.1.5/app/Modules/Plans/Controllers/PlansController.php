<?php

declare(strict_types=1);

namespace App\Modules\Plans\Controllers;

use App\Controllers\BaseController;
use App\Modules\Billing\Models\CoinPackageModel;
use CodeIgniter\HTTP\ResponseInterface;
use Config\Database;

/**
 * PlansController — kelola paket koin (topup) untuk portal member (OWNER).
 * Termasuk "pulihkan paket default" agar owner bisa mengisi paket dari UI tanpa
 * akses terminal.
 */
final class PlansController extends BaseController
{
    public function __construct(private readonly CoinPackageModel $pkg = new CoinPackageModel())
    {
    }

    public function index(): string
    {
        $this->requireOwnerConsole();

        return $this->adminView('App\Modules\Plans\Views\index', [
            'title'    => 'Plans & Pricing',
            'packages' => $this->pkg->orderBy('sort_order', 'ASC')->findAll(),
        ], 'plans');
    }

    public function save(): ResponseInterface
    {
        $this->requireOwnerConsole();
        $data = [
            'label'       => trim((string) $this->request->getPost('label')),
            'price_rp'    => (int) $this->request->getPost('price_rp'),
            'coin_amount' => (int) $this->request->getPost('coin_amount'),
            'bonus_coin'  => (int) $this->request->getPost('bonus_coin'),
            'sort_order'  => (int) $this->request->getPost('sort_order'),
            'is_active'   => 1,
        ];
        if ($data['label'] === '' || $data['price_rp'] <= 0 || $data['coin_amount'] <= 0) {
            return $this->fail('Label, harga, dan jumlah koin wajib diisi.');
        }
        $id = (int) $this->request->getPost('id');
        $id > 0 ? $this->pkg->update($id, $data) : $this->pkg->insert($data);

        return $this->ok([]);
    }

    public function toggle(int $id): ResponseInterface
    {
        $this->requireOwnerConsole();
        $p = $this->pkg->find($id);
        if ($p !== null) {
            $this->pkg->update($id, ['is_active' => $p['is_active'] ? 0 : 1]);
        }

        return $this->ok([]);
    }

    public function delete(int $id): ResponseInterface
    {
        $this->requireOwnerConsole();
        $this->pkg->delete($id);

        return $this->ok([]);
    }

    /** Pulihkan 5 paket koin default (idempoten) — mengisi topup bila kosong. */
    public function restore(): ResponseInterface
    {
        $this->requireOwnerConsole();
        Database::seeder()->call('App\Modules\Billing\Database\Seeds\CoinPackageSeeder');

        return $this->ok(['message' => 'Paket default dipulihkan.']);
    }
}
