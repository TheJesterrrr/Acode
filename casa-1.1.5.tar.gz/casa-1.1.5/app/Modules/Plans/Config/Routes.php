<?php

declare(strict_types=1);

use CodeIgniter\Router\RouteCollection;

/** Rute Plans & Pricing — kelola paket koin (owner). */

/** @var RouteCollection $routes */
$routes->group('casaadmin/plans', ['namespace' => 'App\Modules\Plans\Controllers', 'filter' => 'admin'], static function (RouteCollection $routes): void {
    $routes->get('', 'PlansController::index');
    $routes->post('save', 'PlansController::save', ['filter' => 'audit:PLAN_SAVE']);
    $routes->post('restore', 'PlansController::restore', ['filter' => 'audit:PLAN_RESTORE']);
    $routes->post('(:num)/toggle', 'PlansController::toggle/$1');
    $routes->post('(:num)/delete', 'PlansController::delete/$1', ['filter' => 'audit:PLAN_DELETE']);
});
