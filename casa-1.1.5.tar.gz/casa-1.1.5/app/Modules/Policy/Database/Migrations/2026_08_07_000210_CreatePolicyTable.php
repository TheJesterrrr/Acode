<?php

declare(strict_types=1);

namespace App\Modules\Policy\Database\Migrations;

use CodeIgniter\Database\Migration;
use CodeIgniter\Database\RawSql;

/**
 * Tabel `policy` — hasil Policy Engine per project (Master Plan §5). Satu baris
 * per project: daftar tool Allowed/Blocked + parameter batas (constraints).
 * Gerbang wajib sebelum eksekusi (Master Plan §4 "Batas kritis keamanan").
 */
final class CreatePolicyTable extends Migration
{
    public function up(): void
    {
        $this->forge->addField([
            'project_id'  => ['type' => 'BIGINT', 'unsigned' => true],
            'allowed'     => ['type' => 'TEXT', 'null' => true], // JSON: [toolCode]
            'blocked'     => ['type' => 'TEXT', 'null' => true], // JSON: [{code,reason}]
            'constraints' => ['type' => 'TEXT', 'null' => true], // JSON: {no_bruteforce,no_dos,rate_limit_rps,...}
            'source'      => ['type' => 'VARCHAR', 'constraint' => 12, 'default' => 'manual'], // ai|deterministic|manual
            'summary'     => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => true],
            'raw_rules'   => ['type' => 'TEXT', 'null' => true],
            'updated_at'  => ['type' => 'TIMESTAMP', 'default' => new RawSql('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP')],
        ]);
        $this->forge->addKey('project_id', true);
        $this->forge->createTable('policy', true, ['ENGINE' => 'InnoDB', 'DEFAULT CHARSET' => 'utf8mb4', 'COLLATE' => 'utf8mb4_unicode_ci']);
    }

    public function down(): void
    {
        $this->forge->dropTable('policy', true);
    }
}
