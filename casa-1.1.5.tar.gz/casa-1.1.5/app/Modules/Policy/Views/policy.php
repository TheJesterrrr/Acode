<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<?php
/** @var array $project @var array $policy */
$pid  = (int) $project['id'];
$c    = $policy['constraints'] ?? [];
$sampleRules = "In scope: *.shop.example.com and the REST API.\n"
    . "Out of scope: staging.shop.example.com.\n"
    . "No brute force of credentials. No DoS or stress testing.\n"
    . "Respect a rate limit of 5 requests/second.\n"
    . "Do not run aggressive SQL injection.";
?>
<div class="casa-page-head">
  <a href="<?= esc(site_url('projects/' . $pid)) ?>" class="small text-muted text-decoration-none"><i class="bi bi-arrow-left"></i> <?= esc($project['name']) ?></a>
  <h1 class="mb-0"><i class="bi bi-shield-lock me-1"></i>Policy Engine</h1>
  <p class="text-muted small mb-0">Gerbang wajib sebelum eksekusi. AI Rule Parser mengubah aturan program menjadi daftar tool <b>Allowed</b> / <b>Blocked</b>.</p>
</div>

<div class="row g-3">
  <div class="col-lg-5">
    <div class="casa-card p-3 p-lg-4 h-100">
      <h2 class="h6 mb-2">Aturan program</h2>
      <p class="text-muted small">Tempel aturan program (scope, batasan). AI menyimpulkan constraint.</p>
      <form id="polForm">
        <textarea name="rules" class="form-control font-monospace" rows="9" placeholder="Tempel aturan program di sini…"><?= esc($policy['raw_rules'] ?? $sampleRules) ?></textarea>
        <button id="parseBtn" class="btn btn-primary mt-3"><i class="bi bi-cpu me-1"></i>Parse dengan AI Rule Parser</button>
        <span id="polMsg" class="small ms-2"></span>
      </form>
    </div>
  </div>

  <div class="col-lg-7">
    <div class="casa-card p-3 p-lg-4 h-100">
      <?php if (empty($policy['exists'])): ?>
        <div class="text-center text-muted py-5">
          <i class="bi bi-shield-slash fs-1 d-block mb-2"></i>
          Belum ada policy. Parse aturan untuk membuat gerbang Allowed/Blocked.
        </div>
      <?php else: ?>
        <div class="d-flex align-items-center gap-2 mb-2">
          <h2 class="h6 mb-0">Hasil policy</h2>
          <span class="badge text-bg-<?= $policy['source'] === 'ai' ? 'info' : 'secondary' ?> ms-auto">source: <?= esc($policy['source']) ?></span>
        </div>
        <?php if (! empty($policy['summary'])): ?><p class="small fst-italic text-muted">"<?= esc($policy['summary']) ?>"</p><?php endif; ?>

        <div class="d-flex flex-wrap gap-1 mb-3">
          <?php if (! empty($c['no_bruteforce'])): ?><span class="badge text-bg-danger">no brute force</span><?php endif; ?>
          <?php if (! empty($c['no_dos'])): ?><span class="badge text-bg-danger">no DoS</span><?php endif; ?>
          <?php if (! empty($c['no_aggressive_injection'])): ?><span class="badge text-bg-warning">no aggressive injection</span><?php endif; ?>
          <?php if (! empty($c['rate_limit_rps'])): ?><span class="badge text-bg-secondary">rate limit: <?= (int) $c['rate_limit_rps'] ?> req/s</span><?php endif; ?>
          <?php foreach (($c['out_of_scope'] ?? []) as $oos): ?><span class="badge text-bg-dark">out: <?= esc($oos) ?></span><?php endforeach; ?>
        </div>

        <?php $ownerView = \App\Libraries\ToolLabel::isOwner(); ?>
        <div class="row g-2">
          <div class="col-6">
            <div class="fw-semibold text-success small mb-1"><i class="bi bi-check-circle-fill me-1"></i>Allowed (<?= $ownerView ? count($policy['allowed']) : count(\App\Libraries\ToolLabel::showListDedup($policy['allowed'])) ?>)</div>
            <div class="d-flex flex-wrap gap-1">
              <?php foreach (($ownerView ? $policy['allowed'] : \App\Libraries\ToolLabel::showListDedup($policy['allowed'])) as $code): ?><span class="badge text-bg-light border font-monospace"><?= esc($code) ?></span><?php endforeach; ?>
            </div>
          </div>
          <div class="col-6">
            <div class="fw-semibold text-danger small mb-1"><i class="bi bi-slash-circle me-1"></i>Blocked (<?= count($policy['blocked']) ?>)</div>
            <?php if ($ownerView): ?>
            <ul class="list-unstyled small mb-0">
              <?php foreach ($policy['blocked'] as $b): ?>
                <li><span class="badge text-bg-danger font-monospace"><?= esc($b['code']) ?></span> <span class="text-muted"><?= esc($b['reason']) ?></span></li>
              <?php endforeach; ?>
              <?php if ($policy['blocked'] === []): ?><li class="text-muted">— tidak ada —</li><?php endif; ?>
            </ul>
            <?php else: ?>
            <p class="small text-muted mb-0"><?= count($policy['blocked']) ?> kemampuan berisiko diblokir sesuai aturan program.</p>
            <?php endif; ?>
          </div>
        </div>
        <div class="alert alert-light border small mt-3 mb-0"><i class="bi bi-shield-check me-1"></i>Kemampuan <b>Blocked</b> ditolak oleh gerbang Policy — tidak ada jalur eksekusi yang memintasnya.</div>
      <?php endif; ?>
    </div>
  </div>
</div>

<?= $this->endSection() ?>
<?= $this->section('page_scripts') ?>
<script>
document.getElementById('polForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const b = document.getElementById('parseBtn'), m = document.getElementById('polMsg');
  b.disabled = true; const o = b.innerHTML; b.innerHTML = '<span class="spinner-border spinner-border-sm"></span> AI menganalisis…';
  const d = await casaPost('<?= esc(site_url('projects/' . $pid . '/policy/parse')) ?>', new FormData(e.target));
  if (d.ok) { window.location = d.redirect; }
  else { m.className = 'small ms-2 text-danger'; m.textContent = d.error || 'Gagal.'; b.disabled = false; b.innerHTML = o; }
});
</script>
<?= $this->endSection() ?>
