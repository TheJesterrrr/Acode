<?php

declare(strict_types=1);

namespace App\Modules\Policy\Controllers;

use App\Controllers\BaseController;
use App\Modules\Policy\Services\PolicyEngine;
use App\Modules\Project\Models\ProjectModel;
use CodeIgniter\Exceptions\PageNotFoundException;
use CodeIgniter\HTTP\ResponseInterface;
use RuntimeException;

/**
 * PolicyController — Policy Engine per project (CES 13.2 thin, endpoint member).
 * Rule Parser (AI) mengubah aturan program menjadi daftar Allowed/Blocked.
 */
final class PolicyController extends BaseController
{
    public function __construct(
        private readonly PolicyEngine $engine = new PolicyEngine(),
        private readonly ProjectModel $projects = new ProjectModel(),
    ) {
    }

    private function me(): int
    {
        return (int) $this->session->get('member_id');
    }

    public function show(int $projectId): string
    {
        $project = $this->projects->ownedBy($projectId, $this->me());
        if ($project === null) {
            throw PageNotFoundException::forPageNotFound('Project tidak ditemukan.');
        }

        return $this->memberView('App\Modules\Policy\Views\policy', [
            'title'   => 'Policy — ' . $project['name'],
            'project' => $project,
            'policy'  => $this->engine->getPolicy($projectId, $this->me()),
        ], 'projects');
    }

    public function parse(int $projectId): ResponseInterface
    {
        if ($r = $this->denyViewer()) {
            return $r;
        }
        try {
            $this->engine->parseRules($projectId, $this->me(), (string) $this->request->getPost('rules'));
        } catch (RuntimeException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok(['message' => 'Policy dihasilkan.', 'redirect' => site_url('projects/' . $projectId . '/policy')]);
    }
}
