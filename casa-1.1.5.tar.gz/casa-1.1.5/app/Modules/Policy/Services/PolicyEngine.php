<?php

declare(strict_types=1);

namespace App\Modules\Policy\Services;

use App\Modules\Ai\Services\AiManager;
use App\Modules\Policy\Models\PolicyModel;
use App\Modules\Project\Models\ProjectModel;
use App\Modules\Project\Models\ScopeModel;
use App\Modules\ToolManager\Models\ToolModel;
use RuntimeException;

/**
 * PolicyEngine — gerbang wajib sebelum eksekusi (Master Plan §4). Membaca aturan
 * program lewat AI Rule Parser (peran 'rule_parser'), menghasilkan Policy: daftar
 * tool Allowed vs Blocked + parameter batas. Tidak ada jalur eksekusi yang boleh
 * memintas {@see isToolAllowed()} (prasyarat legal/etis, bukan sekadar fitur).
 */
final class PolicyEngine
{
    /** Pemetaan batasan → tool yang diblokir (dengan alasan). */
    private const BLOCK_MAP = [
        'no_bruteforce'           => [['hydra', 'brute-force dilarang'], ['medusa', 'brute-force dilarang'], ['ncrack', 'brute-force dilarang'], ['patator', 'brute-force dilarang']],
        'no_dos'                  => [['slowloris', 'DoS dilarang'], ['t50', 'flooding/DoS dilarang'], ['nuclei-dos', 'template DoS Nuclei dinonaktifkan']],
        'no_aggressive_injection' => [['sqlmap-aggressive', 'injeksi agresif (--risk/--level tinggi) dilarang'], ['commix', 'command injection agresif dilarang']],
    ];

    private const SYS = 'You convert bug-bounty / pentest program rules into STRICT JSON. '
        . 'Output ONLY one JSON object, no prose, no code fence. Schema: '
        . '{"no_bruteforce":boolean,"no_dos":boolean,"no_aggressive_injection":boolean,'
        . '"rate_limit_rps":integer|null,"out_of_scope":[string],"summary":string}. '
        . 'Infer each boolean true when the rules forbid that activity.';

    public function __construct(
        private readonly PolicyModel $policies = new PolicyModel(),
        private readonly ProjectModel $projects = new ProjectModel(),
        private readonly ScopeModel $scopes = new ScopeModel(),
        private readonly ToolModel $tools = new ToolModel(),
        private readonly AiManager $ai = new AiManager(),
    ) {
    }

    /**
     * Parse aturan program dengan AI Rule Parser → simpan Policy. Bila teks
     * kosong dipakai info scope project. @throws RuntimeException (404/AI gagal)
     */
    public function parseRules(int $projectId, int $customerId, string $rulesText): array
    {
        $project = $this->requireOwned($projectId, $customerId);
        $rulesText = trim($rulesText);

        $user = "Program rules:\n" . ($rulesText !== '' ? $rulesText : '(tidak ada teks; simpulkan dari scope)')
            . "\n\nProject: " . $project['name']
            . "\nrate_limit(req/s): " . ($project['rate_limit'] ?? 'n/a')
            . "\nauth_required: " . (! empty($project['auth_required']) ? 'yes' : 'no')
            . "\nbusiness_critical: " . ($project['business_critical'] ?? '-');

        $raw         = $this->ai->chatForRole('rule_parser', self::SYS, $user);
        $constraints = $this->extractConstraints($raw, $rulesText);

        $this->persist($projectId, $constraints, $rulesText, 'ai');

        return $this->getPolicy($projectId, $customerId);
    }

    /**
     * Pastikan project punya policy — untuk alur Quick Assessment (orang awam).
     * Bila belum ada, terapkan policy default aman (recon + web + vuln non-destruktif;
     * tool agresif/DoS tetap tak dijalankan karena gerbang planner). Idempoten.
     */
    public function ensureDefault(int $projectId, int $customerId): void
    {
        $this->requireOwned($projectId, $customerId);
        if (! empty($this->getPolicy($projectId, $customerId)['exists'])) {
            return;
        }
        $this->persist($projectId, [
            'summary'                 => 'Policy default aman (Quick Assessment) — recon, enumerasi, & pemindaian non-destruktif; brute-force/DoS/injeksi agresif diblokir.',
            'no_bruteforce'           => true,
            'no_dos'                  => true,
            'no_aggressive_injection' => true,
        ], '', 'default');
    }

    /** Policy tersimpan (ter-decode). @throws RuntimeException 404 */
    public function getPolicy(int $projectId, int $customerId): array
    {
        $this->requireOwned($projectId, $customerId);
        $row = $this->policies->forProject($projectId);
        if ($row === null) {
            return ['exists' => false, 'allowed' => [], 'blocked' => [], 'constraints' => [], 'summary' => null, 'source' => null];
        }

        return [
            'exists'      => true,
            'allowed'     => json_decode((string) $row['allowed'], true) ?: [],
            'blocked'     => json_decode((string) $row['blocked'], true) ?: [],
            'constraints' => json_decode((string) $row['constraints'], true) ?: [],
            'summary'     => $row['summary'],
            'source'      => $row['source'],
            'raw_rules'   => $row['raw_rules'],
        ];
    }

    /**
     * GERBANG: apakah tool boleh dijalankan untuk project ini. Tanpa policy →
     * DILARANG (secure by default). Blocked → dilarang.
     */
    public function isToolAllowed(int $projectId, string $toolCode): bool
    {
        $row = $this->policies->forProject($projectId);
        if ($row === null) {
            return false;
        }
        $blocked = array_column(json_decode((string) $row['blocked'], true) ?: [], 'code');
        if (in_array($toolCode, $blocked, true)) {
            return false;
        }
        $allowed = json_decode((string) $row['allowed'], true) ?: [];

        return in_array($toolCode, $allowed, true);
    }

    // ---- internal --------------------------------------------------------

    private function persist(int $projectId, array $c, string $rules, string $source): void
    {
        $blocked = [];
        foreach (self::BLOCK_MAP as $flag => $entries) {
            if (! empty($c[$flag])) {
                foreach ($entries as [$code, $reason]) {
                    $blocked[] = ['code' => $code, 'reason' => $reason];
                }
            }
        }
        $blockedCodes = array_column($blocked, 'code');

        // Allowed = katalog tool aman yang tidak diblokir.
        $allowed = [];
        foreach ($this->tools->catalog() as $t) {
            if (! in_array($t['code'], $blockedCodes, true)) {
                $allowed[] = $t['code'];
            }
        }

        $this->policies->save2($projectId, [
            'allowed'     => json_encode($allowed, JSON_UNESCAPED_SLASHES),
            'blocked'     => json_encode($blocked, JSON_UNESCAPED_SLASHES),
            'constraints' => json_encode($c, JSON_UNESCAPED_SLASHES),
            'source'      => $source,
            'summary'     => mb_substr((string) ($c['summary'] ?? ''), 0, 255) ?: null,
            'raw_rules'   => $rules !== '' ? mb_substr($rules, 0, 4000) : null,
        ]);
    }

    /** Ambil objek JSON dari jawaban model; fallback pemindaian kata kunci. */
    private function extractConstraints(string $text, string $rulesText): array
    {
        $json = null;
        if (preg_match('/\{.*\}/s', $text, $m)) {
            $json = json_decode($m[0], true);
        }
        if (! is_array($json)) {
            $json = $this->keywordScan($rulesText);
        }

        return [
            'no_bruteforce'           => (bool) ($json['no_bruteforce'] ?? false),
            'no_dos'                  => (bool) ($json['no_dos'] ?? false),
            'no_aggressive_injection' => (bool) ($json['no_aggressive_injection'] ?? false),
            'rate_limit_rps'          => isset($json['rate_limit_rps']) && $json['rate_limit_rps'] !== null ? (int) $json['rate_limit_rps'] : null,
            'out_of_scope'            => array_values(array_filter(array_map('strval', (array) ($json['out_of_scope'] ?? [])))),
            'summary'                 => (string) ($json['summary'] ?? ''),
        ];
    }

    /** Fallback tanpa AI: deteksi kasar dari kata kunci aturan. */
    private function keywordScan(string $rules): array
    {
        $r = mb_strtolower($rules);

        return [
            'no_bruteforce'           => (bool) preg_match('/brute[\s-]?force|bruteforce/', $r),
            'no_dos'                  => (bool) preg_match('/\bdos\b|denial of service|ddos/', $r),
            'no_aggressive_injection' => (bool) preg_match('/aggressive|sqlmap|--risk|--level/', $r),
            'rate_limit_rps'          => preg_match('/(\d+)\s*(?:req|request)s?\s*\/?\s*s/', $r, $mm) ? (int) $mm[1] : null,
            'out_of_scope'            => [],
            'summary'                 => 'Diparse dari kata kunci (AI tidak menghasilkan JSON).',
        ];
    }

    /** @return array<string,mixed> @throws RuntimeException bila bukan milik member */
    private function requireOwned(int $projectId, int $customerId): array
    {
        $p = $this->projects->ownedBy($projectId, $customerId);
        if ($p === null) {
            throw new RuntimeException('Project tidak ditemukan.');
        }

        return $p;
    }
}
