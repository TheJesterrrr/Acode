<?php

declare(strict_types=1);

namespace App\Modules\Policy\Models;

use CodeIgniter\Model;

/** PolicyModel — tabel `policy` (CES 13.3). Satu baris per project (upsert). */
final class PolicyModel extends Model
{
    protected $table            = 'policy';
    protected $primaryKey       = 'project_id';
    protected $returnType       = 'array';
    protected $useTimestamps    = false;
    protected $useAutoIncrement = false;
    protected $allowedFields    = ['project_id', 'allowed', 'blocked', 'constraints', 'source', 'summary', 'raw_rules'];

    public function forProject(int $projectId): ?array
    {
        return $this->find($projectId);
    }

    public function save2(int $projectId, array $fields): void
    {
        $fields['project_id'] = $projectId;
        if ($this->find($projectId) !== null) {
            unset($fields['project_id']);
            $this->update($projectId, $fields);
        } else {
            $this->insert($fields, false);
        }
    }
}
