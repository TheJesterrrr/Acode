# Modul Policy — Policy Engine

Gerbang wajib sebelum eksekusi (Master Plan §4 "Batas kritis keamanan"; §9 no.4).
Membaca aturan program lewat **AI Rule Parser** (peran `rule_parser`), menghasilkan
Policy per project: daftar tool **Allowed** vs **Blocked** + parameter batas.

## Isi
- Migrasi `policy` (satu baris per project).
- `Models/PolicyModel`.
- `Services/PolicyEngine` — `parseRules()` (AI), `getPolicy()`, dan **gerbang `isToolAllowed()`**. Memetakan batasan (no_bruteforce/no_dos/no_aggressive_injection/rate_limit/out_of_scope) ke daftar Blocked; Allowed = katalog Tool Manager yang tidak diblokir.
- `Controllers/PolicyController` — thin (member), memakai `member_id` sesi.
- `Config/Routes.php` — `projects/(:num)/policy` (member + audit).
- `Views/policy.php` — tempel aturan → parse → tampil Allowed/Blocked + batasan.

## Gerbang (tidak boleh dipintas)
`PolicyEngine::isToolAllowed($projectId, $toolCode)` — **secure by default**: tanpa
policy → semua DILARANG; tool pada daftar Blocked → DILARANG. Engine/Mission WAJIB
memanggil gerbang ini sebelum menjalankan tool apa pun (Master Plan §4).

## AI Rule Parser
Memakai `AiManager::chatForRole('rule_parser', …)` → JSON batasan. Provider/model
dari AI Settings (default lab: Ollama `qwen2.5:1.5b`, gratis & lokal). Bila model
tidak menghasilkan JSON valid, ada fallback pemindaian kata kunci (aman, tetap
menghasilkan policy).

## Roadmap
Ambil aturan otomatis dari URL program (fetch + parse), pemetaan Blocked yang
lebih kaya per kategori tool, dan penerapan rate limit ke parameter eksekusi Engine.
