<?php

declare(strict_types=1);

use CodeIgniter\Router\RouteCollection;

/** Rute modul Policy — endpoint MEMBER, per project (CES 13.10). */

/** @var RouteCollection $routes */
$routes->group('projects/(:num)/policy', ['namespace' => 'App\Modules\Policy\Controllers', 'filter' => 'member'], static function (RouteCollection $routes): void {
    $routes->get('', 'PolicyController::show/$1');
    $routes->post('parse', 'PolicyController::parse/$1', ['filter' => 'audit:POLICY_PARSE']);
});
