<?php

declare(strict_types=1);

use CodeIgniter\Router\RouteCollection;

/** Rute Compliance — postur OWASP/CWE (member). */

/** @var RouteCollection $routes */
$routes->group('compliance', ['namespace' => 'App\Modules\Compliance\Controllers', 'filter' => 'member'], static function (RouteCollection $routes): void {
    $routes->get('', 'ComplianceController::index');
});
