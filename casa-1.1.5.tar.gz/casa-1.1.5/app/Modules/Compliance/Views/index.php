<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<?php
/** @var array $owasp @var array $cwe */
$top10 = [
    'A01' => 'Broken Access Control', 'A02' => 'Cryptographic Failures', 'A03' => 'Injection',
    'A04' => 'Insecure Design', 'A05' => 'Security Misconfiguration', 'A06' => 'Vulnerable & Outdated Components',
    'A07' => 'Identification & Authentication Failures', 'A08' => 'Software & Data Integrity Failures',
    'A09' => 'Security Logging & Monitoring Failures', 'A10' => 'Server-Side Request Forgery (SSRF)',
];
$sevMeta = ['crit' => 'danger', 'high' => 'warning', 'med' => 'info', 'low' => 'secondary', 'info' => 'light'];
$affected = count(array_filter($top10, static fn ($_, $c) => ! empty($owasp[$c]['total']), ARRAY_FILTER_USE_BOTH));
?>
<div class="casa-page-head">
  <div>
    <h1 class="mb-0"><i class="bi bi-clipboard2-check me-1"></i>Compliance</h1>
    <div class="small text-muted">Postur temuan terhadap OWASP Top-10 (2021) — <?= (int) $affected ?> dari 10 kategori terdampak.</div>
  </div>
</div>

<div class="row g-3">
  <div class="col-lg-8">
    <div class="casa-card p-0 h-100">
      <div class="p-3 border-bottom" style="border-color:var(--casa-card-brd)!important"><h2 class="h6 mb-0">OWASP Top-10 (2021)</h2></div>
      <div class="table-responsive"><table class="table align-middle mb-0">
        <tbody>
          <?php foreach ($top10 as $code => $label): $d = $owasp[$code] ?? null; $tot = (int) ($d['total'] ?? 0); ?>
            <tr>
              <td class="ps-3" style="width:56px"><span class="badge text-bg-<?= $tot > 0 ? 'dark' : 'light border' ?>"><?= $code ?></span></td>
              <td><div class="fw-semibold small"><?= esc($label) ?></div>
                <?php if ($tot > 0): ?>
                  <div class="d-flex gap-1 mt-1">
                    <?php foreach ($sevMeta as $sk => $sc): if (! empty($d['sev'][$sk])): ?>
                      <span class="badge text-bg-<?= $sc ?>"><?= ucfirst($sk[0]) ?><?= (int) $d['sev'][$sk] ?></span>
                    <?php endif; endforeach; ?>
                  </div>
                <?php endif; ?>
              </td>
              <td class="pe-3 text-end" style="width:100px">
                <?php if ($tot > 0): ?><a href="<?= esc(site_url('vulnerabilities?q=' . urlencode($code))) ?>" class="badge text-bg-danger text-decoration-none"><?= $tot ?> temuan</a>
                <?php else: ?><span class="badge text-bg-success"><i class="bi bi-check"></i> bersih</span><?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table></div>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="casa-card p-3 p-lg-4 h-100">
      <h2 class="h6 mb-3">CWE teratas</h2>
      <?php foreach ($cwe as $c): ?>
        <div class="d-flex justify-content-between align-items-center py-1 border-bottom small" style="border-color:var(--casa-card-brd)!important">
          <span class="font-monospace"><?= esc($c['c']) ?></span><span class="badge text-bg-secondary"><?= (int) $c['n'] ?></span>
        </div>
      <?php endforeach; ?>
      <?php if ($cwe === []): ?><p class="text-muted small mb-0">Belum ada temuan ber-CWE.</p><?php endif; ?>
    </div>
  </div>
</div>
<?= $this->endSection() ?>
