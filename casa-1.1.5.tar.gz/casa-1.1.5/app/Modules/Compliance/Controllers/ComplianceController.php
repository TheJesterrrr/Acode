<?php

declare(strict_types=1);

namespace App\Modules\Compliance\Controllers;

use App\Controllers\BaseController;
use App\Modules\Finding\Models\FindingModel;

/**
 * ComplianceController — postur kepatuhan member: sebaran temuan pada OWASP
 * Top-10 (2021) + CWE teratas. Membantu menunjukkan cakupan &  celah keamanan.
 */
final class ComplianceController extends BaseController
{
    public function __construct(private readonly FindingModel $findings = new FindingModel())
    {
    }

    private function me(): int
    {
        return (int) $this->session->get('member_id');
    }

    public function index(): string
    {
        $cid = $this->me();

        // Agregasi OWASP code => {total, severity breakdown}.
        $owasp = [];
        foreach ($this->findings->owaspBySeverity($cid) as $r) {
            if (! preg_match('/A0?(\d{1,2})/i', (string) $r['o'], $m)) {
                continue;
            }
            $code                       = 'A' . str_pad($m[1], 2, '0', STR_PAD_LEFT);
            $owasp[$code]['total']      = ($owasp[$code]['total'] ?? 0) + (int) $r['n'];
            $owasp[$code]['sev'][$r['s']] = (int) $r['n'];
        }

        return $this->memberView('App\Modules\Compliance\Views\index', [
            'title'  => 'Compliance',
            'owasp'  => $owasp,
            'cwe'    => $this->findings->cweTop($cid),
        ], 'compliance');
    }
}
