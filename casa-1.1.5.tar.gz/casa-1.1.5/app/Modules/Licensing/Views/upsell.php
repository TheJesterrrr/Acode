<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<?php /** @var string $feature @var array $edition */ ?>
<div class="casa-page-head"><div><h1 class="mb-0"><i class="bi bi-lock me-1"></i><?= esc($feature) ?></h1></div></div>
<div class="casa-card p-4 p-lg-5 text-center" style="max-width:560px;margin:0 auto">
  <div class="mb-3"><i class="bi bi-lock-fill text-warning" style="font-size:2.4rem"></i></div>
  <h2 class="h5">Fitur ini tidak tersedia pada paket <span class="text-amber"><?= esc($edition['label']) ?></span></h2>
  <p class="text-muted"><b><?= esc($feature) ?></b> tersedia mulai paket <b>Professional</b>. Hubungi administrator CASA untuk meningkatkan paket Anda.</p>
  <a href="<?= esc(site_url('projects')) ?>" class="btn btn-outline-secondary btn-sm"><i class="bi bi-arrow-left me-1"></i>Back to Projects</a>
</div>
<?= $this->endSection() ?>
