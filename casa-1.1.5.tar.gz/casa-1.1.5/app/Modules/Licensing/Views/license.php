<?= $this->extend('layouts/admin') ?>
<?= $this->section('content') ?>
<?php
/** @var array $eff @var string $tierLbl @var bool $is_owner @var array $tiers */
$tierColor = ['community' => 'secondary', 'pro' => 'info', 'enterprise' => 'warning'];
$active    = ! empty($eff['active']);
$expired   = ! empty($eff['expired']);
?>
<div class="casa-page-head">
  <div>
    <h1><i class="bi bi-key me-1"></i>Lisensi &amp; Aktivasi</h1>
    <p class="text-muted small mb-0"><?= $is_owner ? 'Mode <b>OWNER</b>: terbitkan license key untuk pelanggan + aktivasi lokal.' : 'Aktivasi instance ini dengan license key dari owner produk.' ?></p>
  </div>
</div>

<div class="row g-3">
  <!-- Status lisensi instance -->
  <div class="col-lg-5">
    <div class="casa-card p-4 h-100">
      <h2 class="h6 mb-3">Status instance</h2>
      <div class="d-flex align-items-center gap-2 mb-3">
        <span class="badge text-bg-<?= esc($tierColor[$eff['tier']] ?? 'secondary') ?> fs-6 text-uppercase"><?= esc($tierLbl) ?></span>
        <?php if ($active): ?><span class="badge text-bg-success">Aktif</span>
        <?php elseif ($expired): ?><span class="badge text-bg-danger">Kedaluwarsa → Community</span>
        <?php else: ?><span class="badge text-bg-secondary">Belum diaktivasi (Community)</span><?php endif; ?>
      </div>
      <dl class="row small mb-0">
        <dt class="col-5 text-muted">Customer</dt><dd class="col-7"><?= esc($eff['customer'] ?? '—') ?></dd>
        <dt class="col-5 text-muted">License ID</dt><dd class="col-7 font-monospace"><?= esc($eff['license_id'] ?? '—') ?></dd>
        <dt class="col-5 text-muted">Kedaluwarsa</dt><dd class="col-7"><?= esc($eff['exp'] ?? '∞') ?></dd>
      </dl>
    </div>
  </div>

  <!-- Aktivasi -->
  <div class="col-lg-7">
    <div class="casa-card p-4 h-100">
      <h2 class="h6 mb-3">Aktivasi license key</h2>
      <form id="actForm">
        <textarea name="token" class="form-control font-monospace mb-2" rows="4" placeholder="Tempel license key dari owner di sini…" required></textarea>
        <button id="actBtn" class="btn btn-primary"><i class="bi bi-unlock me-1"></i>Activate</button>
        <span id="actMsg" class="small ms-2"></span>
      </form>
      <div class="small text-muted mt-2"><i class="bi bi-info-circle me-1"></i>Belum punya key Pro/Enterprise? Hubungi owner produk. Community jalan tanpa key.</div>
    </div>
  </div>

  <?php if (! $is_owner): ?>
  <!-- Sinkron Online (produk VPS) -->
  <div class="col-12">
    <div class="casa-card p-4" style="border:1px solid var(--casa-amber)">
      <h2 class="h6 mb-1"><i class="bi bi-arrow-repeat text-warning me-1"></i>Sinkron Online <span class="text-muted small">(disarankan)</span></h2>
      <p class="text-muted small mb-3">Tempel <b>Kode Sinkron</b> dari akun casamember Anda (menu Akun Saya) — instance akan menarik lisensi sesuai langganan secara otomatis, tanpa salin-tempel license key. Cukup sekali; berikutnya berjalan otomatis via cron.</p>
      <div class="row g-2 align-items-end">
        <div class="col-md-7">
          <label class="form-label small">Kode Sinkron<?= $sync_secret_set ? ' <span class="badge text-bg-success">tersimpan</span>' : '' ?></label>
          <div class="input-group">
            <input id="syncSecret" class="form-control font-monospace" placeholder="<?= $sync_secret_set ? '•••••••• (tersimpan — isi untuk mengganti)' : 'Tempel kode sinkron di sini…' ?>">
            <button class="btn btn-outline-secondary" type="button" id="saveSecretBtn">Save</button>
          </div>
        </div>
        <div class="col-md-5">
          <button id="syncBtn" class="btn btn-amber"<?= $sync_secret_set ? '' : ' disabled' ?>><i class="bi bi-cloud-download me-1"></i>Sync now</button>
          <span id="syncMsg" class="small ms-2"></span>
        </div>
      </div>
      <?php if ($sync_url === ''): ?>
        <div class="small text-danger mt-2"><i class="bi bi-exclamation-triangle me-1"></i><code>sync.url</code> belum diatur di <code>.env</code> instance ini.</div>
      <?php endif; ?>
    </div>
  </div>
  <?php endif; ?>

  <?php if ($is_owner): ?>
  <!-- Generator (OWNER only) -->
  <div class="col-12">
    <div class="casa-card p-4" style="border:1px solid var(--casa-amber)">
      <h2 class="h6 mb-1"><i class="bi bi-stars text-warning me-1"></i>Generator License Key — <span class="text-warning">OWNER</span></h2>
      <p class="text-muted small">Issue a signed key for the customer. The private key only exists in this console.</p>
      <form id="genForm" class="row g-2 align-items-end">
        <div class="col-md-3"><label class="form-label small">Tier</label>
          <select name="tier" class="form-select">
            <?php foreach ($tiers as $k => $t): if ($k === 'community') { continue; } ?><option value="<?= esc($k) ?>"><?= esc($t['label']) ?></option><?php endforeach; ?>
          </select></div>
        <div class="col-md-3"><label class="form-label small">Masa (hari, 0=selamanya)</label>
          <input name="days" type="number" min="0" value="7" class="form-control"></div>
        <div class="col-md-4"><label class="form-label small">Nama customer</label>
          <input name="customer" class="form-control" placeholder="PT Contoh"></div>
        <div class="col-md-2"><button id="genBtn" class="btn btn-amber w-100"><i class="bi bi-key me-1"></i>Issue</button></div>
      </form>
      <div class="mt-3 d-none" id="genOut">
        <label class="form-label small">License key (kirim ke customer):</label>
        <div class="input-group">
          <textarea id="genToken" class="form-control font-monospace" rows="3" readonly></textarea>
          <button class="btn btn-outline-secondary" id="copyBtn" type="button"><i class="bi bi-clipboard"></i></button>
        </div>
      </div>
      <div id="genMsg" class="small mt-2"></div>
    </div>
  </div>
  <?php endif; ?>
</div>
<?= $this->endSection() ?>

<?= $this->section('page_scripts') ?>
<script>
const L = { activate: '<?= esc(site_url('casaadmin/license/activate')) ?>', generate: '<?= esc(site_url('casaadmin/license/generate')) ?>', secret: '<?= esc(site_url('casaadmin/license/sync-secret')) ?>', sync: '<?= esc(site_url('casaadmin/license/sync')) ?>' };
<?php if (! $is_owner): ?>
document.getElementById('saveSecretBtn').addEventListener('click', async () => {
  const m = document.getElementById('syncMsg'), v = document.getElementById('syncSecret').value.trim();
  if (!v) { m.className = 'small ms-2 text-danger'; m.textContent = 'Isi kode sinkron.'; return; }
  const d = await casaPost(L.secret, { secret: v });
  if (d.ok) { m.className = 'small ms-2 text-success'; m.textContent = 'Kode tersimpan.'; document.getElementById('syncBtn').disabled = false; }
  else { m.className = 'small ms-2 text-danger'; m.textContent = d.error || 'Gagal.'; }
});
document.getElementById('syncBtn').addEventListener('click', async () => {
  const b = document.getElementById('syncBtn'), m = document.getElementById('syncMsg');
  b.disabled = true; const o = b.innerHTML; b.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Menyinkron…';
  const d = await casaPost(L.sync, {});
  b.disabled = false; b.innerHTML = o;
  if (d.ok) { m.className = 'small ms-2 text-success'; m.textContent = d.community ? 'Tak ada langganan aktif — Community.' : ('Aktif: ' + d.tier + (d.exp ? ' s/d ' + d.exp : '')); setTimeout(() => location.reload(), 1200); }
  else { m.className = 'small ms-2 text-danger'; m.textContent = d.error || 'Gagal.'; }
});
<?php endif; ?>
document.getElementById('actForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const b = document.getElementById('actBtn'), m = document.getElementById('actMsg');
  b.disabled = true; const o = b.innerHTML; b.innerHTML = '<span class="spinner-border spinner-border-sm"></span>';
  const d = await casaPost(L.activate, new FormData(e.target));
  if (d.ok) { m.className = 'small ms-2 text-success'; m.textContent = 'Aktif: ' + d.tier + (d.exp ? ' s/d ' + d.exp : ''); setTimeout(() => location.reload(), 900); }
  else { b.disabled = false; b.innerHTML = o; m.className = 'small ms-2 text-danger'; m.textContent = d.error || 'Gagal.'; }
});
<?php if ($is_owner): ?>
document.getElementById('genForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const b = document.getElementById('genBtn'), m = document.getElementById('genMsg');
  b.disabled = true; const o = b.innerHTML; b.innerHTML = '<span class="spinner-border spinner-border-sm"></span>';
  const d = await casaPost(L.generate, new FormData(e.target));
  b.disabled = false; b.innerHTML = o;
  if (d.ok) { document.getElementById('genOut').classList.remove('d-none'); document.getElementById('genToken').value = d.token; m.textContent = ''; }
  else { m.className = 'small mt-2 text-danger'; m.textContent = d.error || 'Gagal.'; }
});
document.getElementById('copyBtn').addEventListener('click', () => {
  const t = document.getElementById('genToken'); t.select(); document.execCommand('copy');
});
<?php endif; ?>
</script>
<?= $this->endSection() ?>
