<?= $this->extend('layouts/admin') ?>
<?= $this->section('content') ?>
<?php
/** @var int $total @var int $active @var array $by_tier @var array $rows */
$tierColor = ['community' => 'secondary', 'pro' => 'info', 'enterprise' => 'warning'];
$cut = strtotime('-3 days');
?>
<div class="casa-page-head">
  <div>
    <h1><i class="bi bi-broadcast me-1"></i>Monitoring Instance</h1>
    <p class="text-muted small mb-0">Telemetri ringkas dari instance pelanggan (phone-home). Tanpa data sensitif pentest — hanya status, tier &amp; hitungan.</p>
  </div>
</div>

<div class="row g-2 mb-3">
  <?php foreach ([['Total instance', $total, 'amber'], ['Aktif (≤3 hari)', $active, 'success'], ['Enterprise', $by_tier['enterprise'] ?? 0, 'warning'], ['Pro', $by_tier['pro'] ?? 0, 'info']] as [$l, $n, $c]): ?>
    <div class="col-6 col-lg-3"><div class="casa-card p-3"><div class="text-muted small"><?= esc($l) ?></div><div class="fs-3 fw-semibold text-<?= esc($c) ?>"><?= (int) $n ?></div></div></div>
  <?php endforeach; ?>
</div>

<div class="casa-card p-0">
  <div class="table-responsive"><table class="table align-middle mb-0">
    <thead><tr><th class="ps-3">Instance</th><th>Customer</th><th>Tier</th><th>Lisensi</th><th class="text-center">Proj</th><th class="text-center">Misi</th><th class="text-center">Temuan</th><th>Terakhir</th></tr></thead>
    <tbody>
      <?php if ($rows === []): ?>
        <tr><td colspan="8" class="text-center text-muted py-4">Belum ada laporan phone-home dari instance mana pun.</td></tr>
      <?php else: foreach ($rows as $r): $online = strtotime((string) $r['last_seen']) >= $cut; ?>
        <tr>
          <td class="ps-3">
            <span class="d-inline-block rounded-circle me-1" style="width:8px;height:8px;background:<?= $online ? 'var(--bs-success)' : 'var(--bs-secondary)' ?>"></span>
            <span class="font-monospace small"><?= esc(substr((string) $r['install_id'], 0, 12)) ?>…</span>
            <div class="small text-muted">v<?= esc($r['version'] ?: '?') ?> · <?= esc($r['ip'] ?: '-') ?></div>
          </td>
          <td class="small"><?= esc($r['customer'] ?: '—') ?></td>
          <td><span class="badge text-bg-<?= esc($tierColor[$r['tier']] ?? 'secondary') ?> text-uppercase"><?= esc($r['tier'] ?: 'community') ?></span></td>
          <td><?= $r['valid'] ? '<span class="badge text-bg-success" title="Token lisensi terverifikasi">✓ sah</span>' : '<span class="badge text-bg-light border">—</span>' ?><div class="small text-muted font-monospace"><?= esc($r['license_id'] ?: '') ?></div></td>
          <td class="text-center"><?= (int) $r['projects'] ?></td>
          <td class="text-center"><?= (int) $r['missions'] ?></td>
          <td class="text-center"><span class="badge text-bg-dark border"><?= (int) $r['findings'] ?></span></td>
          <td class="small text-muted"><?= esc($r['last_seen'] ?: '-') ?></td>
        </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table></div>
</div>
<?= $this->endSection() ?>
