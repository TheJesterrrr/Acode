<?= $this->extend('layouts/admin') ?>
<?= $this->section('content') ?>
<?php
/** @var array $customers @var array $tiers */
$tierBadge = ['community' => 'secondary', 'pro' => 'info', 'enterprise' => 'amber'];
?>
<div class="casa-page-head">
  <div>
    <h1>Lisensi &amp; Edisi</h1>
    <p class="text-muted small mb-0">Tetapkan paket tiap pelanggan — Community / Professional / Enterprise. Gate fitur &amp; kuota mengikuti tier (bisa di-override).</p>
  </div>
</div>

<div class="row g-2 mb-3">
  <?php foreach ($tiers as $key => $t): ?>
    <div class="col-md-4">
      <div class="casa-card p-3 h-100">
        <div class="d-flex align-items-center gap-2 mb-2">
          <span class="badge text-bg-<?= esc($tierBadge[$key] ?? 'secondary') ?> text-uppercase"><?= esc($t['label']) ?></span>
        </div>
        <ul class="small text-muted mb-0 ps-3">
          <li>Project: <?= (int) $t['quota']['projects'] === 0 ? '∞' : (int) $t['quota']['projects'] ?> · Target: <?= (int) $t['quota']['targets'] === 0 ? '∞' : (int) $t['quota']['targets'] ?> · Jadwal: <?= (int) $t['quota']['schedules'] === 0 ? '∞' : (int) $t['quota']['schedules'] ?></li>
          <li>Tools: <?= in_array('*', $t['tools'], true) ? 'semua kategori' : count($t['tools']) . ' kategori (recon)' ?></li>
          <li>Fitur: <?= implode(', ', array_keys(array_filter($t['features']))) ?: '—' ?></li>
        </ul>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<div class="casa-card p-0">
  <div class="table-responsive">
    <table class="table align-middle mb-0">
      <thead><tr><th class="ps-3">Pelanggan</th><th>Paket</th><th>Kedaluwarsa</th><th class="text-end pe-3">Aksi</th></tr></thead>
      <tbody>
        <?php if ($customers === []): ?>
          <tr><td colspan="4" class="text-center text-muted py-4">Belum ada pelanggan.</td></tr>
        <?php else: foreach ($customers as $c): ?>
          <tr>
            <td class="ps-3"><span class="fw-semibold"><?= esc($c['name']) ?></span><div class="small text-muted"><?= esc($c['email']) ?></div></td>
            <td>
              <span class="badge text-bg-<?= esc($tierBadge[$c['tier']] ?? 'secondary') ?> text-uppercase"><?= esc($c['label']) ?></span>
              <?php if ($c['expired']): ?><span class="badge text-bg-danger">kedaluwarsa</span><?php elseif (! $c['has_lic']): ?><span class="small text-muted">(default)</span><?php endif; ?>
            </td>
            <td class="small text-muted"><?= esc($c['expires_at'] ?: '—') ?></td>
            <td class="text-end pe-3">
              <button class="btn btn-sm btn-outline-primary js-set"
                data-id="<?= $c['id'] ?>" data-name="<?= esc($c['name']) ?>" data-tier="<?= esc($c['tier']) ?>" data-expires="<?= esc($c['expires_at'] ?: '') ?>">
                <i class="bi bi-key me-1"></i>Atur paket
              </button>
            </td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Modal atur paket -->
<div class="modal fade" id="licModal" tabindex="-1"><div class="modal-dialog"><div class="modal-content casa-card">
  <div class="modal-header"><h5 class="modal-title">Atur paket — <span id="licName"></span></h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
  <div class="modal-body">
    <form id="licForm">
      <input type="hidden" name="_id" id="licId">
      <div class="mb-3"><label class="form-label small">Tier</label>
        <select name="tier" id="licTier" class="form-select">
          <?php foreach ($tiers as $key => $t): ?><option value="<?= esc($key) ?>"><?= esc($t['label']) ?></option><?php endforeach; ?>
        </select></div>
      <div class="mb-3"><label class="form-label small">Kedaluwarsa (opsional)</label>
        <input type="date" name="expires_at" id="licExpires" class="form-control"></div>
      <div class="row g-2">
        <div class="col-4"><label class="form-label small">Max Project</label><input name="max_projects" type="number" min="0" class="form-control" placeholder="default"></div>
        <div class="col-4"><label class="form-label small">Max Target</label><input name="max_targets" type="number" min="0" class="form-control" placeholder="default"></div>
        <div class="col-4"><label class="form-label small">Max Jadwal</label><input name="max_schedules" type="number" min="0" class="form-control" placeholder="default"></div>
      </div>
      <div class="form-text mb-2">Kosongkan override untuk memakai default tier. 0 = tak terbatas.</div>
      <div class="mb-2"><label class="form-label small">Catatan</label><input name="note" class="form-control" placeholder="mis. trial 30 hari"></div>
      <input type="hidden" name="status" value="active">
    </form>
    <div id="licMsg" class="small"></div>
  </div>
  <div class="modal-footer"><button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button id="licSave" class="btn btn-primary">Save</button></div>
</div></div></div>
<?= $this->endSection() ?>

<?= $this->section('page_scripts') ?>
<script>
const licModal = new bootstrap.Modal('#licModal');
document.querySelectorAll('.js-set').forEach(b => b.addEventListener('click', () => {
  const d = b.dataset;
  document.getElementById('licId').value = d.id;
  document.getElementById('licName').textContent = d.name;
  document.getElementById('licTier').value = d.tier;
  document.getElementById('licExpires').value = d.expires;
  document.getElementById('licMsg').textContent = '';
  licModal.show();
}));
document.getElementById('licSave').addEventListener('click', async () => {
  const id = document.getElementById('licId').value;
  const m = document.getElementById('licMsg');
  const d = await casaPost('<?= esc(site_url('casaadmin/licensing')) ?>/' + id + '/assign', new FormData(document.getElementById('licForm')));
  if (d.ok) { m.className = 'small text-success'; m.textContent = 'Tersimpan (' + d.tier + ')'; setTimeout(() => location.reload(), 700); }
  else { m.className = 'small text-danger'; m.textContent = d.error || 'Gagal.'; }
});
</script>
<?= $this->endSection() ?>
