<?php

declare(strict_types=1);

namespace App\Modules\Licensing\Services;

use App\Modules\Licensing\Config\Edition;
use App\Modules\Licensing\Models\LicenseModel;
use Config\Services;
use RuntimeException;

/**
 * EditionService — resolusi & penegakan edisi (Community/Pro/Enterprise).
 * Menggabungkan default tier (Config\Edition) dengan lisensi pelanggan + override
 * kuota, menangani kedaluwarsa (turun ke default), dan menyediakan gate fitur/
 * kuota/tool untuk dipakai controller & planner.
 */
final class EditionService
{
    private Edition $cfg;

    /** @var array<int,array<string,mixed>> cache per-request */
    private array $cache = [];

    public function __construct(
        private readonly LicenseModel $licenses = new LicenseModel(),
        ?Edition $cfg = null,
        private readonly LicenseKeyService $keys = new LicenseKeyService(),
    ) {
        $this->cfg = $cfg ?? config(Edition::class);
    }

    /**
     * Konfigurasi edisi efektif untuk pelanggan.
     * @return array{tier:string,label:string,status:string,features:array,quota:array,tools:array,expires_at:?string,expired:bool}
     */
    public function resolve(int $customerId): array
    {
        if (isset($this->cache[$customerId])) {
            return $this->cache[$customerId];
        }
        $tier      = $this->cfg->default;
        $expired   = false;
        $expires   = null;
        $overrides = [];
        $status    = 'active';

        // Prioritas 1: LISENSI INSTANCE (license key ter-aktivasi, model self-hosted).
        $inst = $this->keys->effective();
        if ($inst['active'] || $inst['expired']) {
            $expires = $inst['exp'] ?? null;
            $status  = $inst['expired'] ? 'expired' : 'active';
            if ($inst['expired']) {
                $expired = true;                       // turun ke tier default
            } else {
                $tier = in_array($inst['tier'], array_keys($this->cfg->tiers), true) ? $inst['tier'] : $tier;
                foreach ((array) ($inst['quotas'] ?? []) as $k => $v) {
                    $overrides[$k] = $v;
                }
            }
        } elseif (($sub = $this->activeSubscription($customerId)) !== null) {
            // Prioritas 2: LANGGANAN aktif di console owner (self-service). Badge &
            // gate pelanggan mengikuti paket yang mereka beli di portal ini.
            $expires = $sub['expires_at'] ?? null;
            $tier    = in_array($sub['tier'], array_keys($this->cfg->tiers), true) ? $sub['tier'] : $tier;
        } else {
            // Prioritas 3 (fallback SaaS/legacy): lisensi per-pelanggan di DB.
            $lic = $this->licenses->forCustomer($customerId);
            if ($lic !== null) {
                $expires = $lic['expires_at'] ?? null;
                $revoked = ($lic['status'] ?? 'active') === 'revoked';
                $past    = $expires !== null && $expires < date('Y-m-d');
                if ($revoked || $past) {
                    $expired = true;
                } else {
                    $tier      = in_array($lic['tier'] ?? '', array_keys($this->cfg->tiers), true) ? $lic['tier'] : $tier;
                    $overrides = [
                        'projects'  => $lic['max_projects'],
                        'targets'   => $lic['max_targets'],
                        'schedules' => $lic['max_schedules'],
                    ];
                }
            }
        }

        $def   = $this->cfg->tiers[$tier] ?? $this->cfg->tiers[$this->cfg->default];
        $quota = $def['quota'];
        foreach ($overrides as $k => $v) {
            if ($v !== null && $v !== '') {
                $quota[$k] = (int) $v;
            }
        }

        return $this->cache[$customerId] = [
            'tier'       => $tier,
            'label'      => $def['label'],
            'status'     => $status,
            'features'   => $def['features'],
            'quota'      => $quota,
            'tools'      => $def['tools'],
            'expires_at' => $expires,
            'expired'    => $expired,
        ];
    }

    /**
     * Langganan aktif pelanggan di console OWNER (self-service). Mengembalikan null
     * di instance produk pelanggan — di sana sumber edisi adalah license key yang
     * diaktivasi (Prioritas 1), bukan tabel langganan milik owner.
     * @return array<string,mixed>|null
     */
    private function activeSubscription(int $customerId): ?array
    {
        if ((string) (env('license.privateKey') ?: '') === '') {
            return null;
        }
        $sub = (new \App\Modules\Billing\Models\SubscriptionModel())->activeFor($customerId);
        if ($sub === null) {
            return null;
        }
        $exp = (string) ($sub['expires_at'] ?? '');

        return ($exp !== '' && $exp < date('Y-m-d')) ? null : $sub;
    }

    public function can(int $customerId, string $feature): bool
    {
        return (bool) ($this->resolve($customerId)['features'][$feature] ?? false);
    }

    /** Pastikan fitur aktif, atau lempar (dipakai controller sebagai gate). */
    public function requireFeature(int $customerId, string $feature): void
    {
        if (! $this->can($customerId, $feature)) {
            $label = $this->cfg->featureLabels[$feature] ?? $feature;
            throw new RuntimeException("Fitur \"{$label}\" tidak tersedia pada paket " . $this->resolve($customerId)['label'] . '. Upgrade untuk mengaktifkan.');
        }
    }

    /** Batas kuota (0 = tak terbatas). */
    public function quota(int $customerId, string $name): int
    {
        return (int) ($this->resolve($customerId)['quota'][$name] ?? 0);
    }

    /**
     * Pastikan penambahan tidak melebihi kuota.
     * @throws RuntimeException
     */
    public function requireQuota(int $customerId, string $name, int $current): void
    {
        $max = $this->quota($customerId, $name);
        if ($max > 0 && $current >= $max) {
            throw new RuntimeException("Batas paket " . $this->resolve($customerId)['label'] . " tercapai ({$name}: {$max}). Upgrade untuk menambah.");
        }
    }

    /** Batas scan/hari per edisi. @throws RuntimeException bila tercapai. */
    public function requireScanQuota(int $customerId, int $today): void
    {
        $max = $this->quota($customerId, 'scans_per_day');
        if ($max > 0 && $today >= $max) {
            throw new RuntimeException('Batas scan harian paket ' . $this->resolve($customerId)['label']
                . " tercapai ({$max}/hari). Coba lagi besok, atau upgrade paket untuk kuota lebih besar.");
        }
    }

    public function toolCategoryAllowed(int $customerId, string $category): bool
    {
        $tools = $this->resolve($customerId)['tools'];

        return in_array('*', $tools, true) || in_array($category, $tools, true);
    }

    /** Assign/ubah lisensi (admin). @throws RuntimeException */
    public function assign(int $customerId, array $in): void
    {
        $tier = $in['tier'] ?? '';
        if (! isset($this->cfg->tiers[$tier])) {
            throw new RuntimeException('Tier tidak valid.');
        }
        $status = in_array($in['status'] ?? '', ['active', 'revoked'], true) ? $in['status'] : 'active';
        $row    = [
            'customer_id'   => $customerId,
            'tier'          => $tier,
            'status'        => $status,
            'max_projects'  => ($in['max_projects'] ?? '') !== '' ? (int) $in['max_projects'] : null,
            'max_targets'   => ($in['max_targets'] ?? '') !== '' ? (int) $in['max_targets'] : null,
            'max_schedules' => ($in['max_schedules'] ?? '') !== '' ? (int) $in['max_schedules'] : null,
            'expires_at'    => ($in['expires_at'] ?? '') !== '' ? $in['expires_at'] : null,
            'note'          => trim((string) ($in['note'] ?? '')) ?: null,
        ];

        $existing = $this->licenses->forCustomer($customerId);
        if ($existing !== null) {
            $this->licenses->update((int) $existing['id'], $row);
        } else {
            $this->licenses->insert($row);
        }
        unset($this->cache[$customerId]);
    }

    /** @return array<string,array<string,mixed>> semua tier untuk UI */
    public function tiers(): array
    {
        return $this->cfg->tiers;
    }

    /** Ringkasan fitur untuk badge member. */
    public function featureLabels(): array
    {
        return $this->cfg->featureLabels;
    }
}
