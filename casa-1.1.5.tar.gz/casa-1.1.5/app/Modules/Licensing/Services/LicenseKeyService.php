<?php

declare(strict_types=1);

namespace App\Modules\Licensing\Services;

use App\Modules\Licensing\Config\Edition;
use App\Modules\Licensing\Models\InstanceLicenseModel;
use RuntimeException;

/**
 * LicenseKeyService — inti sistem lisensi produk self-hosted. License key =
 * token ter-tanda-tangani RSA-SHA256 (OpenSSL — tersedia hampir di semua PHP):
 * payload {tier, kuota, expired, customer} + tanda tangan private key OWNER.
 * Produk memverifikasi dgn public key yang ditanam (offline, tanpa server).
 * Owner generate; member aktivasi. Kunci disimpan sebagai base64(PEM).
 *
 * Format token: base64url(json_payload) . "." . base64url(signature)
 */
final class LicenseKeyService
{
    public function __construct(
        private readonly InstanceLicenseModel $licenses = new InstanceLicenseModel(),
        private readonly ?Edition $cfg = null,
    ) {
    }

    private function conf(): Edition
    {
        return $this->cfg ?? config(Edition::class);
    }

    // ---- OWNER: buat pasangan kunci & tanda tangani key --------------------

    /**
     * Hasilkan sepasang kunci RSA-2048. @return array{public:string,private:string} (base64 PEM)
     */
    public function generateKeypair(): array
    {
        $res = openssl_pkey_new(['private_key_bits' => 2048, 'private_key_type' => OPENSSL_KEYTYPE_RSA]);
        if ($res === false) {
            throw new RuntimeException('Gagal membuat kunci RSA (OpenSSL).');
        }
        openssl_pkey_export($res, $privPem);
        $pubPem = (string) (openssl_pkey_get_details($res)['key'] ?? '');

        return [
            'public'  => base64_encode($pubPem),
            'private' => base64_encode((string) $privPem),
        ];
    }

    /**
     * Tanda tangani license key (sisi OWNER; butuh private key base64(PEM)).
     * @param array{tier:string,customer?:string,days?:int,quotas?:array,license_id?:string} $in
     * @throws RuntimeException
     */
    public function sign(array $in, string $privateKeyB64): string
    {
        $pem = base64_decode($privateKeyB64, true);
        $sk  = $pem !== false ? openssl_pkey_get_private($pem) : false;
        if ($sk === false) {
            throw new RuntimeException('Private key tidak valid.');
        }
        $tier = in_array($in['tier'] ?? '', ['community', 'pro', 'enterprise'], true) ? $in['tier'] : 'pro';
        $days = (int) ($in['days'] ?? 0);
        $payload = array_filter([
            'v'    => 1,
            'lid'  => $in['license_id'] ?? ('CASA-' . strtoupper(bin2hex(random_bytes(4)))),
            'cust' => $in['customer'] ?? null,
            'tier' => $tier,
            'q'    => $in['quotas'] ?? null,
            'iat'  => date('Y-m-d'),
            'exp'  => $days > 0 ? date('Y-m-d', strtotime("+{$days} days")) : null,
        ], static fn ($v) => $v !== null);

        $json = json_encode($payload, JSON_UNESCAPED_SLASHES);
        $sig  = '';
        if (! openssl_sign($json, $sig, $sk, OPENSSL_ALGO_SHA256)) {
            throw new RuntimeException('Gagal menandatangani license key.');
        }

        return $this->b64url($json) . '.' . $this->b64url($sig);
    }

    // ---- MEMBER: verifikasi & aktivasi -------------------------------------

    /**
     * Verifikasi token dgn public key yang ditanam. @return array payload atau null bila invalid.
     */
    public function verify(string $token): ?array
    {
        $pkB64 = trim($this->conf()->licensePublicKey);
        if ($pkB64 === '') {
            return null; // produk belum ditanami public key
        }
        $pem = base64_decode($pkB64, true);
        $pk  = $pem !== false ? openssl_pkey_get_public($pem) : false;
        if ($pk === false) {
            return null;
        }
        $parts = explode('.', trim($token));
        if (count($parts) !== 2) {
            return null;
        }
        $json = $this->b64urlDecode($parts[0]);
        $sig  = $this->b64urlDecode($parts[1]);
        if ($json === '' || $sig === '' || openssl_verify($json, $sig, $pk, OPENSSL_ALGO_SHA256) !== 1) {
            return null;
        }
        $p = json_decode($json, true);

        return is_array($p) ? $p : null;
    }

    public function isExpired(array $payload): bool
    {
        return ! empty($payload['exp']) && $payload['exp'] < date('Y-m-d');
    }

    /**
     * Aktivasi: verifikasi lalu simpan sebagai lisensi instance. @throws RuntimeException
     * @return array payload
     */
    public function activate(string $token): array
    {
        $p = $this->verify($token);
        if ($p === null) {
            throw new RuntimeException('License key tidak valid atau tanda tangan tidak cocok.');
        }
        if ($this->isExpired($p)) {
            throw new RuntimeException('License key sudah kedaluwarsa (' . ($p['exp'] ?? '') . ').');
        }
        $row = [
            'token'        => trim($token),
            'license_id'   => $p['lid'] ?? null,
            'customer'     => $p['cust'] ?? null,
            'tier'         => $p['tier'] ?? 'community',
            'quotas'       => isset($p['q']) ? json_encode($p['q'], JSON_UNESCAPED_SLASHES) : null,
            'issued_at'    => $p['iat'] ?? null,
            'expires_at'   => $p['exp'] ?? null,
            'activated_at' => date('Y-m-d H:i:s'),
            'updated_at'   => date('Y-m-d H:i:s'),
        ];
        $cur = $this->licenses->current();
        if ($cur !== null) {
            $this->licenses->update((int) $cur['id'], $row);
        } else {
            $this->licenses->insert($row);
        }

        return $p;
    }

    /**
     * Lisensi instance efektif: {tier, quotas, expired, customer, exp, active}.
     * tier turun ke 'community' bila tak ada key / kedaluwarsa (re-verifikasi token).
     * @return array<string,mixed>
     */
    public function effective(): array
    {
        $default = ['tier' => 'community', 'quotas' => null, 'expired' => false, 'active' => false, 'customer' => null, 'exp' => null, 'license_id' => null];
        $cur = $this->licenses->current();
        if ($cur === null) {
            return $default;
        }
        // Re-verifikasi token tersimpan (cegah manipulasi baris DB).
        $p = $this->verify((string) $cur['token']);
        if ($p === null) {
            return $default;
        }
        if ($this->isExpired($p)) {
            return ['tier' => 'community', 'quotas' => null, 'expired' => true, 'active' => false, 'customer' => $p['cust'] ?? null, 'exp' => $p['exp'] ?? null, 'license_id' => $p['lid'] ?? null];
        }

        return [
            'tier'       => $p['tier'] ?? 'community',
            'quotas'     => $p['q'] ?? null,
            'expired'    => false,
            'active'     => true,
            'customer'   => $p['cust'] ?? null,
            'exp'        => $p['exp'] ?? null,
            'license_id' => $p['lid'] ?? null,
        ];
    }

    private function b64url(string $s): string
    {
        return rtrim(strtr(base64_encode($s), '+/', '-_'), '=');
    }

    private function b64urlDecode(string $s): string
    {
        $d = base64_decode(strtr($s, '-_', '+/'), true);

        return $d === false ? '' : $d;
    }
}
