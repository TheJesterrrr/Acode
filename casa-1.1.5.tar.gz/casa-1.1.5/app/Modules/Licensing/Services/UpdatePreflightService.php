<?php

declare(strict_types=1);

namespace App\Modules\Licensing\Services;

use App\Modules\Licensing\Config\Edition;

/**
 * UpdatePreflightService — "cek dulu bakal sukses apa tidak" SEBELUM menekan
 * Upgrade. Menguji syarat yang dibutuhkan `casa:apply-update`: fungsi exec,
 * biner (tar/mysqldump/gzip), folder bisa ditulis, ruang disk cukup, kredensial
 * DB ada, dan ada paket yang siap. Setiap item mengembalikan status + saran
 * perbaikan — jadi kegagalan ketahuan di awal, bukan di tengah update.
 */
final class UpdatePreflightService
{
    public function __construct(
        private readonly LicenseSyncService $sync = new LicenseSyncService(),
    ) {
    }

    private function root(): string
    {
        return dirname(rtrim(APPPATH, '/\\'));
    }

    private function writable(string $sub = ''): string
    {
        $p = rtrim(WRITEPATH, '/\\');

        return $sub === '' ? $p : $p . DIRECTORY_SEPARATOR . $sub;
    }

    /** @return bool biner ada di PATH */
    private function hasBin(string $bin): bool
    {
        if (! function_exists('exec')) {
            return false;
        }
        $out = [];
        $code = 1;
        @exec('command -v ' . escapeshellarg($bin) . ' 2>/dev/null', $out, $code);

        return $code === 0 && $out !== [];
    }

    private function dirWritable(string $dir): bool
    {
        if (! is_dir($dir)) {
            @mkdir($dir, 0775, true);
        }

        return is_dir($dir) && is_writable($dir);
    }

    /**
     * @return array{ok:bool,ready:bool,target:?string,file:?string,current:string,checks:list<array{key:string,label:string,ok:bool,detail:string,critical:bool,fix:string}>}
     */
    public function check(): array
    {
        $cur     = config(Edition::class)->version;
        $pending = $this->sync->pendingUpdate();
        $target  = $pending['version'] ?? null;
        $file    = $pending['file'] ?? null;
        $needBytes = (int) (($pending['size'] ?? 0)) * 3 + 50 * 1024 * 1024; // paket + backup + ekstrak + margin
        if ($needBytes < 200 * 1024 * 1024) {
            $needBytes = 200 * 1024 * 1024; // minimal 200 MB cadangan
        }

        $checks = [];
        $add = static function (string $key, string $label, bool $ok, string $detail, bool $critical, string $fix) use (&$checks): void {
            $checks[] = compact('key', 'label', 'ok', 'detail', 'critical', 'fix');
        };

        // 1. exec() — dibutuhkan untuk backup, ekstrak, migrasi proses baru.
        $hasExec = function_exists('exec');
        $add('exec', 'Fungsi exec() PHP', $hasExec, $hasExec ? 'tersedia' : 'dinonaktifkan di php.ini', true,
            'Hapus exec dari disable_functions di php.ini lalu restart PHP-FPM.');

        // 2. Biner sistem.
        foreach (['tar' => true, 'gzip' => true, 'mysqldump' => true] as $bin => $crit) {
            $ok = $hasExec && $this->hasBin($bin);
            $add('bin_' . $bin, "Biner {$bin}", $ok, $ok ? 'ditemukan' : 'tidak di PATH', (bool) $crit,
                "Pasang {$bin} di server (mis. dnf/apt install).");
        }

        // 3. Folder tujuan bisa ditulis.
        $pend = $this->dirWritable($this->writable('releases' . DIRECTORY_SEPARATOR . 'pending'));
        $add('w_pending', 'Folder writable/releases/pending/ bisa ditulis', $pend, $pend ? 'OK' : 'tidak bisa ditulis', true,
            'cd /var/www/casa && sudo chown -R corenet:apache writable/releases && sudo chmod -R 775 writable/releases');
        $back = $this->dirWritable($this->writable('backups'));
        $add('w_backups', 'Folder writable/backups/ bisa ditulis', $back, $back ? 'OK' : 'tidak bisa ditulis', true,
            'sudo chown -R corenet:apache writable && sudo chmod -R 775 writable');

        // 4. Ruang disk.
        $free = (int) (@disk_free_space($this->root()) ?: 0);
        $okDisk = $free >= $needBytes;
        $add('disk', 'Ruang disk cukup', $okDisk,
            number_format($free / 1048576, 0) . ' MB bebas (butuh ≥ ' . number_format($needBytes / 1048576, 0) . ' MB)', true,
            'Kosongkan disk (hapus backup/log lama) atau tambah kapasitas.');

        // 5. Kredensial DB (untuk backup database).
        $db = (string) (env('database.default.database') ?: '');
        $user = (string) (env('database.default.username') ?: '');
        $okDb = $db !== '' && $user !== '';
        $add('db', 'Kredensial database di .env', $okDb, $okDb ? 'lengkap' : 'tidak lengkap', true,
            'Lengkapi database.default.* di .env.');

        // 6. Ada paket yang ditawarkan.
        $okPkg = $target !== null && $file !== null && $file !== '';
        $add('pkg', 'Ada versi baru siap diunduh/diunggah', $okPkg,
            $okPkg ? "v{$target} ({$file})" : 'belum ada — klik Sync now, atau unggah paket manual', false,
            'Klik Sync now untuk cek versi terbaru, atau unggah paket manual.');

        $ready = true;
        foreach ($checks as $c) {
            if ($c['critical'] && ! $c['ok']) {
                $ready = false;
            }
        }

        return [
            'ok'      => true,
            'ready'   => $ready,           // semua syarat kritis lolos
            'target'  => $target,
            'file'    => $file,
            'current' => $cur,
            'checks'  => $checks,
        ];
    }
}
