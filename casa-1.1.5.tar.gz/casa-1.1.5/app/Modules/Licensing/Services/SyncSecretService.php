<?php

declare(strict_types=1);

namespace App\Modules\Licensing\Services;

use App\Libraries\Crypto;
use App\Modules\Auth\Models\CustomerModel;

/**
 * SyncSecretService — kode sinkron per-pelanggan (console owner). Pelanggan
 * menempelkannya SEKALI di adminlicense VPS agar instance dapat menarik lisensi
 * dari owner (endpoint api/instance/sync).
 *
 * Disimpan dua bentuk di `customers`:
 *   - sync_secret_enc  : terenkripsi (Crypto) → bisa ditampilkan/disalin ulang.
 *   - sync_secret_hash : sha256(kode) → lookup cepat & konstan-waktu saat sync.
 */
final class SyncSecretService
{
    public function __construct(private readonly CustomerModel $customers = new CustomerModel())
    {
    }

    /** Buat/rotasi kode sinkron pelanggan → kembalikan plaintext (tampil sekali). */
    public function rotate(int $customerId): string
    {
        $secret = strtoupper(bin2hex(random_bytes(16))); // 32 hex
        $this->customers->update($customerId, [
            'sync_secret_enc'  => Crypto::encryptText($secret),
            'sync_secret_hash' => hash('sha256', $secret),
        ]);

        return $secret;
    }

    /** Ungkap kode sinkron pelanggan untuk ditampilkan (null bila belum ada). */
    public function reveal(int $customerId): ?string
    {
        $row = $this->customers->find($customerId);
        $enc = (string) ($row['sync_secret_enc'] ?? '');
        if ($enc === '') {
            return null;
        }
        try {
            return Crypto::decryptText($enc);
        } catch (\Throwable $e) {
            return null;
        }
    }

    /** Ambil (buat bila belum ada) kode sinkron pelanggan. */
    public function ensure(int $customerId): string
    {
        return $this->reveal($customerId) ?? $this->rotate($customerId);
    }

    /** Cari pelanggan dari kode sinkron mentah (dipakai endpoint sync). */
    public function findCustomer(string $secret): ?array
    {
        $secret = trim($secret);
        if ($secret === '') {
            return null;
        }
        $row = $this->customers->findBySyncHash(hash('sha256', $secret));
        if ($row === null) {
            return null;
        }
        // Verifikasi konstan-waktu terhadap nilai terenkripsi (pertahanan berlapis).
        $stored = $this->reveal((int) $row['id']);

        return ($stored !== null && hash_equals($stored, $secret)) ? $row : null;
    }
}
