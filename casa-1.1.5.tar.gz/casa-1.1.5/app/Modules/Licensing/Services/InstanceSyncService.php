<?php

declare(strict_types=1);

namespace App\Modules\Licensing\Services;

use App\Libraries\ReleaseRegistry;
use App\Modules\Billing\Services\SubscriptionService;
use App\Modules\Licensing\Config\Edition;
use App\Modules\Licensing\Models\InstanceBindingModel;
use App\Modules\Licensing\Models\InstanceReportModel;

/**
 * InstanceSyncService — sisi OWNER dari endpoint api/instance/sync (PULL lisensi).
 * Pasangan dari phone-home (PUSH). Instance pelanggan mengirim install_id +
 * kode sinkron; owner mengembalikan license_token langganan aktif (sudah
 * ditandatangani → VPS memverifikasi offline sebelum menerapkan).
 *
 * Node-lock: satu kode sinkron hanya boleh mengikat SATU install_id (VPS).
 */
final class InstanceSyncService
{
    public function __construct(
        private readonly SyncSecretService $secrets = new SyncSecretService(),
        private readonly InstanceBindingModel $bindings = new InstanceBindingModel(),
        private readonly SubscriptionService $subs = new SubscriptionService(),
        private readonly InstanceReportModel $reports = new InstanceReportModel(),
    ) {
    }

    /**
     * Proses satu permintaan sync. Selalu mengembalikan array; kunci `status`
     * = kode HTTP yang disarankan controller.
     * @return array<string,mixed>
     */
    public function handle(array $req, string $ip): array
    {
        $installId = trim((string) ($req['install_id'] ?? ''));
        $secret    = trim((string) ($req['sync_secret'] ?? ''));
        if ($installId === '' || $secret === '') {
            return ['ok' => false, 'error' => 'install_id & sync_secret wajib.', 'status' => 400];
        }

        $customer = $this->secrets->findCustomer($secret);
        if ($customer === null) {
            return ['ok' => false, 'error' => 'Kode sinkron tidak dikenal.', 'status' => 401];
        }
        $cid = (int) $customer['id'];

        // --- Node-lock -------------------------------------------------------
        $binding = $this->bindings->activeForCustomer($cid);
        if ($binding === null) {
            // Jendela anti rebut-balik: instance yang BARU SAJA dilepas tak boleh
            // langsung mengikat lagi — beri kesempatan instance BARU sinkron dulu.
            if ($this->bindings->recentlyReleased($cid, $installId)) {
                return [
                    'ok'     => false,
                    'code'   => 'RELEASE_COOLDOWN',
                    'error'  => 'Ikatan baru saja dilepas dari instance ini. Tunggu beberapa menit, atau sinkron dari instance barunya.',
                    'status' => 409,
                ];
            }
            $this->bindings->bind($cid, $installId, $ip);
        } elseif ((string) $binding['install_id'] === $installId) {
            $this->bindings->touch((int) $binding['id'], $ip);
        } else {
            return [
                'ok'     => false,
                'code'   => 'BOUND_ELSEWHERE',
                'error'  => 'Lisensi sudah terikat ke instance lain. Minta owner "lepas ikatan" untuk pindah VPS.',
                'status' => 409,
            ];
        }

        // --- Lisensi aktif ---------------------------------------------------
        $sub = $this->subs->activeForCustomer($cid);

        // --- Telemetri opsional (gabung dengan phone-home) -------------------
        $telemetry = (array) ($req['telemetry'] ?? []);
        $this->recordTelemetry($installId, $customer, $sub, $telemetry, $ip);

        // --- Cek update: tumpangi sync yang SUDAH ada (bukan endpoint baru) —
        // instance kirim versinya sendiri lewat telemetry.version, owner balas
        // rilis VPS terbaru kalau lebih baru. Lihat ReleaseRegistry & panduan
        // fitur "Update Aplikasi" di Lisensi & Aktivasi (instance).
        $update = $this->updateInfo((string) ($telemetry['version'] ?? ''));

        if ($sub === null) {
            return ['ok' => true, 'token' => null, 'tier' => 'community', 'exp' => null, 'license_id' => null, 'update' => $update, 'status' => 200];
        }

        return [
            'ok'          => true,
            'token'       => (string) $sub['license_token'],
            'tier'        => (string) $sub['tier'],
            'exp'         => $sub['expires_at'] ?? null,
            'license_id'  => $sub['license_id'] ?? null,
            'server_time' => date('c'),
            'update'      => $update,
            'status'      => 200,
        ];
    }

    /** Rilis VPS terbaru bila lebih baru dari versi instance, atau null. */
    private function updateInfo(string $currentVersion): ?array
    {
        $latest = ReleaseRegistry::latestVps();
        if ($latest === null || $currentVersion === '' || version_compare($latest['version'], $currentVersion, '<=')) {
            return null;
        }

        return $latest;
    }

    /** Simpan telemetri ringkas ke instance_report (upsert per install_id). */
    private function recordTelemetry(string $installId, array $customer, ?array $sub, array $t, string $ip): void
    {
        $now = date('Y-m-d H:i:s');
        $row = [
            'customer'   => $customer['name'] ?? null,
            'license_id' => $sub['license_id'] ?? null,
            'tier'       => $sub['tier'] ?? 'community',
            'version'    => (string) ($t['version'] ?? config(Edition::class)->version),
            'projects'   => (int) ($t['projects'] ?? 0),
            'missions'   => (int) ($t['missions'] ?? 0),
            'findings'   => (int) ($t['findings'] ?? 0),
            'valid'      => $sub !== null ? 1 : 0,
            'ip'         => mb_substr($ip, 0, 45),
            'last_seen'  => $now,
        ];
        $cur = $this->reports->byInstall($installId);
        if ($cur !== null) {
            $this->reports->update((int) $cur['id'], $row);
        } else {
            $this->reports->insert(['install_id' => $installId, 'first_seen' => $now] + $row);
        }
    }
}
