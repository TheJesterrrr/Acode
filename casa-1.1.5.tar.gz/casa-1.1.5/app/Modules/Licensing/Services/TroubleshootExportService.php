<?php

declare(strict_types=1);

namespace App\Modules\Licensing\Services;

use App\Modules\Licensing\Config\Edition;
use Config\Database;
use Throwable;

/**
 * TroubleshootExportService — kumpulkan satu berkas diagnosa (teks) berisi semua
 * yang dibutuhkan untuk menganalisa kegagalan: versi, lingkungan, kesiapan update,
 * log kejadian berkode (CASA-Exxx), dan cuplikan log aplikasi terbaru. Pengguna
 * cukup unduh lalu kirim ke support — tak perlu SSH untuk mengumpulkan jejak error.
 *
 * Setiap bagian dibungkus try/catch: satu bagian gagal tak boleh menggagalkan
 * seluruh laporan (justru saat sistem bermasalah laporan ini paling dibutuhkan).
 */
final class TroubleshootExportService
{
    public function build(): string
    {
        $L   = [];
        $hr  = str_repeat('=', 64);
        $L[] = $hr;
        $L[] = 'CASA — LAPORAN DIAGNOSA (TROUBLESHOOT EXPORT)';
        $L[] = 'Dibuat: ' . date('Y-m-d H:i:s T');
        $L[] = $hr;

        $this->section($L, '1. VERSI & LINGKUNGAN', function () {
            $o = [];
            try {
                $o[] = 'Versi aplikasi (Edition) : ' . config(Edition::class)->version;
            } catch (Throwable $e) {
                $o[] = 'Versi aplikasi           : (gagal baca: ' . $e->getMessage() . ')';
            }
            $o[] = 'PHP                      : ' . PHP_VERSION;
            $o[] = 'OS                       : ' . php_uname();
            $o[] = 'exec() tersedia          : ' . (function_exists('exec') ? 'ya' : 'TIDAK');
            $o[] = 'memory_limit             : ' . (string) ini_get('memory_limit');
            $o[] = 'upload_max_filesize      : ' . (string) ini_get('upload_max_filesize');
            $o[] = 'post_max_size            : ' . (string) ini_get('post_max_size');
            $root = dirname(rtrim(APPPATH, '/\\'));
            $o[] = 'Disk bebas (root app)    : ' . number_format((int) (@disk_free_space($root) ?: 0) / 1048576, 0) . ' MB';

            return $o;
        });

        $this->section($L, '2. KESIAPAN UPDATE (PREFLIGHT)', function () {
            $o = [];
            $p = (new UpdatePreflightService())->check();
            $o[] = 'Versi sekarang : ' . ($p['current'] ?? '?') . '   Target: ' . ($p['target'] ?? '-');
            $o[] = 'SIAP UPGRADE   : ' . (! empty($p['ready']) ? 'YA' : 'BELUM (ada syarat kritis gagal)');
            $o[] = '';
            foreach ($p['checks'] as $c) {
                $mark = $c['ok'] ? '[OK]  ' : ($c['critical'] ? '[GAGAL]' : '[warn]');
                $o[]  = $mark . ' ' . $c['label'] . ' — ' . $c['detail'];
                if (! $c['ok']) {
                    $o[] = '        fix: ' . $c['fix'];
                }
            }

            return $o;
        });

        $this->section($L, '3. LOG KEJADIAN BERKODE (event_log, 50 terbaru)', function () {
            $o  = [];
            $db = Database::connect();
            $rows = $db->table('event_log')->orderBy('id', 'DESC')->limit(50)->get()->getResultArray();
            if ($rows === []) {
                return ['(kosong — belum ada kejadian tercatat)'];
            }
            foreach ($rows as $r) {
                $o[] = sprintf(
                    '%s  [%s] %s  %s',
                    (string) ($r['created_at'] ?? ''),
                    (string) ($r['level'] ?? ''),
                    (string) ($r['code'] ?? ''),
                    (string) ($r['message'] ?? '')
                );
            }

            return $o;
        });

        $this->section($L, '4. CUPLIKAN LOG APLIKASI TERBARU', function () {
            $dir = rtrim(WRITEPATH, '/\\') . DIRECTORY_SEPARATOR . 'logs';
            $files = glob($dir . DIRECTORY_SEPARATOR . 'log-*.php') ?: [];
            if ($files === []) {
                return ['(tak ada berkas log)'];
            }
            usort($files, static fn ($a, $b): int => filemtime($b) <=> filemtime($a));
            $latest = $files[0];
            $lines  = @file($latest) ?: [];
            $tail   = array_slice($lines, -80); // 80 baris terakhir

            return array_merge(['Berkas: ' . basename($latest), ''], array_map(static fn ($l): string => rtrim((string) $l), $tail));
        });

        $L[] = '';
        $L[] = $hr;
        $L[] = 'Kirim berkas ini ke support@corenet.web.id untuk analisa.';
        $L[] = $hr;

        return implode("\n", $L) . "\n";
    }

    /** Jalankan $fn (menghasilkan baris), bungkus aman, tempel ke $L dengan judul. */
    private function section(array &$L, string $title, callable $fn): void
    {
        $L[] = '';
        $L[] = '## ' . $title;
        $L[] = str_repeat('-', 64);
        try {
            foreach ($fn() as $line) {
                $L[] = $line;
            }
        } catch (Throwable $e) {
            $L[] = '(bagian ini gagal dikumpulkan: ' . $e->getMessage() . ')';
        }
    }
}
