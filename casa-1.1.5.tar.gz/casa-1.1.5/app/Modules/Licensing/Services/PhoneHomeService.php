<?php

declare(strict_types=1);

namespace App\Modules\Licensing\Services;

use App\Modules\Licensing\Config\Edition;
use App\Modules\Licensing\Models\InstanceLicenseModel;
use App\Modules\Licensing\Models\InstanceReportModel;
use Config\Database;
use Config\Services;
use Throwable;

/**
 * PhoneHomeService — telemetri ringkas dari instance pelanggan ke console owner
 * untuk monitoring (Master Plan: owner hanya memantau). TIDAK mengirim data
 * sensitif pentest — hanya install_id, tier, versi, & HITUNGAN project/mission/
 * finding. Owner memverifikasi token lisensi yang disertakan.
 */
final class PhoneHomeService
{
    public function __construct(
        private readonly InstanceReportModel $reports = new InstanceReportModel(),
        private readonly InstanceLicenseModel $licenses = new InstanceLicenseModel(),
        private readonly LicenseKeyService $keys = new LicenseKeyService(),
    ) {
    }

    /** ID unik instance (dibuat sekali, disimpan di writable/install_id). */
    public function installId(): string
    {
        $path = WRITEPATH . 'install_id';
        if (is_file($path)) {
            $id = trim((string) file_get_contents($path));
            if ($id !== '') {
                return $id;
            }
        }
        $id = bin2hex(random_bytes(16));
        @file_put_contents($path, $id);

        return $id;
    }

    /** Kumpulkan telemetri instance ini (sisi pelanggan). @return array<string,mixed> */
    public function collect(): array
    {
        $db  = Database::connect();
        $eff = $this->keys->effective();
        $lic = $this->licenses->current();
        $cnt = static function (string $t) use ($db): int {
            try {
                return (int) $db->table($t)->countAllResults();
            } catch (Throwable $e) {
                return 0;
            }
        };

        return [
            'install_id' => $this->installId(),
            'version'    => config(Edition::class)->version,
            'tier'       => $eff['tier'],
            'license_id' => $eff['license_id'] ?? null,
            'customer'   => $eff['customer'] ?? null,
            'projects'   => $cnt('project'),
            'missions'   => $cnt('mission'),
            'findings'   => $cnt('finding'),
            'token'      => $lic['token'] ?? '',
        ];
    }

    /** Kirim telemetri ke console owner (env phonehome.url). @return bool sukses */
    public function send(): bool
    {
        $url = (string) (env('phonehome.url') ?: '');
        if ($url === '') {
            return false; // tak dikonfigurasi (mis. di console owner sendiri)
        }
        try {
            $client = Services::curlrequest(['timeout' => 10, 'http_errors' => false], null, null, false);
            $res    = $client->post($url, ['headers' => ['Content-Type' => 'application/json'], 'body' => json_encode($this->collect())]);

            return $res->getStatusCode() >= 200 && $res->getStatusCode() < 300;
        } catch (Throwable $e) {
            return false;
        }
    }

    /** Terima laporan di console owner → verifikasi & simpan (upsert). */
    public function receive(array $p, string $ip): void
    {
        $installId = trim((string) ($p['install_id'] ?? ''));
        if ($installId === '') {
            return;
        }
        // Verifikasi token lisensi (bila ada) → tandai valid.
        $valid = 0;
        $token = (string) ($p['token'] ?? '');
        if ($token !== '' && $this->keys->verify($token) !== null) {
            $valid = 1;
        }
        $now = date('Y-m-d H:i:s');
        $row = [
            'customer'   => $p['customer'] ?? null,
            'license_id' => $p['license_id'] ?? null,
            'tier'       => $p['tier'] ?? null,
            'version'    => $p['version'] ?? null,
            'projects'   => (int) ($p['projects'] ?? 0),
            'missions'   => (int) ($p['missions'] ?? 0),
            'findings'   => (int) ($p['findings'] ?? 0),
            'valid'      => $valid,
            'ip'         => mb_substr($ip, 0, 45),
            'last_seen'  => $now,
        ];
        $cur = $this->reports->byInstall($installId);
        if ($cur !== null) {
            $this->reports->update((int) $cur['id'], $row);
        } else {
            $this->reports->insert(['install_id' => $installId, 'first_seen' => $now] + $row);
        }
    }

    /** @return array{total:int,active:int,by_tier:array,rows:array} ringkasan owner */
    public function overview(): array
    {
        $rows   = $this->reports->all();
        $active = 0;
        $byTier = [];
        $cutoff = date('Y-m-d H:i:s', strtotime('-3 days'));
        foreach ($rows as $r) {
            if (($r['last_seen'] ?? '') >= $cutoff) {
                $active++;
            }
            $t          = $r['tier'] ?: 'community';
            $byTier[$t] = ($byTier[$t] ?? 0) + 1;
        }

        return ['total' => count($rows), 'active' => $active, 'by_tier' => $byTier, 'rows' => $rows];
    }
}
