<?php

declare(strict_types=1);

namespace App\Modules\Licensing\Services;

use App\Modules\Setting\Services\SettingService;
use Config\Services;
use RuntimeException;
use Throwable;

/**
 * LicenseSyncService — sisi PRODUK (VPS pelanggan). Menarik license_token dari
 * console owner (env `sync.url`) memakai kode sinkron pelanggan + install_id,
 * lalu MENGAKTIVASINYA secara lokal (verifikasi offline via public key tertanam).
 *
 * Dipakai tombol "Sinkron Online" (adminlicense) dan command `casa:sync` (cron).
 * Kode sinkron disimpan sebagai setting rahasia `license.sync_secret` (terenkripsi).
 */
final class LicenseSyncService
{
    public const SECRET_KEY = 'license.sync_secret';

    /** Kunci setting tempat info update terbaru (hasil sync) disimpan utk ditampilkan. */
    public const UPDATE_AVAILABLE_KEY = 'update.available_version';
    public const UPDATE_FILE_KEY      = 'update.available_file';
    public const UPDATE_SHA256_KEY    = 'update.available_sha256';
    public const UPDATE_SIZE_KEY      = 'update.available_size';

    public function __construct(
        private readonly SettingService $settings = new SettingService(),
        private readonly PhoneHomeService $phone = new PhoneHomeService(),
        private readonly LicenseKeyService $keys = new LicenseKeyService(),
    ) {
    }

    public function hasSecret(): bool
    {
        return (string) ($this->settings->get(self::SECRET_KEY, '') ?? '') !== '';
    }

    /** Simpan kode sinkron (terenkripsi). */
    public function saveSecret(string $secret): void
    {
        $this->settings->set(self::SECRET_KEY, trim($secret), true);
    }

    /**
     * Jalankan satu sinkron. Selalu mengembalikan array {ok, ...}.
     * @return array<string,mixed>
     */
    public function sync(): array
    {
        $secret = (string) ($this->settings->get(self::SECRET_KEY, '') ?? '');
        $url    = (string) (env('sync.url') ?: '');
        if ($secret === '') {
            return ['ok' => false, 'error' => 'Kode sinkron belum diisi di instance ini.'];
        }
        if ($url === '') {
            return ['ok' => false, 'error' => 'sync.url belum dikonfigurasi (.env).'];
        }

        $tel  = $this->phone->collect();
        $body = [
            'install_id'  => $tel['install_id'],
            'sync_secret' => $secret,
            'telemetry'   => [
                'version'  => $tel['version'] ?? null,
                'projects' => $tel['projects'] ?? 0,
                'missions' => $tel['missions'] ?? 0,
                'findings' => $tel['findings'] ?? 0,
            ],
        ];

        try {
            $client = Services::curlrequest(['timeout' => 15, 'http_errors' => false], null, null, false);
            $res    = $client->post($url, ['headers' => ['Content-Type' => 'application/json'], 'body' => json_encode($body)]);
            $data   = json_decode((string) $res->getBody(), true);
        } catch (Throwable $e) {
            return ['ok' => false, 'error' => 'Tak dapat menghubungi server owner: ' . $e->getMessage()];
        }
        if (! is_array($data)) {
            return ['ok' => false, 'error' => 'Respons server tidak valid (HTTP ' . $res->getStatusCode() . ').'];
        }
        if (empty($data['ok'])) {
            return ['ok' => false, 'error' => (string) ($data['error'] ?? 'Sinkron ditolak.'), 'code' => $data['code'] ?? null];
        }

        $this->storeUpdateInfo(is_array($data['update'] ?? null) ? $data['update'] : null);

        // Sukses. Ada token → aktivasi (verifikasi offline). Tak ada → Community.
        $token = (string) ($data['token'] ?? '');
        if ($token === '') {
            return ['ok' => true, 'tier' => 'community', 'community' => true, 'message' => 'Tidak ada langganan aktif — instance berjalan Community.'];
        }
        try {
            $p = $this->keys->activate($token);
        } catch (RuntimeException $e) {
            return ['ok' => false, 'error' => 'Token dari owner ditolak saat verifikasi lokal: ' . $e->getMessage()];
        }

        return ['ok' => true, 'tier' => $p['tier'] ?? '?', 'exp' => $p['exp'] ?? null, 'license_id' => $p['lid'] ?? null];
    }

    /** Simpan (atau bersihkan) info rilis terbaru yang dilaporkan owner saat sync. */
    private function storeUpdateInfo(?array $u): void
    {
        if ($u === null || (string) ($u['version'] ?? '') === '') {
            $this->settings->set(self::UPDATE_AVAILABLE_KEY, '');

            return;
        }
        $this->settings->set(self::UPDATE_AVAILABLE_KEY, (string) $u['version']);
        $this->settings->set(self::UPDATE_FILE_KEY, (string) ($u['file'] ?? ''));
        $this->settings->set(self::UPDATE_SHA256_KEY, (string) ($u['sha256'] ?? ''));
        $this->settings->set(self::UPDATE_SIZE_KEY, (string) ($u['size'] ?? 0));
    }

    /**
     * Update yang tersimpan dari sync terakhir — null bila tak ada atau sudah
     * tak relevan lagi (instance ternyata sudah di versi itu/lebih baru, mis.
     * setelah casa:apply-update jalan). Re-validasi tiap baca, bukan cuma andalkan
     * flag tersimpan, supaya kartu "Update tersedia" otomatis hilang sendiri.
     */
    public function pendingUpdate(): ?array
    {
        $version = (string) ($this->settings->get(self::UPDATE_AVAILABLE_KEY, '') ?? '');
        if ($version === '' || version_compare($version, config(\App\Modules\Licensing\Config\Edition::class)->version, '<=')) {
            return null;
        }

        return [
            'version' => $version,
            'file'    => (string) ($this->settings->get(self::UPDATE_FILE_KEY, '') ?? ''),
            'sha256'  => (string) ($this->settings->get(self::UPDATE_SHA256_KEY, '') ?? ''),
            'size'    => (int) $this->settings->int(self::UPDATE_SIZE_KEY, 0),
        ];
    }

    /**
     * Unduh paket rilis dari owner ke writable/releases/pending/ + sidecar
     * .sha256 (dipakai `casa:apply-update` memverifikasi tanpa perlu akses DB).
     * Auth sama seperti sync() — kode sinkron yang sudah tersimpan.
     * @return array{ok:bool,error?:string,path?:string,file?:string}
     */
    public function downloadUpdate(): array
    {
        $pending = $this->pendingUpdate();
        if ($pending === null || $pending['file'] === '') {
            return ['ok' => false, 'error' => 'Tak ada update yang tercatat — Sync dulu.'];
        }
        $secret = (string) ($this->settings->get(self::SECRET_KEY, '') ?? '');
        $url    = (string) (env('sync.url') ?: '');
        if ($secret === '' || $url === '') {
            return ['ok' => false, 'error' => 'Kode sinkron/sync.url belum disetel.'];
        }
        // sync.url berbentuk .../api/instance/sync — endpoint unduh bertetangga.
        $dlUrl = preg_replace('#/sync/?$#', '/update/download', $url) ?? '';
        if ($dlUrl === $url || $dlUrl === '') {
            return ['ok' => false, 'error' => 'Tak dapat menyusun URL unduh dari sync.url.'];
        }

        try {
            $client = Services::curlrequest(['timeout' => 120, 'http_errors' => false], null, null, false);
            $res    = $client->post($dlUrl, ['headers' => ['Content-Type' => 'application/json'], 'body' => json_encode(['sync_secret' => $secret, 'file' => $pending['file']])]);
        } catch (Throwable $e) {
            return ['ok' => false, 'error' => 'Tak dapat menghubungi server owner: ' . $e->getMessage()];
        }
        if ($res->getStatusCode() !== 200) {
            $j = json_decode((string) $res->getBody(), true);

            return ['ok' => false, 'error' => is_array($j) ? (string) ($j['error'] ?? 'Unduh ditolak.') : 'Unduh gagal (HTTP ' . $res->getStatusCode() . ').'];
        }

        $body = (string) $res->getBody();
        $hash = hash('sha256', $body);
        if ($pending['sha256'] !== '' && ! hash_equals($pending['sha256'], $hash)) {
            return ['ok' => false, 'error' => 'Checksum berkas tak cocok — unduhan mungkin rusak/dimanipulasi. Coba Sync + unduh ulang.'];
        }

        $dir = rtrim(WRITEPATH, '/\\') . DIRECTORY_SEPARATOR . 'releases' . DIRECTORY_SEPARATOR . 'pending';
        if (! is_dir($dir)) {
            @mkdir($dir, 0775, true);
            @chmod($dir, 0775);
        }
        // Pesan izin yang DAPAT DITINDAKLANJUTI — penyebab tersering: folder tak
        // bisa ditulis oleh PHP-FPM (user web). Perbaikannya di server, sekali.
        $permHint = 'Perbaiki izin di server (sekali): cd /var/www/casa && sudo chown -R corenet:apache writable/releases && sudo chmod -R 775 writable/releases'
            . ' (AlmaLinux + SELinux: sudo chcon -R -t httpd_sys_rw_content_t writable/releases).';
        if (! is_dir($dir) || ! is_writable($dir)) {
            return ['ok' => false, 'error' => 'Folder writable/releases/pending/ tak bisa ditulis PHP-FPM. ' . $permHint];
        }
        $path = $dir . DIRECTORY_SEPARATOR . $pending['file'];
        if (@file_put_contents($path, $body) === false) {
            return ['ok' => false, 'error' => 'Gagal menyimpan berkas ke ' . $path . '. ' . $permHint];
        }
        @file_put_contents($path . '.sha256', $hash);

        return ['ok' => true, 'path' => $path, 'file' => $pending['file']];
    }
}
