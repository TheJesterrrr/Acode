<?php

declare(strict_types=1);

namespace App\Modules\Licensing\Database\Migrations;

use CodeIgniter\Database\Migration;

/**
 * Tambah `revoked_at` di instance_binding — jejak KAPAN ikatan dilepas.
 * Dipakai jendela anti rebut-balik: install_id yang baru saja dilepas tak boleh
 * mengikat lagi selama N menit, supaya instance LAMA (cron sinkronnya masih
 * jalan) tidak menyambar slot sebelum instance BARU sempat sinkron.
 */
final class AddBindingRevokedAt extends Migration
{
    public function up(): void
    {
        if (! $this->db->fieldExists('revoked_at', 'instance_binding')) {
            $this->forge->addColumn('instance_binding', [
                'revoked_at' => ['type' => 'DATETIME', 'null' => true, 'after' => 'revoked'],
            ]);
        }
    }

    public function down(): void
    {
        if ($this->db->fieldExists('revoked_at', 'instance_binding')) {
            $this->forge->dropColumn('instance_binding', 'revoked_at');
        }
    }
}
