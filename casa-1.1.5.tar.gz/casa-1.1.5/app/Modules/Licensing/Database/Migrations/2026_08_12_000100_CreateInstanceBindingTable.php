<?php

declare(strict_types=1);

namespace App\Modules\Licensing\Database\Migrations;

use CodeIgniter\Database\Migration;

/**
 * Sinkron lisensi online (adminlicense VPS ↔ console owner).
 *
 * 1) Kolom `sync_secret_enc` + `sync_secret_hash` di `customers`:
 *    - _enc  = kode sinkron terenkripsi (Crypto) → pelanggan bisa lihat/salin
 *              kembali di "Akun Saya".
 *    - _hash = sha256(kode) terindeks → lookup cepat & aman saat endpoint sync
 *              (tanpa memindai/mendekripsi seluruh tabel).
 *
 * 2) Tabel `instance_binding` — node-lock: memetakan pelanggan ↔ install_id VPS
 *    yang mengaktifkan lisensinya. Satu ikatan aktif per pelanggan (owner dapat
 *    "lepas ikatan" saat pelanggan pindah VPS).
 */
final class CreateInstanceBindingTable extends Migration
{
    public function up(): void
    {
        // (1) kolom kode sinkron di customers
        if (! $this->db->fieldExists('sync_secret_hash', 'customers')) {
            $this->forge->addColumn('customers', [
                'sync_secret_enc'  => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => true, 'after' => 'password_hash'],
                'sync_secret_hash' => ['type' => 'VARCHAR', 'constraint' => 64, 'null' => true, 'after' => 'sync_secret_enc'],
            ]);
            $this->db->query('CREATE INDEX idx_customers_sync_hash ON ' . $this->db->prefixTable('customers') . ' (sync_secret_hash)');
        }

        // (2) tabel instance_binding
        $this->forge->addField([
            'id'           => ['type' => 'BIGINT', 'unsigned' => true, 'auto_increment' => true],
            'customer_id'  => ['type' => 'BIGINT', 'unsigned' => true],
            'install_id'   => ['type' => 'VARCHAR', 'constraint' => 64],
            'label'        => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'ip'           => ['type' => 'VARCHAR', 'constraint' => 45, 'null' => true],
            'revoked'      => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 0],
            'bound_at'     => ['type' => 'DATETIME', 'null' => true],
            'last_sync_at' => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addKey(['customer_id', 'revoked']);
        $this->forge->addKey('install_id');
        $this->forge->createTable('instance_binding', true, ['ENGINE' => 'InnoDB', 'DEFAULT CHARSET' => 'utf8mb4', 'COLLATE' => 'utf8mb4_unicode_ci']);
    }

    public function down(): void
    {
        $this->forge->dropTable('instance_binding', true);
        if ($this->db->fieldExists('sync_secret_hash', 'customers')) {
            $this->forge->dropColumn('customers', ['sync_secret_enc', 'sync_secret_hash']);
        }
    }
}
