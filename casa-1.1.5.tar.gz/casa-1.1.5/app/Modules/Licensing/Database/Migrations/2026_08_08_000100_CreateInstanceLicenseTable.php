<?php

declare(strict_types=1);

namespace App\Modules\Licensing\Database\Migrations;

use CodeIgniter\Database\Migration;

/**
 * Tabel `instance_license` — lisensi ter-aktivasi untuk SATU instance self-hosted
 * (model produk + license key). Satu baris (id=1) menyimpan token ter-tanda-tangani
 * + hasil dekode. Diverifikasi lokal dgn public key yang ditanam (offline).
 */
final class CreateInstanceLicenseTable extends Migration
{
    public function up(): void
    {
        $this->forge->addField([
            'id'           => ['type' => 'INT', 'constraint' => 10, 'unsigned' => true, 'auto_increment' => true],
            'token'        => ['type' => 'TEXT'],
            'license_id'   => ['type' => 'VARCHAR', 'constraint' => 40, 'null' => true],
            'customer'     => ['type' => 'VARCHAR', 'constraint' => 150, 'null' => true],
            'tier'         => ['type' => 'VARCHAR', 'constraint' => 12, 'default' => 'community'],
            'quotas'       => ['type' => 'VARCHAR', 'constraint' => 200, 'null' => true], // JSON override kuota
            'issued_at'    => ['type' => 'DATE', 'null' => true],
            'expires_at'   => ['type' => 'DATE', 'null' => true],
            'activated_at' => ['type' => 'DATETIME', 'null' => true],
            'updated_at'   => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->createTable('instance_license', true, ['ENGINE' => 'InnoDB', 'DEFAULT CHARSET' => 'utf8mb4', 'COLLATE' => 'utf8mb4_unicode_ci']);
    }

    public function down(): void
    {
        $this->forge->dropTable('instance_license', true);
    }
}
