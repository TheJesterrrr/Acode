<?php

declare(strict_types=1);

namespace App\Modules\Licensing\Database\Migrations;

use CodeIgniter\Database\Migration;

/**
 * Tabel `instance_report` — laporan phone-home dari instance pelanggan (disimpan
 * di CONSOLE OWNER). Telemetri ringkas untuk monitoring; TANPA data sensitif
 * pentest (hanya hitungan & status). Satu baris per install_id (upsert).
 */
final class CreateInstanceReportTable extends Migration
{
    public function up(): void
    {
        $this->forge->addField([
            'id'          => ['type' => 'INT', 'constraint' => 10, 'unsigned' => true, 'auto_increment' => true],
            'install_id'  => ['type' => 'VARCHAR', 'constraint' => 64],
            'customer'    => ['type' => 'VARCHAR', 'constraint' => 150, 'null' => true],
            'license_id'  => ['type' => 'VARCHAR', 'constraint' => 40, 'null' => true],
            'tier'        => ['type' => 'VARCHAR', 'constraint' => 12, 'null' => true],
            'version'     => ['type' => 'VARCHAR', 'constraint' => 20, 'null' => true],
            'projects'    => ['type' => 'INT', 'constraint' => 8, 'default' => 0],
            'missions'    => ['type' => 'INT', 'constraint' => 8, 'default' => 0],
            'findings'    => ['type' => 'INT', 'constraint' => 8, 'default' => 0],
            'valid'       => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 0], // token lisensi terverifikasi
            'ip'          => ['type' => 'VARCHAR', 'constraint' => 45, 'null' => true],
            'first_seen'  => ['type' => 'DATETIME', 'null' => true],
            'last_seen'   => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addUniqueKey('install_id');
        $this->forge->createTable('instance_report', true, ['ENGINE' => 'InnoDB', 'DEFAULT CHARSET' => 'utf8mb4', 'COLLATE' => 'utf8mb4_unicode_ci']);
    }

    public function down(): void
    {
        $this->forge->dropTable('instance_report', true);
    }
}
