<?php

declare(strict_types=1);

namespace App\Modules\Licensing\Database\Migrations;

use CodeIgniter\Database\Migration;

/**
 * Tabel `license` — lisensi/edisi per pelanggan (Master Plan: Community/Pro/
 * Enterprise). Satu baris aktif per pelanggan (customer_id unik). Batas default
 * mengikuti tier (Config\Edition); kolom kuota di sini adalah OVERRIDE opsional
 * (NULL = pakai default tier).
 */
final class CreateLicenseTable extends Migration
{
    public function up(): void
    {
        $this->forge->addField([
            'id'            => ['type' => 'INT', 'constraint' => 10, 'unsigned' => true, 'auto_increment' => true],
            'customer_id'   => ['type' => 'INT', 'constraint' => 10, 'unsigned' => true],
            'tier'          => ['type' => 'VARCHAR', 'constraint' => 12, 'default' => 'community'], // community|pro|enterprise
            'status'        => ['type' => 'VARCHAR', 'constraint' => 10, 'default' => 'active'],    // active|expired|revoked
            'max_projects'  => ['type' => 'INT', 'constraint' => 6, 'null' => true],  // override; NULL=default tier
            'max_targets'   => ['type' => 'INT', 'constraint' => 6, 'null' => true],
            'max_schedules' => ['type' => 'INT', 'constraint' => 6, 'null' => true],
            'expires_at'    => ['type' => 'DATE', 'null' => true],
            'note'          => ['type' => 'VARCHAR', 'constraint' => 200, 'null' => true],
            'created_at'    => ['type' => 'DATETIME', 'null' => true],
            'updated_at'    => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addUniqueKey('customer_id');
        $this->forge->createTable('license', true, ['ENGINE' => 'InnoDB', 'DEFAULT CHARSET' => 'utf8mb4', 'COLLATE' => 'utf8mb4_unicode_ci']);
    }

    public function down(): void
    {
        $this->forge->dropTable('license', true);
    }
}
