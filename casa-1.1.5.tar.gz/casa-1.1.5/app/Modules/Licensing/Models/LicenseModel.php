<?php

declare(strict_types=1);

namespace App\Modules\Licensing\Models;

use CodeIgniter\Model;

/** LicenseModel — lisensi/edisi per pelanggan (`license`). */
final class LicenseModel extends Model
{
    protected $table         = 'license';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $useTimestamps = true;
    protected $allowedFields  = [
        'customer_id', 'tier', 'status', 'max_projects', 'max_targets',
        'max_schedules', 'expires_at', 'note',
    ];

    public function forCustomer(int $customerId): ?array
    {
        return $this->where('customer_id', $customerId)->first();
    }
}
