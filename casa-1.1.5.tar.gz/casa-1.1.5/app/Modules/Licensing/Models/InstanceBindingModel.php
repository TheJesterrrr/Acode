<?php

declare(strict_types=1);

namespace App\Modules\Licensing\Models;

use CodeIgniter\Model;

/**
 * InstanceBindingModel — node-lock lisensi (`instance_binding`, di console owner).
 * Satu ikatan AKTIF (revoked=0) per pelanggan → 1 lisensi terkunci ke 1 VPS.
 */
final class InstanceBindingModel extends Model
{
    protected $table         = 'instance_binding';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $useTimestamps = false;
    protected $allowedFields  = ['customer_id', 'install_id', 'label', 'ip', 'revoked', 'revoked_at', 'bound_at', 'last_sync_at'];

    /** Jendela (menit) install_id yang baru dilepas dilarang mengikat lagi. */
    public const RELEASE_COOLDOWN_MIN = 15;

    /** Ikatan aktif milik pelanggan (null bila belum ada). */
    public function activeForCustomer(int $customerId): ?array
    {
        return $this->where('customer_id', $customerId)->where('revoked', 0)->orderBy('id', 'DESC')->first();
    }

    /** Buat ikatan baru pelanggan ↔ install_id. */
    public function bind(int $customerId, string $installId, string $ip): int
    {
        $now = date('Y-m-d H:i:s');

        return (int) $this->insert([
            'customer_id'  => $customerId,
            'install_id'   => $installId,
            'ip'           => mb_substr($ip, 0, 45),
            'revoked'      => 0,
            'bound_at'     => $now,
            'last_sync_at' => $now,
        ], true);
    }

    /** Perbarui waktu sinkron terakhir. */
    public function touch(int $id, string $ip): void
    {
        $this->update($id, ['last_sync_at' => date('Y-m-d H:i:s'), 'ip' => mb_substr($ip, 0, 45)]);
    }

    /** Lepas semua ikatan aktif pelanggan (owner / self-service). @return int jumlah dilepas */
    public function revokeForCustomer(int $customerId): int
    {
        $this->builder()
            ->where('customer_id', $customerId)
            ->where('revoked', 0)
            ->update(['revoked' => 1, 'revoked_at' => date('Y-m-d H:i:s')]);

        return $this->db->affectedRows();
    }

    /**
     * True bila install_id ini BARU SAJA dilepas (dalam $minutes menit terakhir).
     * Mencegah instance LAMA merebut balik slot sebelum instance BARU sinkron.
     */
    public function recentlyReleased(int $customerId, string $installId, int $minutes = self::RELEASE_COOLDOWN_MIN): bool
    {
        $since = date('Y-m-d H:i:s', time() - ($minutes * 60));

        return $this->where('customer_id', $customerId)
            ->where('install_id', $installId)
            ->where('revoked', 1)
            ->where('revoked_at >=', $since)
            ->countAllResults() > 0;
    }
}
