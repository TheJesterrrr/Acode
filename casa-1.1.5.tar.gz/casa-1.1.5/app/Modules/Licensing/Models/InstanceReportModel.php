<?php

declare(strict_types=1);

namespace App\Modules\Licensing\Models;

use CodeIgniter\Model;

/** InstanceReportModel — laporan phone-home per instance (`instance_report`). */
final class InstanceReportModel extends Model
{
    protected $table         = 'instance_report';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $useTimestamps = false;
    protected $allowedFields  = [
        'install_id', 'customer', 'license_id', 'tier', 'version',
        'projects', 'missions', 'findings', 'valid', 'ip', 'first_seen', 'last_seen',
    ];

    public function byInstall(string $installId): ?array
    {
        return $this->where('install_id', $installId)->first();
    }

    /** @return array<int,array<string,mixed>> semua instance, terbaru dulu */
    public function all(): array
    {
        return $this->orderBy('last_seen', 'DESC')->findAll(500);
    }
}
