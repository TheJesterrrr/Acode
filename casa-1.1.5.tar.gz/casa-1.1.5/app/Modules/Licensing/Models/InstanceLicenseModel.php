<?php

declare(strict_types=1);

namespace App\Modules\Licensing\Models;

use CodeIgniter\Model;

/** InstanceLicenseModel — lisensi ter-aktivasi instance (`instance_license`, satu baris). */
final class InstanceLicenseModel extends Model
{
    protected $table         = 'instance_license';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $useTimestamps = false;
    protected $allowedFields  = [
        'token', 'license_id', 'customer', 'tier', 'quotas',
        'issued_at', 'expires_at', 'activated_at', 'updated_at',
    ];

    /** Lisensi aktif saat ini (baris tunggal), atau null. */
    public function current(): ?array
    {
        return $this->orderBy('id', 'DESC')->first();
    }
}
