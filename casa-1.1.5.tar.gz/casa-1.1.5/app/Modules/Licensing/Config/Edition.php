<?php

declare(strict_types=1);

namespace App\Modules\Licensing\Config;

use CodeIgniter\Config\BaseConfig;

/**
 * Edition — definisi tier CASA (Community/Pro/Enterprise). Sumber tunggal batas
 * & fitur per tier; lisensi pelanggan menunjuk ke tier + boleh override kuota.
 *
 * quota 0 = tak terbatas. tools:
 *   ['*']  → semua kategori tool boleh.
 *   [daftar kategori] → hanya kategori itu yang boleh dipakai member.
 */
class Edition extends BaseConfig
{
    /** @var array<string,array<string,mixed>> */
    public array $tiers = [
        'community' => [
            'label'    => 'Community',
            'features' => [
                'idor_workbench' => false,
                'automation'     => false,
                'pdf_report'     => false,
                'api_security'   => false,
                'authz_matrix'   => false,
                'business_logic' => false,
            ],
            'quota'    => ['projects' => 1, 'targets' => 5, 'schedules' => 0, 'scans_per_day' => 3],
            'tools'    => ['Asset Discovery', 'DNS', 'HTTP', 'Port Scanning', 'Fingerprint', 'SSL', 'Screenshot', 'Crawling', 'URL Discovery'],
        ],
        'pro' => [
            'label'    => 'Professional',
            'features' => [
                'idor_workbench' => true,
                'automation'     => true,
                'pdf_report'     => true,
                'api_security'   => true,
                'authz_matrix'   => true,
                'business_logic' => true,
            ],
            'quota'    => ['projects' => 15, 'targets' => 100, 'schedules' => 20, 'scans_per_day' => 50],
            'tools'    => ['*'],
        ],
        'enterprise' => [
            'label'    => 'Enterprise',
            'features' => [
                'idor_workbench' => true,
                'automation'     => true,
                'pdf_report'     => true,
                'api_security'   => true,
                'authz_matrix'   => true,
                'business_logic' => true,
            ],
            'quota'    => ['projects' => 0, 'targets' => 0, 'schedules' => 0, 'scans_per_day' => 0],
            'tools'    => ['*'],
        ],
    ];

    /** Tier default bila pelanggan belum punya lisensi. */
    public string $default = 'community';

    /** Versi produk CASA (dilaporkan lewat phone-home). */
    public string $version = '1.1.5';

    /**
     * Public key Ed25519 (base64) untuk memverifikasi license key — DITANAM di
     * produk yang dikirim ke pelanggan. Private key HANYA ada di owner (env
     * `license.privateKey`), tak pernah dikirim. Hasilkan sepasang dgn
     * `php spark casa:license keygen`, lalu tempel public key di sini.
     */
    public string $licensePublicKey = 'LS0tLS1CRUdJTiBQVUJMSUMgS0VZLS0tLS0KTUlJQklqQU5CZ2txaGtpRzl3MEJBUUVGQUFPQ0FROEFNSUlCQ2dLQ0FRRUF0aTloSjNMMVVCZU9jdkFJQWJoaApxT1JiVitsSG40Vk5TVHB6YXl6NmkyN0lzbXRnZk1PTTFSYzRhVGJLU1Zldlh6cmxIbU5YTGl6ZVp2MHBzSjlNCjNCNXNDN1JZSjFqWkk3N2ZPV2JYTFhScEtZcjAvbzVOU1pteXJsVlkyam1HL3RtbUt6TDBQbXpuVUNIdVlycVEKV2FBOUhnUWZVUGJxQlBtMm9YbVRKTTB5aGFQY0twV1h1QWpJM25LTUlvYUJXYmJUeTcwQmFqMzhsaU5id0YxMQo0VERyUFhVcVVJSkxaU0UrY3djRFZtQmFNK1kyb21jRk9wbTRpWFk0cHNpc2NhZTBsSUZ4M1k4VWFrRTZ6RiswClJXM1QzZnhCNHBZV2dvZUlLa3RRY0Y1NVJtelkvbTNid3pFSENLTXdIcjNTbkpZbUFLOVNid0JHeFdRdGJ5SjEKQ3dJREFRQUIKLS0tLS1FTkQgUFVCTElDIEtFWS0tLS0tCg==';

    /** Label fitur untuk UI. @var array<string,string> */
    public array $featureLabels = [
        'idor_workbench' => 'IDOR / BOLA Workbench',
        'automation'     => 'Scan terjadwal (Automation)',
        'pdf_report'     => 'Ekspor laporan PDF',
        'api_security'   => 'API Security',
        'authz_matrix'   => 'AuthZ Matrix (Broken Access Control)',
        'business_logic' => 'Business Logic Lab',
    ];
}
