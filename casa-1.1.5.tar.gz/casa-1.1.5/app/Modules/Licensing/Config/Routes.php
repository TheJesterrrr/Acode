<?php

declare(strict_types=1);

use CodeIgniter\Router\RouteCollection;

/** Rute Lisensi & Edisi — endpoint ADMIN (CES 13.10). */

/** @var RouteCollection $routes */
$routes->group('casaadmin/licensing', ['namespace' => 'App\Modules\Licensing\Controllers', 'filter' => 'admin'], static function (RouteCollection $routes): void {
    $routes->get('', 'LicensingController::index');
    $routes->post('(:num)/assign', 'LicensingController::assign/$1', ['filter' => 'audit:LICENSE_ASSIGN']);
});

/** Lisensi & Aktivasi (key-based, model self-hosted) — ADMIN. */
$routes->group('casaadmin/license', ['namespace' => 'App\Modules\Licensing\Controllers', 'filter' => 'admin'], static function (RouteCollection $routes): void {
    $routes->get('', 'LicenseController::index');
    $routes->post('activate', 'LicenseController::activate', ['filter' => 'audit:LICENSE_ACTIVATE']);
    $routes->post('generate', 'LicenseController::generate', ['filter' => 'audit:LICENSE_GENERATE']);
    $routes->post('sync-secret', 'LicenseController::saveSyncSecret');
    $routes->post('sync', 'LicenseController::sync', ['filter' => 'audit:LICENSE_SYNC']);
});

/** Monitoring instance (owner-only) + penerima phone-home (public, api/* bebas CSRF). */
$routes->get('casaadmin/monitoring', '\App\Modules\Licensing\Controllers\PhoneHomeController::monitor', ['filter' => 'admin']);
$routes->post('api/phonehome', '\App\Modules\Licensing\Controllers\PhoneHomeController::receive');

/** Sinkron lisensi (PULL) — instance pelanggan menarik token dari owner. */
$routes->post('api/instance/sync', '\App\Modules\Licensing\Controllers\InstanceSyncController::sync');

/** Unduh paket rilis VPS — fitur "Update Aplikasi" di instance (auth sama: install_id+sync_secret di body). */
$routes->post('api/instance/update/download', '\App\Modules\Licensing\Controllers\InstanceSyncController::updateDownload');
