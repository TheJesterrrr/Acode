<?php

declare(strict_types=1);

namespace App\Modules\Licensing\Controllers;

use App\Controllers\BaseController;
use App\Libraries\ReleaseRegistry;
use App\Modules\Licensing\Services\InstanceSyncService;
use App\Modules\Licensing\Services\SyncSecretService;
use CodeIgniter\HTTP\ResponseInterface;

/**
 * InstanceSyncController — penerima sync lisensi (public, api/instance/sync,
 * bebas CSRF via pola api/*). Instance pelanggan menarik license_token dari
 * console owner. Hanya relevan di console owner (punya private key untuk
 * menerbitkan langganan); di instance produk endpoint ini tetap ada namun tak
 * pernah menemukan langganan.
 */
final class InstanceSyncController extends BaseController
{
    public function __construct(
        private readonly InstanceSyncService $sync = new InstanceSyncService(),
        private readonly SyncSecretService $secrets = new SyncSecretService(),
    ) {
    }

    public function sync(): ResponseInterface
    {
        // Rate-limit per-IP (cegah brute-force kode sinkron): 30 req/menit.
        $throttler = \Config\Services::throttler();
        if ($throttler->check('sync_' . md5((string) $this->request->getIPAddress()), 30, MINUTE) === false) {
            return $this->response->setStatusCode(429)->setJSON(['ok' => false, 'error' => 'Terlalu banyak permintaan.']);
        }

        $payload = $this->request->getJSON(true);
        if (! is_array($payload)) {
            $payload = $this->request->getPost();
        }
        $res    = $this->sync->handle((array) $payload, (string) $this->request->getIPAddress());
        $status = (int) ($res['status'] ?? 200);
        unset($res['status']);

        return $this->response->setStatusCode($status)->setJSON($res);
    }

    /**
     * Unduh paket rilis VPS — dipakai fitur "Update Aplikasi" di instance
     * (lihat LicenseSyncService::downloadUpdate() & CasaApplyUpdate di sisi
     * instance). Auth sama seperti sync (sync_secret dari body POST, BUKAN
     * query string) — tak perlu node-lock di sini, unduh tak mengubah ikatan.
     */
    public function updateDownload(): ResponseInterface
    {
        $throttler = \Config\Services::throttler();
        if ($throttler->check('update_dl_' . md5((string) $this->request->getIPAddress()), 10, MINUTE) === false) {
            return $this->response->setStatusCode(429)->setJSON(['ok' => false, 'error' => 'Terlalu banyak permintaan.']);
        }

        $payload = $this->request->getJSON(true);
        if (! is_array($payload)) {
            $payload = $this->request->getPost();
        }
        $secret = trim((string) ($payload['sync_secret'] ?? ''));
        $file   = (string) ($payload['file'] ?? '');

        if ($secret === '' || $this->secrets->findCustomer($secret) === null) {
            return $this->response->setStatusCode(401)->setJSON(['ok' => false, 'error' => 'Kode sinkron tidak dikenal.']);
        }

        $path = ReleaseRegistry::path($file);
        if ($path === null) {
            return $this->response->setStatusCode(404)->setJSON(['ok' => false, 'error' => 'Rilis tidak ditemukan.']);
        }

        return $this->response->download($path, null)->setFileName($file);
    }
}
