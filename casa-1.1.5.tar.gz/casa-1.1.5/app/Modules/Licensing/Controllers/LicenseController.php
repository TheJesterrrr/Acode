<?php

declare(strict_types=1);

namespace App\Modules\Licensing\Controllers;

use App\Controllers\BaseController;
use App\Modules\Licensing\Config\Edition;
use App\Modules\Licensing\Services\EditionService;
use App\Modules\Licensing\Services\LicenseKeyService;
use App\Modules\Licensing\Services\LicenseSyncService;
use CodeIgniter\HTTP\ResponseInterface;
use RuntimeException;

/**
 * LicenseController — Lisensi & Aktivasi (admin). Satu halaman tahu-mode:
 * - selalu: status lisensi instance + form AKTIVASI (paste key).
 * - hanya OWNER (env license.privateKey terisi): form GENERATOR license key.
 */
final class LicenseController extends BaseController
{
    public function __construct(
        private readonly LicenseKeyService $keys = new LicenseKeyService(),
        private readonly EditionService $edition = new EditionService(),
        private readonly LicenseSyncService $syncSvc = new LicenseSyncService(),
    ) {
    }

    private function isOwner(): bool
    {
        return (string) (env('license.privateKey') ?: '') !== '';
    }

    public function index(): string
    {
        $eff   = $this->keys->effective();
        $tiers = config(Edition::class)->tiers;

        return $this->adminView('App\Modules\Licensing\Views\license', [
            'title'          => 'Lisensi & Aktivasi',
            'eff'            => $eff,
            'tierLbl'        => $tiers[$eff['tier']]['label'] ?? ucfirst((string) $eff['tier']),
            'is_owner'       => $this->isOwner(),
            'tiers'          => $tiers,
            'sync_url'       => (string) (env('sync.url') ?: ''),
            'sync_secret_set' => $this->syncSvc->hasSecret(),
        ], 'license');
    }

    /** Simpan kode sinkron (produk VPS). */
    public function saveSyncSecret(): ResponseInterface
    {
        $secret = trim((string) $this->request->getPost('secret'));
        if ($secret === '') {
            return $this->fail('Kode sinkron kosong.');
        }
        $this->syncSvc->saveSecret($secret);

        return $this->ok(['message' => 'Kode sinkron tersimpan.']);
    }

    /** Sinkron lisensi online dari console owner (produk VPS). */
    public function sync(): ResponseInterface
    {
        $res = $this->syncSvc->sync();

        return empty($res['ok']) ? $this->fail((string) ($res['error'] ?? 'Gagal.')) : $this->ok($res);
    }

    /** Aktivasi license key (instance mana pun). */
    public function activate(): ResponseInterface
    {
        try {
            $p = $this->keys->activate((string) $this->request->getPost('token'));
        } catch (RuntimeException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok(['tier' => $p['tier'] ?? '?', 'exp' => $p['exp'] ?? null]);
    }

    /** Generate license key (OWNER only). */
    public function generate(): ResponseInterface
    {
        if (! $this->isOwner()) {
            return $this->fail('Hanya console OWNER (dengan private key) yang dapat menerbitkan lisensi.', 403);
        }
        try {
            $token = $this->keys->sign([
                'tier'     => (string) $this->request->getPost('tier'),
                'days'     => (int) $this->request->getPost('days'),
                'customer' => (string) $this->request->getPost('customer'),
            ], (string) env('license.privateKey'));
        } catch (RuntimeException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok(['token' => $token]);
    }
}
