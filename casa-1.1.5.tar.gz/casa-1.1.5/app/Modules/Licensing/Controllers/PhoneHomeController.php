<?php

declare(strict_types=1);

namespace App\Modules\Licensing\Controllers;

use App\Controllers\BaseController;
use App\Modules\Licensing\Services\PhoneHomeService;
use CodeIgniter\HTTP\ResponseInterface;

/**
 * PhoneHomeController — penerima telemetri (public, api/phonehome) + dashboard
 * monitoring (owner-only, casaadmin/monitoring).
 */
final class PhoneHomeController extends BaseController
{
    public function __construct(private readonly PhoneHomeService $phone = new PhoneHomeService())
    {
    }

    /** Penerima phone-home (public, dikecualikan CSRF via api/*). */
    public function receive(): ResponseInterface
    {
        $payload = $this->request->getJSON(true);
        if (! is_array($payload)) {
            $payload = $this->request->getPost();
        }
        $this->phone->receive((array) $payload, (string) $this->request->getIPAddress());

        return $this->response->setJSON(['ok' => true]);
    }

    /** Dashboard monitoring instance (owner-only). */
    public function monitor(): string
    {
        $this->requireOwnerConsole();

        return $this->adminView('App\Modules\Licensing\Views\monitoring', [
            'title' => 'Monitoring Instance',
        ] + $this->phone->overview(), 'monitoring');
    }
}
