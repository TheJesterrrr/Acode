<?php

declare(strict_types=1);

namespace App\Modules\Licensing\Controllers;

use App\Controllers\BaseController;
use App\Modules\Auth\Models\CustomerModel;
use App\Modules\Licensing\Models\LicenseModel;
use App\Modules\Licensing\Services\EditionService;
use CodeIgniter\HTTP\ResponseInterface;
use RuntimeException;

/** LicensingController — kelola edisi/lisensi pelanggan (admin; CES 13.2 thin). */
final class LicensingController extends BaseController
{
    public function __construct(
        private readonly EditionService $edition = new EditionService(),
        private readonly CustomerModel $customers = new CustomerModel(),
        private readonly LicenseModel $licenses = new LicenseModel(),
    ) {
    }

    public function index(): string
    {
        $this->requireOwnerConsole();
        $rows = [];
        foreach ($this->customers->orderBy('id', 'DESC')->findAll(300) as $c) {
            $eff    = $this->edition->resolve((int) $c['id']);
            $lic    = $this->licenses->forCustomer((int) $c['id']);
            $rows[] = [
                'id'         => (int) $c['id'],
                'name'       => $c['name'],
                'email'      => $c['email'],
                'tier'       => $eff['tier'],
                'label'      => $eff['label'],
                'expired'    => $eff['expired'],
                'expires_at' => $lic['expires_at'] ?? null,
                'has_lic'    => $lic !== null,
            ];
        }

        return $this->adminView('App\Modules\Licensing\Views\index', [
            'title'     => 'Lisensi & Edisi',
            'customers' => $rows,
            'tiers'     => $this->edition->tiers(),
        ], 'licensing');
    }

    public function assign(int $customerId): ResponseInterface
    {
        $this->requireOwnerConsole();
        if ($this->customers->find($customerId) === null) {
            return $this->fail('Pelanggan tidak ditemukan.');
        }
        try {
            $this->edition->assign($customerId, [
                'tier'          => (string) $this->request->getPost('tier'),
                'status'        => (string) $this->request->getPost('status'),
                'max_projects'  => $this->request->getPost('max_projects'),
                'max_targets'   => $this->request->getPost('max_targets'),
                'max_schedules' => $this->request->getPost('max_schedules'),
                'expires_at'    => $this->request->getPost('expires_at'),
                'note'          => (string) $this->request->getPost('note'),
            ]);
        } catch (RuntimeException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok(['tier' => $this->edition->resolve($customerId)['label']]);
    }
}
