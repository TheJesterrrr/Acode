# Modul Audit

Jejak tindakan APPEND-ONLY (CES 2.6). Satu-satunya penulis: `AuditService`
(menggantikan `AuditLogger` lama). Model sengaja tidak mengekspos update/delete.

- Redaksi otomatis untuk field peka (password/token/secret/key/hash).
- Aktor disimpulkan dari sesi (admin/member) atau sistem (cron).
- Kegagalan pencatatan tidak menggagalkan aksi bisnis.

`AuditFilter` (app/Filters) kini mendelegasikan ke `AuditService` — menutup
utang teknis **AUD-1**. Panel admin read-only (list/detail) dibangun bersama
admin shell (fase Dashboard).
