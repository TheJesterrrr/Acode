<?php

declare(strict_types=1);

namespace App\Modules\Audit\Models;

use CodeIgniter\Model;

/**
 * AuditLogModel — akses tabel `audit_logs` (CES 13.3).
 *
 * APPEND-ONLY (CES 2.6): model ini SENGAJA tidak mengekspos update/delete.
 * Jejak yang dapat diubah tidak berguna sebagai bukti.
 */
final class AuditLogModel extends Model
{
    protected $table         = 'audit_logs';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $useTimestamps = false;
    protected $allowedFields  = [
        'actor_type', 'actor_id', 'action', 'entity_type', 'entity_id',
        'before_json', 'after_json', 'ip', 'user_agent',
    ];

    /** Daftar terbaru dengan filter opsional (untuk panel admin read-only). */
    public function page(array $filter, int $limit, int $offset): array
    {
        // Nama aktor digabungkan di sini agar tampilan cukup membaca satu kolom.
        // actor_type 'user' merujuk tabel users (admin), 'customer' merujuk
        // customers; 'system' tidak punya baris pemilik (cron/CLI).
        $b = $this->db->table('audit_logs a')
            ->select('a.*, u.name AS user_name, u.email AS user_email,'
                . ' c.name AS customer_name, c.email AS customer_email')
            ->join('users u', "u.id = a.actor_id AND a.actor_type = 'user'", 'left')
            ->join('customers c', "c.id = a.actor_id AND a.actor_type = 'customer'", 'left')
            ->orderBy('a.id', 'DESC');

        if (! empty($filter['action'])) {
            $b->where('a.action', $filter['action']);
        }
        if (! empty($filter['entity_type'])) {
            $b->where('a.entity_type', $filter['entity_type']);
        }

        $rows = $b->get($limit, $offset)->getResultArray();

        foreach ($rows as &$r) {
            $r['actor_name'] = match ($r['actor_type']) {
                'user'     => $r['user_name'] ?? ('Admin #' . (int) $r['actor_id']),
                'customer' => $r['customer_name'] ?? ('Pelanggan #' . (int) $r['actor_id']),
                default    => 'Sistem',
            };
            $r['actor_email'] = $r['user_email'] ?? ($r['customer_email'] ?? null);
        }

        return $rows;
    }
}
