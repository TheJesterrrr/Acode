<?php

declare(strict_types=1);

namespace App\Modules\Audit\Services;

use App\Libraries\Cer;
use App\Modules\Audit\Models\AuditLogModel;
use Throwable;

/**
 * AuditService — pencatat jejak tindakan (CES 2.6, 13.4).
 * Menggantikan facade `AuditLogger` lama. Satu-satunya penulis audit log.
 *
 * - APPEND-ONLY: hanya menulis, tidak pernah ubah/hapus.
 * - REDAKSI: nilai peka (password/token/secret/key/hash) diganti penanda
 *   sebelum ditulis, agar audit log tidak menjadi gudang kredensial.
 * - Kegagalan mencatat TIDAK menggagalkan aksi bisnis (hanya log berkas).
 */
final class AuditService
{
    private const REDACT = [
        'password', 'passwd', 'secret', 'token', 'key', 'hash',
        'chr_api_password', 'l2tp_ipsec_secret', 'agent_token',
    ];

    public function __construct(private readonly AuditLogModel $model = new AuditLogModel())
    {
    }

    /** Aktor disimpulkan dari sesi (admin/member) atau sistem (CLI/cron). */
    public function log(
        string $action,
        ?string $entityType = null,
        ?int $entityId = null,
        ?array $before = null,
        ?array $after = null
    ): void {
        [$actorType, $actorId] = $this->actor();
        $this->write($actorType, $actorId, $action, $entityType, $entityId, $before, $after);
    }

    public function system(
        string $action,
        ?string $entityType = null,
        ?int $entityId = null,
        ?array $after = null
    ): void {
        $this->write('system', null, $action, $entityType, $entityId, null, $after);
    }

    private function write(
        string $actorType,
        ?int $actorId,
        string $action,
        ?string $entityType,
        ?int $entityId,
        ?array $before,
        ?array $after
    ): void {
        try {
            $isCli = is_cli();
            $this->model->insert([
                'actor_type'  => $actorType,
                'actor_id'    => $actorId,
                'action'      => $action,
                'entity_type' => $entityType,
                'entity_id'   => $entityId,
                'before_json' => $this->sanitize($before),
                'after_json'  => $this->sanitize($after),
                'ip'          => $isCli ? null : service('request')->getIPAddress(),
                'user_agent'  => $isCli ? 'cron' : substr((string) service('request')->getUserAgent(), 0, 255),
            ], false);
        } catch (Throwable $e) {
            log_message('error', 'Gagal menulis audit log: ' . $e->getMessage());
        }
    }

    /** @return array{0:string,1:?int} */
    private function actor(): array
    {
        if (is_cli()) {
            return ['system', null];
        }
        $session = session();
        if (Cer::isAdmin() && (int) $session->get('admin_id') > 0) {
            return ['user', (int) $session->get('admin_id')];
        }
        if (Cer::isMember() && (int) $session->get('member_id') > 0) {
            return ['customer', (int) $session->get('member_id')];
        }

        return ['system', null];
    }

    private function sanitize(?array $data): ?string
    {
        if ($data === null) {
            return null;
        }
        foreach ($data as $key => $value) {
            foreach (self::REDACT as $needle) {
                if (stripos((string) $key, $needle) !== false) {
                    $data[$key] = '***REDACTED***';
                    continue 2;
                }
            }
            if (is_string($value) && ! mb_check_encoding($value, 'UTF-8')) {
                $data[$key] = '***BINARY***';
            }
        }

        return json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
}
