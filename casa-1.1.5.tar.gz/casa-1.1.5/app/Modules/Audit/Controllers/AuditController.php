<?php

declare(strict_types=1);

namespace App\Modules\Audit\Controllers;

use App\Controllers\BaseController;
use App\Modules\Audit\Models\AuditLogModel;

/** AuditController — penampil audit log (READ-ONLY; log tak dapat dihapus, CES 2.6). */
final class AuditController extends BaseController
{
    private const PER_PAGE = 50;

    public function __construct(private readonly AuditLogModel $model = new AuditLogModel())
    {
    }

    public function index(): string
    {
        $page   = max(1, (int) $this->request->getGet('page'));
        $filter = [
            'action'      => trim((string) $this->request->getGet('action')),
            'entity_type' => trim((string) $this->request->getGet('entity_type')),
        ];
        $rows = $this->model->page($filter, self::PER_PAGE, ($page - 1) * self::PER_PAGE);

        return $this->adminView('App\Modules\Audit\Views\index', [
            'title'  => 'Audit Log',
            'rows'   => $rows,
            'filter' => $filter,
            'page'   => $page,
            'hasNext' => count($rows) === self::PER_PAGE,
        ], 'audit');
    }
}
