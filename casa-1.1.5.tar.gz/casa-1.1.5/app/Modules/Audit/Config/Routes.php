<?php

declare(strict_types=1);

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */
$routes->get('casaadmin/audit', '\App\Modules\Audit\Controllers\AuditController::index', ['filter' => 'admin']);
