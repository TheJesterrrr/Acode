<?= $this->extend('layouts/admin') ?>
<?= $this->section('content') ?>
<?php /** @var array $rows @var array $filter @var int $page @var bool $hasNext */ ?>
<div class="casa-page-head">
  <h1>Audit Log</h1>
  <span class="small text-muted"><i class="bi bi-shield-lock me-1"></i>Read-only — catatan tidak dapat diubah/dihapus.</span>
</div>
<form class="casa-card p-3 mb-3" method="get">
  <div class="row g-2 align-items-end">
    <div class="col-sm-4"><label class="form-label small">Aksi</label><input name="action" class="form-control form-control-sm" value="<?= esc($filter['action']) ?>" placeholder="mis. TOPUP_APPROVE"></div>
    <div class="col-sm-4"><label class="form-label small">Entitas</label><input name="entity_type" class="form-control form-control-sm" value="<?= esc($filter['entity_type']) ?>" placeholder="mis. vpn_accounts"></div>
    <div class="col-sm-4"><button class="btn btn-sm btn-primary"><i class="bi bi-funnel me-1"></i>Filter</button> <a href="<?= esc(site_url('casaadmin/audit')) ?>" class="btn btn-sm btn-outline-secondary">Reset</a></div>
  </div>
</form>
<div class="casa-card p-3 p-lg-4">
  <div class="table-responsive"><table class="table table-sm align-middle mb-0">
    <thead><tr><th>Waktu</th><th>Aktor</th><th>Aksi</th><th>Entitas</th><th>IP</th></tr></thead>
    <tbody>
    <?php if ($rows === []): ?>
      <tr><td colspan="5" class="text-center text-muted py-4">Tidak ada catatan.</td></tr>
    <?php else: foreach ($rows as $r): ?>
      <tr>
        <td class="small text-muted text-nowrap"><?= esc(substr((string)($r['created_at']??''),0,19)) ?></td>
        <td class="small">
          <div class="fw-600"><?= esc($r['actor_name'] ?? $r['actor_type']) ?></div>
          <?php if (! empty($r['actor_email'])): ?>
            <div class="text-muted" style="font-size:.75rem"><?= esc($r['actor_email']) ?></div>
          <?php endif; ?>
        </td>
        <td><code class="small"><?= esc($r['action']) ?></code></td>
        <td class="small"><?= esc($r['entity_type']) ?><?= $r['entity_id']?' #'.(int)$r['entity_id']:'' ?></td>
        <td class="small text-muted"><?= esc($r['ip']) ?></td>
      </tr>
    <?php endforeach; endif; ?>
    </tbody>
  </table></div>
  <div class="d-flex justify-content-between mt-3">
    <a class="btn btn-sm btn-outline-secondary <?= $page<=1?'disabled':'' ?>" href="?page=<?= $page-1 ?>&action=<?= esc($filter['action']) ?>&entity_type=<?= esc($filter['entity_type']) ?>">← Sebelumnya</a>
    <span class="small text-muted">Halaman <?= $page ?></span>
    <a class="btn btn-sm btn-outline-secondary <?= !$hasNext?'disabled':'' ?>" href="?page=<?= $page+1 ?>&action=<?= esc($filter['action']) ?>&entity_type=<?= esc($filter['entity_type']) ?>">Berikutnya →</a>
  </div>
</div>
<?= $this->endSection() ?>
