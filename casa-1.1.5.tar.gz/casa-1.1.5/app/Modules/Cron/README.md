# Modul Cron

Penjadwal internal untuk shared hosting (satu baris crontab).

    * * * * * cd /path/app && php spark casa:cron >> /dev/null 2>&1

`CronRunner` memutuskan job mana yang jatuh tempo (dari `cron_logs`, bukan
crontab terpisah). Tiap job di bawah `Lock` flock — jalan tumpang-tindih mustahil.

Skeleton belum memuat satu pun job — job adalah urusan modul bisnis.
Daftarkan job di `CronRunner::jobs()`, berurutan dari yang paling dulu harus
jalan.

Job WAJIB tipis: memanggil service yang sudah ada, bukan memuat logika bisnis
sendiri. Satu job = satu keputusan; jangan menggabungkan dua keputusan berbeda
ke dalam satu job, karena kegagalan salah satunya akan menyembunyikan yang lain.

Paksa satu job: `php spark casa:cron renew`. Panel riwayat cron dibangun di shell.
