<?php

declare(strict_types=1);

namespace App\Modules\Cron\Services;

use App\Libraries\Lock;
use App\Libraries\RateLimiter;
use App\Modules\Cron\Jobs\CronJob;
use App\Modules\Cron\Models\CronLogModel;
use Throwable;

/**
 * CronRunner — penjadwal internal (CES 13.4).
 *
 * Shared hosting (cPanel) hanya nyaman dengan SATU baris crontab. Baris itu
 * memanggil `spark casa:cron` tiap menit; runner memutuskan job mana yang jatuh
 * tempo (dari `cron_logs`, bukan crontab terpisah). Tiap job berjalan di bawah
 * Lock flock sendiri — jalan tumpang-tindih (job harian yang lambat) mustahil.
 * Kegagalan satu job tak menghentikan yang lain.
 */
final class CronRunner
{
    public function __construct(private readonly CronLogModel $logs = new CronLogModel())
    {
    }

    /**
     * Daftar job terjadwal aplikasi.
     *
     * @return CronJob[]
     */
    public function jobs(): array
    {
        return [
            new \App\Modules\EngineHealth\Jobs\InfraAuditJob(),
        ];
    }

    /** Jalankan semua job yang jatuh tempo. @return array<int,string> baris ringkasan. */
    public function runDue(?callable $echo = null): array
    {
        $out = [];
        foreach ($this->jobs() as $job) {
            if (! $this->isDue($job)) {
                continue;
            }
            $out[] = $line = $this->runJob($job);
            if ($echo !== null) {
                $echo($line);
            }
        }
        RateLimiter::prune();

        return $out;
    }

    /** Paksa jalankan satu job (tombol admin / uji). */
    public function runOne(string $name): string
    {
        foreach ($this->jobs() as $job) {
            if ($job->name() === $name) {
                return $this->runJob($job);
            }
        }

        return "Job '{$name}' tidak dikenal.";
    }

    public function names(): array
    {
        return array_map(static fn (CronJob $j): string => $j->name(), $this->jobs());
    }

    private function isDue(CronJob $job): bool
    {
        $last = $this->logs->lastOkAt($job->name());

        return $last === null || (time() - $last) >= $job->intervalMinutes() * 60;
    }

    private function runJob(CronJob $job): string
    {
        $result = Lock::run('cron-' . $job->name(), function () use ($job): array {
            $start = hrtime(true);
            try {
                $msg = $job->run();
                $ms  = (int) ((hrtime(true) - $start) / 1e6);
                $this->log($job->name(), 'ok', $msg, $ms);

                return ['ok', $msg, $ms];
            } catch (Throwable $e) {
                $ms = (int) ((hrtime(true) - $start) / 1e6);
                log_message('error', sprintf("Cron '%s' galat: %s", $job->name(), $e->getMessage()));
                $this->log($job->name(), 'error', $e->getMessage(), $ms);

                return ['error', $e->getMessage(), $ms];
            }
        });

        if ($result === null) {
            return sprintf('[%s] dilewati — sudah berjalan (terkunci).', $job->name());
        }

        return sprintf('[%s] %s: %s (%dms)', $job->name(), $result[0], $result[1], $result[2]);
    }

    private function log(string $job, string $status, string $message, int $ms): void
    {
        $this->logs->insert([
            'job' => $job, 'status' => $status,
            'message' => mb_substr($message, 0, 500), 'duration_ms' => $ms, 'ran_at' => date('Y-m-d H:i:s'),
        ], false);
    }
}
