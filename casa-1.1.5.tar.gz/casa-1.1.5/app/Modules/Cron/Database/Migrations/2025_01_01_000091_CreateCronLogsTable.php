<?php

declare(strict_types=1);

namespace App\Modules\Cron\Database\Migrations;

use CodeIgniter\Database\Migration;
use CodeIgniter\Database\RawSql;

/** Tabel `cron_logs` — jejak eksekusi job terjadwal (CES 13.8). Tabel ke-25. */
final class CreateCronLogsTable extends Migration
{
    public function up(): void
    {
        $this->forge->addField([
            'id'          => ['type' => 'BIGINT', 'unsigned' => true, 'auto_increment' => true],
            'job'         => ['type' => 'VARCHAR', 'constraint' => 60],
            'status'      => ['type' => 'ENUM', 'constraint' => ['ok', 'error']],
            'message'     => ['type' => 'VARCHAR', 'constraint' => 500, 'null' => true],
            'duration_ms' => ['type' => 'INT', 'unsigned' => true, 'null' => true],
            'ran_at'      => ['type' => 'TIMESTAMP', 'default' => new RawSql('CURRENT_TIMESTAMP')],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addKey(['job', 'status', 'ran_at']);
        $this->forge->createTable('cron_logs', true, ['ENGINE' => 'InnoDB', 'DEFAULT CHARSET' => 'utf8mb4', 'COLLATE' => 'utf8mb4_unicode_ci']);
    }

    public function down(): void
    {
        $this->forge->dropTable('cron_logs', true);
    }
}
