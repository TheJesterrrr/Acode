<?php

declare(strict_types=1);

namespace App\Modules\Cron\Jobs;

/**
 * CronJob — kontrak satu pekerjaan terjadwal (CES 1.6). Satu job = satu
 * keputusan (renew TIDAK sekaligus suspend), agar bug pada satu tak merembet.
 */
interface CronJob
{
    public function name(): string;

    public function label(): string;

    /** Interval minimum antar-jalan (menit). Runner memanggil hanya bila jatuh tempo. */
    public function intervalMinutes(): int;

    /** Jalankan; kembalikan ringkasan singkat untuk cron_logs. */
    public function run(): string;
}
