<?php

declare(strict_types=1);

use CodeIgniter\Router\RouteCollection;

/** Rute modul Cron — admin (CES 13.10). */

/** @var RouteCollection $routes */
$routes->group('casaadmin/cron', ['namespace' => 'App\Modules\Cron\Controllers', 'filter' => 'admin'], static function (RouteCollection $routes): void {
    $routes->get('',                'CronController::index');
    $routes->post('([a-z-]+)/run',  'CronController::run/$1');
});
