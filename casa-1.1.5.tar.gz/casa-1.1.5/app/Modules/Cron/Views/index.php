<?= $this->extend('layouts/admin') ?>
<?= $this->section('content') ?>
<?php /** @var array $jobs @var array $recent */
if (! function_exists('itv')) { function itv(int $m): string { return $m>=1440 ? intdiv($m,1440).' hari' : ($m>=60 ? intdiv($m,60).' jam' : $m.' menit'); } } ?>
<div class="casa-page-head"><h1>Riwayat Cron</h1></div>

<div class="casa-card p-3 p-lg-4 mb-3">
  <h2 class="h6 mb-3">Job Terjadwal</h2>
  <div class="table-responsive"><table class="table table-sm align-middle mb-0">
    <thead><tr><th>Job</th><th>Interval</th><th>Terakhir Sukses</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($jobs as $j): ?>
      <tr>
        <td><div class="fw-600"><?= esc($j['label']) ?></div><code class="small text-muted"><?= esc($j['name']) ?></code></td>
        <td class="small"><?= esc(itv((int)$j['interval'])) ?></td>
        <td class="small text-muted"><?= esc($j['last'] ?? 'belum pernah') ?></td>
        <td class="text-end"><button class="btn btn-sm btn-outline-primary" onclick="runJob('<?= esc($j['name']) ?>',this)"><i class="bi bi-play-fill"></i> Run</button></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <div class="form-text mt-2"><i class="bi bi-info-circle me-1"></i>Crontab cPanel: <code>* * * * * cd /path/app &amp;&amp; php spark casa:cron &gt;&gt; /dev/null 2&gt;&amp;1</code></div>
</div>

<div class="casa-card p-3 p-lg-4">
  <h2 class="h6 mb-3">Eksekusi Terakhir</h2>
  <div class="table-responsive"><table class="table table-sm align-middle mb-0">
    <thead><tr><th>Waktu</th><th>Job</th><th>Status</th><th>Durasi</th><th>Pesan</th></tr></thead>
    <tbody>
    <?php if ($recent === []): ?>
      <tr><td colspan="5" class="text-center text-muted py-3">Belum ada eksekusi.</td></tr>
    <?php else: foreach ($recent as $r): ?>
      <tr>
        <td class="small text-muted text-nowrap"><?= esc(substr((string)$r['ran_at'],0,19)) ?></td>
        <td><code class="small"><?= esc($r['job']) ?></code></td>
        <td><span class="badge bg-<?= $r['status']==='ok'?'success':'danger' ?>"><?= esc($r['status']) ?></span></td>
        <td class="small"><?= $r['duration_ms']!==null?(int)$r['duration_ms'].'ms':'—' ?></td>
        <td class="small text-muted"><?= esc($r['message']) ?></td>
      </tr>
    <?php endforeach; endif; ?>
    </tbody>
  </table></div>
</div>
<?= $this->endSection() ?>

<?= $this->section('page_scripts') ?>
<script>
async function runJob(name, btn){ btn.disabled=true;
  var d=await casaPost('<?= esc(site_url('casaadmin/cron/')) ?>'+name+'/run',{});
  if(d.ok){ alert(d.message||'Done.'); location.reload(); } else { alert(d.error||'Failed.'); btn.disabled=false; }
}
</script>
<?= $this->endSection() ?>
