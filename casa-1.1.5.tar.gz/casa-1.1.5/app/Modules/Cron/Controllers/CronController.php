<?php

declare(strict_types=1);

namespace App\Modules\Cron\Controllers;

use App\Controllers\BaseController;
use App\Modules\Cron\Models\CronLogModel;
use App\Modules\Cron\Services\CronRunner;
use CodeIgniter\HTTP\ResponseInterface;

/** CronController — pemantauan & pemicu manual job terjadwal (admin). CES 13.2. */
final class CronController extends BaseController
{
    public function __construct(
        private readonly CronRunner $runner = new CronRunner(),
        private readonly CronLogModel $logs = new CronLogModel(),
    ) {
    }

    public function index(): string
    {
        $jobs = [];
        foreach ($this->runner->jobs() as $job) {
            $last = $this->logs->lastOkAt($job->name());
            $jobs[] = [
                'name'     => $job->name(),
                'label'    => $job->label(),
                'interval' => $job->intervalMinutes(),
                'last'     => $last ? date('Y-m-d H:i', $last) : null,
            ];
        }

        return $this->adminView('App\Modules\Cron\Views\index', [
            'title'  => 'Riwayat Cron',
            'jobs'   => $jobs,
            'recent' => $this->logs->recent(50),
        ], 'cron');
    }

    /** POST /casaadmin/cron/{name}/run — paksa jalankan satu job. */
    public function run(string $name): ResponseInterface
    {
        $message = $this->runner->runOne($name);

        return $this->ok(['message' => $message]);
    }
}
