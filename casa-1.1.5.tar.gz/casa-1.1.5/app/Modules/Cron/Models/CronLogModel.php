<?php

declare(strict_types=1);

namespace App\Modules\Cron\Models;

use CodeIgniter\Model;

/** CronLogModel — jejak eksekusi cron (tabel `cron_logs`). */
final class CronLogModel extends Model
{
    protected $table         = 'cron_logs';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $useTimestamps = false;
    protected $allowedFields  = ['job', 'status', 'message', 'duration_ms', 'ran_at'];

    /** Waktu (unix) job terakhir SUKSES, atau null bila belum pernah. */
    public function lastOkAt(string $job): ?int
    {
        $row = $this->select('ran_at')->where('job', $job)->where('status', 'ok')
            ->orderBy('id', 'DESC')->first();

        return $row === null ? null : strtotime((string) $row['ran_at']);
    }

    public function recent(int $limit = 50): array
    {
        return $this->orderBy('id', 'DESC')->findAll($limit);
    }
}
