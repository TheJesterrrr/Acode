<?php

declare(strict_types=1);

use CodeIgniter\Router\RouteCollection;

/** Rute Automation / pemindaian terjadwal — endpoint MEMBER (CES 13.10). */

/** @var RouteCollection $routes */
$routes->group('projects/(:num)/automation', ['namespace' => 'App\Modules\Automation\Controllers', 'filter' => 'member'], static function (RouteCollection $routes): void {
    $routes->get('', 'AutomationController::index/$1');
    $routes->post('', 'AutomationController::create/$1', ['filter' => 'audit:SCHEDULE_CREATE']);
    $routes->post('(:num)/toggle', 'AutomationController::toggle/$1/$2', ['filter' => 'audit:SCHEDULE_TOGGLE']);
    $routes->post('(:num)/delete', 'AutomationController::delete/$1/$2', ['filter' => 'audit:SCHEDULE_DELETE']);
});
