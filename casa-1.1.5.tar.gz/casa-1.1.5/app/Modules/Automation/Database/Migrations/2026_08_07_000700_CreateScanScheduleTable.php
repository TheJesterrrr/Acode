<?php

declare(strict_types=1);

namespace App\Modules\Automation\Database\Migrations;

use CodeIgniter\Database\Migration;

/**
 * Tabel `scan_schedule` — Automation / pemindaian terjadwal (Master Plan §12 #20).
 * Worker `casa:schedule` (cron) meluncurkan Mission saat `next_run_at` jatuh tempo.
 */
final class CreateScanScheduleTable extends Migration
{
    public function up(): void
    {
        $this->forge->addField([
            'id'              => ['type' => 'INT', 'constraint' => 10, 'unsigned' => true, 'auto_increment' => true],
            'project_id'      => ['type' => 'INT', 'constraint' => 10, 'unsigned' => true],
            'customer_id'     => ['type' => 'INT', 'constraint' => 10, 'unsigned' => true],
            'brief'           => ['type' => 'VARCHAR', 'constraint' => 200, 'null' => true],
            'cadence'         => ['type' => 'VARCHAR', 'constraint' => 10], // hourly|daily|weekly|monthly
            'run_hour'        => ['type' => 'TINYINT', 'constraint' => 2, 'default' => 2],  // 0-23 (waktu server)
            'run_dow'         => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 1],  // 0=Min..6=Sab (weekly)
            'run_dom'         => ['type' => 'TINYINT', 'constraint' => 2, 'default' => 1],  // 1-28 (monthly)
            'enabled'         => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 1],
            'last_run_at'     => ['type' => 'DATETIME', 'null' => true],
            'next_run_at'     => ['type' => 'DATETIME', 'null' => true],
            'last_mission_id' => ['type' => 'INT', 'constraint' => 10, 'unsigned' => true, 'null' => true],
            'last_error'      => ['type' => 'VARCHAR', 'constraint' => 200, 'null' => true],
            'run_count'       => ['type' => 'INT', 'constraint' => 8, 'default' => 0],
            'created_at'      => ['type' => 'DATETIME', 'null' => true],
            'updated_at'      => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey(['enabled', 'next_run_at']);
        $this->forge->addKey('project_id');
        $this->forge->createTable('scan_schedule', true, ['ENGINE' => 'InnoDB', 'DEFAULT CHARSET' => 'utf8mb4', 'COLLATE' => 'utf8mb4_unicode_ci']);
    }

    public function down(): void
    {
        $this->forge->dropTable('scan_schedule', true);
    }
}
