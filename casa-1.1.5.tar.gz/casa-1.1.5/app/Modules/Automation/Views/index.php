<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<?php
/** @var array $project @var array $schedules */
$pid  = (int) $project['id'];
$days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
$cadLabel = ['hourly' => 'Tiap jam', 'daily' => 'Harian', 'weekly' => 'Mingguan', 'monthly' => 'Bulanan'];
?>
<div class="casa-page-head">
  <div>
    <a href="<?= esc(site_url('projects/' . $pid)) ?>" class="small text-muted text-decoration-none"><i class="bi bi-arrow-left"></i> <?= esc($project['name']) ?></a>
    <h1 class="mb-0"><i class="bi bi-clock-history me-1"></i>Automation</h1>
    <div class="small text-muted">Scan terjadwal — CASA meluncurkan Mission otomatis sesuai jadwal. Worker <code>casa:schedule</code> (cron) yang menjalankan.</div>
  </div>
</div>

<div class="row g-3">
  <div class="col-lg-5">
    <div class="casa-card p-3 p-lg-4">
      <h2 class="h6 mb-3">Jadwal baru</h2>
      <form id="schForm">
        <div class="mb-3"><label class="form-label small">Brief misi (opsional)</label>
          <input name="brief" class="form-control" placeholder="mis. Audit mingguan permukaan serang"></div>
        <div class="mb-3"><label class="form-label small">Kadensi</label>
          <select name="cadence" id="cadence" class="form-select">
            <option value="daily">Harian</option>
            <option value="weekly" selected>Mingguan</option>
            <option value="monthly">Bulanan</option>
            <option value="hourly">Tiap jam</option>
          </select></div>
        <div class="row g-2">
          <div class="col-6 fld-hour"><label class="form-label small">Jam (0-23)</label>
            <input name="run_hour" type="number" min="0" max="23" value="2" class="form-control"></div>
          <div class="col-6 fld-dow"><label class="form-label small">Hari (mingguan)</label>
            <select name="run_dow" class="form-select">
              <?php foreach ($days as $i => $d): ?><option value="<?= $i ?>" <?= $i === 1 ? 'selected' : '' ?>><?= $d ?></option><?php endforeach; ?>
            </select></div>
          <div class="col-6 fld-dom d-none"><label class="form-label small">Tanggal (1-28)</label>
            <input name="run_dom" type="number" min="1" max="28" value="1" class="form-control"></div>
        </div>
        <button id="schBtn" class="btn btn-primary mt-3"><i class="bi bi-plus-lg me-1"></i>Add schedule</button>
        <span id="schMsg" class="small ms-2"></span>
      </form>
      <div class="small text-muted mt-3"><i class="bi bi-info-circle me-1"></i>Jadwal butuh Policy + target siap. Bila belum, misi terjadwal akan mencatat error (lihat kolom Catatan) tanpa menghentikan jadwal.</div>
    </div>
  </div>

  <div class="col-lg-7">
    <div class="casa-card p-0 h-100">
      <div class="p-3 border-bottom" style="border-color:var(--casa-card-brd)!important"><h2 class="h6 mb-0">Jadwal aktif (<?= count($schedules) ?>)</h2></div>
      <div class="table-responsive">
        <table class="table align-middle mb-0">
          <thead><tr><th class="ps-3">Kadensi</th><th>Berikutnya</th><th>Terakhir</th><th>Status</th><th class="text-end pe-3">Aksi</th></tr></thead>
          <tbody>
            <?php if ($schedules === []): ?>
              <tr><td colspan="5" class="text-center text-muted py-4">Belum ada jadwal.</td></tr>
            <?php else: foreach ($schedules as $s): ?>
              <tr data-id="<?= (int) $s['id'] ?>">
                <td class="ps-3">
                  <div class="fw-semibold"><?= esc($cadLabel[$s['cadence']] ?? $s['cadence']) ?></div>
                  <div class="small text-muted">
                    <?php if ($s['cadence'] === 'weekly'): ?><?= esc($days[(int) $s['run_dow']]) ?>, <?php elseif ($s['cadence'] === 'monthly'): ?>tgl <?= (int) $s['run_dom'] ?>, <?php endif; ?>
                    <?php if ($s['cadence'] !== 'hourly'): ?>jam <?= sprintf('%02d:00', (int) $s['run_hour']) ?><?php endif; ?>
                    <?= $s['brief'] ? '· ' . esc($s['brief']) : '' ?>
                  </div>
                  <?php if (! empty($s['last_error'])): ?><div class="small text-danger" title="<?= esc($s['last_error']) ?>"><i class="bi bi-exclamation-triangle"></i> <?= esc(mb_strimwidth($s['last_error'], 0, 48, '…')) ?></div><?php endif; ?>
                </td>
                <td class="small font-monospace"><?= esc($s['next_run_at'] ?? '—') ?></td>
                <td class="small">
                  <?php if (! empty($s['last_run_at'])): ?>
                    <?= esc($s['last_run_at']) ?>
                    <?php if (! empty($s['last_mission_id'])): ?><a href="<?= esc(site_url('missions/' . (int) $s['last_mission_id'])) ?>" class="d-block small">Mission #<?= (int) $s['last_mission_id'] ?></a><?php endif; ?>
                    <span class="text-muted">(<?= (int) $s['run_count'] ?>×)</span>
                  <?php else: ?><span class="text-muted">belum</span><?php endif; ?>
                </td>
                <td><span class="badge <?= (int) $s['enabled'] === 1 ? 'text-bg-success' : 'text-bg-secondary' ?> js-en"><?= (int) $s['enabled'] === 1 ? 'Aktif' : 'Nonaktif' ?></span></td>
                <td class="text-end pe-3">
                  <button class="btn btn-sm btn-outline-secondary js-toggle" title="Aktif/nonaktif"><i class="bi bi-power"></i></button>
                  <button class="btn btn-sm btn-outline-danger js-del" title="Delete"><i class="bi bi-trash"></i></button>
                </td>
              </tr>
            <?php endforeach; endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('page_scripts') ?>
<script>
const AP = {
  create: '<?= esc(site_url('projects/' . $pid . '/automation')) ?>',
  base:   '<?= esc(site_url('projects/' . $pid . '/automation')) ?>',
};
// Tampilkan field sesuai kadensi.
const cad = document.getElementById('cadence');
function syncFields(){
  const v = cad.value;
  document.querySelector('.fld-hour').classList.toggle('d-none', v === 'hourly');
  document.querySelector('.fld-dow').classList.toggle('d-none', v !== 'weekly');
  document.querySelector('.fld-dom').classList.toggle('d-none', v !== 'monthly');
}
cad.addEventListener('change', syncFields); syncFields();

document.getElementById('schForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const b = document.getElementById('schBtn'), m = document.getElementById('schMsg');
  b.disabled = true; const o = b.innerHTML; b.innerHTML = '<span class="spinner-border spinner-border-sm"></span>';
  const d = await casaPost(AP.create, new FormData(e.target));
  b.disabled = false; b.innerHTML = o;
  if (d.ok) { location.reload(); } else { m.className = 'small ms-2 text-danger'; m.textContent = d.error || 'Gagal.'; }
});
document.querySelectorAll('.js-toggle').forEach(btn => btn.addEventListener('click', async (e) => {
  const id = e.target.closest('tr').dataset.id;
  const d = await casaPost(AP.base + '/' + id + '/toggle', {});
  if (d.ok) location.reload();
}));
document.querySelectorAll('.js-del').forEach(btn => btn.addEventListener('click', async (e) => {
  const id = e.target.closest('tr').dataset.id;
  const d = await casaPost(AP.base + '/' + id + '/delete', {});
  if (d.ok) e.target.closest('tr').remove();
}));
</script>
<?= $this->endSection() ?>
