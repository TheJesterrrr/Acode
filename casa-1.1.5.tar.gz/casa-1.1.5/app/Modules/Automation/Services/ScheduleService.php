<?php

declare(strict_types=1);

namespace App\Modules\Automation\Services;

use App\Modules\Automation\Models\ScheduleModel;
use App\Modules\Mission\Services\MissionService;
use App\Modules\Project\Models\ProjectModel;
use DateTimeImmutable;
use RuntimeException;
use Throwable;

/**
 * ScheduleService — Automation / pemindaian terjadwal (Master Plan §12 #20).
 * Membuat & memelihara jadwal; worker `casa:schedule` memanggil runDue() dari
 * cron untuk meluncurkan Mission secara otomatis pada kadensi yang dipilih.
 */
final class ScheduleService
{
    private const CADENCES = ['hourly', 'daily', 'weekly', 'monthly'];

    public function __construct(
        private readonly ScheduleModel $schedules = new ScheduleModel(),
        private readonly ProjectModel $projects = new ProjectModel(),
        private readonly MissionService $missions = new MissionService(),
    ) {
    }

    /** @return array<int,array<string,mixed>> jadwal milik project (dgn cek kepemilikan) */
    public function forProject(int $projectId, int $customerId): array
    {
        $this->requireProject($projectId, $customerId);

        return $this->schedules->forProject($projectId);
    }

    /** Jumlah total jadwal milik pelanggan (kuota edisi). */
    public function countForCustomer(int $customerId): int
    {
        return $this->schedules->countForCustomer($customerId);
    }

    /** Buat jadwal baru → kembalikan id. @throws RuntimeException */
    public function create(int $projectId, int $customerId, array $in): int
    {
        $this->requireProject($projectId, $customerId);
        $cadence = in_array($in['cadence'] ?? '', self::CADENCES, true) ? $in['cadence'] : 'weekly';
        $hour    = max(0, min(23, (int) ($in['run_hour'] ?? 2)));
        $dow     = max(0, min(6, (int) ($in['run_dow'] ?? 1)));
        $dom     = max(1, min(28, (int) ($in['run_dom'] ?? 1)));

        return (int) $this->schedules->insert([
            'project_id'  => $projectId,
            'customer_id' => $customerId,
            'brief'       => trim((string) ($in['brief'] ?? '')) ?: null,
            'cadence'     => $cadence,
            'run_hour'    => $hour,
            'run_dow'     => $dow,
            'run_dom'     => $dom,
            'enabled'     => 1,
            'next_run_at' => $this->nextRun($cadence, $hour, $dow, $dom)->format('Y-m-d H:i:s'),
        ], true);
    }

    /** Aktif/nonaktif. @throws RuntimeException */
    public function toggle(int $id, int $customerId): bool
    {
        $s       = $this->requireSchedule($id, $customerId);
        $enabled = (int) $s['enabled'] === 1 ? 0 : 1;
        $upd     = ['enabled' => $enabled];
        if ($enabled === 1) {
            $upd['next_run_at'] = $this->nextRun($s['cadence'], (int) $s['run_hour'], (int) $s['run_dow'], (int) $s['run_dom'])->format('Y-m-d H:i:s');
        }
        $this->schedules->update($id, $upd);

        return (bool) $enabled;
    }

    /** @throws RuntimeException */
    public function delete(int $id, int $customerId): void
    {
        $this->requireSchedule($id, $customerId);
        $this->schedules->delete($id);
    }

    /**
     * Jalankan jadwal jatuh tempo (dipanggil `casa:schedule` dari cron).
     * @return array{launched:int,failed:int,skipped:int}
     */
    public function runDue(): array
    {
        $now  = new DateTimeImmutable('now');
        $due  = $this->schedules->due($now->format('Y-m-d H:i:s'));
        $stat = ['launched' => 0, 'failed' => 0, 'skipped' => 0];

        foreach ($due as $s) {
            $upd = [
                'last_run_at' => $now->format('Y-m-d H:i:s'),
                'run_count'   => (int) $s['run_count'] + 1,
                'next_run_at' => $this->nextRun($s['cadence'], (int) $s['run_hour'], (int) $s['run_dow'], (int) $s['run_dom'], $now)->format('Y-m-d H:i:s'),
            ];
            try {
                $missionId              = $this->missions->launch((int) $s['project_id'], (int) $s['customer_id'], (string) ($s['brief'] ?? ''));
                $upd['last_mission_id'] = $missionId;
                $upd['last_error']      = null;
                $stat['launched']++;
            } catch (Throwable $e) {
                $upd['last_error'] = mb_substr($e->getMessage(), 0, 200);
                $stat['failed']++;
            }
            $this->schedules->update((int) $s['id'], $upd);
        }

        return $stat;
    }

    /** Hitung waktu jalan berikutnya sesuai kadensi. */
    public function nextRun(string $cadence, int $hour, int $dow, int $dom, ?DateTimeImmutable $from = null): DateTimeImmutable
    {
        $from = $from ?? new DateTimeImmutable('now');

        return match ($cadence) {
            'hourly'  => $from->setTime((int) $from->format('H'), 0)->modify('+1 hour'),
            'weekly'  => $this->advanceTo($from->setTime($hour, 0), static fn (DateTimeImmutable $d): bool => (int) $d->format('w') === $dow, 7),
            'monthly' => $this->advanceTo($from->setTime($hour, 0), static fn (DateTimeImmutable $d): bool => (int) $d->format('j') === $dom, 366),
            default   => $this->dailyNext($from, $hour), // daily
        };
    }

    private function dailyNext(DateTimeImmutable $from, int $hour): DateTimeImmutable
    {
        $today = $from->setTime($hour, 0);

        return $today > $from ? $today : $today->modify('+1 day');
    }

    /** Maju hari demi hari hingga predikat benar & waktunya di masa depan. */
    private function advanceTo(DateTimeImmutable $start, callable $match, int $maxDays): DateTimeImmutable
    {
        $now = new DateTimeImmutable('now');
        $d   = $start;
        for ($i = 0; $i <= $maxDays; $i++) {
            if ($match($d) && $d > $now) {
                return $d;
            }
            $d = $d->modify('+1 day');
        }

        return $start->modify('+1 day'); // fallback aman
    }

    private function requireProject(int $projectId, int $customerId): array
    {
        $p = $this->projects->ownedBy($projectId, $customerId);
        if ($p === null) {
            throw new RuntimeException('Project tidak ditemukan.');
        }

        return $p;
    }

    private function requireSchedule(int $id, int $customerId): array
    {
        $s = $this->schedules->find($id);
        if ($s === null || (int) $s['customer_id'] !== $customerId) {
            throw new RuntimeException('Jadwal tidak ditemukan.');
        }

        return $s;
    }
}
