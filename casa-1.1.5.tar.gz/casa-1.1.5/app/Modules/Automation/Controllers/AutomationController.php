<?php

declare(strict_types=1);

namespace App\Modules\Automation\Controllers;

use App\Controllers\BaseController;
use App\Modules\Automation\Services\ScheduleService;
use App\Modules\Licensing\Services\EditionService;
use App\Modules\Project\Services\ProjectService;
use CodeIgniter\Exceptions\PageNotFoundException;
use CodeIgniter\HTTP\ResponseInterface;
use RuntimeException;

/** AutomationController — jadwal pemindaian per project (member; CES 13.2 thin). */
final class AutomationController extends BaseController
{
    public function __construct(
        private readonly ScheduleService $sched = new ScheduleService(),
        private readonly ProjectService $projects = new ProjectService(),
        private readonly EditionService $edition = new EditionService(),
    ) {
    }

    private function me(): int
    {
        return (int) $this->session->get('member_id');
    }

    public function index(int $projectId): string
    {
        if (! $this->edition->can($this->me(), 'automation')) {
            return $this->memberView('App\Modules\Licensing\Views\upsell', [
                'title'   => 'Automation',
                'feature' => 'Scan terjadwal (Automation)',
                'edition' => $this->edition->resolve($this->me()),
            ], 'projects');
        }
        try {
            $project   = $this->projects->getProject($projectId, $this->me());
            $schedules = $this->sched->forProject($projectId, $this->me());
        } catch (RuntimeException $e) {
            throw PageNotFoundException::forPageNotFound($e->getMessage());
        }

        return $this->memberView('App\Modules\Automation\Views\index', [
            'title'     => 'Automation — ' . $project['name'],
            'project'   => $project,
            'schedules' => $schedules,
        ], 'projects');
    }

    public function create(int $projectId): ResponseInterface
    {
        if ($r = $this->denyViewer()) {
            return $r;
        }
        try {
            $this->edition->requireFeature($this->me(), 'automation');
            $this->edition->requireQuota($this->me(), 'schedules', $this->sched->countForCustomer($this->me()));
            $id = $this->sched->create($projectId, $this->me(), [
                'brief'    => (string) $this->request->getPost('brief'),
                'cadence'  => (string) $this->request->getPost('cadence'),
                'run_hour' => (int) $this->request->getPost('run_hour'),
                'run_dow'  => (int) $this->request->getPost('run_dow'),
                'run_dom'  => (int) $this->request->getPost('run_dom'),
            ]);
        } catch (RuntimeException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok(['id' => $id]);
    }

    public function toggle(int $projectId, int $id): ResponseInterface
    {
        if ($r = $this->denyViewer()) {
            return $r;
        }
        try {
            $enabled = $this->sched->toggle($id, $this->me());
        } catch (RuntimeException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok(['enabled' => $enabled]);
    }

    public function delete(int $projectId, int $id): ResponseInterface
    {
        if ($r = $this->denyViewer()) {
            return $r;
        }
        try {
            $this->sched->delete($id, $this->me());
        } catch (RuntimeException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok([]);
    }
}
