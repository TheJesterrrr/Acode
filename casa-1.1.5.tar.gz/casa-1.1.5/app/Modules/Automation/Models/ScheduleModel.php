<?php

declare(strict_types=1);

namespace App\Modules\Automation\Models;

use CodeIgniter\Model;

/** ScheduleModel — jadwal pemindaian (`scan_schedule`). */
final class ScheduleModel extends Model
{
    protected $table         = 'scan_schedule';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $useTimestamps = true;
    protected $allowedFields  = [
        'project_id', 'customer_id', 'brief', 'cadence', 'run_hour', 'run_dow',
        'run_dom', 'enabled', 'last_run_at', 'next_run_at', 'last_mission_id',
        'last_error', 'run_count',
    ];

    /** @return array<int,array<string,mixed>> jadwal milik project */
    public function forProject(int $projectId): array
    {
        return $this->where('project_id', $projectId)->orderBy('id', 'DESC')->findAll();
    }

    /** Jumlah total jadwal milik pelanggan (untuk kuota edisi). */
    public function countForCustomer(int $customerId): int
    {
        return $this->where('customer_id', $customerId)->countAllResults();
    }

    /** @return array<int,array<string,mixed>> jadwal aktif yang jatuh tempo */
    public function due(string $now): array
    {
        return $this->where('enabled', 1)
            ->where('next_run_at <=', $now)
            ->orderBy('next_run_at', 'ASC')
            ->findAll(50);
    }
}
