# Modul Automation — Pemindaian Terjadwal

Menjadwalkan **Mission** otomatis per project pada kadensi yang dipilih
(Master Plan §12 #20). CASA meluncurkan misi tanpa intervensi manual; hasil
(finding, report) mengikuti alur Mission/Engine yang sudah ada.

## Komponen
- `Database/Migrations/…CreateScanScheduleTable` — tabel `scan_schedule`.
- `Models/ScheduleModel` — CRUD + `forProject()` + `due()`.
- `Services/ScheduleService` — buat/toggle/hapus jadwal, hitung `next_run_at`
  (hourly/daily/weekly/monthly), dan `runDue()` yang dipanggil worker.
- `Controllers/AutomationController` — endpoint **member** (thin, CES 13.2).
- `Views/index` — form jadwal + tabel jadwal aktif (toggle/hapus, link mission).
- `App\Commands\CasaSchedule` (`casa:schedule`) — worker cron peluncur misi.

## Cron
Terdaftar di `/etc/cron.d/corenet-casa` (lock sendiri):

```
* * * * * nobody flock -n /tmp/casa-schedule.lock php /var/www/casa/spark casa:schedule >/dev/null 2>&1
```

Hanya jadwal dengan `enabled=1` dan `next_run_at <= now` yang berjalan; setelah
jalan, `next_run_at` dihitung ulang. Bila prasyarat misi belum siap (Policy /
target / tool), error dicatat di `last_error` tanpa menghentikan jadwal.

## Rute (member)
- `GET  projects/{id}/automation` — kelola jadwal.
- `POST projects/{id}/automation` — buat (audit `SCHEDULE_CREATE`).
- `POST projects/{id}/automation/{sid}/toggle` — aktif/nonaktif.
- `POST projects/{id}/automation/{sid}/delete` — hapus.
