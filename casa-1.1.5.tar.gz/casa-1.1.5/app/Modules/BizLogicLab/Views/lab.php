<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<?php
/** @var array $project */
$pid   = (int) $project['id'];
$creds = $project['credentials'] ?? [];
$checks = [
    'negative_qty' => 'Kuantitas negatif (-1)',
    'zero_qty'     => 'Kuantitas nol (0)',
    'inflate_qty'  => 'Kuantitas berlebih (999999)',
    'price_tamper' => 'Manipulasi harga (→1)',
    'replay'       => 'Penyerahan ganda (replay)',
];
?>
<div class="casa-page-head">
  <div>
    <a href="<?= esc(site_url('projects/' . $pid)) ?>" class="small text-muted text-decoration-none"><i class="bi bi-arrow-left"></i> <?= esc($project['name']) ?></a>
    <h1 class="mb-0"><i class="bi bi-diagram-3 me-1"></i>Business Logic Lab <span class="badge text-bg-warning align-middle"><i class="bi bi-lock-fill"></i> Pro</span></h1>
    <div class="small text-muted">Uji cacat logika bisnis yang dilewati scanner: kuantitas negatif/nol, manipulasi harga, kuantitas berlebih, penyerahan ganda. AI menilai penerimaan tak semestinya (CWE-840).</div>
  </div>
</div>

<div class="row g-3">
  <div class="col-lg-5">
    <div class="casa-card p-3 p-lg-4">
      <h2 class="h6 mb-3">Request dasar</h2>
      <form id="blForm">
        <div class="row g-2 mb-2">
          <div class="col-4"><label class="form-label small">Method</label>
            <select name="method" class="form-select">
              <?php foreach (['POST', 'PUT', 'PATCH', 'GET'] as $mm): ?><option><?= $mm ?></option><?php endforeach; ?>
            </select></div>
          <div class="col-8"><label class="form-label small">Akun uji</label>
            <select name="cred" class="form-select">
              <option value="0">Anonymous</option>
              <?php foreach ($creds as $c): ?><option value="<?= (int) $c['id'] ?>"><?= esc($c['label']) ?> · <?= esc($c['role'] ?: 'user') ?></option><?php endforeach; ?>
            </select></div>
        </div>
        <div class="mb-2"><label class="form-label small">URL</label>
          <input name="url" class="form-control font-monospace" placeholder="http://127.0.0.1:3000/api/BasketItems/" required></div>
        <div class="mb-3"><label class="form-label small">Body (JSON)</label>
          <textarea name="body" class="form-control font-monospace" rows="5" placeholder='{"ProductId":1,"BasketId":1,"quantity":1}'></textarea></div>
        <div class="mb-3">
          <label class="form-label small">Uji yang dijalankan</label>
          <?php foreach ($checks as $k => $lbl): ?>
            <div class="form-check">
              <input class="form-check-input" type="checkbox" name="checks[]" value="<?= esc($k) ?>" id="ck_<?= esc($k) ?>" checked>
              <label class="form-check-label small" for="ck_<?= esc($k) ?>"><?= esc($lbl) ?></label>
            </div>
          <?php endforeach; ?>
        </div>
        <button id="blBtn" class="btn btn-primary"><i class="bi bi-play-fill me-1"></i>Run logic test</button>
        <span id="blMsg" class="small ms-2"></span>
      </form>
    </div>
  </div>
  <div class="col-lg-7">
    <div class="casa-card p-3 p-lg-4 h-100">
      <h2 class="h6 mb-3">Hasil</h2>
      <div id="blResult" class="text-muted small">Jalankan untuk melihat baseline, mutasi, & temuan.</div>
    </div>
  </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('page_scripts') ?>
<script>
const RUN = '<?= esc(site_url('projects/' . $pid . '/bizlogic/run')) ?>';
function st(s){ if(s===0) return '<span class="text-muted">—</span>'; const ok=s>=200&&s<300; return `<span class="${ok?'text-success':'text-warning'}">${s}</span>`; }
document.getElementById('blForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const b = document.getElementById('blBtn'), m = document.getElementById('blMsg'), out = document.getElementById('blResult');
  b.disabled = true; const o = b.innerHTML; b.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Menguji…'; m.textContent = '';
  const d = await casaPost(RUN, new FormData(e.target));
  b.disabled = false; b.innerHTML = o;
  if (!d.ok) { m.className = 'small ms-2 text-danger'; m.textContent = d.error || 'Gagal.'; return; }
  let h = `<div class="mb-2 small">Baseline: HTTP ${st(d.baseline.status)} <span class="text-muted">(${d.baseline.len}b)</span></div>`;
  h += '<table class="table table-sm align-middle"><thead><tr><th>Uji</th><th>Status</th><th>Catatan</th></tr></thead><tbody>';
  Object.values(d.results).forEach(r => {
    h += `<tr><td class="small">${r.label}</td><td>${r.applied?st(r.status):'<span class="text-muted">N/A</span>'}</td><td class="small text-muted">${(r.note||'').replace(/</g,'&lt;')}</td></tr>`;
  });
  h += '</tbody></table>';
  if (d.violations.length) {
    h += '<div class="mt-2"><b class="text-danger">Temuan (' + d.violations.length + ')</b>';
    d.violations.forEach((v,i) => {
      const sc = v.severity==='crit'?'danger':(v.severity==='high'?'warning':'secondary');
      h += `<div class="alert alert-${sc} py-2 my-2"><span class="badge text-bg-${sc} text-uppercase me-1">${v.severity}</span><b>${v.check}</b>
        <div class="small">${(v.reason||'').replace(/</g,'&lt;')}</div>
        ${d.finding_ids[i]?`<a href="/findings/${d.finding_ids[i]}" class="small">Lihat finding #${d.finding_ids[i]}</a>`:''}</div>`;
    });
    h += '</div>';
  } else {
    h += '<div class="alert alert-success mt-2 py-2"><i class="bi bi-shield-check me-1"></i>Tidak ada cacat logika terdeteksi.</div>';
  }
  out.innerHTML = h;
});
</script>
<?= $this->endSection() ?>
