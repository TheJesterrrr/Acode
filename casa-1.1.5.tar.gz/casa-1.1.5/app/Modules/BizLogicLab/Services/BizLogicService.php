<?php

declare(strict_types=1);

namespace App\Modules\BizLogicLab\Services;

use App\Modules\Ai\Services\AiManager;
use App\Modules\Finding\Services\FindingService;
use App\Modules\Project\Models\ProjectCredentialModel;
use App\Modules\Project\Models\ProjectModel;
use App\Modules\Project\Services\AuthContextResolver;
use Config\Services;
use RuntimeException;
use Throwable;

/**
 * BizLogicService — Business Logic Lab (Master Plan value-add). Menguji cacat
 * logika bisnis yang tak terdeteksi scanner: kuantitas negatif/nol, manipulasi
 * harga, kuantitas berlebih, dan penyerahan ganda (reuse). Memakai Test Account
 * (auth-context), lalu AI menilai apakah mutasi diterima secara tidak semestinya.
 * Catat Finding CWE-840 (Business Logic Errors).
 */
final class BizLogicService
{
    /** @var array<string,array{label:string,pattern:string,value:int}> */
    private const CHECKS = [
        'negative_qty' => ['label' => 'Kuantitas negatif (-1)', 'pattern' => '/(quantity|qty|jumlah|count|amount|items?)/i', 'value' => -1],
        'zero_qty'     => ['label' => 'Kuantitas nol (0)', 'pattern' => '/(quantity|qty|jumlah|count|items?)/i', 'value' => 0],
        'inflate_qty'  => ['label' => 'Kuantitas berlebih (999999)', 'pattern' => '/(quantity|qty|jumlah|count|items?)/i', 'value' => 999999],
        'price_tamper' => ['label' => 'Manipulasi harga (→1)', 'pattern' => '/(price|total|cost|harga|amount|subtotal|discount|balance|saldo|point)/i', 'value' => 1],
    ];

    private const SYS = 'You are a business-logic security analyst. A baseline authenticated request was tampered '
        . "(quantity/price mutated) and replayed. Given baseline vs mutated HTTP results, decide if the application "
        . "IMPROPERLY ACCEPTED an invalid business operation (e.g., negative/zero quantity, tampered price, unlimited "
        . "quantity, duplicate submission). Answer STRICT JSON only: "
        . '{"violations":[{"check":string,"severity":"crit|high|med|low","reason":string}]}. Empty if none.';

    public function __construct(
        private readonly ProjectModel $projects = new ProjectModel(),
        private readonly ProjectCredentialModel $creds = new ProjectCredentialModel(),
        private readonly AuthContextResolver $auth = new AuthContextResolver(),
        private readonly AiManager $ai = new AiManager(),
        private readonly FindingService $findings = new FindingService(),
    ) {
    }

    /**
     * @param string[] $checks kunci dari CHECKS + opsional 'replay'
     * @return array{baseline:array,results:array,violations:array,finding_ids:array}
     * @throws RuntimeException
     */
    public function run(int $projectId, int $customerId, int $credId, string $method, string $url, string $body, array $checks): array
    {
        if ($this->projects->ownedBy($projectId, $customerId) === null) {
            throw new RuntimeException('Project tidak ditemukan.');
        }
        $url    = trim($url);
        $method = strtoupper(trim($method)) ?: 'POST';
        if (! preg_match('#^https?://#i', $url)) {
            throw new RuntimeException('URL harus diawali http(s)://');
        }
        $data = [];
        if (trim($body) !== '') {
            $data = json_decode($body, true);
            if (! is_array($data)) {
                throw new RuntimeException('Body harus JSON valid.');
            }
        }

        $headers = ['Content-Type' => 'application/json', 'Accept' => 'application/json'];
        if ($credId > 0) {
            $c = $this->creds->find($credId);
            if ($c === null || (int) $c['project_id'] !== $projectId) {
                throw new RuntimeException('Akun uji tidak ditemukan.');
            }
            $headers += $this->auth->headersFor($c);
        }

        $client   = Services::curlrequest(['timeout' => 12, 'connect_timeout' => 5, 'http_errors' => false], null, null, false);
        $baseline = $this->send($client, $method, $url, $data, $headers);

        $results = [];
        foreach ($checks as $key) {
            if ($key === 'replay') {
                $r1 = $this->send($client, $method, $url, $data, $headers);
                $r2 = $this->send($client, $method, $url, $data, $headers);
                $results['replay'] = ['label' => 'Penyerahan ganda (replay)', 'applied' => true, 'status' => $r2['status'], 'len' => $r2['len'], 'note' => "kirim ke-2 → HTTP {$r2['status']}"];
                continue;
            }
            if (! isset(self::CHECKS[$key])) {
                continue;
            }
            $spec              = self::CHECKS[$key];
            [$mutated, $count] = $this->mutate($data, $spec['pattern'], $spec['value']);
            if ($count === 0) {
                $results[$key] = ['label' => $spec['label'], 'applied' => false, 'note' => 'tak ada field cocok'];
                continue;
            }
            $r             = $this->send($client, $method, $url, $mutated, $headers);
            $results[$key] = ['label' => $spec['label'], 'applied' => true, 'fields' => $count, 'status' => $r['status'], 'len' => $r['len'], 'note' => "{$count} field dimutasi → HTTP {$r['status']}"];
        }

        $violations = $this->analyze($baseline, $results);
        $findingIds = $this->record($projectId, $method, $url, $violations);

        return ['baseline' => $baseline, 'results' => $results, 'violations' => $violations, 'finding_ids' => $findingIds];
    }

    /**
     * Mutasi rekursif: set field numerik yg namanya cocok pola → nilai baru.
     * @return array{0:array,1:int}
     */
    private function mutate(array $data, string $pattern, int $value): array
    {
        $count = 0;
        $walk  = static function (&$node) use (&$walk, $pattern, $value, &$count): void {
            foreach ($node as $k => &$v) {
                if (is_array($v)) {
                    $walk($v);
                } elseif (is_numeric($v) && is_string($k) && preg_match($pattern, $k) && ! preg_match('/id$/i', (string) $k)) {
                    $v = $value;
                    $count++;
                }
            }
        };
        $copy = $data;
        $walk($copy);

        return [$copy, $count];
    }

    /** @return array{status:int,len:int,snippet:string} */
    private function send($client, string $method, string $url, array $data, array $headers): array
    {
        try {
            $opts = ['headers' => $headers];
            if ($data !== []) {
                $opts['body'] = json_encode($data);
            }
            $res  = $client->request($method, $url, $opts);
            $body = (string) $res->getBody();

            return ['status' => $res->getStatusCode(), 'len' => mb_strlen($body), 'snippet' => mb_substr($body, 0, 160)];
        } catch (Throwable $e) {
            return ['status' => 0, 'len' => 0, 'snippet' => ''];
        }
    }

    /** Heuristik + AI: mutasi diterima (2xx) padahal seharusnya ditolak = kandidat. */
    private function analyze(array $baseline, array $results): array
    {
        $heur = [];
        foreach ($results as $key => $r) {
            if (($r['applied'] ?? false) && isset($r['status']) && $r['status'] >= 200 && $r['status'] < 300) {
                $sev = in_array($key, ['negative_qty', 'price_tamper'], true) ? 'high' : 'med';
                $heur[$key] = ['check' => $r['label'], 'severity' => $sev, 'reason' => 'Operasi tidak valid (' . $r['label'] . ') diterima server (HTTP ' . $r['status'] . ').'];
            }
        }

        try {
            $lines = ["Baseline: HTTP {$baseline['status']} len {$baseline['len']}"];
            foreach ($results as $key => $r) {
                $lines[] = "{$key} ({$r['label']}): " . ($r['applied'] ? "HTTP {$r['status']} len {$r['len']}" : 'N/A');
            }
            $raw = $this->ai->chatForRole('vuln_analyst', self::SYS, implode("\n", $lines));
            if (preg_match('/\{.*\}/s', $raw, $mm)) {
                $j = json_decode($mm[0], true);
                if (is_array($j) && isset($j['violations']) && is_array($j['violations'])) {
                    $ai = [];
                    foreach ($j['violations'] as $v) {
                        if (is_array($v) && ! empty($v['check'])) {
                            $ai[(string) $v['check']] = [
                                'check'    => (string) $v['check'],
                                'severity' => in_array($v['severity'] ?? '', ['crit', 'high', 'med', 'low'], true) ? $v['severity'] : 'med',
                                'reason'   => (string) ($v['reason'] ?? 'Cacat logika bisnis.'),
                            ];
                        }
                    }
                    if ($ai !== []) {
                        return array_values($ai + $heur);
                    }
                }
            }
        } catch (Throwable $e) {
            // pakai heuristik
        }

        return array_values($heur);
    }

    /** @return int[] */
    private function record(int $projectId, string $method, string $url, array $violations): array
    {
        $ids = [];
        foreach ($violations as $v) {
            $ids[] = $this->findings->record([
                'project_id'  => $projectId,
                'title'       => 'Business Logic — ' . $v['check'] . ' diterima',
                'severity'    => $v['severity'],
                'cwe'         => 'CWE-840',
                'cvss'        => $v['severity'] === 'crit' ? '8.6' : ($v['severity'] === 'high' ? '7.1' : '5.0'),
                'category'    => 'Business Logic Error',
                'asset'       => $method . ' ' . $url,
                'tool'        => 'bizlogic-lab',
                'description' => "Cacat logika bisnis: {$v['reason']}",
                'evidence'    => 'Business Logic Lab — mutasi request terautentikasi (' . esc($v['check']) . ').',
                'remediation' => 'Validasi aturan bisnis di sisi server: tolak kuantitas ≤ 0 & di atas batas wajar, hitung harga dari sumber tepercaya (bukan input klien), terapkan idempotensi/anti-replay, dan verifikasi urutan alur.',
            ]);
        }

        return $ids;
    }
}
