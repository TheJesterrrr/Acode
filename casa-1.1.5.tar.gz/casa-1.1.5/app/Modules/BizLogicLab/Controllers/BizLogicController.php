<?php

declare(strict_types=1);

namespace App\Modules\BizLogicLab\Controllers;

use App\Controllers\BaseController;
use App\Modules\BizLogicLab\Services\BizLogicService;
use App\Modules\Licensing\Services\EditionService;
use App\Modules\Project\Services\ProjectService;
use CodeIgniter\Exceptions\PageNotFoundException;
use CodeIgniter\HTTP\ResponseInterface;
use RuntimeException;

/** BizLogicController — Business Logic Lab (member; CES 13.2 thin). */
final class BizLogicController extends BaseController
{
    public function __construct(
        private readonly BizLogicService $lab = new BizLogicService(),
        private readonly ProjectService $projects = new ProjectService(),
        private readonly EditionService $edition = new EditionService(),
    ) {
    }

    private function me(): int
    {
        return (int) $this->session->get('member_id');
    }

    public function show(int $projectId): string
    {
        if (! $this->edition->can($this->me(), 'business_logic')) {
            return $this->memberView('App\Modules\Licensing\Views\upsell', [
                'title'   => 'Business Logic Lab',
                'feature' => 'Business Logic Lab',
                'edition' => $this->edition->resolve($this->me()),
            ], 'projects');
        }
        try {
            $project = $this->projects->getProject($projectId, $this->me());
        } catch (RuntimeException $e) {
            throw PageNotFoundException::forPageNotFound($e->getMessage());
        }

        return $this->memberView('App\Modules\BizLogicLab\Views\lab', [
            'title'   => 'Business Logic Lab — ' . $project['name'],
            'project' => $project,
        ], 'projects');
    }

    public function run(int $projectId): ResponseInterface
    {
        if ($r = $this->denyViewer()) {
            return $r;
        }
        try {
            $this->edition->requireFeature($this->me(), 'business_logic');
            $res = $this->lab->run(
                $projectId,
                $this->me(),
                (int) $this->request->getPost('cred'),
                (string) $this->request->getPost('method'),
                (string) $this->request->getPost('url'),
                (string) $this->request->getPost('body'),
                array_map('strval', (array) $this->request->getPost('checks')),
            );
        } catch (RuntimeException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok($res);
    }
}
