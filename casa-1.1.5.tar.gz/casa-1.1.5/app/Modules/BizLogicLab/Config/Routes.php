<?php

declare(strict_types=1);

use CodeIgniter\Router\RouteCollection;

/** Rute Business Logic Lab — endpoint MEMBER (CES 13.10). */

/** @var RouteCollection $routes */
$routes->group('projects/(:num)/bizlogic', ['namespace' => 'App\Modules\BizLogicLab\Controllers', 'filter' => 'member'], static function (RouteCollection $routes): void {
    $routes->get('', 'BizLogicController::show/$1');
    $routes->post('run', 'BizLogicController::run/$1', ['filter' => 'audit:BIZLOGIC_RUN']);
});
