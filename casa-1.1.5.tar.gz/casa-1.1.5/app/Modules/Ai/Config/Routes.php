<?php

declare(strict_types=1);

use CodeIgniter\Router\RouteCollection;

/** Rute modul Ai — AI Settings, endpoint admin (CES 13.10). */

/** @var RouteCollection $routes */
$routes->group('casaadmin/ai', ['namespace' => 'App\Modules\Ai\Controllers', 'filter' => 'admin'], static function (RouteCollection $routes): void {
    $routes->get('',          'AiController::index');
    $routes->post('provider', 'AiController::saveProvider', ['filter' => 'audit:AI_PROVIDER_UPDATE']);
    $routes->post('roles',    'AiController::saveRoles',    ['filter' => 'audit:AI_ROLES_UPDATE']);
    $routes->post('test',     'AiController::test',         ['filter' => 'audit:AI_TEST']);
});
