<?= $this->extend('layouts/admin') ?>
<?= $this->section('content') ?>
<?php
/** @var array $providers @var array $roles @var array $saved @var array $roleMap */
$provJson = esc(json_encode($saved, JSON_UNESCAPED_SLASHES), 'attr');
$catJson  = esc(json_encode($providers, JSON_UNESCAPED_SLASHES), 'attr');
?>
<div class="casa-page-head">
  <h1>AI Settings</h1>
  <p class="text-muted small mb-0">Pilih provider per role. Planner tidak tahu model mana yang berjalan di baliknya — AI Manager yang memutuskan. Kunci API disimpan terenkripsi.</p>
</div>

<div class="casa-card p-3 p-lg-4 mb-3">
  <h2 class="h6 mb-3">Provider</h2>
  <div class="row g-2" id="provCards">
    <?php foreach ($providers as $code => $c): $s = $saved[$code] ?? []; ?>
      <div class="col-6 col-lg-4">
        <label class="casa-prov d-block border rounded p-3 h-100" style="cursor:pointer">
          <input type="radio" name="prov" value="<?= esc($code) ?>" class="form-check-input me-2">
          <b><?= esc($c['label']) ?></b>
          <?php if (! empty($s['enabled'])): ?><span class="badge bg-success ms-1">aktif</span><?php endif; ?>
          <div class="small text-muted mt-1"><?= esc($c['adapter']) ?><?= ! empty($s['has_key']) ? ' · kunci tersimpan' : '' ?></div>
          <?php if (! empty($s['last_status'])): ?>
            <div class="small mt-1 <?= $s['last_status'] === 'ok' ? 'text-success' : 'text-danger' ?>">
              <?= $s['last_status'] === 'ok' ? '✓ terhubung' : '✗ gagal' ?><?= isset($s['last_latency_ms']) ? ' · ' . (int) $s['last_latency_ms'] . 'ms' : '' ?>
            </div>
          <?php endif; ?>
        </label>
      </div>
    <?php endforeach; ?>
  </div>

  <form id="provForm" class="mt-3">
    <input type="hidden" name="code" id="p_code">
    <div class="row g-3">
      <div class="col-lg-7">
        <label class="form-label small">API key</label>
        <input type="password" name="api_key" id="p_key" class="form-control" autocomplete="off" placeholder="Biarkan kosong = tidak mengubah kunci tersimpan">
      </div>
      <div class="col-lg-5">
        <label class="form-label small">Model default</label>
        <input type="text" name="model" id="p_model" class="form-control" placeholder="mis. claude-opus-5 / qwen2.5">
      </div>
      <div class="col-lg-9">
        <label class="form-label small">Base URL</label>
        <input type="text" name="base_url" id="p_base" class="form-control" placeholder="endpoint provider">
      </div>
      <div class="col-lg-3 d-flex align-items-end">
        <div class="form-check">
          <input type="checkbox" name="enabled" id="p_enabled" value="1" class="form-check-input">
          <label for="p_enabled" class="form-check-label small">Aktifkan</label>
        </div>
      </div>
    </div>
    <div class="mt-3 d-flex align-items-center gap-2 flex-wrap">
      <button id="p_save" class="btn btn-primary"><i class="bi bi-save me-1"></i> Save provider</button>
      <button id="p_test" type="button" class="btn btn-outline-secondary"><i class="bi bi-plug me-1"></i> Test connection</button>
      <span id="p_result" class="small ms-1"></span>
    </div>
  </form>
</div>

<div class="casa-card p-3 p-lg-4">
  <h2 class="h6 mb-1">AI roles</h2>
  <p class="text-muted small">Tiap role bisa berjalan di provider berbeda — campur Ollama lokal untuk volume dengan model cloud untuk judgment.</p>
  <form id="roleForm">
    <div class="table-responsive">
      <table class="table align-middle mb-2">
        <thead><tr><th>Role</th><th style="width:34%">Provider</th><th style="width:34%">Model</th></tr></thead>
        <tbody>
          <?php foreach ($roles as $key => $label): $rc = $roleMap[$key] ?? ['provider_code' => 'ollama', 'model' => '']; ?>
            <tr>
              <td class="fw-semibold"><?= esc($label) ?></td>
              <td>
                <select name="roles[<?= esc($key) ?>][provider]" class="form-select form-select-sm">
                  <?php foreach ($providers as $pc => $c): ?>
                    <option value="<?= esc($pc) ?>" <?= ($rc['provider_code'] ?? '') === $pc ? 'selected' : '' ?>><?= esc($c['label']) ?></option>
                  <?php endforeach; ?>
                </select>
              </td>
              <td><input name="roles[<?= esc($key) ?>][model]" class="form-control form-control-sm" value="<?= esc($rc['model'] ?? '') ?>" placeholder="model"></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <button id="r_save" class="btn btn-primary"><i class="bi bi-save me-1"></i> Save role mapping</button>
    <span id="r_result" class="small ms-2"></span>
  </form>
</div>
<?= $this->endSection() ?>

<?= $this->section('page_scripts') ?>
<script>
const SAVED = JSON.parse('<?= $provJson ?>');
const CAT   = JSON.parse('<?= $catJson ?>');
const $ = (id) => document.getElementById(id);

function selectProvider(code){
  $('p_code').value = code;
  const s = SAVED[code] || {}, c = CAT[code] || {};
  $('p_base').value  = s.base_url || c.base || '';
  $('p_model').value = s.default_model || '';
  $('p_enabled').checked = !!(s.enabled && Number(s.enabled) === 1);
  $('p_key').value = '';
  $('p_key').placeholder = s.has_key ? 'Kunci tersimpan — kosong = tidak diubah' : 'Tempel kunci API';
  $('p_result').textContent = '';
}
document.querySelectorAll('input[name=prov]').forEach(r => r.addEventListener('change', () => selectProvider(r.value)));
// pilih provider pertama secara default
const first = document.querySelector('input[name=prov]');
if (first) { first.checked = true; selectProvider(first.value); }

$('provForm').addEventListener('submit', async (e) => {
  e.preventDefault(); const b = $('p_save'); b.disabled = true;
  const d = await casaPost('<?= esc(site_url('casaadmin/ai/provider')) ?>', new FormData($('provForm')));
  const r = $('p_result');
  if (d.ok) { r.className = 'small ms-1 text-success'; r.textContent = d.message || 'Tersimpan.'; setTimeout(() => location.reload(), 600); }
  else { r.className = 'small ms-1 text-danger'; r.textContent = d.error || 'Gagal.'; b.disabled = false; }
});

$('p_test').addEventListener('click', async () => {
  const r = $('p_result'); r.className = 'small ms-1 text-muted'; r.textContent = 'Menguji…';
  const d = await casaPost('<?= esc(site_url('casaadmin/ai/test')) ?>', { code: $('p_code').value });
  if (d.ok) { r.className = 'small ms-1 text-success'; r.textContent = '✓ ' + (d.message || 'Terhubung') + (d.latency_ms ? ' · ' + d.latency_ms + 'ms' : ''); }
  else { r.className = 'small ms-1 text-danger'; r.textContent = '✗ ' + (d.error || 'Gagal'); }
});

$('roleForm').addEventListener('submit', async (e) => {
  e.preventDefault(); const b = $('r_save'); b.disabled = true;
  const d = await casaPost('<?= esc(site_url('casaadmin/ai/roles')) ?>', new FormData($('roleForm')));
  const r = $('r_result');
  if (d.ok) { r.className = 'small ms-2 text-success'; r.textContent = d.message || 'Tersimpan.'; }
  else { r.className = 'small ms-2 text-danger'; r.textContent = d.error || 'Gagal.'; }
  b.disabled = false;
});
</script>
<?= $this->endSection() ?>
