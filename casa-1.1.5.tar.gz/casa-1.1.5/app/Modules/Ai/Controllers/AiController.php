<?php

declare(strict_types=1);

namespace App\Modules\Ai\Controllers;

use App\Controllers\BaseController;
use App\Modules\Ai\Services\AiManager;
use App\Modules\Ai\Services\AiSettingsService;
use CodeIgniter\HTTP\ResponseInterface;

/**
 * AiController — AI Settings (CES 13.2 thin). Admin memilih provider, menyimpan
 * kunci (terenkripsi), memetakan AI Role, dan menguji koneksi. Seluruh logika
 * ada di service/manager; controller hanya menata input & respons.
 */
final class AiController extends BaseController
{
    public function __construct(
        private readonly AiSettingsService $settings = new AiSettingsService(),
        private readonly AiManager $manager = new AiManager(),
    ) {
    }

    public function index(): string
    {
        return $this->adminView('App\Modules\Ai\Views\index', [
            'title'     => 'AI Settings',
            'providers' => AiSettingsService::PROVIDERS,
            'roles'     => AiSettingsService::ROLES,
            'saved'     => $this->settings->providersSafe(),
            'roleMap'   => $this->settings->roleMap(),
        ], 'ai');
    }

    public function saveProvider(): ResponseInterface
    {
        try {
            $this->settings->saveProvider([
                'code'     => $this->request->getPost('code'),
                'base_url' => $this->request->getPost('base_url'),
                'model'    => $this->request->getPost('model'),
                'api_key'  => $this->request->getPost('api_key'),
                'enabled'  => $this->request->getPost('enabled'),
            ]);
        } catch (\InvalidArgumentException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok(['message' => 'Provider disimpan.']);
    }

    public function saveRoles(): ResponseInterface
    {
        $roles = $this->request->getPost('roles');
        $n     = is_array($roles) ? $this->settings->saveRoles($roles) : 0;

        return $this->ok(['message' => "Pemetaan role disimpan ({$n})."]);
    }

    public function test(): ResponseInterface
    {
        $code   = (string) $this->request->getPost('code');
        $result = $this->manager->testConnection($code);

        return $result['ok']
            ? $this->ok(['message' => $result['message'], 'latency_ms' => $result['latency_ms']])
            : $this->fail($result['message']);
    }
}
