<?php

declare(strict_types=1);

namespace App\Modules\Ai\Database\Seeds;

use App\Modules\Ai\Services\AiSettingsService;
use CodeIgniter\Database\Seeder;

/**
 * DefaultAiConfigSeeder — baris awal `ai_provider` (6 provider, nonaktif, tanpa
 * kunci) & `ai_role_config` (7 role default → Ollama lokal). Idempoten: hanya
 * menyisipkan yang belum ada; tidak menimpa konfigurasi admin.
 */
final class DefaultAiConfigSeeder extends Seeder
{
    public function run(): void
    {
        $prov = $this->db->table('ai_provider');
        foreach (AiSettingsService::PROVIDERS as $code => $cat) {
            if ($prov->where('code', $code)->countAllResults() === 0) {
                $prov->insert([
                    'code'         => $code,
                    'adapter_type' => $cat['adapter'],
                    'label'        => $cat['label'],
                    'base_url'     => $cat['base'] ?: null,
                    'enabled'      => 0,
                ]);
            }
        }

        $roles = $this->db->table('ai_role_config');
        foreach (array_keys(AiSettingsService::ROLES) as $role) {
            if ($roles->where('role', $role)->countAllResults() === 0) {
                $roles->insert(['role' => $role, 'provider_code' => 'ollama', 'model' => '']);
            }
        }
    }
}
