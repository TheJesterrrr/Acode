<?php

declare(strict_types=1);

namespace App\Modules\Ai\Database\Migrations;

use CodeIgniter\Database\Migration;
use CodeIgniter\Database\RawSql;

/** Tabel `ai_provider` — konfigurasi penyedia AI (Master Plan §5; CES 13.8). */
final class CreateAiProviderTable extends Migration
{
    public function up(): void
    {
        $this->forge->addField([
            'code'            => ['type' => 'VARCHAR', 'constraint' => 20],
            'adapter_type'    => ['type' => 'VARCHAR', 'constraint' => 16],
            'label'           => ['type' => 'VARCHAR', 'constraint' => 60],
            'base_url'        => ['type' => 'VARCHAR', 'constraint' => 200, 'null' => true],
            'api_key_enc'     => ['type' => 'TEXT', 'null' => true], // terenkripsi (Crypto)
            'default_model'   => ['type' => 'VARCHAR', 'constraint' => 80, 'null' => true],
            'enabled'         => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 0],
            'last_status'     => ['type' => 'VARCHAR', 'constraint' => 12, 'null' => true],
            'last_latency_ms' => ['type' => 'INT', 'constraint' => 11, 'null' => true],
            'last_tested_at'  => ['type' => 'TIMESTAMP', 'null' => true],
            'updated_at'      => ['type' => 'TIMESTAMP', 'default' => new RawSql('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP')],
        ]);
        $this->forge->addKey('code', true); // primary
        $this->forge->createTable('ai_provider', true, ['ENGINE' => 'InnoDB', 'DEFAULT CHARSET' => 'utf8mb4', 'COLLATE' => 'utf8mb4_unicode_ci']);
    }

    public function down(): void
    {
        $this->forge->dropTable('ai_provider', true);
    }
}
