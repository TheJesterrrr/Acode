<?php

declare(strict_types=1);

namespace App\Modules\Ai\Database\Migrations;

use CodeIgniter\Database\Migration;
use CodeIgniter\Database\RawSql;

/** Tabel `ai_role_config` — pemetaan AI Role → provider+model (Master Plan §5). */
final class CreateAiRoleConfigTable extends Migration
{
    public function up(): void
    {
        $this->forge->addField([
            'role'          => ['type' => 'VARCHAR', 'constraint' => 24],
            'provider_code' => ['type' => 'VARCHAR', 'constraint' => 20],
            'model'         => ['type' => 'VARCHAR', 'constraint' => 80, 'null' => true],
            'updated_at'    => ['type' => 'TIMESTAMP', 'default' => new RawSql('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP')],
        ]);
        $this->forge->addKey('role', true); // primary
        $this->forge->createTable('ai_role_config', true, ['ENGINE' => 'InnoDB', 'DEFAULT CHARSET' => 'utf8mb4', 'COLLATE' => 'utf8mb4_unicode_ci']);
    }

    public function down(): void
    {
        $this->forge->dropTable('ai_role_config', true);
    }
}
