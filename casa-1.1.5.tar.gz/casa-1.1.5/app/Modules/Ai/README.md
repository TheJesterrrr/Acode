# Modul Ai — AI Manager / AI Settings

Konfigurasi & verifikasi penyedia AI (Master Plan §4 `Ai`). Iterasi pertama:
memenuhi kriteria penerimaan §9 no.2 (pilih provider, simpan kunci terenkripsi,
Test Connection). Rujukan rencana: `../../../rencana/01-Modul-Ai-AI-Settings.md`.

## Isi
- `Models/AiProviderModel` — tabel `ai_provider`; enkripsi `api_key_enc` via `App\Libraries\Crypto`. Kunci **tidak pernah** dikembalikan ke controller/tampilan (hanya `keyFor()` internal).
- `Models/AiRoleConfigModel` — tabel `ai_role_config`; pemetaan 7 AI Role → provider+model.
- `Services/AiSettingsService` — pintu tunggal baca/tulis + katalog `PROVIDERS`/`ROLES` (whitelist, Zero Hardcode).
- `Services/AiManager` — merakit adapter yang tepat per provider; `testConnection()`. Dipakai modul Mission/Planner kelak.
- `Adapters/` — 3 jenis (Master Plan §11): `OpenAiCompatAdapter` (Ollama/OpenAI/OpenRouter/Azure), `AnthropicAdapter` (Claude), `GeminiAdapter`. Semua turun dari `AbstractHttpAdapter` (CURLRequest + timeout + pesan ramah).
- `Controllers/AiController` — thin (13.2): `index`, `saveProvider`, `saveRoles`, `test`.
- `Config/Routes.php` — grup `casaadmin/ai`, filter `admin` + `audit:*` (auto-discovered).
- `Database/Migrations` + `DefaultAiConfigSeeder` — skema + 6 provider (nonaktif) & 7 role default→Ollama.
- `Views/index.php` — layar AI Settings (admin shell + Bootstrap 5).

## Kepatuhan Kitab
- **5.6/5.7**: kunci terenkripsi (Crypto AES-256-GCM), tidak di-hardcode, tidak dicatat ke log/audit (audit hanya `AI_PROVIDER_UPDATE`/`AI_ROLES_UPDATE`/`AI_TEST`).
- **13.2/13.3/13.4/13.7**: thin controller, logika di service, akses tabel di model, otorisasi+audit lewat filter.
- **1.6 Zero Hardcode**: daftar provider/role di service, bukan tersebar.

## Prasyarat jalan di lab
`.env` `encryption.keyPath` → berkas kunci 32-byte di luar document root (syarat `Crypto`).
Jalankan migrasi + `DefaultAiConfigSeeder`, buka `casaadmin/ai` sebagai admin.

## Roadmap (di luar iterasi ini)
Pemakaian AI nyata di Mission (chat/complete per role) lewat `AiManager`; deteksi
VRAM & rekomendasi model lokal (Master Plan §11).
