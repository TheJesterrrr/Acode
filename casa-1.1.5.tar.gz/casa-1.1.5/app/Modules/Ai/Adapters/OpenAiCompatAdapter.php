<?php

declare(strict_types=1);

namespace App\Modules\Ai\Adapters;

/**
 * OpenAiCompatAdapter — mencakup Ollama (lokal), OpenAI, OpenRouter, Azure
 * OpenAI, dan mesin lain yang mengekspos jalur OpenAI-compatible `/models`.
 * Test Connection = GET {baseUrl}/models (Ollama juga mengekspos ini di `/v1`).
 */
final class OpenAiCompatAdapter extends AbstractHttpAdapter
{
    public function testConnection(): array
    {
        $url     = rtrim($this->baseUrl, '/') . '/models';
        $headers = ['Accept' => 'application/json'];
        // Ollama lokal tidak butuh kunci; provider cloud memakai Bearer.
        if ($this->apiKey !== '') {
            $headers['Authorization'] = 'Bearer ' . $this->apiKey;
        }

        [$status, $latency, $netError] = $this->timedGet($url, $headers);

        return $this->verdict($status, $latency, $netError);
    }

    public function chat(string $system, string $user): string
    {
        if ($this->model === '') {
            throw new \RuntimeException('Model belum dipilih untuk provider ini.');
        }
        $messages = [];
        if ($system !== '') {
            $messages[] = ['role' => 'system', 'content' => $system];
        }
        $messages[] = ['role' => 'user', 'content' => $user];

        $headers = ['Accept' => 'application/json'];
        if ($this->apiKey !== '') {
            $headers['Authorization'] = 'Bearer ' . $this->apiKey;
        }

        $body = $this->postJson(rtrim($this->baseUrl, '/') . '/chat/completions', $headers, [
            'model'       => $this->model,
            'messages'    => $messages,
            'stream'      => false,
            'temperature' => 0.1,
        ]);
        $j    = json_decode($body, true);
        $text = is_array($j) ? ($j['choices'][0]['message']['content'] ?? '') : '';
        if (! is_string($text) || trim($text) === '') {
            throw new \RuntimeException('Jawaban AI kosong.');
        }

        return $text;
    }
}
