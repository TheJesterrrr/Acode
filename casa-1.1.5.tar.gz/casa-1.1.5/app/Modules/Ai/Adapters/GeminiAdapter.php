<?php

declare(strict_types=1);

namespace App\Modules\Ai\Adapters;

/**
 * GeminiAdapter — Google Gemini. Test Connection = GET
 * {baseUrl}/v1beta/models?key=API_KEY (kunci pada query sesuai API Google).
 */
final class GeminiAdapter extends AbstractHttpAdapter
{
    public function testConnection(): array
    {
        if ($this->apiKey === '') {
            return ['ok' => false, 'latency_ms' => 0, 'message' => 'Isi & simpan kunci API Gemini lebih dulu.'];
        }

        $url = rtrim($this->baseUrl, '/') . '/v1beta/models?key=' . rawurlencode($this->apiKey);
        [$status, $latency, $netError] = $this->timedGet($url, ['Accept' => 'application/json']);

        return $this->verdict($status, $latency, $netError);
    }

    public function chat(string $system, string $user): string
    {
        if ($this->apiKey === '' || $this->model === '') {
            throw new \RuntimeException('Kunci & model Gemini wajib diisi.');
        }
        $url     = rtrim($this->baseUrl, '/') . '/v1beta/models/' . rawurlencode($this->model) . ':generateContent?key=' . rawurlencode($this->apiKey);
        $payload = ['contents' => [['parts' => [['text' => $user]]]]];
        if ($system !== '') {
            $payload['systemInstruction'] = ['parts' => [['text' => $system]]];
        }
        $body = $this->postJson($url, ['Accept' => 'application/json'], $payload);
        $j    = json_decode($body, true);
        $text = is_array($j) ? ($j['candidates'][0]['content']['parts'][0]['text'] ?? '') : '';
        if (! is_string($text) || trim($text) === '') {
            throw new \RuntimeException('Jawaban AI kosong.');
        }

        return $text;
    }
}
