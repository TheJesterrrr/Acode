<?php

declare(strict_types=1);

namespace App\Modules\Ai\Adapters;

/**
 * AiProviderAdapter — kontrak tunggal seluruh penyedia AI (Master Plan §11:
 * hanya 3 jenis adapter — OpenAI-compatible, Anthropic, Gemini).
 *
 * Iterasi pertama hanya butuh {@see testConnection()}. Method chat/complete
 * untuk pemakaian AI di Mission menyusul tanpa mengubah kontrak ini
 * (Extensible by Default, Kitab 1.6).
 */
interface AiProviderAdapter
{
    /**
     * Uji jangkauan + kredensial provider. Tidak melempar pada galat jaringan
     * atau HTTP 4xx/5xx — mengembalikan verdikt yang dapat dipahami pengguna.
     *
     * @return array{ok:bool,latency_ms:int,message:string}
     */
    public function testConnection(): array;

    /**
     * Inferensi chat: kirim system+user, kembalikan teks jawaban asisten.
     *
     * @param string $system instruksi peran (boleh kosong)
     * @param string $user   isi permintaan
     * @throws \RuntimeException dengan pesan ramah bila gagal
     */
    public function chat(string $system, string $user): string;
}
