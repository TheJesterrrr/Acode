<?php

declare(strict_types=1);

namespace App\Modules\Ai\Adapters;

use Config\Services;
use Throwable;

/**
 * AbstractHttpAdapter — dasar bersama tiga adapter HTTP. Membungkus CURLRequest
 * CI4 dengan timeout, `http_errors=false` (4xx/5xx tidak melempar), dan
 * penerjemahan galat menjadi pesan ramah pengguna (Kitab 2.4). TIDAK pernah
 * mencatat kunci/token (Kitab 5.7).
 */
abstract class AbstractHttpAdapter implements AiProviderAdapter
{
    protected const TIMEOUT         = 8;
    protected const CONNECT_TIMEOUT = 4;
    protected const CHAT_TIMEOUT    = 240; // inferensi bisa lambat di model lokal CPU (tanpa GPU)

    public function __construct(
        protected readonly string $baseUrl,
        protected readonly string $apiKey,
        protected readonly string $model = '',
    ) {
    }

    /**
     * GET terukur. Mengembalikan [statusCode, latencyMs, errorString|null].
     *
     * @param array<string,string> $headers
     * @return array{0:int,1:int,2:?string}
     */
    protected function timedGet(string $url, array $headers = []): array
    {
        $client = Services::curlrequest([
            'timeout'         => self::TIMEOUT,
            'connect_timeout' => self::CONNECT_TIMEOUT,
            'http_errors'     => false,
        ], null, null, false);

        $start = microtime(true);
        try {
            $res     = $client->get($url, ['headers' => $headers]);
            $latency = (int) round((microtime(true) - $start) * 1000);

            return [$res->getStatusCode(), $latency, null];
        } catch (Throwable $e) {
            $latency = (int) round((microtime(true) - $start) * 1000);

            return [0, $latency, $e->getMessage()];
        }
    }

    /**
     * POST JSON terukur untuk inferensi. Mengembalikan body string.
     *
     * @param array<string,string> $headers
     * @param array<string,mixed>  $payload
     * @throws \RuntimeException pesan ramah bila gagal jaringan/HTTP
     */
    protected function postJson(string $url, array $headers, array $payload): string
    {
        $client = Services::curlrequest([
            'timeout'         => self::CHAT_TIMEOUT,
            'connect_timeout' => self::CONNECT_TIMEOUT,
            'http_errors'     => false,
        ], null, null, false);

        try {
            $res = $client->post($url, [
                'headers' => ['Content-Type' => 'application/json'] + $headers,
                'body'    => json_encode($payload, JSON_UNESCAPED_SLASHES),
            ]);
        } catch (Throwable $e) {
            throw new \RuntimeException('Provider AI tak terjangkau: ' . mb_substr($e->getMessage(), 0, 80));
        }

        $status = $res->getStatusCode();
        $body   = (string) $res->getBody();
        if ($status === 401 || $status === 403) {
            throw new \RuntimeException('Kunci API ditolak (HTTP ' . $status . ').');
        }
        if ($status < 200 || $status >= 300) {
            throw new \RuntimeException('Provider AI membalas HTTP ' . $status . '.');
        }

        return $body;
    }

    /** Terjemahkan kode HTTP menjadi verdikt seragam. */
    protected function verdict(int $status, int $latency, ?string $netError): array
    {
        if ($netError !== null) {
            return ['ok' => false, 'latency_ms' => $latency, 'message' => 'Host tak terjangkau (' . $this->shortNet($netError) . ').'];
        }
        if ($status === 200) {
            return ['ok' => true, 'latency_ms' => $latency, 'message' => 'Terhubung.'];
        }
        if ($status === 401 || $status === 403) {
            return ['ok' => false, 'latency_ms' => $latency, 'message' => 'Kunci API ditolak (HTTP ' . $status . ').'];
        }
        if ($status === 404) {
            return ['ok' => false, 'latency_ms' => $latency, 'message' => 'Endpoint tidak ditemukan (HTTP 404) — periksa Base URL/model.'];
        }

        return ['ok' => false, 'latency_ms' => $latency, 'message' => 'Provider membalas HTTP ' . $status . '.'];
    }

    private function shortNet(string $msg): string
    {
        $msg = trim($msg);

        return $msg === '' ? 'timeout' : mb_substr($msg, 0, 80);
    }
}
