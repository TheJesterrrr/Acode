<?php

declare(strict_types=1);

namespace App\Modules\Ai\Adapters;

/**
 * AnthropicAdapter — Claude (format Anthropic). Test Connection = GET
 * {baseUrl}/v1/models dengan header `x-api-key` + `anthropic-version`.
 */
final class AnthropicAdapter extends AbstractHttpAdapter
{
    private const API_VERSION = '2023-06-01';

    public function testConnection(): array
    {
        if ($this->apiKey === '') {
            return ['ok' => false, 'latency_ms' => 0, 'message' => 'Isi & simpan kunci API Claude lebih dulu.'];
        }

        $url = rtrim($this->baseUrl, '/') . '/v1/models';
        [$status, $latency, $netError] = $this->timedGet($url, [
            'x-api-key'         => $this->apiKey,
            'anthropic-version' => self::API_VERSION,
            'Accept'            => 'application/json',
        ]);

        return $this->verdict($status, $latency, $netError);
    }

    public function chat(string $system, string $user): string
    {
        if ($this->apiKey === '' || $this->model === '') {
            throw new \RuntimeException('Kunci & model Claude wajib diisi.');
        }
        $body = $this->postJson(rtrim($this->baseUrl, '/') . '/v1/messages', [
            'x-api-key'         => $this->apiKey,
            'anthropic-version' => self::API_VERSION,
            'Accept'            => 'application/json',
        ], [
            'model'      => $this->model,
            'max_tokens' => 1024,
            'system'     => $system,
            'messages'   => [['role' => 'user', 'content' => $user]],
        ]);
        $j    = json_decode($body, true);
        $text = is_array($j) ? ($j['content'][0]['text'] ?? '') : '';
        if (! is_string($text) || trim($text) === '') {
            throw new \RuntimeException('Jawaban AI kosong.');
        }

        return $text;
    }
}
