<?php

declare(strict_types=1);

namespace App\Modules\Ai\Models;

use CodeIgniter\Model;

/**
 * AiRoleConfigModel — akses tabel `ai_role_config` (CES 13.3).
 * Memetakan tiap AI Role ke satu provider + model. Tanpa data rahasia.
 */
final class AiRoleConfigModel extends Model
{
    protected $table            = 'ai_role_config';
    protected $primaryKey       = 'role';
    protected $returnType       = 'array';
    protected $useTimestamps    = false;
    protected $useAutoIncrement = false;
    protected $allowedFields    = ['role', 'provider_code', 'model'];

    /** @return array<string,array{provider_code:string,model:?string}> */
    public function allAsMap(): array
    {
        $out = [];
        foreach ($this->findAll() as $row) {
            $out[$row['role']] = ['provider_code' => $row['provider_code'], 'model' => $row['model']];
        }

        return $out;
    }

    public function put(string $role, string $providerCode, string $model): void
    {
        $fields = ['provider_code' => $providerCode, 'model' => $model];
        if ($this->find($role) !== null) {
            $this->update($role, $fields);
        } else {
            $this->insert(['role' => $role] + $fields, false);
        }
    }
}
