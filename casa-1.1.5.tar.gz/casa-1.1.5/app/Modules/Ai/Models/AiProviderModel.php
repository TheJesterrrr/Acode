<?php

declare(strict_types=1);

namespace App\Modules\Ai\Models;

use App\Libraries\Crypto;
use CodeIgniter\Model;
use Throwable;

/**
 * AiProviderModel — akses tabel `ai_provider` (CES 13.3).
 *
 * `api_key_enc` disimpan terenkripsi (AES-256-GCM via Crypto) dan HANYA
 * didekripsi lewat {@see keyFor()} untuk keperluan internal (Test Connection /
 * pemanggilan AI). Nilai kunci TIDAK pernah dikembalikan ke controller/tampilan
 * (Kitab 5.6/5.7). Aturan bisnis (whitelist code, tipe adapter) ada di service.
 */
final class AiProviderModel extends Model
{
    protected $table            = 'ai_provider';
    protected $primaryKey       = 'code';
    protected $returnType       = 'array';
    protected $useTimestamps    = false;
    protected $useAutoIncrement = false;
    protected $allowedFields    = [
        'code', 'adapter_type', 'label', 'base_url', 'api_key_enc',
        'default_model', 'enabled', 'last_status', 'last_latency_ms', 'last_tested_at',
    ];

    /**
     * Seluruh provider untuk tampilan — TANPA nilai kunci; hanya flag `has_key`.
     *
     * @return array<string,array<string,mixed>> code => baris aman
     */
    public function allSafe(): array
    {
        $out = [];
        foreach ($this->findAll() as $row) {
            $out[$row['code']] = $this->strip($row);
        }

        return $out;
    }

    /** Baris mentah satu provider (termasuk `api_key_enc`); null bila tak ada. */
    public function get(string $code): ?array
    {
        return $this->find($code);
    }

    /** Kunci API terdekripsi untuk pemakaian internal; '' bila kosong/gagal. */
    public function keyFor(string $code): string
    {
        $row = $this->find($code);
        $enc = (string) ($row['api_key_enc'] ?? '');
        if ($enc === '') {
            return '';
        }
        try {
            return Crypto::decryptText($enc);
        } catch (Throwable $e) {
            log_message('error', "Gagal mendekripsi kunci AI '{$code}': " . $e->getMessage());

            return '';
        }
    }

    /**
     * Upsert konfigurasi provider. Kunci baru dienkripsi; `$plainKey === null`
     * berarti "jangan ubah kunci" (pola kosong = jangan ubah).
     */
    public function upsert(string $code, array $fields, ?string $plainKey): void
    {
        if ($plainKey !== null && $plainKey !== '') {
            $fields['api_key_enc'] = Crypto::encryptText($plainKey);
        }
        $fields['code'] = $code;

        if ($this->find($code) !== null) {
            unset($fields['code']);
            $this->update($code, $fields);
        } else {
            $this->insert($fields, false);
        }
    }

    /** Catat hasil Test Connection (tanpa menyimpan nilai rahasia apa pun). */
    public function markTested(string $code, string $status, ?int $latencyMs): void
    {
        $this->update($code, [
            'last_status'     => $status,
            'last_latency_ms' => $latencyMs,
            'last_tested_at'  => date('Y-m-d H:i:s'),
        ]);
    }

    /** Buang kolom rahasia; tambahkan flag `has_key`. */
    private function strip(array $row): array
    {
        $row['has_key'] = ((string) ($row['api_key_enc'] ?? '')) !== '';
        unset($row['api_key_enc']);

        return $row;
    }
}
