<?php

declare(strict_types=1);

namespace App\Modules\Ai\Services;

use App\Modules\Ai\Adapters\AiProviderAdapter;
use App\Modules\Ai\Adapters\AnthropicAdapter;
use App\Modules\Ai\Adapters\GeminiAdapter;
use App\Modules\Ai\Adapters\OpenAiCompatAdapter;

/**
 * AiManager — memilih & merakit adapter yang tepat untuk sebuah provider
 * (Master Plan §4 "AI Manager"). Modul lain (Planner/Analyst/Report) kelak
 * memanggil manager ini per AI Role tanpa tahu provider yang dipakai di baliknya.
 *
 * Iterasi pertama: menyediakan Test Connection. Pemakaian chat menyusul.
 */
final class AiManager
{
    public function __construct(
        private readonly AiSettingsService $settings = new AiSettingsService(),
    ) {
    }

    /** True bila peran AI ini siap pakai: provider ada, enabled, & model ter-set. */
    public function readyForRole(string $role): bool
    {
        $cfg          = $this->settings->roleMap()[$role] ?? [];
        $providerCode = (string) ($cfg['provider_code'] ?? 'ollama');
        $row          = $this->settings->provider($providerCode);
        if ($row === null || (int) ($row['enabled'] ?? 0) !== 1) {
            return false;
        }
        $model = trim((string) ($cfg['model'] ?? '')) ?: (string) ($row['default_model'] ?? '');

        return $model !== '';
    }

    /** Rakit adapter dari konfigurasi provider tersimpan; null bila tak ada. */
    public function adapterFor(string $code): ?AiProviderAdapter
    {
        $row = $this->settings->provider($code);
        if ($row === null) {
            return null;
        }

        return $this->build($row, $code, (string) ($row['default_model'] ?? ''));
    }

    /**
     * Inferensi untuk sebuah AI Role: pilih provider+model dari ai_role_config,
     * lalu jalankan chat. Dipakai Rule Parser/Analyst/Report Writer, dsb.
     *
     * @throws \RuntimeException pesan ramah bila konfigurasi/inferensi gagal
     */
    public function chatForRole(string $role, string $system, string $user): string
    {
        $cfg          = $this->settings->roleMap()[$role] ?? [];
        $providerCode = (string) ($cfg['provider_code'] ?? 'ollama');
        $row          = $this->settings->provider($providerCode);
        if ($row === null) {
            throw new \RuntimeException("Provider '{$providerCode}' untuk peran '{$role}' belum dikonfigurasi.");
        }
        $model = trim((string) ($cfg['model'] ?? '')) ?: (string) ($row['default_model'] ?? '');
        if ($model === '') {
            throw new \RuntimeException("Model untuk peran '{$role}' belum ditetapkan (AI Settings).");
        }

        return $this->build($row, $providerCode, $model)->chat($system, $user);
    }

    /** @param array<string,mixed> $row baris ai_provider */
    private function build(array $row, string $code, string $model): AiProviderAdapter
    {
        $base = (string) ($row['base_url'] ?? '');
        $key  = $this->settings->providerKey($code);

        return match ($row['adapter_type']) {
            'anthropic' => new AnthropicAdapter($base, $key, $model),
            'gemini'    => new GeminiAdapter($base, $key, $model),
            default     => new OpenAiCompatAdapter($base, $key, $model),
        };
    }

    /**
     * Uji koneksi provider tersimpan dan catat hasilnya.
     *
     * @return array{ok:bool,latency_ms:int,message:string}
     */
    public function testConnection(string $code): array
    {
        $adapter = $this->adapterFor($code);
        if ($adapter === null) {
            return ['ok' => false, 'latency_ms' => 0, 'message' => 'Simpan konfigurasi provider ini lebih dulu.'];
        }

        $result = $adapter->testConnection();
        $this->settings->recordTest($code, $result['ok'], $result['latency_ms']);

        return $result;
    }
}
