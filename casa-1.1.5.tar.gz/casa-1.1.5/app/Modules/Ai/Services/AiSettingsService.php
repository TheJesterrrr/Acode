<?php

declare(strict_types=1);

namespace App\Modules\Ai\Services;

use App\Modules\Ai\Models\AiProviderModel;
use App\Modules\Ai\Models\AiRoleConfigModel;

/**
 * AiSettingsService — satu-satunya pintu baca/tulis konfigurasi AI (CES 13.4).
 * Memegang katalog provider & role (Zero Hardcode di kode pemakai), memvalidasi
 * masukan (whitelist), dan menjaga agar nilai kunci TIDAK bocor ke pemanggil.
 */
final class AiSettingsService
{
    /** Katalog provider: code => [label, adapter_type, base bawaan]. Master Plan §11. */
    public const PROVIDERS = [
        'ollama'     => ['label' => 'Ollama (Local)',  'adapter' => 'openai_compat', 'base' => 'http://localhost:11434/v1'],
        'claude'     => ['label' => 'Claude',          'adapter' => 'anthropic',     'base' => 'https://api.anthropic.com'],
        'openai'     => ['label' => 'OpenAI',          'adapter' => 'openai_compat', 'base' => 'https://api.openai.com/v1'],
        'gemini'     => ['label' => 'Gemini',          'adapter' => 'gemini',        'base' => 'https://generativelanguage.googleapis.com'],
        'openrouter' => ['label' => 'OpenRouter',      'adapter' => 'openai_compat', 'base' => 'https://openrouter.ai/api/v1'],
        'azure'      => ['label' => 'Azure OpenAI',    'adapter' => 'openai_compat', 'base' => ''],
    ];

    /** 7 AI Role (Master Plan §4): key => label tampilan. */
    public const ROLES = [
        'rule_parser'      => 'Rule Parser',
        'planner'          => 'Planner',
        'vuln_analyst'     => 'Vulnerability Analyst',
        'fp_validator'     => 'False-Positive Validator',
        'report_writer'    => 'Report Writer',
        'security_advisor' => 'Security Advisor',
        'chat_assistant'   => 'Chat Assistant',
    ];

    public function __construct(
        private readonly AiProviderModel $providers = new AiProviderModel(),
        private readonly AiRoleConfigModel $roles = new AiRoleConfigModel(),
    ) {
    }

    /** Provider untuk tampilan — tanpa kunci, hanya `has_key`. */
    public function providersSafe(): array
    {
        return $this->providers->allSafe();
    }

    /** Pemetaan role → [provider_code, model] untuk tampilan. */
    public function roleMap(): array
    {
        return $this->roles->allAsMap();
    }

    /** Baris mentah satu provider (dipakai AiManager). null bila tak dikenal/ada. */
    public function provider(string $code): ?array
    {
        return isset(self::PROVIDERS[$code]) ? $this->providers->get($code) : null;
    }

    /** Kunci terdekripsi untuk pemakaian internal (AiManager). '' bila kosong. */
    public function providerKey(string $code): string
    {
        return $this->providers->keyFor($code);
    }

    /**
     * Simpan satu provider dari masukan terpercaya-terbatas. `apiKey` kosong =
     * jangan ubah kunci. `adapter_type` selalu diambil dari katalog, bukan input.
     *
     * @param array<string,mixed> $in
     * @throws \InvalidArgumentException bila code di luar katalog
     */
    public function saveProvider(array $in): void
    {
        $code = (string) ($in['code'] ?? '');
        if (! isset(self::PROVIDERS[$code])) {
            throw new \InvalidArgumentException('Provider tidak dikenal.');
        }
        $cat  = self::PROVIDERS[$code];
        $base = trim((string) ($in['base_url'] ?? '')) ?: $cat['base'];

        $fields = [
            'adapter_type'  => $cat['adapter'],
            'label'         => $cat['label'],
            'base_url'      => $base,
            'default_model' => trim((string) ($in['model'] ?? '')) ?: null,
            'enabled'       => ! empty($in['enabled']) ? 1 : 0,
        ];

        $plainKey = array_key_exists('api_key', $in) ? trim((string) $in['api_key']) : '';
        $this->providers->upsert($code, $fields, $plainKey === '' ? null : $plainKey);
    }

    /** Catat hasil Test Connection. */
    public function recordTest(string $code, bool $ok, ?int $latency): void
    {
        if (isset(self::PROVIDERS[$code])) {
            $this->providers->markTested($code, $ok ? 'ok' : 'fail', $latency);
        }
    }

    /**
     * Simpan pemetaan role. Hanya role & provider yang ada di katalog diterima.
     *
     * @param array<string,array{provider:string,model:string}> $in role => cfg
     * @return int jumlah role tersimpan
     */
    public function saveRoles(array $in): int
    {
        $n = 0;
        foreach ($in as $role => $cfg) {
            if (! isset(self::ROLES[$role])) {
                continue;
            }
            $provider = (string) ($cfg['provider'] ?? '');
            if (! isset(self::PROVIDERS[$provider])) {
                continue;
            }
            $this->roles->put($role, $provider, trim((string) ($cfg['model'] ?? '')));
            $n++;
        }

        return $n;
    }
}
