<?php

declare(strict_types=1);

use CodeIgniter\Router\RouteCollection;

/** Rute installer (CES 13.10). Tanpa filter — dijaga install.lock di controller.
 *  HAPUS folder Install setelah pemasangan. */

/** @var RouteCollection $routes */
$routes->group('install', ['namespace' => 'App\Modules\Install\Controllers'], static function (RouteCollection $routes): void {
    $routes->get('',        'InstallController::index');
    $routes->match(['get', 'post'], 'database', 'InstallController::database');
    $routes->get('migrate', 'InstallController::migrate');
    $routes->match(['get', 'post'], 'admin',    'InstallController::admin');
    $routes->match(['get', 'post'], 'company',  'InstallController::company');
    $routes->get('finish',  'InstallController::finish');
});
