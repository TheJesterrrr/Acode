# Modul Install

Wizard instalasi web (tanpa SSH) yang memandu konfigurasi database,
administrator, dan data perusahaan — sesuai CES §2.6 dan
Blueprint Fase 6.

- `Controllers/InstallController` — satu langkah per request (requirements
  → database → migrate → admin → company → finish).
- `Services/Installer` — logika tiap langkah. Langkah database menulis
  `.env`; langkah migrasi berikutnya boot ulang dengan `.env` baru sehingga
  koneksi DB sudah hidup. Kunci enkripsi (`casa.key`, 32-byte) ditulis di
  luar web root (`writable/`) — dump database yang bocor tetap tidak
  terbaca tanpanya.
- Terkunci otomatis via `writable/install.lock` setelah instalasi selesai
  (`Installer::isLocked()`/`lock()`); langkah selanjutnya menampilkan
  `Views/locked.php` dan menolak instalasi ulang.

Business Module ini TIDAK menggantikan mekanisme CPR (installer/backup/
restore/migration engine milik platform) — ia hanya wizard orkestrasi
tingkat aplikasi di atas Migration/Seeder CI4 bawaan (CES §13.10).
