<?php

declare(strict_types=1);

namespace App\Modules\Install\Services;

use App\Modules\Auth\Models\UserModel;
use App\Modules\Setting\Services\SettingService;
use CodeIgniter\Database\Exceptions\DatabaseException;
use Config\Database;
use mysqli;
use RuntimeException;
use Throwable;

/**
 * Installer — logika wizard pemasangan (CES 13.4).
 *
 * Setiap langkah adalah request tersendiri: langkah database menulis .env,
 * langkah migrasi berikutnya boot dengan .env baru (DB hidup). Kunci enkripsi
 * ditulis ke berkas 32-byte di luar web root (writable/), pathnya ke .env —
 * sehingga dump DB yang bocor tetap tak terbaca.
 */
final class Installer
{
    public const LOCK = 'install.lock';

    public function isLocked(): bool
    {
        return is_file(WRITEPATH . self::LOCK);
    }

    public function lock(): void
    {
        @file_put_contents(WRITEPATH . self::LOCK, 'Terpasang: ' . date('c') . "\n");
    }

    /** @return array<int,array{name:string,ok:bool,hint:string}> */
    public function requirements(): array
    {
        $r = [];
        $r[] = ['name' => 'PHP ≥ 8.1', 'ok' => version_compare(PHP_VERSION, '8.1.0', '>='), 'hint' => 'Versi ' . PHP_VERSION];
        foreach (['intl', 'mbstring', 'json', 'openssl', 'fileinfo', 'curl'] as $ext) {
            $r[] = ['name' => "Ekstensi {$ext}", 'ok' => extension_loaded($ext), 'hint' => ''];
        }
        $r[] = ['name' => 'Ekstensi mysqli/pdo_mysql', 'ok' => extension_loaded('mysqli') || extension_loaded('pdo_mysql'), 'hint' => ''];
        $r[] = ['name' => 'writable/ dapat ditulis', 'ok' => is_writable(WRITEPATH), 'hint' => WRITEPATH];
        $r[] = ['name' => 'Root proyek dapat ditulis (.env)', 'ok' => is_writable(ROOTPATH), 'hint' => 'Untuk menulis .env'];

        return $r;
    }

    public function requirementsPass(): bool
    {
        foreach ($this->requirements() as $req) {
            if (! $req['ok']) {
                return false;
            }
        }

        return true;
    }

    /** Uji koneksi DB langsung (belum lewat config CI4). @throws RuntimeException */
    public function testDatabase(array $db): void
    {
        try {
            $conn = @new mysqli($db['hostname'], $db['username'], $db['password'], $db['database'], (int) $db['port']);
        } catch (Throwable $e) {
            throw new RuntimeException('Gagal terhubung: ' . $e->getMessage());
        }
        if ($conn->connect_errno) {
            throw new RuntimeException('Gagal terhubung ke database: ' . $conn->connect_error);
        }
        $conn->close();
    }

    /** Tulis .env + berkas kunci enkripsi. */
    public function writeEnv(array $db, string $baseUrl, string $adminUrl = ''): void
    {
        $keyPath = WRITEPATH . 'casa.key';
        if (! is_file($keyPath)) {
            file_put_contents($keyPath, random_bytes(32));
            @chmod($keyPath, 0600);
        }

        $lines = [
            'CI_ENVIRONMENT = production',
            "app.baseURL = '" . rtrim($baseUrl, '/') . "/'",
            // Endpoint admin (CES 11.5.2). WAJIB berbeda dari baseURL agar
            // panel admin dikenali; bila sama, seluruh host dianggap member.
            "app.adminURL = '" . rtrim($adminUrl !== '' ? $adminUrl : $baseUrl, '/') . "/'",
            "app.appTimezone = 'Asia/Jakarta'",
            'app.forceGlobalSecureRequests = false',
            '',
            "database.default.hostname = {$db['hostname']}",
            "database.default.database = {$db['database']}",
            "database.default.username = {$db['username']}",
            "database.default.password = {$db['password']}",
            "database.default.DBDriver = MySQLi",
            "database.default.port = {$db['port']}",
            '',
            "encryption.keyPath = writable/casa.key",
            '',
            "security.csrfProtection = 'session'",
            "security.tokenRandomize = true",
        ];
        if (file_put_contents(ROOTPATH . '.env', implode("\n", $lines) . "\n") === false) {
            throw new RuntimeException('Tidak dapat menulis berkas .env. Periksa izin folder.');
        }
    }

    /** Jalankan migrasi + seeder data (dipanggil pada request setelah .env ditulis). */
    public function migrate(): void
    {
        try {
            service('migrations')->setNamespace(null)->latest();
        } catch (DatabaseException $e) {
            throw new RuntimeException('Migrasi gagal: ' . $e->getMessage());
        }

        // Daftarkan seeder modul bisnis di sini setelah modulnya dibuat.
        // Urutannya penting bila antar-seeder saling bergantung.
        $seeder = Database::seeder();
        foreach ([
            'App\Modules\Setting\Database\Seeds\DefaultSettingsSeeder',
            'App\Modules\Ai\Database\Seeds\DefaultAiConfigSeeder',
            'App\Modules\ToolManager\Database\Seeds\ToolCatalogSeeder',
            'App\Modules\Billing\Database\Seeds\CoinPackageSeeder',
        ] as $class) {
            $seeder->call($class);
        }
    }

    public function createAdmin(string $name, string $email, string $password): void
    {
        (new UserModel())->insert([
            'name'          => $name,
            'email'         => strtolower(trim($email)),
            'password_hash' => password_hash($password, PASSWORD_BCRYPT),
            'role'          => 'owner',
            'is_active'     => 1,
        ], false);
    }

    public function saveCompany(array $c): void
    {
        $s = new SettingService();
        foreach (['company_name', 'company_email', 'company_phone', 'whatsapp_number'] as $k) {
            if (isset($c[$k])) {
                $s->set($k, trim((string) $c[$k]));
            }
        }
    }

}
