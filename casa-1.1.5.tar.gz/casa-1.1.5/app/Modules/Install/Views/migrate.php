<?= $this->extend('App\Modules\Install\Views\_layout') ?>
<?= $this->section('content') ?>
<?php /** @var ?string $error @var ?bool $done */ ?>
<h1 class="h4 mb-1">Migrasi Database</h1>
<?php if (! empty($error)): ?>
  <div class="alert alert-danger"><?= esc($error) ?></div>
  <a href="<?= esc(site_url('install/database')) ?>" class="btn btn-outline-secondary">← Back to Database</a>
  <a href="<?= esc(site_url('install/migrate')) ?>" class="btn btn-primary">Try Again</a>
<?php elseif (! empty($done)): ?>
  <div class="alert alert-success"><i class="bi bi-check-circle me-1"></i> 23 tabel dibuat & data awal terisi (paket, harga, pengaturan).</div>
  <div class="d-flex justify-content-end"><a href="<?= esc(site_url('install/admin')) ?>" class="btn btn-primary">Next <i class="bi bi-arrow-right"></i></a></div>
<?php else: ?>
  <p class="text-muted">Menjalankan migrasi…</p>
<?php endif; ?>
<?= $this->endSection() ?>
