<?= $this->extend('App\Modules\Install\Views\_layout') ?>
<?= $this->section('content') ?>
<div class="text-center">
  <i class="bi bi-check-circle-fill text-success display-3"></i>
  <h1 class="h4 mt-3">Instalasi Selesai</h1>
  <p class="text-muted">CASA siap digunakan.</p>
  <div class="alert alert-warning text-start small">
    <strong>Langkah keamanan wajib:</strong> hapus folder <code>app/Modules/Install</code> dari server.
    Installer sudah dikunci (<code>writable/install.lock</code>), tetapi menghapus foldernya lebih aman.
  </div>
  <div class="d-grid gap-2 col-8 mx-auto">
    <a href="<?= esc(site_url('casaadmin')) ?>" class="btn btn-primary">Go to Admin Panel</a>
    <a href="<?= esc(site_url('login')) ?>" class="btn btn-outline-secondary">Member Login Page</a>
  </div>
</div>
<?= $this->endSection() ?>
