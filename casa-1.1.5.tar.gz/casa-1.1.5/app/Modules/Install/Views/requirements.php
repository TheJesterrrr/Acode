<?= $this->extend('App\Modules\Install\Views\_layout') ?>
<?= $this->section('content') ?>
<?php /** @var array $reqs @var bool $pass */ ?>
<h1 class="h4 mb-1">Persyaratan Sistem</h1>
<p class="text-muted small">Pastikan semua terpenuhi sebelum melanjutkan.</p>
<ul class="list-group mb-4">
  <?php foreach ($reqs as $r): ?>
    <li class="list-group-item d-flex justify-content-between align-items-center">
      <span><?= esc($r['name']) ?> <?php if($r['hint']): ?><small class="text-muted">— <?= esc($r['hint']) ?></small><?php endif; ?></span>
      <?php if ($r['ok']): ?><span class="badge bg-success"><i class="bi bi-check-lg"></i></span>
      <?php else: ?><span class="badge bg-danger"><i class="bi bi-x-lg"></i></span><?php endif; ?>
    </li>
  <?php endforeach; ?>
</ul>
<div class="d-flex justify-content-end">
  <?php if ($pass): ?><a href="<?= esc(site_url('install/database')) ?>" class="btn btn-primary">Next <i class="bi bi-arrow-right"></i></a>
  <?php else: ?><a href="<?= esc(site_url('install')) ?>" class="btn btn-outline-secondary">Check Again</a><?php endif; ?>
</div>
<?= $this->endSection() ?>
