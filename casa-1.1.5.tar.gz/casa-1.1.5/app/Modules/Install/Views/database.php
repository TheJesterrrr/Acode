<?= $this->extend('App\Modules\Install\Views\_layout') ?>
<?= $this->section('content') ?>
<?php /** @var ?string $error @var array $old */ $old=$old??[]; ?>
<h1 class="h4 mb-1">Koneksi Database</h1>
<p class="text-muted small">Buat database MySQL kosong di cPanel, lalu isikan kredensialnya.</p>
<?php if (! empty($error)): ?><div class="alert alert-danger"><?= esc($error) ?></div><?php endif; ?>
<form method="post" action="<?= esc(site_url('install/database')) ?>">
  <?= csrf_field() ?>
  <div class="row g-3">
    <div class="col-8"><label class="form-label small">Host</label><input name="hostname" class="form-control" value="<?= esc($old['hostname']??'localhost') ?>"></div>
    <div class="col-4"><label class="form-label small">Port</label><input name="port" class="form-control" value="<?= esc($old['port']??'3306') ?>"></div>
    <div class="col-12"><label class="form-label small">Nama Database</label><input name="database" class="form-control" value="<?= esc($old['database']??'') ?>" required></div>
    <div class="col-6"><label class="form-label small">Username</label><input name="username" class="form-control" value="<?= esc($old['username']??'') ?>" required></div>
    <div class="col-6"><label class="form-label small">Password</label><input name="password" type="password" class="form-control"></div>
    <div class="col-12">
      <label class="form-label small">URL Panel Admin <span class="text-muted">(subdomain terpisah)</span></label>
      <input name="admin_url" class="form-control" placeholder="https://casaadmin.domain-anda.com/" value="<?= esc($old['admin_url']??'') ?>">
      <div class="form-text">Wajib berbeda dari alamat member. Bila dikosongkan, panel admin tidak dikenali dan semua host diperlakukan sebagai portal member.</div>
    </div>
  </div>
  <div class="d-flex justify-content-end mt-4"><button class="btn btn-primary">Test & Next <i class="bi bi-arrow-right"></i></button></div>
</form>
<?= $this->endSection() ?>
