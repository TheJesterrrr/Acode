<?= $this->extend('App\Modules\Install\Views\_layout') ?>
<?= $this->section('content') ?>
<?php /** @var ?string $error @var array $old */ $old=$old??[]; ?>
<h1 class="h4 mb-1">Akun Administrator</h1>
<p class="text-muted small">Akun pemilik (owner) dengan akses penuh.</p>
<?php if (! empty($error)): ?><div class="alert alert-danger"><?= esc($error) ?></div><?php endif; ?>
<form method="post" action="<?= esc(site_url('install/admin')) ?>">
  <?= csrf_field() ?>
  <div class="mb-3"><label class="form-label small">Nama</label><input name="name" class="form-control" value="<?= esc($old['name']??'') ?>" required></div>
  <div class="mb-3"><label class="form-label small">Email</label><input name="email" type="email" class="form-control" value="<?= esc($old['email']??'') ?>" required></div>
  <div class="mb-3"><label class="form-label small">Password <small class="text-muted">(min. 8 karakter)</small></label><input name="password" type="password" class="form-control" required></div>
  <div class="d-flex justify-content-end"><button class="btn btn-primary">Next <i class="bi bi-arrow-right"></i></button></div>
</form>
<?= $this->endSection() ?>
