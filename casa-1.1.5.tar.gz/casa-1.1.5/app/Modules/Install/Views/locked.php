<?= $this->extend('App\Modules\Install\Views\_layout') ?>
<?= $this->section('content') ?>
<div class="text-center">
  <i class="bi bi-lock-fill text-success display-4"></i>
  <h1 class="h4 mt-3">Sudah Terpasang</h1>
  <p class="text-muted">Aplikasi sudah selesai dipasang. Demi keamanan, <strong>hapus folder installer</strong> (<code>app/Modules/Install</code>) dan berkas <code>writable/install.lock</code> hanya bila ingin memasang ulang.</p>
  <a href="<?= esc(site_url('casaadmin')) ?>" class="btn btn-primary">Go to Admin Panel</a>
</div>
<?= $this->endSection() ?>
