<?php
/** @var string $step_key */
$steps = ['requirements'=>'Persyaratan','database'=>'Database','migrate'=>'Migrasi','admin'=>'Admin','company'=>'Perusahaan','finish'=>'Selesai'];
$keys = array_keys($steps); $cur = array_search($step_key, $keys, true); $cur = $cur===false?-1:$cur;
?>
<!doctype html><html lang="id" data-bs-theme="light"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="<?= esc(csrf_hash()) ?>">
<title>Instalasi — CoreNet Remote Platform</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<style>
body{background:#eef1f8;font-family:system-ui,sans-serif;} .wrap{max-width:720px;margin:2.5rem auto;padding:0 1rem;}
.brand{color:#4353c4;font-weight:700;font-size:1.4rem;text-align:center;margin-bottom:1.25rem;}
.card{border:0;border-radius:16px;box-shadow:0 10px 40px rgba(30,42,94,.10);}
.steps{display:flex;gap:.25rem;list-style:none;padding:0;margin:0 0 1.25rem;font-size:.72rem;}
.steps li{flex:1;text-align:center;color:#9aa3c9;border-top:3px solid #dde2f2;padding-top:.4rem;}
.steps li.done{color:#22b07d;border-color:#22b07d;} .steps li.cur{color:#4353c4;border-color:#4353c4;font-weight:600;}
.btn-primary{--bs-btn-bg:#4353c4;--bs-btn-border-color:#4353c4;--bs-btn-hover-bg:#37459f;--bs-btn-hover-border-color:#37459f;}
</style></head><body>
<div class="wrap">
  <div class="brand"><i class="bi bi-broadcast-pin"></i> CoreNet Remote Platform</div>
  <?php if ($cur >= 0): ?>
  <ul class="steps">
    <?php foreach ($steps as $k=>$label): $i=array_search($k,$keys,true); ?>
      <li class="<?= $i<$cur?'done':($i===$cur?'cur':'') ?>"><?= esc($label) ?></li>
    <?php endforeach; ?>
  </ul>
  <?php endif; ?>
  <div class="card"><div class="card-body p-4 p-lg-5">
    <?= $this->renderSection('content') ?>
  </div></div>
  <p class="text-center text-muted small mt-3">v<?= esc(defined('CASA_VERSION')?CASA_VERSION:'1.0.0') ?> — CoreNet IT Solutions</p>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body></html>
