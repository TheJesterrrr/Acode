<?= $this->extend('App\Modules\Install\Views\_layout') ?>
<?= $this->section('content') ?>
<h1 class="h4 mb-1">Data Perusahaan</h1>
<p class="text-muted small">Tampil di invoice & notifikasi. Bisa diubah nanti di Pengaturan.</p>
<form method="post" action="<?= esc(site_url('install/company')) ?>">
  <?= csrf_field() ?>
  <div class="mb-3"><label class="form-label small">Nama Perusahaan</label><input name="company_name" class="form-control" value="CoreNet IT Solutions" required></div>
  <div class="row g-3">
    <div class="col-6"><label class="form-label small">Email</label><input name="company_email" type="email" class="form-control"></div>
    <div class="col-6"><label class="form-label small">Telepon</label><input name="company_phone" class="form-control"></div>
  </div>
  <div class="mb-3 mt-3"><label class="form-label small">Nomor WhatsApp</label><input name="whatsapp_number" class="form-control" placeholder="0812…"></div>
  <div class="d-flex justify-content-end"><button class="btn btn-primary">Next <i class="bi bi-arrow-right"></i></button></div>
</form>
<?= $this->endSection() ?>
