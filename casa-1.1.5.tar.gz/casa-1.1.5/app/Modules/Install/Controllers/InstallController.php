<?php

declare(strict_types=1);

namespace App\Modules\Install\Controllers;

use App\Modules\Install\Services\Installer;
use CodeIgniter\Controller;
use CodeIgniter\HTTP\RedirectResponse;
use RuntimeException;
use Throwable;

/**
 * InstallController — wizard pemasangan (Master Plan §5). Standalone: tidak
 * memakai shell/DB sampai langkah migrasi. Terkunci setelah selesai
 * (writable/install.lock) — kunjungan berikutnya ditolak.
 */
final class InstallController extends Controller
{
    protected $helpers = ['url', 'form'];
    private Installer $installer;

    public function __construct()
    {
        $this->installer = new Installer();
    }

    private function locked(): bool
    {
        return $this->installer->isLocked();
    }

    private function render(string $step, array $data = []): string
    {
        return view('App\Modules\Install\Views\\' . $step, $data + ['step_key' => $step]);
    }

    /* -------------------------------------------------------------- 1. Requirements */

    public function index(): string
    {
        if ($this->locked()) {
            return $this->render('locked');
        }

        return $this->render('requirements', [
            'reqs' => $this->installer->requirements(),
            'pass' => $this->installer->requirementsPass(),
        ]);
    }

    /* ------------------------------------------------------------------ 2. Database */

    public function database(): string|RedirectResponse
    {
        if ($this->locked()) {
            return redirect()->to(site_url('install'));
        }
        if ($this->request->getMethod() === 'POST') {
            $db = [
                'hostname' => trim((string) $this->request->getPost('hostname')) ?: 'localhost',
                'database' => trim((string) $this->request->getPost('database')),
                'username' => trim((string) $this->request->getPost('username')),
                'password' => (string) $this->request->getPost('password'),
                'port'     => (int) ($this->request->getPost('port') ?: 3306),
            ];
            try {
                $this->installer->testDatabase($db);
                $baseUrl  = rtrim((string) site_url(''), '/') ?: $this->request->getUri()->getScheme() . '://' . $this->request->getUri()->getHost();
                $adminUrl = trim((string) $this->request->getPost('admin_url'));
                $this->installer->writeEnv($db, $baseUrl, $adminUrl);

                return redirect()->to(site_url('install/migrate'));
            } catch (RuntimeException $e) {
                return $this->render('database', ['error' => $e->getMessage(), 'old' => $db + ['admin_url' => $adminUrl ?? '']]);
            }
        }

        return $this->render('database', ['old' => []]);
    }

    /* ------------------------------------------------------------------- 3. Migrate */

    public function migrate(): string|RedirectResponse
    {
        if ($this->locked()) {
            return redirect()->to(site_url('install'));
        }
        try {
            $this->installer->migrate();
        } catch (Throwable $e) {
            return $this->render('migrate', ['error' => $e->getMessage()]);
        }

        return $this->render('migrate', ['done' => true]);
    }

    /* --------------------------------------------------------------------- 4. Admin */

    public function admin(): string|RedirectResponse
    {
        if ($this->locked()) {
            return redirect()->to(site_url('install'));
        }
        if ($this->request->getMethod() === 'POST') {
            $name  = trim((string) $this->request->getPost('name'));
            $email = trim((string) $this->request->getPost('email'));
            $pass  = (string) $this->request->getPost('password');
            $err   = null;
            if ($name === '' || ! filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($pass) < 8) {
                $err = 'Nama, email valid, dan password minimal 8 karakter wajib diisi.';
            }
            if ($err === null) {
                try {
                    $this->installer->createAdmin($name, $email, $pass);

                    return redirect()->to(site_url('install/company'));
                } catch (Throwable $e) {
                    $err = 'Gagal membuat admin: ' . $e->getMessage();
                }
            }

            return $this->render('admin', ['error' => $err, 'old' => compact('name', 'email')]);
        }

        return $this->render('admin', ['old' => []]);
    }

    /* ------------------------------------------------------------------- 5. Company */

    public function company(): string|RedirectResponse
    {
        if ($this->locked()) {
            return redirect()->to(site_url('install'));
        }
        if ($this->request->getMethod() === 'POST') {
            $this->installer->saveCompany([
                'company_name'    => $this->request->getPost('company_name'),
                'company_email'   => $this->request->getPost('company_email'),
                'company_phone'   => $this->request->getPost('company_phone'),
                'whatsapp_number' => $this->request->getPost('whatsapp_number'),
            ]);

            return redirect()->to(site_url('install/finish'));
        }

        return $this->render('company');
    }

    /* -------------------------------------------------------------------- 6. Finish */

    public function finish(): string|RedirectResponse
    {
        if ($this->locked()) {
            return redirect()->to(site_url('install'));
        }
        $this->installer->lock();

        return $this->render('finish');
    }
}
