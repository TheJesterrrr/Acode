<?= $this->extend('layouts/admin') ?>
<?= $this->section('content') ?>
<?php /** @var array $manifest */ ?>
<div class="casa-page-head"><h1 class="h4 mb-0"><i class="bi bi-rss me-1"></i>Detection Feed</h1></div>

<div class="row g-3">
  <div class="col-lg-5">
    <div class="casa-card p-4 h-100">
      <h2 class="h6 mb-3">Feed aktif</h2>
      <div class="d-flex align-items-baseline gap-2 mb-2">
        <span class="display-6 fw-bold">v<?= (int) $manifest['version'] ?></span>
        <?php if ((int) $manifest['version'] === 0): ?><span class="badge text-bg-secondary">Belum dipublikasikan</span><?php else: ?><span class="badge text-bg-success">Aktif</span><?php endif; ?>
      </div>
      <dl class="row small mb-0">
        <dt class="col-5 text-muted">Nuclei ref</dt><dd class="col-7 font-monospace"><?= esc($manifest['nuclei_ref']) ?></dd>
        <dt class="col-5 text-muted">Terbit</dt><dd class="col-7"><?= esc($manifest['published_at'] ?: '—') ?></dd>
        <dt class="col-5 text-muted">Catatan</dt><dd class="col-7"><?= esc($manifest['notes'] ?: '—') ?></dd>
      </dl>
      <div class="small text-muted mt-3"><i class="bi bi-info-circle me-1"></i>Instance pelanggan menarik feed ini via <code>casa:feed-sync</code> (cron) lalu memperbarui template/aturan deteksinya otomatis.</div>
    </div>
  </div>
  <div class="col-lg-7">
    <div class="casa-card p-4 h-100" style="border:1px solid var(--casa-amber)">
      <h2 class="h6 mb-1"><i class="bi bi-broadcast-pin text-warning me-1"></i>Publikasikan versi baru</h2>
      <p class="text-muted small">Naikkan versi feed agar seluruh instance pelanggan memperbarui konten deteksi pada sinkron berikutnya.</p>
      <form id="pubForm" class="row g-2 align-items-end">
        <div class="col-md-5"><label class="form-label small">Nuclei templates ref/tag</label>
          <input name="nuclei_ref" class="form-control" value="<?= esc($manifest['nuclei_ref'] ?: 'latest') ?>" placeholder="latest / v10.2.6"></div>
        <div class="col-md-7"><label class="form-label small">Catatan rilis</label>
          <input name="notes" class="form-control" placeholder="mis. +CVE-2026-xxxx, aturan API baru"></div>
        <div class="col-12 mt-2"><button id="pubBtn" class="btn btn-amber"><i class="bi bi-broadcast me-1"></i>Publikasikan v<?= (int) $manifest['version'] + 1 ?></button>
          <span id="pubMsg" class="small ms-2"></span></div>
      </form>
      <hr>
      <div class="small text-muted"><b>Endpoint manifest:</b> <code><?= esc(site_url('api/feed/latest')) ?></code> — dibaca instance pelanggan untuk mengecek versi terbaru.</div>
    </div>
  </div>
</div>

<div class="casa-card p-4 mt-3">
  <h2 class="h6 mb-1"><i class="bi bi-toggles me-1"></i>Tool aktif untuk instance member</h2>
  <?php $nAllowed = count($allowed); ?>
  <p class="text-muted small mb-2"><b>Centang = tool diizinkan</b> dipakai instance pelanggan; <b>tak tercentang = dicabut</b> (hilang dari instance saat sinkron berikutnya). <b>Kosong</b> (tak ada tercentang) = <b>tak ada tool diizinkan</b> → instance tak bisa menjalankan scan. Nama asli hanya tampil di sini (owner).</p>
  <div class="d-flex flex-wrap align-items-center gap-2 mb-2">
    <span class="badge text-bg-<?= $nAllowed > 0 ? 'success' : 'danger' ?>" id="allowCount"><?= $nAllowed > 0 ? ($nAllowed . ' tool diizinkan') : 'Tak ada tool diizinkan' ?></span>
    <span class="small text-muted">dari <?= count($catalog) ?> tool runnable</span>
    <a href="#" class="small ms-2" id="checkAll">centang semua</a> ·
    <a href="#" class="small" id="checkNone">kosongkan</a>
  </div>
  <div class="row g-2">
    <?php foreach ($catalog as $code => $name): ?>
      <div class="col-6 col-md-4 col-lg-3">
        <label class="d-flex align-items-center gap-2 small">
          <input type="checkbox" class="form-check-input mt-0 js-tool" value="<?= esc($code) ?>" <?= in_array($code, $allowed, true) ? 'checked' : '' ?>>
          <span><span class="fw-semibold"><?= esc($name) ?></span> <span class="text-muted font-monospace">(<?= esc($code) ?>)</span></span>
        </label>
      </div>
    <?php endforeach; ?>
  </div>
  <button class="btn btn-primary mt-3" id="saveToolsBtn"><i class="bi bi-save me-1"></i>Save active tools</button>
  <span id="toolsMsg" class="small ms-2"></span>
</div>
<?= $this->endSection() ?>

<?= $this->section('page_scripts') ?>
<script>
document.getElementById('pubForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const b = document.getElementById('pubBtn'), m = document.getElementById('pubMsg');
  b.disabled = true;
  const d = await casaPost('<?= esc(site_url('casaadmin/feed/publish')) ?>', new FormData(e.target));
  b.disabled = false;
  if (d.ok) { m.className = 'small ms-2 text-success'; m.textContent = 'Feed v' + d.version + ' terbit.'; setTimeout(() => location.reload(), 900); }
  else { m.className = 'small ms-2 text-danger'; m.textContent = d.error || 'Gagal.'; }
});
function refreshAllowCount(){
  const n = document.querySelectorAll('.js-tool:checked').length;
  const b = document.getElementById('allowCount');
  b.textContent = n > 0 ? (n + ' tool diizinkan') : 'Tak ada tool diizinkan';
  b.className = 'badge text-bg-' + (n > 0 ? 'success' : 'danger');
}
document.querySelectorAll('.js-tool').forEach(c => c.addEventListener('change', refreshAllowCount));
document.getElementById('checkAll').addEventListener('click', (e) => { e.preventDefault(); document.querySelectorAll('.js-tool').forEach(x => x.checked = true); refreshAllowCount(); });
document.getElementById('checkNone').addEventListener('click', (e) => { e.preventDefault(); document.querySelectorAll('.js-tool').forEach(x => x.checked = false); refreshAllowCount(); });
document.getElementById('saveToolsBtn').addEventListener('click', async () => {
  const fd = new FormData();
  document.querySelectorAll('.js-tool:checked').forEach(x => fd.append('tools[]', x.value));
  const d = await casaPost('<?= esc(site_url('casaadmin/feed/tools')) ?>', fd);
  const m = document.getElementById('toolsMsg');
  if (d.ok) { m.className = 'small ms-2 text-success'; m.textContent = d.count + ' tool diizinkan · feed v' + d.version; }
  else { m.className = 'small ms-2 text-danger'; m.textContent = d.error || 'Gagal.'; }
});
</script>
<?= $this->endSection() ?>
