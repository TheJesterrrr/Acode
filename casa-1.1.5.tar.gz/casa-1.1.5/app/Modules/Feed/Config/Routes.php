<?php

declare(strict_types=1);

use CodeIgniter\Router\RouteCollection;

/** Rute Detection Feed — halaman owner + manifest publik. */

/** @var RouteCollection $routes */
$routes->group('casaadmin/feed', ['namespace' => 'App\Modules\Feed\Controllers', 'filter' => 'admin'], static function (RouteCollection $routes): void {
    $routes->get('', 'FeedController::index');
    $routes->post('publish', 'FeedController::publish', ['filter' => 'audit:FEED_PUBLISH']);
    $routes->post('tools', 'FeedController::saveTools', ['filter' => 'audit:FEED_TOOLS']);
});

/** Manifest feed publik (dibaca casa:feed-sync). api/* bebas CSRF. */
$routes->get('api/feed/latest', '\App\Modules\Feed\Controllers\FeedController::latest');
