<?php

declare(strict_types=1);

namespace App\Modules\Feed\Controllers;

use App\Controllers\BaseController;
use App\Modules\Feed\Services\FeedService;
use CodeIgniter\HTTP\ResponseInterface;

/**
 * FeedController — Detection Feed. Halaman owner (kelola/publish versi feed) +
 * endpoint manifest publik (dibaca casa:feed-sync di instance pelanggan).
 */
final class FeedController extends BaseController
{
    public function __construct(private readonly FeedService $feed = new FeedService())
    {
    }

    /** Halaman owner. */
    public function index(): string
    {
        $this->requireOwnerConsole();

        // Katalog tool ber-adapter (kode → nama asli; owner boleh lihat).
        $supported = \App\Modules\Adapter\Services\AdapterFactory::supported();
        $names     = [];
        foreach (\Config\Database::connect()->query('SELECT code, name FROM tool')->getResultArray() as $t) {
            $names[$t['code']] = (string) ($t['name'] ?? $t['code']);
        }
        $catalog = [];
        foreach ($supported as $code) {
            $catalog[$code] = $names[$code] ?? $code;
        }
        ksort($catalog);

        return $this->adminView('App\Modules\Feed\Views\index', [
            'title'    => 'Detection Feed',
            'manifest' => $this->feed->manifest(),
            'catalog'  => $catalog,
            'allowed'  => $this->feed->allowedTools(),
        ], 'feed');
    }

    /** Simpan allowlist tool untuk instance member (owner). */
    public function saveTools(): ResponseInterface
    {
        $this->requireOwnerConsole();
        $codes = (array) $this->request->getPost('tools');
        $this->feed->setAllowedTools($codes);

        return $this->ok(['count' => count($this->feed->allowedTools()), 'version' => $this->feed->manifest()['version']]);
    }

    /** Terbitkan versi feed baru (owner). */
    public function publish(): ResponseInterface
    {
        $this->requireOwnerConsole();
        $m = $this->feed->publish(
            (string) $this->request->getPost('nuclei_ref'),
            (string) $this->request->getPost('notes'),
        );

        return $this->ok($m);
    }

    /** Manifest publik (api/feed/latest) — dibaca instance pelanggan. */
    public function latest(): ResponseInterface
    {
        return $this->response->setJSON(['ok' => true] + $this->feed->manifest());
    }
}
