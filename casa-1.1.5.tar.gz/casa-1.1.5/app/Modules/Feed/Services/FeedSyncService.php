<?php

declare(strict_types=1);

namespace App\Modules\Feed\Services;

use App\Modules\Setting\Services\SettingService;
use App\Modules\ToolManager\Services\ToolInstaller;
use Config\Services;
use Throwable;

/**
 * FeedSyncService — sisi PRODUK (VPS pelanggan). Membaca manifest Detection Feed
 * dari owner (env `feed.url`); bila versinya lebih baru dari lokal, memperbarui
 * konten deteksi (nuclei-templates) lalu mencatat versi lokal. Dipakai command
 * casa:feed-sync (cron). Idempoten & aman diulang.
 */
final class FeedSyncService
{
    public function __construct(
        private readonly SettingService $s = new SettingService(),
        private readonly ToolInstaller $tools = new ToolInstaller(),
    ) {
    }

    /** @return array<string,mixed> */
    public function sync(): array
    {
        $url = (string) (env('feed.url') ?: '');
        if ($url === '') {
            return ['ok' => false, 'error' => 'feed.url belum dikonfigurasi (.env).'];
        }
        try {
            $client = Services::curlrequest(['timeout' => 20, 'http_errors' => false], null, null, false);
            $m      = json_decode((string) $client->get($url)->getBody(), true);
        } catch (Throwable $e) {
            return ['ok' => false, 'error' => 'Tak dapat mengambil manifest: ' . $e->getMessage()];
        }
        if (! is_array($m) || empty($m['ok'])) {
            return ['ok' => false, 'error' => 'Manifest feed tidak valid.'];
        }

        // Simpan allowlist tool dari owner (dipakai Planner & halaman Tools member).
        if (array_key_exists('tools', $m)) {
            $this->s->set('feed.tools_allowed', json_encode(array_values((array) $m['tools']), JSON_UNESCAPED_SLASHES));
        }

        $remote = (int) ($m['version'] ?? 0);
        $local  = $this->s->int('feed.local_version', 0);
        if ($remote <= $local) {
            return ['ok' => true, 'updated' => false, 'version' => $local, 'message' => "Sudah versi terbaru (v{$local})."];
        }

        // Versi baru → perbarui konten deteksi (nuclei-templates).
        try {
            $this->tools->updateNucleiTemplates();
        } catch (Throwable $e) {
            return ['ok' => false, 'error' => 'Gagal memperbarui template: ' . $e->getMessage()];
        }
        $this->s->set('feed.local_version', (string) $remote);
        $this->s->set('feed.local_synced_at', date('Y-m-d H:i:s'));

        return ['ok' => true, 'updated' => true, 'version' => $remote, 'message' => "Feed diperbarui ke v{$remote}."];
    }
}
