<?php

declare(strict_types=1);

namespace App\Modules\Feed\Services;

use App\Modules\Setting\Services\SettingService;

/**
 * FeedService — manifest "Detection Feed" (owner). Feed = versi konten deteksi:
 * ref/tag nuclei-templates yang dipin owner + catatan rilis. Instance pelanggan
 * membaca manifest ini (api/feed/latest) via casa:feed-sync lalu memperbarui
 * template/aturannya. Analog dgn plugin-feed Nessus.
 *
 * Disimpan sebagai Setting (tanpa tabel khusus) agar ringan.
 */
final class FeedService
{
    public function __construct(private readonly SettingService $s = new SettingService())
    {
    }

    /** @return array<string,mixed> */
    public function manifest(): array
    {
        return [
            'version'      => $this->s->int('feed.version', 0),
            'nuclei_ref'   => (string) $this->s->get('feed.nuclei_ref', 'latest'),
            'notes'        => (string) $this->s->get('feed.notes', ''),
            'published_at' => (string) $this->s->get('feed.published_at', ''),
            'tools'        => $this->allowedTools(),
        ];
    }

    /** Allowlist tool untuk instance member (kosong = semua diizinkan). @return array<int,string> */
    public function allowedTools(): array
    {
        $arr = json_decode((string) $this->s->get('feed.tools', ''), true);

        return is_array($arr) ? array_values(array_map('strval', $arr)) : [];
    }

    /** Set allowlist tool (owner) + naikkan versi feed agar member sinkron. */
    public function setAllowedTools(array $codes): void
    {
        $clean = array_values(array_unique(array_filter(array_map(static fn ($c) => strtolower(trim((string) $c)), $codes))));
        $this->s->set('feed.tools', json_encode($clean, JSON_UNESCAPED_SLASHES));
        $this->s->set('feed.version', (string) ($this->s->int('feed.version', 0) + 1));
        $this->s->set('feed.published_at', date('Y-m-d H:i:s'));
    }

    /** Terbitkan versi feed baru (owner). @return array manifest baru */
    public function publish(string $nucleiRef, string $notes): array
    {
        $v = $this->s->int('feed.version', 0) + 1;
        $this->s->set('feed.version', (string) $v);
        $this->s->set('feed.nuclei_ref', trim($nucleiRef) ?: 'latest');
        $this->s->set('feed.notes', trim($notes));
        $this->s->set('feed.published_at', date('Y-m-d H:i:s'));

        return $this->manifest();
    }
}
