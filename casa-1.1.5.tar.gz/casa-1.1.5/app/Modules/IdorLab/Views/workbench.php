<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<?php
/** @var array $project */
$pid   = (int) $project['id'];
$creds = $project['credentials'] ?? [];
?>
<div class="casa-page-head">
  <div>
    <a href="<?= esc(site_url('projects/' . $pid)) ?>" class="small text-muted text-decoration-none"><i class="bi bi-arrow-left"></i> <?= esc($project['name']) ?></a>
    <h1 class="mb-0"><i class="bi bi-arrow-left-right me-1"></i>IDOR Workbench <span class="badge text-bg-warning align-middle"><i class="bi bi-lock-fill"></i> Pro</span></h1>
    <div class="small text-muted">Login A → capture → swap token B → replay → compare → verdict AI. Kelas bug bounty paling bernilai (BOLA).</div>
  </div>
</div>

<?php if (count($creds) < 2): ?>
  <div class="casa-card p-4">
    <p class="mb-2">Butuh minimal <b>2 Test Accounts</b> (mis. User A &amp; User B) untuk uji BOLA cross-akun.</p>
    <a href="<?= esc(site_url('projects/' . $pid)) ?>" class="btn btn-primary btn-sm"><i class="bi bi-key me-1"></i>Add Test Accounts</a>
  </div>
<?php else: ?>
<div class="row g-3">
  <div class="col-lg-5">
    <div class="casa-card p-3 p-lg-4">
      <h2 class="h6 mb-3">Konfigurasi uji</h2>
      <form id="idorForm">
        <div class="mb-3"><label class="form-label small">Akun A (pemilik objek)</label>
          <select name="cred_a" class="form-select" required>
            <?php foreach ($creds as $c): ?><option value="<?= (int) $c['id'] ?>"><?= esc($c['label']) ?> <?= $c['role'] ? '(' . esc($c['role']) . ')' : '' ?> · <?= esc($c['scheme']) ?></option><?php endforeach; ?>
          </select></div>
        <div class="mb-3"><label class="form-label small">Akun B (penyerang)</label>
          <select name="cred_b" class="form-select" required>
            <?php foreach ($creds as $i => $c): ?><option value="<?= (int) $c['id'] ?>" <?= $i === 1 ? 'selected' : '' ?>><?= esc($c['label']) ?> <?= $c['role'] ? '(' . esc($c['role']) . ')' : '' ?> · <?= esc($c['scheme']) ?></option><?php endforeach; ?>
          </select></div>
        <div class="mb-3"><label class="form-label small">URL objek (ber-ID numerik)</label>
          <input name="object_url" class="form-control font-monospace" placeholder="http://127.0.0.1:3000/rest/basket/1" required></div>
        <button id="runBtn" class="btn btn-primary"><i class="bi bi-play-fill me-1"></i>Run BOLA Test</button>
        <span id="idorMsg" class="small ms-2"></span>
      </form>
    </div>
  </div>
  <div class="col-lg-7">
    <div class="casa-card p-3 p-lg-4 h-100">
      <h2 class="h6 mb-3">Hasil</h2>
      <div id="idorResult" class="text-muted small">Jalankan uji untuk melihat alur &amp; verdict.</div>
    </div>
  </div>
</div>
<?php endif; ?>
<?= $this->endSection() ?>

<?= $this->section('page_scripts') ?>
<script>
const RUN = '<?= esc(site_url('projects/' . $pid . '/idor/run')) ?>';
const F = document.getElementById('idorForm');
if (F) F.addEventListener('submit', async (e) => {
  e.preventDefault();
  const b = document.getElementById('runBtn'), m = document.getElementById('idorMsg'), out = document.getElementById('idorResult');
  b.disabled = true; const o = b.innerHTML; b.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Menguji…'; m.textContent = '';
  const d = await casaPost(RUN, new FormData(F));
  b.disabled = false; b.innerHTML = o;
  if (!d.ok) { m.className = 'small ms-2 text-danger'; m.textContent = d.error || 'Gagal.'; return; }
  const vcolor = d.verdict === 'confirmed' ? 'danger' : (d.verdict === 'likely' ? 'warning' : 'secondary');
  let html = '<div class="mb-3">';
  (d.steps || []).forEach((s, i) => {
    const ic = s.bad ? '<span class="text-danger">✗</span>' : (s.ok ? '<span class="text-success">✓</span>' : '<span class="text-muted">•</span>');
    html += `<div class="d-flex gap-2 py-2 border-bottom" style="border-color:var(--casa-card-brd)!important">
      <div>${ic}</div><div><div class="fw-semibold small">${i+1}. ${s.step}</div><div class="small text-muted font-monospace">${(s.detail||'').replace(/</g,'&lt;')}</div></div></div>`;
  });
  html += '</div>';
  html += `<div class="alert alert-${vcolor} d-flex align-items-center gap-2"><i class="bi bi-shield-${d.verdict==='not_idor'?'check':'exclamation'}"></i>
     <div><b>Verdict AI: ${d.verdict.toUpperCase()}</b><div class="small">${(d.reason||'').replace(/</g,'&lt;')}</div></div></div>`;
  if (d.finding_id) html += `<a href="/findings/${d.finding_id}" class="btn btn-sm btn-outline-primary"><i class="bi bi-bug me-1"></i>View finding</a>`;
  out.innerHTML = html;
});
</script>
<?= $this->endSection() ?>
