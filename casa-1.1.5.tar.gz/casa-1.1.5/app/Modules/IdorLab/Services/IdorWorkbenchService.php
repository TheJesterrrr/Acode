<?php

declare(strict_types=1);

namespace App\Modules\IdorLab\Services;

use App\Modules\Ai\Services\AiManager;
use App\Modules\Finding\Services\FindingService;
use App\Modules\Project\Models\ProjectCredentialModel;
use App\Modules\Project\Models\ProjectModel;
use App\Modules\Project\Services\AuthContextResolver;
use Config\Services;
use RuntimeException;
use Throwable;

/**
 * IdorWorkbenchService — IDOR Workbench terautentikasi (Master Plan §12 #15,
 * flagship). Memakai Test Accounts (auth-context) untuk alur BOLA nyata:
 * Login A → capture object A → swap token B → replay → compare → AI verdict.
 * Kelas bug bernilai tertinggi yang butuh penilaian (bukan sekadar signature).
 */
final class IdorWorkbenchService
{
    private const SYS = 'You are a BOLA/IDOR analyst. Two authenticated users (A and B) accessed the SAME '
        . "object URL, and B also enumerated adjacent IDs. Answer STRICT JSON only: "
        . '{"verdict":"confirmed|likely|not_idor","severity":"crit|high|med|low|info","reason":string}. '
        . "Confirmed when user B retrieves user A's object (or other users' objects) it should not access.";

    public function __construct(
        private readonly ProjectModel $projects = new ProjectModel(),
        private readonly ProjectCredentialModel $creds = new ProjectCredentialModel(),
        private readonly AiManager $ai = new AiManager(),
        private readonly FindingService $findings = new FindingService(),
        private readonly AuthContextResolver $auth = new AuthContextResolver(),
    ) {
    }

    /**
     * Jalankan uji BOLA A vs B pada satu object URL.
     * @return array{steps:array,verdict:string,reason:string,finding_id:?int}
     * @throws RuntimeException
     */
    public function run(int $projectId, int $customerId, int $credAId, int $credBId, string $objectUrl): array
    {
        if ($this->projects->ownedBy($projectId, $customerId) === null) {
            throw new RuntimeException('Project tidak ditemukan.');
        }
        $objectUrl = trim($objectUrl);
        if (! preg_match('#^https?://.+/(\d+)(?:[/?].*)?$#', $objectUrl, $m)) {
            throw new RuntimeException('URL objek harus ber-ID numerik di akhir path, mis. http://host/rest/basket/1');
        }
        $id   = (int) $m[1];
        $base = preg_replace('#\d+(?:[/?].*)?$#', '', $objectUrl);

        $credA = $this->requireCred($credAId, $projectId);
        $credB = $this->requireCred($credBId, $projectId);
        $authA = $this->auth->headersFor($credA);
        $authB = $this->auth->headersFor($credB);

        $steps = [];
        $client = Services::curlrequest(['timeout' => 10, 'connect_timeout' => 5, 'http_errors' => false], null, null, false);

        // 1) A akses objeknya sendiri
        [$sa, $ba] = $this->fetch($client, $objectUrl, $authA);
        $steps[] = ['step' => 'Login A → GET objek (token A)', 'detail' => "{$objectUrl} → HTTP {$sa}", 'ok' => $sa === 200];

        // 2) Swap ke token B, akses objek MILIK A
        [$sb, $bb] = $this->fetch($client, $objectUrl, $authB);
        $leak = $sb === 200 && mb_strlen(trim($bb)) > 40;
        $steps[] = ['step' => 'Swap token B → replay objek A', 'detail' => "{$objectUrl} → HTTP {$sb}" . ($leak ? ' (mengembalikan data!)' : ''), 'ok' => ! $leak, 'bad' => $leak];

        // 3) Enumerasi ID berdekatan dengan token B
        $enum = [];
        foreach ([$id - 1, $id + 1, $id + 2] as $p) {
            if ($p <= 0) {
                continue;
            }
            [$s, $b] = $this->fetch($client, $base . $p, $authB);
            $enum[] = "id={$p} → HTTP {$s}" . ($s === 200 && mb_strlen(trim($b)) > 40 ? ' (data)' : '');
        }
        $steps[] = ['step' => 'Enumerasi ID berdekatan (token B)', 'detail' => implode(' · ', $enum), 'ok' => true];

        // 4) Verdict AI
        $verdict = $leak ? 'likely' : 'not_idor';
        $reason  = $leak ? 'Token B memperoleh objek milik A (HTTP 200, ada data).' : 'Token B tidak memperoleh objek A.';
        $sev     = 'high';
        try {
            $usr = "Object URL: {$objectUrl}\nA (own) status={$sa} len=" . mb_strlen($ba)
                . "\nB (replay A's object) status={$sb} len=" . mb_strlen($bb) . " sameBody=" . ($ba !== '' && $ba === $bb ? 'yes' : 'no')
                . "\nB enumerate: " . implode(' ', $enum)
                . "\nB body sample: " . mb_substr($bb, 0, 200);
            $raw = $this->ai->chatForRole('vuln_analyst', self::SYS, $usr);
            if (preg_match('/\{.*\}/s', $raw, $mm)) {
                $j = json_decode($mm[0], true);
                if (is_array($j)) {
                    $verdict = (string) ($j['verdict'] ?? $verdict);
                    $reason  = (string) ($j['reason'] ?? $reason);
                    $sev     = in_array($j['severity'] ?? '', ['crit', 'high', 'med', 'low', 'info'], true) ? $j['severity'] : $sev;
                }
            }
        } catch (Throwable $e) {
            // pertahankan verdikt heuristik
        }

        $findingId = null;
        if ($verdict === 'confirmed' || $verdict === 'likely') {
            $findingId = $this->findings->record([
                'project_id'  => $projectId,
                'title'       => 'IDOR / BOLA terautentikasi — ' . $base . '{id}',
                'severity'    => $verdict === 'confirmed' ? 'crit' : $sev,
                'cwe'         => 'CWE-639',
                'cvss'        => $verdict === 'confirmed' ? '9.1' : '8.1',
                'category'    => 'IDOR / BOLA',
                'asset'       => $objectUrl,
                'tool'        => 'idor-workbench',
                'description' => "Broken Object Level Authorization: {$reason}\nAkun A={$credA['label']} B={$credB['label']}.",
                'evidence'    => "A(own) {$objectUrl} -> {$sa}\nB(replay) {$objectUrl} -> {$sb}\nB enum: " . implode(' ', $enum),
                'remediation' => 'Terapkan pemeriksaan kepemilikan objek di sisi server (WHERE owner = caller), gunakan ID non-sekuensial (UUID), tambahkan uji akses per-objek pada CI.',
            ]);
        }

        return ['steps' => $steps, 'verdict' => $verdict, 'reason' => $reason, 'finding_id' => $findingId];
    }

    private function requireCred(int $id, int $projectId): array
    {
        $c = $this->creds->find($id);
        if ($c === null || (int) $c['project_id'] !== $projectId) {
            throw new RuntimeException('Akun uji tidak ditemukan / bukan milik project.');
        }

        return $c;
    }

    /** @return array{0:int,1:string} [status, body] */
    private function fetch($client, string $url, array $headers): array
    {
        try {
            $res = $client->get($url, ['headers' => ['Accept' => 'application/json'] + $headers]);

            return [$res->getStatusCode(), (string) $res->getBody()];
        } catch (Throwable $e) {
            return [0, ''];
        }
    }
}
