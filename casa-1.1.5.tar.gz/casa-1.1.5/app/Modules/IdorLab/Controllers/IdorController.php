<?php

declare(strict_types=1);

namespace App\Modules\IdorLab\Controllers;

use App\Controllers\BaseController;
use App\Modules\IdorLab\Services\IdorWorkbenchService;
use App\Modules\Licensing\Services\EditionService;
use App\Modules\Project\Services\ProjectService;
use CodeIgniter\Exceptions\PageNotFoundException;
use CodeIgniter\HTTP\ResponseInterface;
use RuntimeException;

/** IdorController — IDOR Workbench terautentikasi (member; CES 13.2 thin). */
final class IdorController extends BaseController
{
    public function __construct(
        private readonly IdorWorkbenchService $wb = new IdorWorkbenchService(),
        private readonly ProjectService $projects = new ProjectService(),
        private readonly EditionService $edition = new EditionService(),
    ) {
    }

    private function me(): int
    {
        return (int) $this->session->get('member_id');
    }

    public function show(int $projectId): string
    {
        if (! $this->edition->can($this->me(), 'idor_workbench')) {
            return $this->memberView('App\Modules\Licensing\Views\upsell', [
                'title'   => 'IDOR Workbench',
                'feature' => 'IDOR / BOLA Workbench',
                'edition' => $this->edition->resolve($this->me()),
            ], 'projects');
        }
        try {
            $project = $this->projects->getProject($projectId, $this->me());
        } catch (RuntimeException $e) {
            throw PageNotFoundException::forPageNotFound($e->getMessage());
        }

        return $this->memberView('App\Modules\IdorLab\Views\workbench', [
            'title'   => 'IDOR Workbench — ' . $project['name'],
            'project' => $project,
        ], 'projects');
    }

    public function run(int $projectId): ResponseInterface
    {
        if ($r = $this->denyViewer()) {
            return $r;
        }
        try {
            $this->edition->requireFeature($this->me(), 'idor_workbench');
            $res = $this->wb->run(
                $projectId,
                $this->me(),
                (int) $this->request->getPost('cred_a'),
                (int) $this->request->getPost('cred_b'),
                (string) $this->request->getPost('object_url'),
            );
        } catch (RuntimeException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok($res);
    }
}
