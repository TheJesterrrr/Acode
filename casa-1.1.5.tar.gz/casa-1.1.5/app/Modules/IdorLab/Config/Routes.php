<?php

declare(strict_types=1);

use CodeIgniter\Router\RouteCollection;

/** Rute IDOR Workbench — endpoint MEMBER (CES 13.10). */

/** @var RouteCollection $routes */
$routes->group('projects/(:num)/idor', ['namespace' => 'App\Modules\IdorLab\Controllers', 'filter' => 'member'], static function (RouteCollection $routes): void {
    $routes->get('', 'IdorController::show/$1');
    $routes->post('run', 'IdorController::run/$1', ['filter' => 'audit:IDOR_WORKBENCH']);
});
