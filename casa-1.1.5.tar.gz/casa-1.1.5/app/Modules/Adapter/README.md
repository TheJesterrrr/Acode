# Modul Adapter
CASA tidak pernah memanggil tool langsung — selalu lewat Adapter, yang MENORMALKAN
keluaran tiap tool ke format internal tunggal (findings/assets). Master Plan §4.
- `Services/ToolAdapter` (kontrak) + `AbstractCliAdapter` (proc_open + timeout).
- `HttpxAdapter`, `NucleiAdapter` (Nuclei diarahkan ke template lokal agar tak auto-unduh repo besar).
- `AdapterFactory::forCode()` / `supported()`.
Roadmap: adapter untuk katalog tool lain (katana, ffuf, dalfox, dst.).
