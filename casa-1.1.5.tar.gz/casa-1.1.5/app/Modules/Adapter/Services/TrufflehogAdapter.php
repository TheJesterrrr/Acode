<?php

declare(strict_types=1);

namespace App\Modules\Adapter\Services;

/**
 * TrufflehogAdapter — deteksi rahasia di repositori git (Secret Detection §12 #24).
 * Target = URL repo git. Trufflehog memindai remote langsung (tanpa clone manual).
 */
final class TrufflehogAdapter extends AbstractCliAdapter
{
    private const CAP = 100;

    public function code(): string
    {
        return 'trufflehog';
    }

    public function run(string $binPath, string $target): array
    {
        $repo = trim($target);
        $bin  = is_file($binPath) ? $binPath : ((string) (env('tools.dir') ?: '/opt/casa-tools') . '/trufflehog');
        if (! is_file($bin)) {
            return ['findings' => [], 'assets' => [], 'raw' => 'trufflehog not found'];
        }

        $cmd = escapeshellarg($bin) . ' git ' . escapeshellarg($repo) . ' --json --no-update --concurrency=2 2>/dev/null';
        [$out] = $this->exec($cmd);

        $findings = [];
        foreach (preg_split('/\r?\n/', trim($out)) as $line) {
            if ($line === '' || $line[0] !== '{') {
                continue;
            }
            $j = json_decode($line, true);
            if (! is_array($j) || empty($j['DetectorName'])) {
                continue;
            }
            $git      = $j['SourceMetadata']['Data']['Git'] ?? [];
            $verified = ! empty($j['Verified']);
            $file     = (string) ($git['file'] ?? '');
            $findings[] = [
                'severity'    => $verified ? 'crit' : 'high',
                'title'       => 'Secret exposed: ' . (string) $j['DetectorName'] . ($verified ? ' (VERIFIED)' : ''),
                'category'    => 'Secret Detection',
                'asset'       => $repo . ($file !== '' ? ' → ' . $file : ''),
                'tool'        => 'trufflehog',
                'cwe'         => 'CWE-798',
                'cvss'        => $verified ? '9.8' : '7.5',
                'description' => 'Credential/secret ' . (string) $j['DetectorName'] . ' found in git history'
                    . ($file !== '' ? " (file {$file}, commit " . mb_substr((string) ($git['commit'] ?? ''), 0, 10) . ')' : '') . '.'
                    . ($verified ? ' The VERIFIED secret is still active — rotate it immediately.' : ''),
                'evidence'    => 'Detector=' . (string) $j['DetectorName'] . ' verified=' . ($verified ? 'yes' : 'no') . ' file=' . $file,
                'remediation' => 'Revoke & rotate the credential; remove it from history (git filter-repo/BFG); use a secret manager; add secret scanning to CI (pre-commit).',
            ];
            if (count($findings) >= self::CAP) {
                break;
            }
        }

        return ['findings' => $findings, 'assets' => [], 'raw' => mb_substr($out, 0, 2000)];
    }
}
