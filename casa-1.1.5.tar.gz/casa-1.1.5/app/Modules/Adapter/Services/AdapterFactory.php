<?php

declare(strict_types=1);

namespace App\Modules\Adapter\Services;

/** AdapterFactory — memilih Adapter untuk sebuah kode tool (Master Plan §4). */
final class AdapterFactory
{
    /** Kode tool yang sudah didukung Adapter di rilis pertama. */
    public static function supported(): array
    {
        return [
            // amass DIPENSIUNKAN: daemon `amass engine` v4 menggantung & menahan lock
            // worker. subfinder sudah menutup Subdomain Discovery.
            'httpx', 'nuclei', 'dalfox', 'sqlmap', 'idor', 'katana', 'naabu', 'subfinder',
            'gau', 'dnsx', 'testssl', 'ffuf', 'gowitness', 'whatweb', 'nikto',
            'arjun', 'wafw00f', 'trufflehog', 'gitleaks', 'trivy',
            'waybackurls', 'hakrawler', 'feroxbuster', 'nmap', 'wpscan',
        ];
    }

    /** Tool "builtin" tak butuh binari terpasang (dijalankan CASA sendiri). */
    public static function isBuiltin(string $code): bool
    {
        return $code === 'idor';
    }

    /** Tipe target web (default untuk mayoritas adapter). */
    private const WEB = ['domain', 'subdomain', 'ip', 'cidr', 'url', 'api', 'asn'];

    /**
     * Tipe target yang berlaku untuk sebuah adapter. Secret scanner → repo git;
     * Trivy → image container atau repo. Sisanya menyasar target web.
     * @return string[]
     */
    public static function targetKinds(string $code): array
    {
        return match ($code) {
            'gitleaks', 'trufflehog' => ['repo'],
            'trivy'                  => ['repo', 'image'],
            default                  => self::WEB,
        };
    }

    /** Apakah adapter cocok dijalankan pada tipe target ini (planner sadar-tipe). */
    public static function appliesTo(string $code, string $targetType): bool
    {
        return in_array($targetType, self::targetKinds($code), true);
    }

    public static function forCode(string $code): ?ToolAdapter
    {
        return match ($code) {
            'httpx'  => new HttpxAdapter(),
            'nuclei' => new NucleiAdapter(),
            'dalfox' => new DalfoxAdapter(),
            'sqlmap' => new SqlmapAdapter(),
            'idor'   => new IdorAdapter(),
            'katana'    => new KatanaAdapter(),
            'naabu'     => new NaabuAdapter(),
            'subfinder' => new SubfinderAdapter(),
            'amass'     => new AmassAdapter(),
            'gau'       => new GauAdapter(),
            'dnsx'      => new DnsxAdapter(),
            'testssl'   => new TestsslAdapter(),
            'ffuf'      => new FfufAdapter(),
            'gowitness' => new GowitnessAdapter(),
            'whatweb'   => new WhatWebAdapter(),
            'nikto'     => new NiktoAdapter(),
            'arjun'      => new ArjunAdapter(),
            'wafw00f'    => new Wafw00fAdapter(),
            'trufflehog' => new TrufflehogAdapter(),
            'gitleaks'   => new GitleaksAdapter(),
            'trivy'      => new TrivyAdapter(),
            'waybackurls' => new WaybackurlsAdapter(),
            'hakrawler'   => new HakrawlerAdapter(),
            'feroxbuster' => new FeroxbusterAdapter(),
            'nmap'        => new NmapAdapter(),
            'wpscan'      => new WpscanAdapter(),
            default  => null,
        };
    }
}
