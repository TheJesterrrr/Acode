<?php

declare(strict_types=1);

namespace App\Modules\Adapter\Services;

/**
 * NmapAdapter — pemindaian port + deteksi service/versi (-sV). Menghasilkan asset
 * 'port' dan finding info per port terbuka (berguna untuk memetakan permukaan &
 * versi usang). Parsing XML (-oX -).
 *
 * Port-range mengikuti depth (ScanProfile): Light=top 100, Standard=top 1000,
 * Deep=seluruh port TCP.
 *
 * DEEP = DUA TAHAP (lihat runDeep): dulu `nmap -p- -sV` dijalankan sekaligus dan
 * sering menembus TIMEOUT → XML terpotong → balik 0 port DIAM-DIAM
 * (casa-nmap-timeout-silent-zero). Kini Deep: (1) temukan port terbuka cepat
 * TANPA -sV, lalu (2) deteksi service HANYA pada port yang terbuka. Jauh lebih
 * efisien & andal; cakupan port sama.
 */
final class NmapAdapter extends AbstractCliAdapter
{
    private const CAP = 100;

    public function code(): string
    {
        return 'nmap';
    }

    public function run(string $binPath, string $target): array
    {
        $host  = $this->host($target);
        $depth = \App\Libraries\ScanProfile::depth();

        if ($depth === 'deep') {
            return $this->runDeep($binPath, $host);
        }

        // Light/Standard: satu tahap (port + service sekaligus). Batasi -sV dengan
        // host-timeout agar tak nyangkut lama pada service yang lambat merespons.
        $cmd = escapeshellarg($binPath) . ' -Pn -T4 ' . \App\Libraries\ScanProfile::nmapPorts()
            . ' -sV --version-light --version-intensity 2 --host-timeout 120s -oX - '
            . escapeshellarg($host) . ' 2>/dev/null';
        [$out] = $this->exec($cmd);

        return $this->parse($out, $host);
    }

    /**
     * Deep dua-tahap:
     *   Tahap 1 — discovery SELURUH port TCP tanpa -sV (cepat, -T4, tanpa
     *             host-timeout). Ini yang dulu terpotong kalau digabung -sV.
     *   Tahap 2 — service detection HANYA pada port terbuka hasil tahap 1.
     * Fallback: bila tahap 2 tak menghasilkan apa-apa (mis. timeout), pakai
     * daftar port tahap 1 agar temuan port tetap ada.
     */
    private function runDeep(string $binPath, string $host): array
    {
        // Tahap 1 — seluruh port TCP, tanpa service detection.
        $cmd1   = escapeshellarg($binPath) . ' -Pn -T4 -p- -oX - ' . escapeshellarg($host) . ' 2>/dev/null';
        [$out1] = $this->exec($cmd1);
        $ports  = $this->openPorts($out1);

        if ($ports === []) {
            // Mungkin memang tak ada port terbuka — kembalikan hasil tahap 1 apa adanya.
            return $this->parse($out1, $host);
        }

        // Tahap 2 — service detection hanya pada port terbuka (batasi panjang arg).
        $plist  = implode(',', array_slice($ports, 0, 500));
        $cmd2   = escapeshellarg($binPath) . ' -Pn -sV --version-light --version-intensity 2 -p '
            . escapeshellarg($plist) . ' -oX - ' . escapeshellarg($host) . ' 2>/dev/null';
        [$out2] = $this->exec($cmd2);

        $res = $this->parse($out2, $host);
        if ($res['assets'] === [] && $res['findings'] === []) {
            return $this->parse($out1, $host);
        }

        return $res;
    }

    /** Ambil daftar nomor port TCP terbuka dari XML nmap (tanpa service detection). */
    private function openPorts(string $xmlStr): array
    {
        $xml = @simplexml_load_string($xmlStr);
        if ($xml === false) {
            return [];
        }
        $ports = [];
        foreach ($xml->host->ports->port ?? [] as $p) {
            if ((string) ($p->state['state'] ?? '') !== 'open') {
                continue;
            }
            $portid = (int) ($p['portid'] ?? 0);
            if ($portid > 0) {
                $ports[] = $portid;
            }
        }
        sort($ports);

        return $ports;
    }

    /** Parse XML nmap menjadi ['findings'=>…, 'assets'=>…, 'raw'=>…]. */
    private function parse(string $out, string $host): array
    {
        $assets   = [];
        $findings = [];
        $xml      = @simplexml_load_string($out);
        if ($xml === false) {
            return ['findings' => [], 'assets' => [], 'raw' => mb_substr($out, 0, 2000)];
        }

        foreach ($xml->host->ports->port ?? [] as $p) {
            if ((string) ($p->state['state'] ?? '') !== 'open') {
                continue;
            }
            $portid = (string) ($p['portid'] ?? '');
            $proto  = (string) ($p['protocol'] ?? 'tcp');
            $svc    = $p->service;
            $name   = (string) ($svc['name'] ?? '');
            $prod   = trim((string) ($svc['product'] ?? '') . ' ' . (string) ($svc['version'] ?? ''));
            $label  = $name . ($prod !== '' ? " ({$prod})" : '');

            $assets[] = ['type' => 'port', 'value' => "{$host}:{$portid}/{$proto}", 'source' => 'nmap'];
            $findings[] = [
                'severity'    => 'info',
                'title'       => "Port {$portid}/{$proto} open — {$label}",
                'category'    => 'Network',
                'asset'       => "{$host}:{$portid}",
                'tool'        => 'nmap',
                'cwe'         => null,
                'cvss'        => null,
                'description' => "Detected service: {$label}. Verify the version is current & that it should be publicly exposed.",
                'evidence'    => trim("service={$name} product={$prod}"),
            ];
            if (count($findings) >= self::CAP) {
                break;
            }
        }

        return ['findings' => $findings, 'assets' => $assets, 'raw' => mb_substr($out, 0, 2000)];
    }
}
