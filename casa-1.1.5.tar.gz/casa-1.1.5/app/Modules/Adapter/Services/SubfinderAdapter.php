<?php

declare(strict_types=1);

namespace App\Modules\Adapter\Services;

/** SubfinderAdapter — enumerasi subdomain; hasil menjadi asset host. */
final class SubfinderAdapter extends AbstractCliAdapter
{
    public function code(): string
    {
        return 'subfinder';
    }

    public function run(string $binPath, string $target): array
    {
        $domain = $this->host($target);
        // Depth: Light = sumber pasif cepat; Standard = -all (semua sumber);
        // Deep = + rekursif (enumerasi bertingkat, lebih dalam & lebih lama).
        $depth  = \App\Libraries\ScanProfile::depth();
        $extra  = $depth === 'deep' ? ' -all -recursive' : ($depth === 'standard' ? ' -all' : '');
        $cmd    = escapeshellarg($binPath) . ' -d ' . escapeshellarg($domain) . $extra
            . ' -json -silent -nc -timeout 8 -disable-update-check 2>/dev/null';
        [$out] = $this->exec($cmd);

        $assets = [];
        foreach (preg_split('/\r?\n/', trim($out)) as $line) {
            if ($line === '' || $line[0] !== '{') {
                continue;
            }
            $j    = json_decode($line, true);
            $host = is_array($j) ? (string) ($j['host'] ?? '') : '';
            if ($host !== '') {
                $assets[] = ['type' => 'host', 'value' => $host, 'source' => 'subfinder'];
            }
        }

        return ['findings' => [], 'assets' => $assets, 'raw' => mb_substr($out, 0, 2000)];
    }
}
