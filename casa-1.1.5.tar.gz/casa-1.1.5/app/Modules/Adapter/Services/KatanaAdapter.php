<?php

declare(strict_types=1);

namespace App\Modules\Adapter\Services;

/** KatanaAdapter — crawl web; keluaran URL menjadi asset (Attack Surface). */
final class KatanaAdapter extends AbstractCliAdapter
{
    public function code(): string
    {
        return 'katana';
    }

    public function run(string $binPath, string $target): array
    {
        // Depth → kedalaman crawl: Light d=1, Standard d=2, Deep d=5 (+ -jc: crawl
        // endpoint di dalam file JS). Makin dalam = makin banyak URL & makin lama.
        $depth = \App\Libraries\ScanProfile::depth();
        $d     = $depth === 'deep' ? 5 : ($depth === 'light' ? 1 : 2);
        $jc    = $depth === 'deep' ? ' -jc' : '';
        $cmd = escapeshellarg($binPath) . ' -u ' . escapeshellarg($target)
            . ' -jsonl -silent -nc -d ' . $d . ' -c 10 -timeout 8 -disable-update-check' . $jc
            . \App\Libraries\ScanProfile::headerArgs()
            . ' 2>/dev/null';
        [$out] = $this->exec($cmd);

        $assets = [];
        $seen   = [];
        foreach (preg_split('/\r?\n/', trim($out)) as $line) {
            if ($line === '' || $line[0] !== '{') {
                continue;
            }
            $j   = json_decode($line, true);
            $url = is_array($j) ? (string) ($j['request']['endpoint'] ?? $j['endpoint'] ?? '') : '';
            if ($url === '' || isset($seen[$url])) {
                continue;
            }
            $seen[$url] = true;
            $assets[]   = ['type' => 'url', 'value' => $url, 'source' => 'katana'];
            if (count($assets) >= 200) {
                break;
            }
        }

        return ['findings' => [], 'assets' => $assets, 'raw' => mb_substr($out, 0, 2000)];
    }
}
