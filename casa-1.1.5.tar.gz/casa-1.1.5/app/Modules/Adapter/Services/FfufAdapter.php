<?php

declare(strict_types=1);

namespace App\Modules\Adapter\Services;

/**
 * FfufAdapter — brute konten/direktori (Directory Enumeration §12 #9) → findings.
 * Memakai wordlist ringan bawaan CASA di {toolsDir}/wordlists/common.txt.
 */
final class FfufAdapter extends AbstractCliAdapter
{
    private const CAP = 100;

    /** Signature (status+length) yang muncul >= ini kali dianggap halaman block
     *  WAF/bot-protection seragam, bukan path yang benar-benar ada satu-satu —
     *  dirangkum jadi SATU temuan info, bukan dibanjir per-path (mencegah
     *  false-positif BAC/patch dari noise wordlist). ffuf -ac semestinya
     *  menyaring ini sendiri, tapi terbukti gagal di target yang body 403-nya
     *  sedikit berbeda per path (mis. ada nama path di body) walau length sama. */
    private const NOISE_THRESHOLD = 3;

    public function code(): string
    {
        return 'ffuf';
    }

    public function run(string $binPath, string $target): array
    {
        $base = rtrim(trim($target), '/');
        if (! preg_match('#^https?://#i', $base)) {
            $base = 'http://' . $base;
        }
        $wl = (string) (env('tools.dir') ?: '/opt/casa-tools') . '/wordlists/common.txt';
        if (! is_file($wl)) {
            return ['findings' => [], 'assets' => [], 'raw' => 'wordlist not found: ' . $wl];
        }
        $json = '/tmp/casa_ffuf_' . bin2hex(random_bytes(4)) . '.json';

        // Rate/konkurensi/timeout mengikuti ScanProfile; hanya status "menarik".
        $rate = \App\Libraries\ScanProfile::rate();
        $t    = \App\Libraries\ScanProfile::concurrency();
        $to   = \App\Libraries\ScanProfile::timeout();
        $cmd = escapeshellarg($binPath) . ' -u ' . escapeshellarg($base . '/FUZZ')
            . ' -w ' . escapeshellarg($wl)
            . " -mc 200,204,301,302,307,401,403 -ac -t {$t} -rate {$rate} -timeout {$to}"
            . ' -of json -o ' . escapeshellarg($json) . ' -s'
            . \App\Libraries\ScanProfile::headerArgs()
            . ' 2>/dev/null';
        $this->exec($cmd);

        $findings = [];
        $raw      = '';
        if (is_file($json)) {
            $raw  = (string) file_get_contents($json);
            $data = json_decode($raw, true);

            // Kelompokkan hit per signature (status+length) dulu, SEBELUM dibikin
            // finding. ffuf -ac (auto-calibrate) semestinya sudah membuang halaman
            // block WAF/bot-protection yang seragam, tapi terbukti bisa lolos kalau
            // body 403-nya sedikit beda per path (nama path ikut ditulis di body)
            // walau panjangnya identik. Signature yang berulang >= NOISE_THRESHOLD
            // kali dianggap bukan temuan per-path asli.
            $hits = [];
            foreach ((array) ($data['results'] ?? []) as $r) {
                $url = (string) ($r['url'] ?? '');
                if ($url === '') {
                    continue;
                }
                $status = (int) ($r['status'] ?? 0);
                $len    = (int) ($r['length'] ?? -1);
                $hits[$status . ':' . $len][] = ['url' => $url, 'path' => (string) parse_url($url, PHP_URL_PATH)];
            }

            foreach ($hits as $sig => $group) {
                if (count($findings) >= self::CAP) {
                    break;
                }
                [$status, $len] = array_map('intval', explode(':', $sig, 2));

                if (count($group) >= self::NOISE_THRESHOLD) {
                    // Signature seragam di banyak path acak → kemungkinan besar
                    // halaman block WAF/bot-protection, bukan N resource nyata.
                    // Satu temuan info merangkum semuanya, bukan dibanjir per-path.
                    $contoh = array_slice(array_column($group, 'path'), 0, 8);
                    $findings[] = [
                        'severity'    => 'info',
                        'title'       => 'Uniform HTTP ' . $status . ' across ' . count($group) . ' fuzzed paths (likely WAF/bot block, not real findings)',
                        'category'    => 'Content Discovery',
                        'asset'       => $base,
                        'tool'        => 'ffuf',
                        'cwe'         => null,
                        'cvss'        => null,
                        'description' => count($group) . " wordlist paths all returned HTTP {$status} with an identical response length ({$len}) — consistent with a generic WAF/bot-protection block page rather than " . count($group) . ' genuinely distinct resources. Not flagged individually to avoid false-positive BAC/patch findings. Examples: ' . implode(', ', $contoh) . (count($group) > 8 ? ', …' : '') . '. Spot-check manually (browser/Burp) only if a specific path is of real interest.',
                        'evidence'    => 'ffuf status=' . $status . ' len=' . $len . ' count=' . count($group),
                    ];
                    \App\Libraries\CasaLog::log('CASA-E015', "ffuf: {$status} seragam di " . count($group) . " path pada {$base} — dirangkum 1 temuan, bukan di-spam per-path", null, null, 'info');

                    continue;
                }

                foreach ($group as $h) {
                    if (count($findings) >= self::CAP) {
                        break;
                    }
                    // 401/403 = protected (interesting); 200/30x = exposed.
                    $sev = in_array($status, [401, 403], true) ? 'low' : 'info';
                    $findings[] = [
                        'severity'    => $sev,
                        'title'       => 'Path found (' . $status . '): ' . $h['path'],
                        'category'    => 'Content Discovery',
                        'asset'       => $h['url'],
                        'tool'        => 'ffuf',
                        'cwe'         => $status === 403 ? 'CWE-548' : null,
                        'cvss'        => null,
                        'description' => "ffuf found a resource at {$h['url']} (HTTP {$status}).",
                        'evidence'    => 'ffuf status=' . $status . ' len=' . $len,
                    ];
                }
            }
            @unlink($json);
        }

        return ['findings' => $findings, 'assets' => [], 'raw' => mb_substr($raw, 0, 2000)];
    }
}
