<?php

declare(strict_types=1);

namespace App\Modules\Adapter\Services;

/**
 * GitleaksAdapter — deteksi rahasia di repositori git (Secret Detection §12 #24).
 * Target = URL repo git. Gitleaks butuh repo lokal → clone dangkal ke /tmp lalu scan.
 */
final class GitleaksAdapter extends AbstractCliAdapter
{
    private const CAP = 100;

    public function code(): string
    {
        return 'gitleaks';
    }

    public function run(string $binPath, string $target): array
    {
        $repo = trim($target);
        $bin  = is_file($binPath) ? $binPath : ((string) (env('tools.dir') ?: '/opt/casa-tools') . '/gitleaks');
        if (! is_file($bin)) {
            return ['findings' => [], 'assets' => [], 'raw' => 'gitleaks not found'];
        }
        $dir  = '/tmp/casa_gl_' . bin2hex(random_bytes(4));
        $json = $dir . '.json';

        // Clone dangkal (riwayat terbatas) agar cepat & hemat ruang.
        $this->exec('git clone --depth 40 --quiet ' . escapeshellarg($repo) . ' ' . escapeshellarg($dir) . ' 2>/dev/null');
        if (! is_dir($dir)) {
            return ['findings' => [], 'assets' => [], 'raw' => 'clone failed: ' . $repo];
        }

        $this->exec(escapeshellarg($bin) . ' detect --source ' . escapeshellarg($dir)
            . ' --report-format json --report-path ' . escapeshellarg($json)
            . ' --redact --no-banner --exit-code 0 2>/dev/null');

        $findings = [];
        $raw      = '';
        if (is_file($json)) {
            $raw  = (string) file_get_contents($json);
            $rows = json_decode($raw, true);
            foreach (is_array($rows) ? $rows : [] as $r) {
                if (! is_array($r)) {
                    continue;
                }
                $file = (string) ($r['File'] ?? '');
                $findings[] = [
                    'severity'    => 'high',
                    'title'       => 'Secret exposed: ' . (string) ($r['RuleID'] ?? 'secret'),
                    'category'    => 'Secret Detection',
                    'asset'       => $repo . ($file !== '' ? ' → ' . $file : ''),
                    'tool'        => 'gitleaks',
                    'cwe'         => 'CWE-798',
                    'cvss'        => '7.5',
                    'description' => (string) ($r['Description'] ?? 'Secret detected') . " (file {$file}, line " . (string) ($r['StartLine'] ?? '?') . ').',
                    'evidence'    => 'RuleID=' . (string) ($r['RuleID'] ?? '') . ' commit=' . mb_substr((string) ($r['Commit'] ?? ''), 0, 10) . ' secret=[redacted]',
                    'remediation' => 'Revoke & rotate the credential; clean the history (BFG/git filter-repo); use a secret manager + pre-commit scanning.',
                ];
                if (count($findings) >= self::CAP) {
                    break;
                }
            }
            @unlink($json);
        }
        $this->exec('rm -rf ' . escapeshellarg($dir) . ' 2>/dev/null');

        return ['findings' => $findings, 'assets' => [], 'raw' => mb_substr($raw, 0, 2000)];
    }
}
