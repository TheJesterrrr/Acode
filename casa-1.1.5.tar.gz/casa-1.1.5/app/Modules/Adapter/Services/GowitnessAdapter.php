<?php

declare(strict_types=1);

namespace App\Modules\Adapter\Services;

/**
 * GowitnessAdapter — tangkapan layar situs (Screenshot §12 #10) → asset evidence.
 * Screenshot menjadi bukti (evidence), bukan temuan; disimpan di {toolsDir}/shots.
 */
final class GowitnessAdapter extends AbstractCliAdapter
{
    public function code(): string
    {
        return 'gowitness';
    }

    public function run(string $binPath, string $target): array
    {
        $url = trim($target);
        if (! preg_match('#^https?://#i', $url)) {
            $url = 'http://' . $url;
        }
        $dir = (string) (env('tools.dir') ?: '/opt/casa-tools') . '/shots';
        @mkdir($dir, 0775, true);
        $before = glob($dir . '/*.jpeg') ?: [];
        $beforeN = count($before) + count((array) (glob($dir . '/*.png') ?: []));

        // gowitness v3: scan single. Toleran terhadap variasi flag (best-effort).
        $cmd = escapeshellarg($binPath) . ' scan single --url ' . escapeshellarg($url)
            . ' --screenshot-path ' . escapeshellarg($dir) . ' --timeout 20 2>/dev/null';
        [$out] = $this->exec($cmd);

        $shots  = array_merge((array) (glob($dir . '/*.jpeg') ?: []), (array) (glob($dir . '/*.png') ?: []));
        $assets = [];
        if (count($shots) > $beforeN) {
            // Ambil file terbaru sebagai bukti.
            usort($shots, static fn ($a, $b): int => filemtime($b) <=> filemtime($a));
            $assets[] = ['type' => 'screenshot', 'value' => $shots[0], 'source' => 'gowitness'];
        }

        return ['findings' => [], 'assets' => $assets, 'raw' => mb_substr($out, 0, 800)];
    }
}
