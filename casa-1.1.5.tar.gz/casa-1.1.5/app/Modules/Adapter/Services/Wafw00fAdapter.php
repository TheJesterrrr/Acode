<?php

declare(strict_types=1);

namespace App\Modules\Adapter\Services;

/**
 * Wafw00fAdapter — deteksi Web Application Firewall (recon HTTP §12 #12/#23 konteks).
 * wafw00f dipasang via pipx bersama di {toolsDir}/pybin. Hasil = temuan info
 * (ada/tidaknya WAF memengaruhi strategi & interpretasi scan).
 */
final class Wafw00fAdapter extends AbstractCliAdapter
{
    public function code(): string
    {
        return 'wafw00f';
    }

    public function run(string $binPath, string $target): array
    {
        $url = trim($target);
        if (! preg_match('#^https?://#i', $url)) {
            $url = 'http://' . $url;
        }
        $bin = is_file($binPath) ? $binPath : ((string) (env('tools.dir') ?: '/opt/casa-tools') . '/pybin/wafw00f');
        if (! is_file($bin)) {
            return ['findings' => [], 'assets' => [], 'raw' => 'wafw00f not found'];
        }
        $json = '/tmp/casa_wafw00f_' . bin2hex(random_bytes(4)) . '.json';

        // Depth: Light = deteksi cepat; Standard/Deep = -a (uji semua tanda WAF).
        $all = \App\Libraries\ScanProfile::depth() === 'light' ? '' : ' -a';
        $cmd = escapeshellarg($bin) . ' ' . escapeshellarg($url) . $all . ' -f json -o ' . escapeshellarg($json) . ' 2>/dev/null';
        $this->exec($cmd);

        $findings = [];
        $raw      = '';
        if (is_file($json)) {
            $raw  = (string) file_get_contents($json);
            $rows = json_decode($raw, true);
            foreach (is_array($rows) ? $rows : [] as $r) {
                if (! is_array($r)) {
                    continue;
                }
                $detected = ! empty($r['detected']);
                $waf      = trim((string) ($r['firewall'] ?? '') . ' ' . (string) ($r['manufacturer'] ?? ''));
                $findings[] = [
                    'severity'    => 'info',
                    'title'       => $detected ? ('WAF detected: ' . ($waf !== '' ? $waf : 'generic')) : 'No WAF detected',
                    'category'    => 'WAF Detection',
                    'asset'       => (string) ($r['url'] ?? $url),
                    'tool'        => 'wafw00f',
                    'cwe'         => null,
                    'cvss'        => null,
                    'description' => $detected
                        ? ('Target is protected by a WAF (' . ($waf ?: 'generic') . '); adjust payloads & interpret scan results accordingly.')
                        : 'No WAF detected in front of the target; attack surface is more direct.',
                    'evidence'    => mb_substr($raw, 0, 400),
                ];
            }
            @unlink($json);
        }

        return ['findings' => $findings, 'assets' => [], 'raw' => mb_substr($raw, 0, 1500)];
    }
}
