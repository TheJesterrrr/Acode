<?php

declare(strict_types=1);

namespace App\Modules\Adapter\Services;

/**
 * SqlmapAdapter — normalkan keluaran sqlmap (SQLi). Tool Python (dijalankan via
 * python3). Menguji parameter GET pada URL. WAJIB lewat gerbang Policy (agresif,
 * biasanya diblokir bila aturan program melarang injeksi agresif).
 */
final class SqlmapAdapter extends AbstractCliAdapter
{
    public function code(): string
    {
        return 'sqlmap';
    }

    public function run(string $binPath, string $target): array
    {
        $csv = sys_get_temp_dir() . '/casa_sqlmap_' . bin2hex(random_bytes(4)) . '.csv';
        // $binPath menunjuk sqlmap.py; jalankan dengan python3. Level/risk rendah
        // agar hemat; --batch non-interaktif; --results-file mencatat temuan.
        // Depth → kedalaman uji: Deep pakai --level 2 (lebih banyak titik injeksi),
        // selain itu --level 1. TETAP --risk 1 & --technique=BEU (hindari S=stacked
        // yang bisa merusak); tanpa dump/ubah data. Policy-gated di hulu.
        $level = \App\Libraries\ScanProfile::depth() === 'deep' ? 2 : 1;
        $cmd = 'python3 ' . escapeshellarg($binPath) . ' -u ' . escapeshellarg($target)
            . ' --batch --level ' . $level . ' --risk 1 --technique=BEU --smart --flush-session'
            . ' --disable-coloring -v 0 --output-dir=' . escapeshellarg(sys_get_temp_dir() . '/sqlmap_out')
            . ' --results-file=' . escapeshellarg($csv) . ' 2>/dev/null';
        [$out] = $this->exec($cmd);

        $findings = [];
        if (is_file($csv)) {
            $lines = array_filter(array_map('trim', explode("\n", (string) file_get_contents($csv))));
            array_shift($lines); // header
            foreach ($lines as $line) {
                $col = str_getcsv($line);
                if (count($col) < 3 || ($col[2] ?? '') === '') {
                    continue;
                }
                [$url, $place, $param] = [$col[0] ?? $target, $col[1] ?? 'GET', $col[2]];
                $tech = $col[3] ?? '';
                $findings[] = [
                    'severity'    => 'high',
                    'title'       => "SQL Injection on parameter '{$param}' ({$place})",
                    'category'    => 'Injection / SQLi',
                    'asset'       => $url,
                    'tool'        => 'sqlmap',
                    'cwe'         => 'CWE-89',
                    'cvss'        => '8.6',
                    'description' => "Parameter {$param} on {$place} is vulnerable to SQL injection. Technique: {$tech}.",
                    'evidence'    => mb_substr($line, 0, 800),
                ];
            }
            @unlink($csv);
        }

        return ['findings' => $findings, 'assets' => [], 'raw' => mb_substr($out, 0, 2000)];
    }
}
