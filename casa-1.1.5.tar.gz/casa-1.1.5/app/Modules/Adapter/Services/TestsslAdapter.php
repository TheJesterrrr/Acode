<?php

declare(strict_types=1);

namespace App\Modules\Adapter\Services;

/** TestsslAdapter — audit TLS/sertifikat/cipher (SSL Analysis §12 #11) → findings. */
final class TestsslAdapter extends AbstractCliAdapter
{
    private const SEV = ['CRITICAL' => 'crit', 'HIGH' => 'high', 'MEDIUM' => 'med', 'LOW' => 'low', 'WARN' => 'low'];

    public function code(): string
    {
        return 'testssl';
    }

    public function run(string $binPath, string $target): array
    {
        $host = $this->host($target);
        if (! str_contains($host, ':')) {
            $host .= ':443';
        }
        $json = '/tmp/casa_testssl_' . bin2hex(random_bytes(4)) . '.json';

        $cmd = escapeshellarg($binPath) . ' --quiet --warnings off --color 0 --fast --sneaky'
            . ' --jsonfile ' . escapeshellarg($json) . ' ' . escapeshellarg($host) . ' >/dev/null 2>&1';
        $this->exec($cmd);

        $findings = [];
        $raw      = '';
        if (is_file($json)) {
            $raw  = (string) file_get_contents($json);
            $data = json_decode($raw, true);
            foreach (is_array($data) ? $data : [] as $row) {
                $sevIn = strtoupper((string) ($row['severity'] ?? ''));
                $id    = (string) ($row['id'] ?? '');
                if (! isset(self::SEV[$sevIn])) {
                    continue; // lewati OK/INFO/DEBUG
                }
                // Lewati entri meta/diagnostik testssl (bukan temuan nyata).
                if (preg_match('/^(engine|scan|service|pre_|cipherlist|clientsimulation|banner|hasError|optimal_proto|protocol_support|grease|ipv|rating|overall)/i', $id)) {
                    continue;
                }
                $findings[] = [
                    'severity'    => self::SEV[$sevIn],
                    'title'       => 'TLS: ' . (string) ($row['id'] ?? 'issue'),
                    'category'    => 'SSL/TLS',
                    'asset'       => $host,
                    'tool'        => 'testssl',
                    'cwe'         => 'CWE-326',
                    'cvss'        => null,
                    'description' => (string) ($row['finding'] ?? ''),
                    'evidence'    => 'testssl.sh id=' . (string) ($row['id'] ?? '') . ' severity=' . $sevIn,
                ];
            }
            @unlink($json);
        }

        return ['findings' => $findings, 'assets' => [], 'raw' => mb_substr($raw, 0, 2000)];
    }
}
