<?php

declare(strict_types=1);

namespace App\Modules\Adapter\Services;

/** NaabuAdapter — port scan; port terbuka menjadi asset service (Attack Surface). */
final class NaabuAdapter extends AbstractCliAdapter
{
    public function code(): string
    {
        return 'naabu';
    }

    public function run(string $binPath, string $target): array
    {
        $host = $this->host($target);
        // Port-range mengikuti depth (Light=top 100, Standard=top 1000, Deep=-p -).
        // Rate paket/detik mengikuti depth (20/60/150) via ScanProfile.
        $cmd  = escapeshellarg($binPath) . ' -host ' . escapeshellarg($host)
            . ' -json -silent -nc ' . \App\Libraries\ScanProfile::naabuPorts()
            . ' -c 25 -rate ' . \App\Libraries\ScanProfile::rate() . ' -disable-update-check 2>/dev/null';
        [$out] = $this->exec($cmd);

        $assets = [];
        foreach (preg_split('/\r?\n/', trim($out)) as $line) {
            if ($line === '' || $line[0] !== '{') {
                continue;
            }
            $j = json_decode($line, true);
            if (! is_array($j) || ! isset($j['port'])) {
                continue;
            }
            $h = (string) ($j['host'] ?? $j['ip'] ?? $host);
            $assets[] = ['type' => 'service', 'value' => $h . ':' . (int) $j['port'], 'source' => 'naabu'];
        }

        return ['findings' => [], 'assets' => $assets, 'raw' => mb_substr($out, 0, 2000)];
    }
}
