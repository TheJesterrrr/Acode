<?php

declare(strict_types=1);

namespace App\Modules\Adapter\Services;

/** WaybackurlsAdapter — URL historis dari Wayback Machine (recon bug bounty) → asset url. */
final class WaybackurlsAdapter extends AbstractCliAdapter
{
    private const CAP = 300;

    public function code(): string
    {
        return 'waybackurls';
    }

    public function run(string $binPath, string $target): array
    {
        $domain = $this->host($target);
        // waybackurls membaca domain dari STDIN.
        [$out] = $this->exec(escapeshellarg($binPath) . ' 2>/dev/null', $domain . "\n");

        $assets = [];
        $seen   = [];
        foreach (preg_split('/\r?\n/', trim($out)) as $line) {
            $url = trim($line);
            if ($url === '' || ! preg_match('#^https?://#i', $url)) {
                continue;
            }
            $key = strtok($url, '?');
            if (! isset($seen[$key])) {
                $seen[$key] = true;
                $assets[]   = ['type' => 'url', 'value' => mb_substr($url, 0, 500), 'source' => 'waybackurls'];
                if (count($assets) >= self::CAP) {
                    break;
                }
            }
        }

        return ['findings' => [], 'assets' => $assets, 'raw' => mb_substr($out, 0, 2000)];
    }
}
