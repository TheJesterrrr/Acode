<?php

declare(strict_types=1);

namespace App\Modules\Adapter\Services;

/**
 * NiktoAdapter — pemindai web server klasik (Vulnerability Scan §12 #23, pelengkap
 * Nuclei). Nikto = skrip Perl (git-clone) → dijalankan `perl nikto.pl`. Di luar
 * workflow default (lambat); tersedia untuk pemindaian terarah.
 */
final class NiktoAdapter extends AbstractCliAdapter
{
    public function code(): string
    {
        return 'nikto';
    }

    public function run(string $binPath, string $target): array
    {
        $url = trim($target);
        if (! preg_match('#^https?://#i', $url)) {
            $url = 'http://' . $url;
        }
        $script = is_file($binPath) ? $binPath : ((string) (env('tools.dir') ?: '/opt/casa-tools') . '/nikto/program/nikto.pl');
        if (! is_file($script)) {
            return ['findings' => [], 'assets' => [], 'raw' => 'nikto not found'];
        }
        $json = '/tmp/casa_nikto_' . bin2hex(random_bytes(4)) . '.json';

        // -maxtime membatasi durasi; -Tuning membatasi kelas uji agar tak meledak.
        // Depth → anggaran waktu: Light 120s, Standard 200s, Deep 280s. Tetap di
        // bawah cap luar TIMEOUT=300 (timeout -k 15 300) agar JSON tak terpotong.
        $depth = \App\Libraries\ScanProfile::depth();
        $maxt  = $depth === 'deep' ? 280 : ($depth === 'light' ? 120 : 200);
        $cmd = 'perl ' . escapeshellarg($script) . ' -h ' . escapeshellarg($url)
            . ' -Format json -output ' . escapeshellarg($json)
            . ' -maxtime ' . $maxt . ' -timeout 8 -nointeractive -ask no 2>/dev/null';
        $this->exec($cmd);

        $findings = [];
        $raw      = '';
        if (is_file($json)) {
            $raw  = (string) file_get_contents($json);
            $data = json_decode($raw, true);
            // Nikto bisa mengeluarkan objek atau array host; cari "vulnerabilities".
            $vulns = [];
            if (isset($data['vulnerabilities'])) {
                $vulns = $data['vulnerabilities'];
            } elseif (is_array($data)) {
                foreach ($data as $h) {
                    if (isset($h['vulnerabilities'])) {
                        $vulns = array_merge($vulns, (array) $h['vulnerabilities']);
                    }
                }
            }
            foreach ((array) $vulns as $v) {
                $msg = trim((string) ($v['msg'] ?? ''));
                if ($msg === '') {
                    continue;
                }
                $findings[] = [
                    'severity'    => 'low',
                    'title'       => 'Nikto: ' . mb_substr($msg, 0, 120),
                    'category'    => 'Web Server',
                    'asset'       => $url . (string) ($v['url'] ?? ''),
                    'tool'        => 'nikto',
                    'cwe'         => null,
                    'cvss'        => null,
                    'description' => $msg,
                    'evidence'    => trim((string) ($v['method'] ?? 'GET') . ' ' . ($v['url'] ?? '') . ' · ' . ($v['references'] ?? '')),
                ];
            }
            @unlink($json);
        }

        return ['findings' => $findings, 'assets' => [], 'raw' => mb_substr($raw, 0, 2000)];
    }
}
