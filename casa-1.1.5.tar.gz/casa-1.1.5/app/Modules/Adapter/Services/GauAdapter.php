<?php

declare(strict_types=1);

namespace App\Modules\Adapter\Services;

/** GauAdapter — kumpulkan URL arsip (Web/URL Enumeration §12 #8) → asset url. */
final class GauAdapter extends AbstractCliAdapter
{
    private const CAP = 200;

    public function code(): string
    {
        return 'gau';
    }

    public function run(string $binPath, string $target): array
    {
        $domain = $this->host($target);
        // Batasi ke provider cepat (wayback) + threads agar cocok satu task lab;
        // provider lambat (otx/urlscan/commoncrawl) dilewati agar tak menyentuh timeout.
        // Depth: Standard/Deep sertakan subdomain (--subs); Deep saring aset statis.
        $depth = \App\Libraries\ScanProfile::depth();
        $subs  = $depth === 'light' ? '' : ' --subs';
        $bl    = $depth === 'deep' ? ' --blacklist png,jpg,gif,css,woff' : '';
        $cmd = escapeshellarg($binPath) . ' --providers wayback --threads 5 --timeout 6' . $subs . $bl . ' ' . escapeshellarg($domain) . ' 2>/dev/null';
        [$out] = $this->exec($cmd);

        $assets = [];
        $seen   = [];
        foreach (preg_split('/\r?\n/', trim($out)) as $line) {
            $url = trim($line);
            if ($url === '' || ! preg_match('#^https?://#i', $url)) {
                continue;
            }
            // Normalkan (buang query untuk dedup ringan) namun simpan URL asli.
            $key = strtok($url, '?');
            if (! isset($seen[$key])) {
                $seen[$key] = true;
                $assets[]   = ['type' => 'url', 'value' => mb_substr($url, 0, 500), 'source' => 'gau'];
                if (count($assets) >= self::CAP) {
                    break;
                }
            }
        }

        return ['findings' => [], 'assets' => $assets, 'raw' => mb_substr($out, 0, 2000)];
    }
}
