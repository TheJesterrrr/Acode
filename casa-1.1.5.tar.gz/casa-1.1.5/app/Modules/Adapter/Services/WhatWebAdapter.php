<?php

declare(strict_types=1);

namespace App\Modules\Adapter\Services;

/**
 * WhatWebAdapter — deteksi teknologi web (Technology Detection §12 #7).
 * WhatWeb adalah skrip Ruby (git-clone) → dijalankan via `ruby <script>`.
 * Hasil plugin menjadi satu temuan info + aset teknologi.
 */
final class WhatWebAdapter extends AbstractCliAdapter
{
    public function code(): string
    {
        return 'whatweb';
    }

    public function run(string $binPath, string $target): array
    {
        $url = trim($target);
        if (! preg_match('#^https?://#i', $url)) {
            $url = 'http://' . $url;
        }
        // Resolusi skrip: pakai binPath bila file, jika tidak pakai lokasi git-clone.
        $script = is_file($binPath) ? $binPath : ((string) (env('tools.dir') ?: '/opt/casa-tools') . '/whatweb/whatweb');
        if (! is_file($script)) {
            return ['findings' => [], 'assets' => [], 'raw' => 'whatweb not found'];
        }
        $json = '/tmp/casa_whatweb_' . bin2hex(random_bytes(4)) . '.json';

        // Depth → level agresi: Light = -a 1 (cepat), Standard/Deep = -a 3 (lengkap).
        $agg = \App\Libraries\ScanProfile::depth() === 'light' ? 1 : 3;
        $cmd = 'ruby ' . escapeshellarg($script) . ' --quiet --no-errors -a ' . $agg . ' --max-threads 1 --open-timeout 8 --read-timeout 12'
            . ' --log-json=' . escapeshellarg($json) . ' ' . escapeshellarg($url) . ' >/dev/null 2>&1';
        $this->exec($cmd);

        $assets = [];
        $techs  = [];
        $raw    = '';
        if (is_file($json)) {
            $raw = (string) file_get_contents($json);
            foreach (preg_split('/\r?\n/', trim($raw)) as $line) {
                if ($line === '' || $line[0] !== '{') {
                    continue;
                }
                $j = json_decode($line, true);
                foreach ((array) ($j['plugins'] ?? []) as $name => $meta) {
                    if (! isset($techs[$name])) {
                        $ver          = '';
                        if (is_array($meta) && ! empty($meta['version'])) {
                            $ver = ' ' . (is_array($meta['version']) ? implode('/', $meta['version']) : $meta['version']);
                        }
                        $techs[$name] = $name . $ver;
                        $assets[]     = ['type' => 'tech', 'value' => trim($name . $ver), 'source' => 'whatweb'];
                    }
                }
            }
            @unlink($json);
        }

        $findings = [];
        if ($techs !== []) {
            $findings[] = [
                'severity'    => 'info',
                'title'       => 'Technology detected (' . count($techs) . ')',
                'category'    => 'Technology Detection',
                'asset'       => $url,
                'tool'        => 'whatweb',
                'cwe'         => null,
                'cvss'        => null,
                'description' => 'Detected technology stack: ' . implode(', ', array_slice(array_values($techs), 0, 25)) . '.',
                'evidence'    => mb_substr(implode(', ', array_values($techs)), 0, 1200),
            ];
        }

        return ['findings' => $findings, 'assets' => $assets, 'raw' => mb_substr($raw, 0, 2000)];
    }
}
