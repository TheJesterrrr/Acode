<?php

declare(strict_types=1);

namespace App\Modules\Adapter\Services;

/**
 * HttpxAdapter — normalkan keluaran httpx (Tech/HTTP discovery). Menghasilkan
 * satu asset per host hidup dan satu temuan INFO berisi teknologi/server.
 */
final class HttpxAdapter extends AbstractCliAdapter
{
    public function code(): string
    {
        return 'httpx';
    }

    public function run(string $binPath, string $target): array
    {
        // Deep menambah -follow-redirects (ikuti pengalihan untuk permukaan lebih lengkap).
        $fr  = \App\Libraries\ScanProfile::depth() === 'deep' ? ' -follow-redirects' : '';
        $cmd = escapeshellarg($binPath) . ' -json -silent -nc -status-code -title -tech-detect -web-server -timeout 10' . $fr
            . \App\Libraries\ScanProfile::headerArgs();
        // Kirim target UTUH (dengan skema & port) — httpx menerima URL; jangan
        // strip port agar target seperti http://host:3000 tetap benar.
        [$out] = $this->exec($cmd, trim($target) . "\n");

        $findings = [];
        $assets   = [];
        foreach (preg_split('/\r?\n/', trim($out)) as $line) {
            if ($line === '') {
                continue;
            }
            $j = json_decode($line, true);
            if (! is_array($j)) {
                continue;
            }
            $url    = (string) ($j['url'] ?? $j['input'] ?? $target);
            $status = (string) ($j['status_code'] ?? '?');
            $title  = (string) ($j['title'] ?? '');
            $tech   = implode(', ', array_map('strval', (array) ($j['tech'] ?? [])));
            $server = (string) ($j['webserver'] ?? '');

            $assets[]   = ['type' => 'host', 'value' => $url, 'source' => 'httpx'];
            $findings[] = [
                'severity'    => 'info',
                'title'       => 'Live HTTP service — ' . $status . ($title !== '' ? ' · ' . $title : ''),
                'category'    => 'Tech / HTTP',
                'asset'       => $url,
                'tool'        => 'httpx',
                'cwe'         => null,
                'cvss'        => null,
                'description' => 'Server: ' . ($server ?: 'n/a') . "\nTech: " . ($tech ?: 'n/a') . "\nStatus: " . $status,
                'evidence'    => $line,
            ];
        }

        return ['findings' => $findings, 'assets' => $assets, 'raw' => $out];
    }
}
