<?php

declare(strict_types=1);

namespace App\Modules\Adapter\Services;

/** NucleiAdapter — normalkan keluaran Nuclei (Vuln Scan) menjadi temuan. */
final class NucleiAdapter extends AbstractCliAdapter
{
    private const SEV = ['critical' => 'crit', 'high' => 'high', 'medium' => 'med', 'low' => 'low', 'info' => 'info', 'unknown' => 'info'];

    public function code(): string
    {
        return 'nuclei';
    }

    public function run(string $binPath, string $target): array
    {
        // Arahkan ke direktori template lokal; bila kosong, Nuclei jadi no-op
        // cepat TANPA mengunduh repo template (ratusan MB) secara diam-diam.
        // Pembaruan template dikelola Tool Manager (feed), bukan saat scan.
        $tpl = (string) (env('tools.dir') ?: '/opt/casa-tools') . '/nuclei-templates';
        @mkdir($tpl, 0755, true);

        // Scope ke subdirektori HTTP yang paling relevan & andal untuk aplikasi
        // web (misconfig, exposures, technologies, default-logins). Memindai
        // seluruh ~13k template terlalu berat untuk satu task lab; subset ini
        // cepat, mengena, dan mencakup temuan bermakna. Kecualikan dos/fuzz.
        // Breadth template & severity mengikuti depth: Light = sempit (high/crit),
        // Deep = tambah vulnerabilities/cves + severity sampai low. Makin dalam,
        // makin banyak diperiksa → makin lama.
        $depth = \App\Libraries\ScanProfile::depth();
        $dirs  = ['http/misconfiguration', 'http/default-logins', 'http/exposures', 'http/technologies'];
        if ($depth === 'light') {
            $dirs = ['http/misconfiguration', 'http/default-logins'];
        } elseif ($depth === 'deep') {
            $dirs = array_merge($dirs, ['http/vulnerabilities', 'http/cves', 'network']);
        }
        $paths = '';
        foreach ($dirs as $sub) {
            if (is_dir($tpl . '/' . $sub)) {
                $paths .= ' -t ' . escapeshellarg($tpl . '/' . $sub);
            }
        }
        if ($paths === '') { // template belum ada → scan seluruh dir
            $paths = ' -t ' . escapeshellarg($tpl);
        }
        $paths .= ' -severity ' . escapeshellarg(\App\Libraries\ScanProfile::nucleiSeverity());

        // Rate/konkurensi/timeout mengikuti ScanProfile (hormati batas laju program).
        $rl = \App\Libraries\ScanProfile::rate();
        $c  = \App\Libraries\ScanProfile::concurrency();
        $to = \App\Libraries\ScanProfile::timeout();
        $cmd = escapeshellarg($binPath) . ' -u ' . escapeshellarg($target)
            . $paths
            . " -jsonl -silent -nc -timeout {$to} -c {$c} -rl {$rl}"
            . ' -etags dos,fuzz,intrusive'
            . ' -disable-update-check -no-interactsh'
            . \App\Libraries\ScanProfile::headerArgs()
            . ' 2>/dev/null';
        [$out] = $this->exec($cmd);

        $findings = [];
        foreach (preg_split('/\r?\n/', trim($out)) as $line) {
            if ($line === '' || $line[0] !== '{') {
                continue;
            }
            $j = json_decode($line, true);
            if (! is_array($j)) {
                continue;
            }
            $info  = $j['info'] ?? [];
            $sevIn = strtolower((string) ($info['severity'] ?? 'info'));
            $cls   = $info['classification'] ?? [];
            $cwe   = null;
            if (! empty($cls['cwe-id'])) {
                $cwe = strtoupper((string) (is_array($cls['cwe-id']) ? ($cls['cwe-id'][0] ?? '') : $cls['cwe-id']));
            }
            $tags = (array) ($info['tags'] ?? []);

            $findings[] = [
                'severity'    => self::SEV[$sevIn] ?? 'info',
                'title'       => (string) ($info['name'] ?? ($j['template-id'] ?? 'Nuclei finding')),
                'category'    => $tags[0] ?? 'Nuclei',
                'asset'       => (string) ($j['matched-at'] ?? $j['host'] ?? $target),
                'tool'        => 'nuclei',
                'cwe'         => $cwe,
                'cvss'        => isset($cls['cvss-score']) ? (string) $cls['cvss-score'] : null,
                'description' => (string) ($info['description'] ?? ('Template: ' . ($j['template-id'] ?? '?'))),
                'evidence'    => mb_substr($line, 0, 1500),
            ];
        }

        return ['findings' => $findings, 'assets' => [], 'raw' => $out];
    }
}
