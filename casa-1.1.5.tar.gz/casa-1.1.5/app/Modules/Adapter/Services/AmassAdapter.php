<?php

declare(strict_types=1);

namespace App\Modules\Adapter\Services;

/** AmassAdapter — enumerasi subdomain pasif (Asset Discovery §12 #3) → asset host. */
final class AmassAdapter extends AbstractCliAdapter
{
    public function code(): string
    {
        return 'amass';
    }

    public function run(string $binPath, string $target): array
    {
        $domain = $this->host($target);
        // Pasif saja (tak menyerang), batasi waktu agar cocok untuk satu task lab.
        $cmd = escapeshellarg($binPath) . ' enum -passive -nocolor -timeout 3 -d ' . escapeshellarg($domain) . ' 2>/dev/null';
        [$out] = $this->exec($cmd);

        $assets = [];
        $seen   = [];
        foreach (preg_split('/\r?\n/', trim($out)) as $line) {
            $line = trim($line);
            // Ambil token yang tampak seperti subdomain dari domain target.
            if ($line !== '' && preg_match('/([a-z0-9_-]+\.)+' . preg_quote($domain, '/') . '$/i', $line, $m)) {
                $host = strtolower($m[0]);
                if (! isset($seen[$host])) {
                    $seen[$host]  = true;
                    $assets[]     = ['type' => 'host', 'value' => $host, 'source' => 'amass'];
                }
            }
        }

        return ['findings' => [], 'assets' => $assets, 'raw' => mb_substr($out, 0, 2000)];
    }
}
