<?php

declare(strict_types=1);

namespace App\Modules\Adapter\Services;

/**
 * WpscanAdapter — audit WordPress (versi, plugin/tema rentan, temuan menarik).
 * Tanpa API token wpscan tetap enumerasi versi/plugin & interesting_findings;
 * data kerentanan lengkap butuh token (opsional). Output --format json.
 */
final class WpscanAdapter extends AbstractCliAdapter
{
    private const CAP = 80;

    public function code(): string
    {
        return 'wpscan';
    }

    public function run(string $binPath, string $target): array
    {
        $url = $this->url($target);
        $cmd = escapeshellarg($binPath) . ' --url ' . escapeshellarg($url)
            . ' --format json --no-banner --random-user-agent --disable-tls-checks'
            . ' --plugins-version-detection passive 2>/dev/null';
        [$out] = $this->exec($cmd);

        $j = json_decode(trim($out), true);
        if (! is_array($j)) {
            return ['findings' => [], 'assets' => [], 'raw' => mb_substr($out, 0, 2000)];
        }

        $findings = [];
        $add = function (string $sev, string $title, string $desc, array $refs = []) use (&$findings): void {
            if (count($findings) >= self::CAP) {
                return;
            }
            $ev = '';
            foreach (['cve' => 'CVE', 'url' => 'Ref'] as $k => $lbl) {
                foreach ((array) ($refs[$k] ?? []) as $r) {
                    $ev .= "{$lbl}: {$r}\n";
                }
            }
            $findings[] = [
                'severity'    => $sev,
                'title'       => mb_substr($title, 0, 200),
                'category'    => 'WordPress',
                'asset'       => '',
                'tool'        => 'wpscan',
                'cwe'         => null,
                'cvss'        => null,
                'description' => $desc,
                'evidence'    => mb_substr(trim($ev), 0, 1000),
            ];
        };

        // Versi core + kerentanannya.
        $ver = (string) ($j['version']['number'] ?? '');
        if ($ver !== '') {
            $add('info', "WordPress core v{$ver} detected", 'Core version exposed — make sure it is always kept up to date.');
        }
        foreach ((array) ($j['version']['vulnerabilities'] ?? []) as $v) {
            $add('high', 'WP core: ' . (string) ($v['title'] ?? 'vulnerability'), 'Vulnerability in the WordPress core.', (array) ($v['references'] ?? []));
        }
        // Plugin rentan.
        foreach ((array) ($j['plugins'] ?? []) as $name => $pl) {
            foreach ((array) ($pl['vulnerabilities'] ?? []) as $v) {
                $add('high', "Plugin '{$name}': " . (string) ($v['title'] ?? 'vulnerability'), "Plugin {$name} is vulnerable.", (array) ($v['references'] ?? []));
            }
        }
        // Tema utama rentan.
        foreach ((array) ($j['main_theme']['vulnerabilities'] ?? []) as $v) {
            $add('high', 'Theme: ' . (string) ($v['title'] ?? 'vulnerability'), 'The active theme is vulnerable.', (array) ($v['references'] ?? []));
        }
        // Temuan menarik (config backup, user enum, dll).
        foreach ((array) ($j['interesting_findings'] ?? []) as $f) {
            $to = (string) ($f['to_s'] ?? ($f['type'] ?? 'finding'));
            $add('low', 'WP: ' . $to, 'Interesting finding from WordPress enumeration.', ['url' => (array) ($f['url'] ?? [])]);
        }

        return ['findings' => $findings, 'assets' => [], 'raw' => mb_substr($out, 0, 2000)];
    }

    private function url(string $target): string
    {
        $t = trim($target);

        return preg_match('#^https?://#i', $t) ? $t : 'https://' . $this->host($t);
    }
}
