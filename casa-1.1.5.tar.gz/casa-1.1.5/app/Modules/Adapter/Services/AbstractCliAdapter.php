<?php

declare(strict_types=1);

namespace App\Modules\Adapter\Services;

/** Dasar adapter berbasis CLI: menjalankan proses dengan timeout & aman. */
abstract class AbstractCliAdapter implements ToolAdapter
{
    protected const TIMEOUT = 300;

    /** Batas ukuran stdout yang dibaca ke memori (tool verbose di target besar —
     *  katana, ffuf, feroxbuster, hakrawler, waybackurls — bisa menghasilkan
     *  ratusan MB). Tiap adapter cuma perlu secuplik untuk diringkas/di-parse. */
    protected const MAX_OUTPUT_BYTES = 20 * 1024 * 1024;

    /**
     * Jalankan perintah; kembalikan [stdout, exitCode]. `$stdin` opsional.
     *
     * stdout ditulis proses anak LANGSUNG ke file sementara (bukan pipe yang
     * dibaca utuh ke memori via stream_get_contents tanpa batas) lalu dibaca
     * kembali dengan BATAS UKURAN. Alasan: stream_get_contents() lama memuat
     * SELURUH output sekaligus — di situs besar ini melampaui memory_limit dan
     * memicu fatal "Allowed memory size exhausted". Fatal semacam ini TIDAK
     * tertangkap try/catch Throwable (lihat EngineService::runTask()), jadi
     * proses worker mati di tengah task dan task tertinggal macet di status
     * 'running' selamanya (lih. TaskModel::reapStale() untuk pemulihannya).
     * Menulis ke file menghindari lonjakan memori itu dari akarnya.
     *
     * @return array{0:string,1:int}
     */
    protected function exec(string $cmd, string $stdin = ''): array
    {
        $tmp  = tempnam(sys_get_temp_dir(), 'casa_out_');
        $desc = [0 => ['pipe', 'r'], 1 => ['file', $tmp, 'w'], 2 => ['pipe', 'w']];
        $env  = ['HOME' => '/tmp', 'PATH' => '/usr/local/bin:/usr/bin:/bin'];
        // -k 15: bila tool abai SIGTERM setelah TIMEOUT, kirim SIGKILL 15s kemudian.
        $proc = proc_open('timeout -k 15 ' . self::TIMEOUT . ' ' . $cmd, $desc, $pipes, '/tmp', $env);
        if (! is_resource($proc)) {
            @unlink($tmp);

            return ['', 1];
        }
        if ($stdin !== '') {
            fwrite($pipes[0], $stdin);
        }
        fclose($pipes[0]);
        fclose($pipes[2]);
        $code = proc_close($proc);

        $out = '';
        $fh  = @fopen($tmp, 'rb');
        if ($fh !== false) {
            $out = (string) fread($fh, self::MAX_OUTPUT_BYTES);
            fclose($fh);
        }
        @unlink($tmp);

        return [$out, $code];
    }

    /** Ambil host dari target (buang skema/port/path). */
    protected function host(string $target): string
    {
        $h = preg_replace('#^[a-z]+://#i', '', trim($target));

        return preg_replace('#[/:].*$#', '', (string) $h);
    }
}
