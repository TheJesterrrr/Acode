<?php

declare(strict_types=1);

namespace App\Modules\Adapter\Services;

/** HakrawlerAdapter — crawler cepat endpoint/aset dari sebuah URL → asset url. */
final class HakrawlerAdapter extends AbstractCliAdapter
{
    private const CAP = 300;

    public function code(): string
    {
        return 'hakrawler';
    }

    public function run(string $binPath, string $target): array
    {
        $url = $this->url($target);
        // hakrawler membaca URL seed dari STDIN; -d kedalaman, -u unik, -subs sertakan subdomain.
        // Depth → kedalaman crawl: Light d=1, Standard d=2, Deep d=3.
        $depth = \App\Libraries\ScanProfile::depth();
        $dep   = $depth === 'deep' ? 3 : ($depth === 'light' ? 1 : 2);
        $cmd = escapeshellarg($binPath) . ' -d ' . $dep . ' -u -subs -t 8'
            . \App\Libraries\ScanProfile::headerJoinedArg('-h', ';;')
            . ' 2>/dev/null';
        [$out] = $this->exec($cmd, $url . "\n");

        $assets = [];
        $seen   = [];
        foreach (preg_split('/\r?\n/', trim($out)) as $line) {
            $u = trim($line);
            if ($u === '' || ! preg_match('#^https?://#i', $u)) {
                continue;
            }
            $key = strtok($u, '?');
            if (! isset($seen[$key])) {
                $seen[$key] = true;
                $assets[]   = ['type' => 'url', 'value' => mb_substr($u, 0, 500), 'source' => 'hakrawler'];
                if (count($assets) >= self::CAP) {
                    break;
                }
            }
        }

        return ['findings' => [], 'assets' => $assets, 'raw' => mb_substr($out, 0, 2000)];
    }

    /** Pastikan target berupa URL berskema (hakrawler butuh URL seed). */
    private function url(string $target): string
    {
        $t = trim($target);

        return preg_match('#^https?://#i', $t) ? $t : 'https://' . $this->host($t);
    }
}
