<?php

declare(strict_types=1);

namespace App\Modules\Adapter\Services;

/**
 * ArjunAdapter — temukan parameter HTTP tersembunyi (API Security §12 #16).
 * Arjun dipasang via pipx bersama di {toolsDir}/pybin. Parameter tersembunyi =
 * permukaan serang tambahan (input tak terdokumentasi) → temuan info.
 */
final class ArjunAdapter extends AbstractCliAdapter
{
    public function code(): string
    {
        return 'arjun';
    }

    public function run(string $binPath, string $target): array
    {
        $url = trim($target);
        if (! preg_match('#^https?://#i', $url)) {
            $url = 'http://' . $url;
        }
        $bin = is_file($binPath) ? $binPath : ((string) (env('tools.dir') ?: '/opt/casa-tools') . '/pybin/arjun');
        if (! is_file($bin)) {
            return ['findings' => [], 'assets' => [], 'raw' => 'arjun not found'];
        }
        $json = '/tmp/casa_arjun_' . bin2hex(random_bytes(4)) . '.json';

        // Cepat & andal untuk anggaran waktu lab: banyak thread + timeout/permintaan
        // pendek + chunk kecil. (Daftar param default besar; ini menahannya wajar.)
        // Depth → metode HTTP yang diuji: Light = GET; Standard/Deep = GET,POST.
        $methods = \App\Libraries\ScanProfile::depth() === 'light' ? 'GET' : 'GET,POST';
        $cmd = escapeshellarg($bin) . ' -u ' . escapeshellarg($url) . ' -oJ ' . escapeshellarg($json)
            . ' -m ' . $methods . ' -t 25 -T 4 -c 250 --stable'
            . \App\Libraries\ScanProfile::headerJoinedArg('--headers', "\n")
            . ' 2>/dev/null';
        $this->exec($cmd);

        $params = [];
        $raw    = '';
        if (is_file($json)) {
            $raw = (string) file_get_contents($json);
            $this->collectParams(json_decode($raw, true), $params);
            @unlink($json);
        }
        $params = array_values(array_unique(array_filter($params)));

        $findings = [];
        if ($params !== []) {
            $findings[] = [
                'severity'    => 'info',
                'title'       => 'Hidden parameter(s) found (' . count($params) . ')',
                'category'    => 'API Security',
                'asset'       => $url,
                'tool'        => 'arjun',
                'cwe'         => 'CWE-233',
                'cvss'        => null,
                'description' => 'Arjun found undocumented parameters on ' . $url . ': ' . implode(', ', array_slice($params, 0, 30)) . '. Test further for IDOR/injection.',
                'evidence'    => mb_substr(implode(', ', $params), 0, 1200),
            ];
        }

        return ['findings' => $findings, 'assets' => [], 'raw' => mb_substr($raw, 0, 2000)];
    }

    /** Kumpulkan nama parameter dari struktur JSON arjun (bentuknya bervariasi). */
    private function collectParams(mixed $node, array &$out): void
    {
        if (is_array($node)) {
            foreach ($node as $k => $v) {
                if ($k === 'params' && is_array($v)) {
                    foreach ($v as $p) {
                        if (is_string($p)) {
                            $out[] = $p;
                        }
                    }
                } elseif (is_string($v) && ! is_int($k)) {
                    // abaikan meta
                } else {
                    $this->collectParams($v, $out);
                }
                // daftar string langsung (mis. { url: [p1,p2] })
                if (is_int($k) && is_string($v)) {
                    $out[] = $v;
                }
            }
        }
    }
}
