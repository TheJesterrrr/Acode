<?php

declare(strict_types=1);

namespace App\Modules\Adapter\Services;

/**
 * TrivyAdapter — pindai kerentanan image container / repo (Container §12 #26,
 * juga SBOM/dependency). Target `image` = ref image (mis. alpine:latest); target
 * `repo` = URL git. Deteksi mode dari bentuk target.
 */
final class TrivyAdapter extends AbstractCliAdapter
{
    protected const TIMEOUT = 420; // DB + scan bisa lama
    private const CAP = 120;
    private const SEV = ['CRITICAL' => 'crit', 'HIGH' => 'high', 'MEDIUM' => 'med', 'LOW' => 'low', 'UNKNOWN' => 'info'];

    public function code(): string
    {
        return 'trivy';
    }

    public function run(string $binPath, string $target): array
    {
        $t   = trim($target);
        $bin = is_file($binPath) ? $binPath : ((string) (env('tools.dir') ?: '/opt/casa-tools') . '/trivy');
        if (! is_file($bin)) {
            return ['findings' => [], 'assets' => [], 'raw' => 'trivy not found'];
        }
        // Mode: URL git → repo; selain itu → image.
        $mode = preg_match('#^(https?://|git@).*|.*\.git$#i', $t) ? 'repo' : 'image';
        $json = '/tmp/casa_trivy_' . bin2hex(random_bytes(4)) . '.json';

        $cmd = escapeshellarg($bin) . ' ' . $mode . ' ' . escapeshellarg($t)
            . ' --format json --quiet --scanners vuln --timeout 5m'
            . ' --severity CRITICAL,HIGH,MEDIUM --output ' . escapeshellarg($json) . ' 2>/dev/null';
        $this->exec($cmd);

        $findings = [];
        $raw      = '';
        if (is_file($json)) {
            $raw  = (string) file_get_contents($json);
            $data = json_decode($raw, true);
            foreach ((array) ($data['Results'] ?? []) as $res) {
                $tgt = (string) ($res['Target'] ?? $t);
                foreach ((array) ($res['Vulnerabilities'] ?? []) as $v) {
                    $sevIn = strtoupper((string) ($v['Severity'] ?? 'UNKNOWN'));
                    $cwe   = null;
                    if (! empty($v['CweIDs'][0])) {
                        $cwe = (string) $v['CweIDs'][0];
                    }
                    $cvss = null;
                    if (! empty($v['CVSS'])) {
                        foreach ((array) $v['CVSS'] as $src) {
                            if (isset($src['V3Score'])) {
                                $cvss = (string) $src['V3Score'];
                                break;
                            }
                        }
                    }
                    $findings[] = [
                        'severity'    => self::SEV[$sevIn] ?? 'info',
                        'title'       => (string) ($v['VulnerabilityID'] ?? 'VULN') . ' — ' . (string) ($v['PkgName'] ?? ''),
                        'category'    => $mode === 'repo' ? 'Dependency (SCA)' : 'Container',
                        'asset'       => $tgt . ' · ' . (string) ($v['PkgName'] ?? '') . '@' . (string) ($v['InstalledVersion'] ?? ''),
                        'tool'        => 'trivy',
                        'cwe'         => $cwe,
                        'cvss'        => $cvss,
                        'description' => (string) ($v['Title'] ?? ($v['Description'] ?? 'Component vulnerability')) . '. Fixed: ' . (string) ($v['FixedVersion'] ?? '—') . '.',
                        'evidence'    => (string) ($v['VulnerabilityID'] ?? '') . ' ' . (string) ($v['PkgName'] ?? '') . ' ' . (string) ($v['InstalledVersion'] ?? '') . ' sev=' . $sevIn,
                        'remediation' => 'Update ' . (string) ($v['PkgName'] ?? 'the package') . ' to ' . (string) ($v['FixedVersion'] ?? 'a patched version') . '; keep monitoring SBOM & CVEs continuously.',
                    ];
                    if (count($findings) >= self::CAP) {
                        break 2;
                    }
                }
            }
            @unlink($json);
        }

        return ['findings' => $findings, 'assets' => [], 'raw' => mb_substr($raw, 0, 2000)];
    }
}
