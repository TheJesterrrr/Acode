<?php

declare(strict_types=1);

namespace App\Modules\Adapter\Services;

/**
 * ToolAdapter — kontrak Adapter (Master Plan §4). CASA tidak pernah memanggil
 * tool langsung; selalu lewat Adapter, yang MENORMALKAN keluaran tiap tool
 * menjadi format internal tunggal: daftar `findings` + `assets`.
 */
interface ToolAdapter
{
    /** Kode tool yang ditangani (mis. 'httpx', 'nuclei'). */
    public function code(): string;

    /**
     * Jalankan tool terhadap target, kembalikan hasil ternormalisasi.
     *
     * @return array{findings:array<int,array<string,mixed>>,assets:array<int,array<string,mixed>>,raw:string}
     */
    public function run(string $binPath, string $target): array;
}
