<?php

declare(strict_types=1);

namespace App\Modules\Adapter\Services;

/** DalfoxAdapter — normalkan keluaran Dalfox (XSS). Menguji parameter pada URL. */
final class DalfoxAdapter extends AbstractCliAdapter
{
    private const SEV = ['critical' => 'crit', 'high' => 'high', 'medium' => 'med', 'low' => 'low', 'info' => 'info'];

    public function code(): string
    {
        return 'dalfox';
    }

    public function run(string $binPath, string $target): array
    {
        // Depth: Light = hanya temukan titik refleksi, TANPA kirim payload XSS
        // (aman/non-intrusif). Standard/Deep = uji payload; worker & delay sesuai depth.
        $depth = \App\Libraries\ScanProfile::depth();
        $mode  = $depth === 'light' ? ' --only-discovery' : '';
        $tune  = $depth === 'deep' ? ' --worker 5 --delay 200' : ($depth === 'standard' ? ' --worker 3 --delay 200' : ' --worker 1');
        $cmd = escapeshellarg($binPath) . ' url ' . escapeshellarg($target)
            . ' --format json --silence --no-color --no-spinner --skip-mining-dom'
            . $mode . $tune . ' --timeout 8'
            . \App\Libraries\ScanProfile::headerArgs()
            . ' 2>/dev/null';
        [$out] = $this->exec($cmd);

        $findings = [];
        foreach ($this->rows($out) as $r) {
            if (! is_array($r)) {
                continue;
            }
            $sev = strtolower((string) ($r['severity'] ?? 'medium'));
            $param = (string) ($r['param'] ?? '');
            $findings[] = [
                'severity'    => self::SEV[$sev] ?? 'med',
                'title'       => 'XSS (' . ($r['inject_type'] ?? 'reflected') . ')' . ($param !== '' ? " on param '{$param}'" : ''),
                'category'    => 'XSS',
                'asset'       => (string) ($r['data'] ?? $target),
                'tool'        => 'dalfox',
                'cwe'         => (string) ($r['cwe'] ?? 'CWE-79'),
                'cvss'        => null,
                'description' => (string) ($r['message_str'] ?? 'Cross-site scripting detected.') . "\nParam: {$param}",
                'evidence'    => mb_substr((string) ($r['payload'] ?? '') . "\n" . (string) ($r['evidence'] ?? ''), 0, 1200),
            ];
        }

        return ['findings' => $findings, 'assets' => [], 'raw' => $out];
    }

    /** Dalfox --format json dapat berupa array JSON atau JSONL; tangani keduanya. */
    private function rows(string $out): array
    {
        $out = trim($out);
        if ($out === '') {
            return [];
        }
        $j = json_decode($out, true);
        if (is_array($j)) {
            return array_is_list($j) ? $j : [$j];
        }
        $rows = [];
        foreach (preg_split('/\r?\n/', $out) as $line) {
            if ($line !== '' && $line[0] === '{') {
                $d = json_decode($line, true);
                if (is_array($d)) {
                    $rows[] = $d;
                }
            }
        }

        return $rows;
    }
}
