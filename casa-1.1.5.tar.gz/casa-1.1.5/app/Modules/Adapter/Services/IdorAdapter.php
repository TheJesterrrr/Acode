<?php

declare(strict_types=1);

namespace App\Modules\Adapter\Services;

use App\Modules\Ai\Services\AiManager;
use Config\Services;
use Throwable;

/**
 * IdorAdapter — deteksi IDOR / Broken Object Level Authorization (Master Plan §12
 * #15; kelas bug bounty paling bernilai). BUKAN tool CLI: memprobe ID objek
 * berurutan pada endpoint dan meminta AI Vulnerability Analyst menilai apakah
 * objek milik pihak lain dapat diakses tanpa otorisasi.
 *
 * Target berupa URL objek ber-ID numerik, mis. http://host/api/Feedbacks/1 —
 * bila tak ada ID numerik di path, adapter tidak menghasilkan apa-apa.
 */
final class IdorAdapter implements ToolAdapter
{
    private const SYS = 'You are a BOLA/IDOR analyst. Given HTTP responses for sequential object IDs '
        . 'fetched WITHOUT authentication, answer STRICT JSON only: '
        . '{"verdict":"confirmed|likely|not_idor","reason":string}. '
        . 'Mark confirmed/likely only when distinct objects that plausibly belong to different '
        . 'users/tenants are returned (200) without auth. Public/static resources are not_idor.';

    public function __construct(private readonly AiManager $ai = new AiManager())
    {
    }

    public function code(): string
    {
        return 'idor';
    }

    public function run(string $binPath, string $target): array
    {
        if (! preg_match('#^(.*/)(\d+)(/?)(?:\?.*)?$#', $target, $m)) {
            return ['findings' => [], 'assets' => [], 'raw' => 'Target bukan endpoint objek ber-ID numerik.'];
        }
        $base = $m[1];
        $id   = (int) $m[2];

        $client  = Services::curlrequest(['timeout' => 8, 'connect_timeout' => 4, 'http_errors' => false], null, null, false);
        $samples = [];
        foreach ([$id - 1, $id, $id + 1, $id + 2] as $probe) {
            if ($probe <= 0) {
                continue;
            }
            $url = $base . $probe;
            try {
                $res    = $client->get($url);
                $status = $res->getStatusCode();
                $body   = mb_substr((string) $res->getBody(), 0, 400);
            } catch (Throwable $e) {
                $status = 0;
                $body   = '';
            }
            $samples[] = ['id' => $probe, 'url' => $url, 'status' => $status, 'body' => $body];
        }

        // Kandidat: >=2 respons 200 dengan isi berbeda.
        $ok = array_values(array_filter($samples, static fn ($s) => $s['status'] === 200 && trim($s['body']) !== ''));
        $distinct = count(array_unique(array_map(static fn ($s) => $s['body'], $ok)));
        if (count($ok) < 2 || $distinct < 2) {
            return ['findings' => [], 'assets' => [], 'raw' => 'Tidak ada indikasi IDOR (objek tak dapat dienumerasi tanpa auth).'];
        }

        $verdict = 'likely';
        $reason  = 'Objek berurutan mengembalikan data berbeda (200) tanpa autentikasi.';
        try {
            $user = "Endpoint: {$base}{id}\n" . implode("\n", array_map(
                static fn ($s) => "id={$s['id']} status={$s['status']} body=" . mb_substr($s['body'], 0, 160),
                $samples
            ));
            $raw = $this->ai->chatForRole('vuln_analyst', self::SYS, $user);
            if (preg_match('/\{.*\}/s', $raw, $mm)) {
                $j = json_decode($mm[0], true);
                if (is_array($j)) {
                    $verdict = (string) ($j['verdict'] ?? $verdict);
                    $reason  = (string) ($j['reason'] ?? $reason);
                }
            }
        } catch (Throwable $e) {
            // Tanpa AI: pertahankan verdikt heuristik 'likely'.
        }

        if ($verdict === 'not_idor') {
            return ['findings' => [], 'assets' => [], 'raw' => 'AI menilai bukan IDOR: ' . $reason];
        }

        $ev = implode("\n", array_map(static fn ($s) => "GET {$s['url']} -> {$s['status']}", $samples));

        return [
            'findings' => [[
                'severity'    => $verdict === 'confirmed' ? 'high' : 'med',
                'title'       => 'IDOR / BOLA — object can be enumerated without authorization',
                'category'    => 'IDOR / BOLA',
                'asset'       => $base . '{id}',
                'tool'        => 'idor',
                'cwe'         => 'CWE-639',
                'cvss'        => $verdict === 'confirmed' ? '8.1' : '6.5',
                'description' => "Broken Object Level Authorization: {$reason}",
                'evidence'    => $ev,
            ]],
            'assets' => [],
            'raw'    => $ev,
        ];
    }
}
