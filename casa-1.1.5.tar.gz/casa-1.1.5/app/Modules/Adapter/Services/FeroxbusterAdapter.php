<?php

declare(strict_types=1);

namespace App\Modules\Adapter\Services;

/**
 * FeroxbusterAdapter — content discovery rekursif (endpoint tersembunyi) → asset url.
 *
 * feroxbuster menebak ribuan path dari wordlist, sama seperti ffuf — rawan
 * halaman block WAF/bot-protection yang membalas "ditemukan" (200/30x) untuk
 * HAMPIR SEMUA tebakan, bukan karena path itu benar ada. --silent (tanpa -v)
 * TIDAK membawa Content-Length ke output, jadi tak bisa kelompokkan per
 * signature status+length seperti FfufAdapter. Mitigasi di sini: batasi jumlah
 * URL yang diambil dari SATU direktori rekursi yang sama (mis. ribuan hasil di
 * bawah /xyz/) — kalau satu cabang menghasilkan jauh lebih banyak dari wajar,
 * itu tanda crawl trap/wildcard, bukan ribuan endpoint nyata satu-satu.
 */
final class FeroxbusterAdapter extends AbstractCliAdapter
{
    private const CAP          = 300;
    private const WORDLIST     = '/opt/casa-tools/wordlists/common.txt';
    /** Maks aset diambil dari satu induk direktori yang sama (anti crawl-trap/wildcard). */
    private const PER_PARENT_CAP = 15;

    public function code(): string
    {
        return 'feroxbuster';
    }

    public function run(string $binPath, string $target): array
    {
        $url = $this->url($target);
        $wl  = is_file(self::WORDLIST) ? self::WORDLIST : '/usr/share/wordlists/common.txt';
        // --silent → hanya URL ditemukan; -d 2 batasi rekursi; -k izinkan TLS invalid.
        // Depth → kedalaman rekursi: Light d=1, Standard d=2, Deep d=3.
        $depth = \App\Libraries\ScanProfile::depth();
        $fdd   = $depth === 'deep' ? 3 : ($depth === 'light' ? 1 : 2);
        $cmd = escapeshellarg($binPath) . ' -u ' . escapeshellarg($url)
            . ' -w ' . escapeshellarg($wl)
            . ' --silent -k -n -d ' . $fdd . ' -t 20 --timeout 7'
            . \App\Libraries\ScanProfile::headerArgs()
            . ' 2>/dev/null';
        [$out] = $this->exec($cmd);

        $assets    = [];
        $seen      = [];
        $perParent = [];
        foreach (preg_split('/\r?\n/', trim($out)) as $line) {
            $u = trim($line);
            if ($u === '' || ! preg_match('#^https?://#i', $u) || isset($seen[$u])) {
                continue;
            }
            $seen[$u] = true;
            $parent   = (string) (parse_url($u, PHP_URL_PATH) !== null ? dirname((string) parse_url($u, PHP_URL_PATH)) : '/');
            $perParent[$parent] = ($perParent[$parent] ?? 0) + 1;
            if ($perParent[$parent] > self::PER_PARENT_CAP) {
                // Direktori ini sudah melewati batas wajar — kemungkinan besar
                // crawl trap/wildcard (server balas "ada" untuk hampir semua
                // tebakan di bawah path ini), bukan endpoint nyata satu-satu.
                continue;
            }
            $assets[] = ['type' => 'url', 'value' => mb_substr($u, 0, 500), 'source' => 'feroxbuster'];
            if (count($assets) >= self::CAP) {
                break;
            }
        }

        return ['findings' => [], 'assets' => $assets, 'raw' => mb_substr($out, 0, 2000)];
    }

    private function url(string $target): string
    {
        $t = trim($target);

        return preg_match('#^https?://#i', $t) ? $t : 'https://' . $this->host($t);
    }
}
