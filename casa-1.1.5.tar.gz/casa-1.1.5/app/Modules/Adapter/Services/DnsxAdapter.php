<?php

declare(strict_types=1);

namespace App\Modules\Adapter\Services;

/** DnsxAdapter — resolusi & rekaman DNS (DNS Analysis §12 #4) → asset IP + info. */
final class DnsxAdapter extends AbstractCliAdapter
{
    public function code(): string
    {
        return 'dnsx';
    }

    public function run(string $binPath, string $target): array
    {
        $domain = $this->host($target);
        // Kirim domain via stdin; minta A/AAAA/CNAME/MX/NS/TXT sebagai JSON.
        $cmd = escapeshellarg($binPath) . ' -json -silent -a -aaaa -cname -mx -ns -txt -resp -timeout 5 2>/dev/null';
        [$out] = $this->exec($cmd, $domain . "\n");

        $assets   = [];
        $records  = [];
        foreach (preg_split('/\r?\n/', trim($out)) as $line) {
            if ($line === '' || $line[0] !== '{') {
                continue;
            }
            $j = json_decode($line, true);
            if (! is_array($j)) {
                continue;
            }
            foreach ((array) ($j['a'] ?? []) as $ip) {
                $assets[] = ['type' => 'ip', 'value' => (string) $ip, 'source' => 'dnsx'];
                $records[] = 'A ' . $ip;
            }
            foreach (['aaaa' => 'AAAA', 'cname' => 'CNAME', 'mx' => 'MX', 'ns' => 'NS', 'txt' => 'TXT'] as $k => $lbl) {
                foreach ((array) ($j[$k] ?? []) as $v) {
                    $records[] = $lbl . ' ' . (is_array($v) ? json_encode($v) : (string) $v);
                }
            }
        }

        $findings = [];
        if ($records !== []) {
            $findings[] = [
                'severity'    => 'info',
                'title'       => 'DNS Record ' . $domain,
                'category'    => 'DNS Analysis',
                'asset'       => $domain,
                'tool'        => 'dnsx',
                'cwe'         => null,
                'cvss'        => null,
                'description' => "DNS record collected for {$domain} (attack surface intelligence).",
                'evidence'    => mb_substr(implode("\n", array_unique($records)), 0, 1500),
            ];
        }

        return ['findings' => $findings, 'assets' => $assets, 'raw' => mb_substr($out, 0, 2000)];
    }
}
