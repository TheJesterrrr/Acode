<?php

declare(strict_types=1);

namespace App\Modules\Broadcast\Services;

use App\Modules\Setting\Services\SettingService;

/**
 * BroadcastService — pengumuman owner ke instance pelanggan. Disimpan sebagai
 * JSON di Settings (tanpa tabel) agar ringan. Instance membaca yang aktif via
 * api/announcements. Level: info | warning | critical.
 */
final class BroadcastService
{
    private const KEY = 'broadcast.items';

    public function __construct(private readonly SettingService $s = new SettingService())
    {
    }

    /** @return array<int,array<string,mixed>> */
    public function all(): array
    {
        $raw = (string) $this->s->get(self::KEY, '');
        $arr = $raw !== '' ? json_decode($raw, true) : [];

        return is_array($arr) ? $arr : [];
    }

    /** @return array<int,array<string,mixed>> hanya yang aktif (untuk instance) */
    public function active(): array
    {
        return array_values(array_filter($this->all(), static fn (array $a): bool => ! empty($a['active'])));
    }

    public function add(string $title, string $body, string $level): void
    {
        $items = $this->all();
        array_unshift($items, [
            'id'         => (string) (time() . random_int(10, 99)),
            'title'      => mb_substr(trim($title), 0, 160),
            'body'       => mb_substr(trim($body), 0, 2000),
            'level'      => in_array($level, ['info', 'warning', 'critical'], true) ? $level : 'info',
            'active'     => true,
            'created_at' => date('Y-m-d H:i'),
        ]);
        $this->save(array_slice($items, 0, 50));
    }

    public function toggle(string $id): void
    {
        $items = $this->all();
        foreach ($items as &$a) {
            if ((string) $a['id'] === $id) {
                $a['active'] = ! ($a['active'] ?? false);
            }
        }
        unset($a);
        $this->save($items);
    }

    public function remove(string $id): void
    {
        $this->save(array_values(array_filter($this->all(), static fn (array $a): bool => (string) $a['id'] !== $id)));
    }

    private function save(array $items): void
    {
        $this->s->set(self::KEY, json_encode($items, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    }
}
