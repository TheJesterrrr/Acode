<?php

declare(strict_types=1);

namespace App\Modules\Broadcast\Controllers;

use App\Controllers\BaseController;
use App\Modules\Broadcast\Services\BroadcastService;
use CodeIgniter\HTTP\ResponseInterface;

/**
 * BroadcastController — pengumuman owner ke instance pelanggan. Halaman owner
 * (kelola) + endpoint publik api/announcements (dibaca instance).
 */
final class BroadcastController extends BaseController
{
    public function __construct(private readonly BroadcastService $bc = new BroadcastService())
    {
    }

    public function index(): string
    {
        $this->requireOwnerConsole();

        return $this->adminView('App\Modules\Broadcast\Views\index', [
            'title' => 'Broadcast',
            'items' => $this->bc->all(),
        ], 'broadcast');
    }

    public function create(): ResponseInterface
    {
        $this->requireOwnerConsole();
        $title = trim((string) $this->request->getPost('title'));
        if ($title === '') {
            return $this->fail('Judul wajib diisi.');
        }
        $this->bc->add($title, (string) $this->request->getPost('body'), (string) $this->request->getPost('level'));

        return $this->ok([]);
    }

    public function toggle(string $id): ResponseInterface
    {
        $this->requireOwnerConsole();
        $this->bc->toggle($id);

        return $this->ok([]);
    }

    public function delete(string $id): ResponseInterface
    {
        $this->requireOwnerConsole();
        $this->bc->remove($id);

        return $this->ok([]);
    }

    /** Publik: pengumuman aktif (dibaca instance pelanggan). */
    public function latest(): ResponseInterface
    {
        return $this->response->setJSON(['ok' => true, 'items' => $this->bc->active()]);
    }
}
