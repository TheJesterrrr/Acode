<?php

declare(strict_types=1);

use CodeIgniter\Router\RouteCollection;

/** Rute Broadcast — pengumuman owner + endpoint publik. */

/** @var RouteCollection $routes */
$routes->group('casaadmin/broadcast', ['namespace' => 'App\Modules\Broadcast\Controllers', 'filter' => 'admin'], static function (RouteCollection $routes): void {
    $routes->get('', 'BroadcastController::index');
    $routes->post('create', 'BroadcastController::create', ['filter' => 'audit:BROADCAST_CREATE']);
    $routes->post('(:segment)/toggle', 'BroadcastController::toggle/$1');
    $routes->post('(:segment)/delete', 'BroadcastController::delete/$1', ['filter' => 'audit:BROADCAST_DELETE']);
});

/** Pengumuman aktif (publik, dibaca instance pelanggan). */
$routes->get('api/announcements', '\App\Modules\Broadcast\Controllers\BroadcastController::latest');
