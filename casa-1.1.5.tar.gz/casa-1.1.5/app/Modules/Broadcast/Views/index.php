<?= $this->extend('layouts/admin') ?>
<?= $this->section('content') ?>
<?php /** @var array $items */
$lvl = ['info' => 'info', 'warning' => 'warning', 'critical' => 'danger'];
?>
<div class="casa-page-head"><h1 class="h4 mb-0"><i class="bi bi-megaphone me-1"></i>Broadcast</h1></div>

<div class="row g-3">
  <div class="col-lg-5">
    <div class="casa-card p-4 h-100">
      <h2 class="h6 mb-1">Pengumuman baru</h2>
      <p class="text-muted small">Tampil di seluruh instance pelanggan (via <code>api/announcements</code>).</p>
      <form id="bcForm">
        <div class="mb-2"><label class="form-label small">Judul</label><input name="title" class="form-control" required></div>
        <div class="mb-2"><label class="form-label small">Isi</label><textarea name="body" class="form-control" rows="3"></textarea></div>
        <div class="mb-3"><label class="form-label small">Level</label>
          <select name="level" class="form-select"><option value="info">Info</option><option value="warning">Warning</option><option value="critical">Critical</option></select></div>
        <button class="btn btn-primary" id="bcBtn"><i class="bi bi-send me-1"></i>Publish</button><span id="bcMsg" class="small ms-2"></span>
      </form>
    </div>
  </div>
  <div class="col-lg-7">
    <div class="casa-card p-0 h-100">
      <div class="p-3 border-bottom" style="border-color:var(--casa-card-brd)!important"><h2 class="h6 mb-0">Pengumuman (<?= count($items) ?>)</h2></div>
      <div class="p-3 d-flex flex-column gap-2">
        <?php foreach ($items as $it): ?>
          <div class="border rounded p-2 d-flex gap-2 align-items-start" style="border-color:var(--casa-card-brd)!important;<?= empty($it['active']) ? 'opacity:.55' : '' ?>">
            <span class="badge text-bg-<?= $lvl[$it['level']] ?? 'info' ?> mt-1"><?= esc(ucfirst($it['level'])) ?></span>
            <div class="flex-grow-1"><div class="fw-semibold"><?= esc($it['title']) ?></div><div class="small text-muted"><?= esc($it['body']) ?></div><div class="small text-muted"><?= esc($it['created_at']) ?></div></div>
            <div class="d-flex flex-column gap-1">
              <button class="btn btn-sm btn-outline-secondary js-tg" data-id="<?= esc($it['id']) ?>"><?= empty($it['active']) ? 'Activate' : 'Deactivate' ?></button>
              <button class="btn btn-sm btn-outline-danger js-del" data-id="<?= esc($it['id']) ?>"><i class="bi bi-trash"></i></button>
            </div>
          </div>
        <?php endforeach; ?>
        <?php if ($items === []): ?><p class="text-muted small mb-0">Belum ada pengumuman.</p><?php endif; ?>
      </div>
    </div>
  </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('page_scripts') ?>
<script>
const BASE = '<?= esc(site_url('casaadmin/broadcast')) ?>';
document.getElementById('bcForm').addEventListener('submit', async (e) => { e.preventDefault();
  const b = document.getElementById('bcBtn'), m = document.getElementById('bcMsg'); b.disabled = true;
  const d = await casaPost(BASE + '/create', new FormData(e.target)); b.disabled = false;
  if (d.ok) { location.reload(); } else { m.className = 'small ms-2 text-danger'; m.textContent = d.error || 'Gagal.'; }
});
document.querySelectorAll('.js-tg').forEach(x => x.addEventListener('click', async () => { await casaPost(BASE + '/' + x.dataset.id + '/toggle', {}); location.reload(); }));
document.querySelectorAll('.js-del').forEach(x => x.addEventListener('click', async () => { if (confirm('Hapus pengumuman?')) { await casaPost(BASE + '/' + x.dataset.id + '/delete', {}); location.reload(); } }));
</script>
<?= $this->endSection() ?>
