<?php

declare(strict_types=1);

use CodeIgniter\Router\RouteCollection;

/** Rute Attack Surface — inventaris aset global (member). */

/** @var RouteCollection $routes */
$routes->group('attack-surface', ['namespace' => 'App\Modules\AttackSurface\Controllers', 'filter' => 'member'], static function (RouteCollection $routes): void {
    $routes->get('', 'AttackSurfaceController::index');
});
