<?php

declare(strict_types=1);

namespace App\Modules\AttackSurface\Controllers;

use App\Controllers\BaseController;
use App\Modules\Project\Models\AssetModel;

/**
 * AttackSurfaceController — inventaris aset GLOBAL milik member (lintas project).
 * Data diisi dari hasil recon mission (httpx, subfinder, naabu, katana, dll.)
 * lewat AssetModel. Read-only; kepemilikan ditegakkan via join project.customer_id.
 */
final class AttackSurfaceController extends BaseController
{
    public function __construct(private readonly AssetModel $assets = new AssetModel())
    {
    }

    private function me(): int
    {
        return (int) $this->session->get('member_id');
    }

    public function index(): string
    {
        $type = trim((string) $this->request->getGet('type'));
        $q    = trim((string) $this->request->getGet('q'));
        $cid  = $this->me();

        return $this->memberView('App\Modules\AttackSurface\Views\index', [
            'title'  => 'Attack Surface',
            'assets' => $this->assets->forCustomer($cid, $type, $q),
            'stats'  => $this->assets->typeStatsForCustomer($cid),
            'type'   => $type,
            'q'      => $q,
        ], 'surface');
    }
}
