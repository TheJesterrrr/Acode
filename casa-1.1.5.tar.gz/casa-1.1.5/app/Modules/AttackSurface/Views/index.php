<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<?php
/** @var array $assets @var array $stats @var string $type @var string $q */
$meta = [
    'host'      => ['Host', 'bi-hdd-network', 'primary'],
    'ip'        => ['IP', 'bi-ethernet', 'primary'],
    'subdomain' => ['Subdomain', 'bi-diagram-3', 'info'],
    'domain'    => ['Domain', 'bi-globe2', 'info'],
    'url'       => ['URL', 'bi-link-45deg', 'success'],
    'endpoint'  => ['Endpoint', 'bi-signpost-split', 'success'],
    'service'   => ['Service/Port', 'bi-hdd-rack', 'warning'],
    'port'      => ['Port', 'bi-hdd-rack', 'warning'],
    'tech'      => ['Teknologi', 'bi-cpu', 'secondary'],
    'technology'=> ['Teknologi', 'bi-cpu', 'secondary'],
];
$label = static fn (string $t): array => $meta[$t] ?? [ucfirst($t), 'bi-box', 'secondary'];
$total = array_sum($stats);
?>
<div class="casa-page-head">
  <div>
    <h1 class="mb-0"><i class="bi bi-diagram-2 me-1"></i>Attack Surface</h1>
    <div class="small text-muted"><?= number_format($total, 0, ',', '.') ?> aset ditemukan lintas seluruh project Anda — hasil recon mission.</div>
  </div>
</div>

<!-- Stat tiles per tipe (klik untuk memfilter) -->
<div class="row g-2 mb-3">
  <?php foreach ($stats as $t => $n): [$lbl, $ic, $col] = $label((string) $t); ?>
    <div class="col-6 col-md-3 col-lg-2">
      <a href="<?= esc(site_url('attack-surface?type=' . urlencode((string) $t))) ?>"
         class="d-block casa-card p-3 text-decoration-none <?= $type === (string) $t ? 'border-primary' : '' ?>">
        <div class="d-flex align-items-center gap-2 text-<?= esc($col) ?>"><i class="bi <?= esc($ic) ?>"></i>
          <span class="small text-muted text-uppercase" style="letter-spacing:.04em"><?= esc($lbl) ?></span></div>
        <div class="fs-4 fw-bold mt-1"><?= number_format((int) $n, 0, ',', '.') ?></div>
      </a>
    </div>
  <?php endforeach; ?>
  <?php if ($stats === []): ?>
    <div class="col-12"><div class="casa-card p-4 text-center text-muted">
      Belum ada aset. Luncurkan <b>Mission</b> (recon) pada sebuah project untuk memetakan attack surface.
    </div></div>
  <?php endif; ?>
</div>

<?php if ($stats !== []): ?>
<div class="casa-card p-0">
  <div class="p-3 border-bottom d-flex flex-wrap gap-2 align-items-center" style="border-color:var(--casa-card-brd)!important">
    <form class="d-flex gap-2 flex-grow-1" method="get" action="<?= esc(site_url('attack-surface')) ?>">
      <?php if ($type !== ''): ?><input type="hidden" name="type" value="<?= esc($type) ?>"><?php endif; ?>
      <input name="q" value="<?= esc($q) ?>" class="form-control form-control-sm" placeholder="Cari aset (host, url, teknologi…)">
      <button class="btn btn-sm btn-primary"><i class="bi bi-search"></i></button>
    </form>
    <?php if ($type !== '' || $q !== ''): ?>
      <a href="<?= esc(site_url('attack-surface')) ?>" class="btn btn-sm btn-outline-secondary">Reset</a>
    <?php endif; ?>
  </div>
  <div class="table-responsive">
    <table class="table align-middle mb-0">
      <thead><tr><th class="ps-3">Tipe</th><th>Nilai</th><th>Sumber</th><th class="pe-3">Project</th></tr></thead>
      <tbody>
        <?php if ($assets === []): ?>
          <tr><td colspan="4" class="text-center text-muted py-4">Tidak ada aset cocok filter.</td></tr>
        <?php endif; ?>
        <?php foreach ($assets as $a): [$lbl, $ic, $col] = $label((string) $a['type']); ?>
          <tr>
            <td class="ps-3"><span class="badge text-bg-<?= esc($col) ?>"><i class="bi <?= esc($ic) ?> me-1"></i><?= esc($lbl) ?></span></td>
            <td class="font-monospace small" style="word-break:break-all"><?= esc($a['value']) ?></td>
            <td class="small text-muted"><?= esc(\App\Libraries\ToolLabel::show($a['source']) ?: '—') ?></td>
            <td class="small"><?= esc($a['project_name'] ?? '—') ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>
<?= $this->endSection() ?>
