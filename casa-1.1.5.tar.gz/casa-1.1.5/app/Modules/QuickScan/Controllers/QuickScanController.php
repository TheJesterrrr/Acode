<?php

declare(strict_types=1);

namespace App\Modules\QuickScan\Controllers;

use App\Controllers\BaseController;
use App\Modules\QuickScan\Services\QuickScanService;
use CodeIgniter\HTTP\ResponseInterface;
use RuntimeException;

/** QuickScanController — Quick Assessment satu-klik (member; CES 13.2 thin). */
final class QuickScanController extends BaseController
{
    public function __construct(private readonly QuickScanService $quick = new QuickScanService())
    {
    }

    private function me(): int
    {
        return (int) $this->session->get('member_id');
    }

    public function show(): string
    {
        $key = (string) $this->request->getGet('template');
        $tpl = \App\Modules\ScanTemplates\Config\ScanTemplateCatalog::get($key);

        return $this->memberView('App\Modules\QuickScan\Views\wizard', [
            'title'  => 'Assessment Baru',
            'tplKey' => $tpl !== null ? $key : '',
            'tpl'    => $tpl,
        ], 'quickscan');
    }

    public function launch(): ResponseInterface
    {
        if ($r = $this->denyViewer()) {
            return $r;
        }
        try {
            $res = $this->quick->launch(
                $this->me(),
                (string) $this->request->getPost('target'),
                (string) $this->request->getPost('name'),
                (string) $this->request->getPost('template'),
                (string) $this->request->getPost('depth'),
                (string) $this->request->getPost('headers'),
            );
        } catch (RuntimeException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok([
            'redirect' => site_url('missions/' . $res['mission_id']),
            'type'     => $res['type'],
            'count'    => $res['count'] ?? 1,
        ]);
    }
}
