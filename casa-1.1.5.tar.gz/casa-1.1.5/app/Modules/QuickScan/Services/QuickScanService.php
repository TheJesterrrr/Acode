<?php

declare(strict_types=1);

namespace App\Modules\QuickScan\Services;

use App\Modules\Licensing\Services\EditionService;
use App\Modules\Mission\Services\MissionService;
use App\Modules\Policy\Services\PolicyEngine;
use App\Modules\Project\Services\ProjectService;
use App\Modules\ScanTemplates\Config\ScanTemplateCatalog;
use Config\Database;
use RuntimeException;

/**
 * QuickScanService — "Quick Assessment" satu-klik (pembeda: dapat dipakai orang
 * awam). Satu input target → CASA otomatis: buat Project → tambah Target → terapkan
 * Policy default aman → luncurkan Mission (orkestrasi 21 Adapter + AI). Pengguna
 * tak perlu memahami tool: cukup masukkan URL/domain lalu lihat hasil + laporan.
 */
final class QuickScanService
{
    public function __construct(
        private readonly ProjectService $projects = new ProjectService(),
        private readonly PolicyEngine $policy = new PolicyEngine(),
        private readonly MissionService $missions = new MissionService(),
        private readonly EditionService $edition = new EditionService(),
    ) {
    }

    /** Jumlah Mission (scan) yang diluncurkan pelanggan HARI INI. */
    private function scansToday(int $customerId): int
    {
        $db = Database::connect();

        return (int) ($db->query(
            'SELECT COUNT(*) n FROM mission WHERE customer_id=' . (int) $customerId . ' AND DATE(created_at)=CURDATE()'
        )->getRowArray()['n'] ?? 0);
    }

    /**
     * Jalankan assessment satu-klik. Kembalikan [projectId, missionId].
     * @return array{project_id:int,mission_id:int,type:string,value:string}
     * @throws RuntimeException
     */
    public function launch(int $customerId, string $targetInput, string $name = '', string $template = '', string $depth = '', string $headers = ''): array
    {
        // Terima SATU atau BANYAK target (satu per baris — mis. hasil import gambar).
        $lines = array_values(array_unique(array_filter(
            array_map('trim', preg_split('/\r?\n/', $targetInput) ?: []),
            static fn (string $l): bool => $l !== '',
        )));
        if ($lines === []) {
            throw new RuntimeException('Masukkan minimal satu target: URL, domain, repo git, atau image container.');
        }

        // Gerbang batas scan harian per edisi (cegah penyalahgunaan hapus-ulang project).
        $this->edition->requireScanQuota($customerId, $this->scansToday($customerId));

        // Resolusi template → kapabilitas (scope) + depth default.
        $template = ScanTemplateCatalog::valid($template) ? $template : '';
        $caps     = $template !== '' ? ScanTemplateCatalog::caps($template) : [];
        $depth    = in_array($depth, ['light', 'standard', 'deep'], true)
            ? $depth
            : ($template !== '' ? ScanTemplateCatalog::depth($template) : 'standard');
        [$firstType, $firstValue] = $this->classify($lines[0]);
        $name = trim($name) !== '' ? trim($name) : $this->deriveName($firstValue);

        // 1) Project (kuota edisi ditegakkan di service).
        $projectId = $this->projects->createProject($customerId, [
            'name'        => $name,
            'program_url' => (count($lines) === 1 && in_array($firstType, ['url', 'domain'], true)) ? $firstValue : '',
        ]);

        // 2) Target(s).
        $added = 0;
        foreach ($lines as $line) {
            [$type, $value] = $this->classify($line);
            try {
                $this->projects->addTarget($projectId, $customerId, $type, $value, 'Assessment Baru');
                $added++;
            } catch (RuntimeException) {
                break; // kuota target tercapai → hentikan, tetap lanjut dengan yang ada.
            }
        }
        if ($added === 0) {
            throw new RuntimeException('Tak ada target valid ditambahkan (cek kuota paket).');
        }

        // 3) Policy default aman (tanpa perlu AI Rule Parser / input pengguna).
        $this->policy->ensureDefault($projectId, $customerId);

        // 4) Mission — planner memilih tool yang cocok tipe target & terpasang.
        $missionId = $this->missions->launch($projectId, $customerId, 'Assessment: ' . $name, $caps, $depth, $template, $headers);

        return ['project_id' => $projectId, 'mission_id' => $missionId, 'type' => $firstType, 'value' => $firstValue, 'count' => $added, 'depth' => $depth, 'template' => $template];
    }

    /**
     * Tebak tipe & normalkan target dari input awam.
     * @return array{0:string,1:string} [type, value]
     */
    private function classify(string $input): array
    {
        $in = trim($input);
        if ($in === '') {
            throw new RuntimeException('Masukkan target: URL situs, domain, repo git, atau image container.');
        }
        // Repo git (github/gitlab/…/.git).
        if (preg_match('#^(https?://)?(www\.)?(github\.com|gitlab\.com|bitbucket\.org)/[\w.-]+/[\w.-]+#i', $in) || preg_match('#\.git$#i', $in)) {
            return ['repo', preg_match('#^https?://#i', $in) ? $in : 'https://' . ltrim($in, '/')];
        }
        // IPv4 (opsional :port) → host/domain. WAJIB sebelum cek image, agar
        // "103.171.152.5:53" tak salah dikira container image (host:tag). Port
        // dibuang: scanner menentukan port sendiri (top-ports/-p-), bukan dari target.
        if (preg_match('#^\d{1,3}(\.\d{1,3}){3}(:\d{1,5})?$#', $in)) {
            return ['domain', (string) preg_replace('#:\d+$#', '', $in)];
        }
        // Image container (mengandung ":" tag tanpa skema & tanpa titik domain, atau ada "/" registry).
        if (! preg_match('#^https?://#i', $in) && ! str_contains($in, ' ') && preg_match('#^[\w./-]+:[\w.-]+$#', $in) && ! preg_match('#\.(com|net|org|io|id|co|dev|app|web)\b#i', $in)) {
            return ['image', $in];
        }
        // URL lengkap.
        if (preg_match('#^https?://#i', $in)) {
            return ['url', $in];
        }
        // Ada path → URL; hanya host → domain.
        if (str_contains($in, '/')) {
            return ['url', 'https://' . ltrim($in, '/')];
        }

        return ['domain', strtolower($in)];
    }

    private function deriveName(string $value): string
    {
        $host = preg_replace('#^[a-z]+://#i', '', $value);
        $host = preg_replace('#[/:].*$#', '', (string) $host);

        return ($host !== '' ? $host : 'Target') . ' — ' . date('d M');
    }
}
