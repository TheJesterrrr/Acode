<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<div class="casa-page-head">
  <div>
    <h1 class="mb-0"><i class="bi bi-stars me-1"></i>Assessment Baru</h1>
    <div class="small text-muted">Masukkan target (URL, domain, repo, atau image). CASA menjalankan Recon → scan → validasi → Report otomatis. Opsional: upload screenshot Scope untuk mengisi target dari gambar.</div>
  </div>
</div>

<div class="row justify-content-center">
  <div class="col-lg-9">
    <div class="casa-card p-4 p-lg-5">
      <form id="qsForm">
        <?php $tpl = $tpl ?? null; $tplKey = $tplKey ?? ''; $defDepth = $tpl['depth'] ?? 'standard'; ?>
        <input type="hidden" name="template" value="<?= esc($tplKey) ?>">
        <?php if ($tpl): ?>
          <div class="alert alert-info d-flex align-items-start gap-2 py-2 px-3 small mb-3">
            <i class="bi <?= esc($tpl['icon']) ?> mt-1"></i>
            <div>
              <b>Template: <?= esc($tpl['name']) ?></b> — <?= esc($tpl['desc']) ?>
              <div class="mt-1 text-muted">Kapabilitas: <?= esc(implode(' · ', $tpl['caps'] ?: ['Seluruh kapabilitas'])) ?></div>
            </div>
            <a href="<?= esc(site_url('scan')) ?>" class="ms-auto text-decoration-none" title="Scan penuh tanpa template">ganti</a>
          </div>
        <?php endif; ?>
        <!-- Nama project -->
        <div class="mb-3">
          <label class="form-label fw-semibold">Judul / Nama Project</label>
          <input name="name" id="qsName" class="form-control form-control-lg" placeholder="mis. Sonic Healthcare — recon (dibuat otomatis bila kosong)">
        </div>

        <!-- Upload gambar target -->
        <div class="mb-3">
          <label class="form-label fw-semibold">Upload gambar target <span class="text-muted fw-normal small">(opsional — screenshot halaman Scope)</span></label>
          <div class="d-flex flex-wrap align-items-center gap-2">
            <label id="drop" class="d-flex align-items-center gap-2 px-3 py-2 mb-0" style="border:1.5px dashed var(--casa-card-brd);border-radius:.5rem;cursor:pointer">
              <i class="bi bi-image text-muted"></i><span class="small" id="fileName">Klik / seret gambar</span>
              <input type="file" id="img" accept="image/*" hidden>
            </label>
            <button type="button" id="readBtn" class="btn btn-outline-secondary btn-sm"><i class="bi bi-magic me-1"></i>Baca gambar &amp; isi target</button>
            <span id="readMsg" class="small text-muted"></span>
          </div>
          <img id="preview" class="img-fluid rounded mt-2 d-none" alt="preview" style="max-height:130px">
        </div>

        <!-- Daftar target -->
        <div class="mb-2">
          <label class="form-label fw-semibold">Target <span class="text-muted fw-normal small">(satu per baris — URL, domain, repo git, atau image container)</span></label>
          <textarea name="target" id="qsTarget" class="form-control font-monospace" rows="6" placeholder="contoh:&#10;https://target.com&#10;api.target.com&#10;github.com/OWASP/NodeGoat" required></textarea>
          <div class="mt-2 d-flex flex-wrap gap-2 align-items-center">
            <span class="small text-muted">Contoh cepat:</span>
            <button type="button" class="btn btn-sm btn-outline-secondary qs-ex">https://juice-shop.herokuapp.com</button>
            <button type="button" class="btn btn-sm btn-outline-secondary qs-ex">example.com</button>
            <span class="small text-muted ms-auto" id="tCount"></span>
          </div>
        </div>

        <!-- Kedalaman scan (Light/Standard/Deep) -->
        <div class="mb-3">
          <label class="form-label fw-semibold">Kedalaman scan</label>
          <div class="btn-group w-100" role="group" aria-label="Kedalaman scan">
            <input type="radio" class="btn-check" name="depth" id="d_light" value="light" <?= $defDepth === 'light' ? 'checked' : '' ?>>
            <label class="btn btn-outline-secondary" for="d_light">Light<span class="d-block small text-muted">cepat · port umum</span></label>
            <input type="radio" class="btn-check" name="depth" id="d_std" value="standard" <?= $defDepth === 'standard' ? 'checked' : '' ?>>
            <label class="btn btn-outline-secondary" for="d_std">Standard<span class="d-block small text-muted">seimbang</span></label>
            <input type="radio" class="btn-check" name="depth" id="d_deep" value="deep" <?= $defDepth === 'deep' ? 'checked' : '' ?>>
            <label class="btn btn-outline-secondary" for="d_deep">Deep<span class="d-block small text-muted">full port · semua template</span></label>
          </div>
          <div class="small text-muted mt-1"><i class="bi bi-clock-history me-1"></i>Makin dalam makin menyeluruh, tapi makin lama — Deep memakai full port (<code>-p-</code>) + seluruh template Nuclei.</div>
        </div>

        <!-- Header HTTP kustom (disuntik ke semua request tool) -->
        <div class="mb-3">
          <label class="form-label fw-semibold" for="qsHeaders">Header HTTP kustom <span class="text-muted fw-normal small">(opsional — satu per baris, format <code>Name: Value</code>)</span></label>
          <textarea name="headers" id="qsHeaders" class="form-control font-monospace" rows="3" placeholder="contoh (aturan bug bounty):&#10;X-Request-Purpose: Research&#10;X-Bugcrowd-Ninja: username-anda"></textarea>
          <div class="d-flex flex-wrap align-items-center gap-2 mt-2">
            <button type="button" class="btn btn-sm btn-outline-info" onclick="var t=document.getElementById('qsHeaders');var u=(prompt('Username Bugcrowd (opsional, boleh kosong):')||'').trim();t.value='X-Request-Purpose: Research'+(u?('\nX-Bugcrowd-Ninja: '+u):'');">
              <i class="bi bi-shield-plus me-1"></i>Isi header Bugcrowd
            </button>
            <span class="small text-muted"><i class="bi bi-info-circle me-1"></i>Disuntik ke httpx, nuclei, katana, ffuf, feroxbuster, dalfox, arjun, hakrawler — menghindari IP-block & menandai aktivitas researcher.</span>
          </div>
        </div>

        <div class="casa-card p-3 my-3" style="background:var(--casa-card-alt,transparent)">
          <div class="small fw-semibold mb-2"><i class="bi bi-magic me-1 text-warning"></i>Yang CASA lakukan otomatis</div>
          <div class="row row-cols-2 row-cols-md-4 g-2 small text-muted">
            <div><i class="bi bi-1-circle me-1"></i>Buat project + policy aman</div>
            <div><i class="bi bi-2-circle me-1"></i>Recon &amp; pemetaan target</div>
            <div><i class="bi bi-3-circle me-1"></i>Scan Vulnerability</div>
            <div><i class="bi bi-4-circle me-1"></i>Validasi temuan + Report</div>
          </div>
        </div>

        <button id="qsBtn" class="btn btn-amber btn-lg w-100"><i class="bi bi-play-fill me-1"></i>Start Assessment</button>
        <div id="qsMsg" class="small mt-2 text-center"></div>
        <div class="small text-muted text-center mt-2"><i class="bi bi-shield-check me-1"></i>Hanya jalankan pada target yang Anda <b>miliki izin</b> (mis. program bug bounty yang berlaku) &amp; sesuai ROE. Uji non-destruktif.</div>
      </form>
    </div>
  </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('page_scripts') ?>
<!-- OCR di peramban (client-side) — server tak menjalankan tool dari web request -->
<script src="https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js"></script>
<script>
const $ = (s) => document.querySelector(s);
let picked = null;

function countTargets(){
  const n = $('#qsTarget').value.split('\n').map(x=>x.trim()).filter(Boolean).length;
  $('#tCount').textContent = n ? (n + ' target') : '';
}
$('#qsTarget').addEventListener('input', countTargets);

$('.qs-ex') && document.querySelectorAll('.qs-ex').forEach(b => b.addEventListener('click', () => {
  const t = $('#qsTarget'); t.value = (t.value.trim() ? t.value.trim()+'\n' : '') + b.textContent.trim(); countTargets();
}));

// --- Upload gambar ---
$('#drop').addEventListener('click', () => $('#img').click());
['dragover','drop'].forEach(ev => $('#drop').addEventListener(ev, e => e.preventDefault()));
$('#drop').addEventListener('drop', e => { if (e.dataTransfer.files[0]) setFile(e.dataTransfer.files[0]); });
$('#img').addEventListener('change', e => { if (e.target.files[0]) setFile(e.target.files[0]); });
function setFile(f){
  picked = f; $('#fileName').textContent = f.name;
  const r = new FileReader(); r.onload = () => { const p=$('#preview'); p.src=r.result; p.classList.remove('d-none'); }; r.readAsDataURL(f);
}

$('#readBtn').addEventListener('click', async () => {
  if (!picked){ $('#readMsg').innerHTML = '<span class="text-danger">Pilih gambar dulu.</span>'; return; }
  const b = $('#readBtn'), m = $('#readMsg'); const o = b.innerHTML;
  b.disabled = true;
  try {
    if (typeof Tesseract === 'undefined'){ throw new Error('lib'); }
    m.className = 'small text-muted'; m.textContent = 'Memuat OCR (sekali unduh)…';
    // OCR dijalankan di peramban Anda (bukan server).
    const { data } = await Tesseract.recognize(picked, 'eng', {
      logger: (p) => { if (p.status === 'recognizing text') b.innerHTML = '<span class="spinner-border spinner-border-sm"></span> ' + Math.round(p.progress*100) + '%'; }
    });
    const text = (data && data.text) ? data.text : '';
    b.innerHTML = o;
    if (text.trim().length < 4){ b.disabled = false; m.innerHTML = '<span class="text-danger">Gambar tak terbaca. Coba screenshot lebih jelas / zoom Scope.</span>'; return; }
    // Kirim TEKS (bukan gambar) ke server untuk ekstraksi host in-scope (regex + AI lokal).
    const d = await casaPost('<?= esc(site_url('member/import/analyze')) ?>', { text });
    b.disabled = false;
    if (!d.ok){ m.innerHTML = '<span class="text-danger">'+(d.error||'Gagal.')+'</span>'; return; }
    const existing = new Set($('#qsTarget').value.split('\n').map(x=>x.trim()).filter(Boolean));
    d.targets.filter(t=>t.in_scope).forEach(t => existing.add(t.value));
    $('#qsTarget').value = [...existing].join('\n'); countTargets();
    m.innerHTML = '<i class="bi bi-check-circle text-success me-1"></i>'+d.targets.length+' terbaca'+(d.ai?' · disaring AI lokal':'')+'. Tinjau daftar di bawah.';
  } catch (e) {
    b.disabled = false; b.innerHTML = o;
    m.innerHTML = '<span class="text-danger">OCR gagal dimuat (butuh internet di peramban). Ketik target manual saja.</span>';
  }
});

// --- Submit ---
$('#qsForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const b = $('#qsBtn'), m = $('#qsMsg');
  b.disabled = true; const o = b.innerHTML; b.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Menyiapkan &amp; meluncurkan…';
  m.className = 'small mt-2 text-center text-muted'; m.textContent = 'CASA membuat project, menyusun policy, dan meluncurkan mission…';
  const d = await casaPost('<?= esc(site_url('scan')) ?>', new FormData(e.target));
  if (d.ok && d.redirect) { m.textContent = 'Berhasil'+(d.count?(' ('+d.count+' target)'):'')+'! Mengalihkan…'; location.href = d.redirect; }
  else { b.disabled = false; b.innerHTML = o; m.className = 'small mt-2 text-center text-danger'; m.textContent = d.error || 'Gagal memulai.'; }
});
countTargets();
</script>
<?= $this->endSection() ?>
