<?php

declare(strict_types=1);

use CodeIgniter\Router\RouteCollection;

/** Rute Quick Assessment — endpoint MEMBER (CES 13.10). */

/** @var RouteCollection $routes */
$routes->group('scan', ['namespace' => 'App\Modules\QuickScan\Controllers', 'filter' => 'member'], static function (RouteCollection $routes): void {
    $routes->get('', 'QuickScanController::show');
    $routes->post('', 'QuickScanController::launch', ['filter' => 'audit:QUICK_SCAN']);
});
