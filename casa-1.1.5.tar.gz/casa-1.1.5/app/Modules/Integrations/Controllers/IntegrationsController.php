<?php

declare(strict_types=1);

namespace App\Modules\Integrations\Controllers;

use App\Controllers\BaseController;
use App\Modules\Setting\Services\SettingService;
use CodeIgniter\HTTP\ResponseInterface;

/**
 * IntegrationsController — Notifikasi (SMTP/Slack) & Integrasi (webhook/API/Jira).
 * Admin. Nilai rahasia (sandi/token) disimpan terenkripsi via SettingService.
 */
final class IntegrationsController extends BaseController
{
    /** field => is_secret */
    private const FIELDS = [
        'notif.smtp_host' => false, 'notif.smtp_port' => false, 'notif.smtp_user' => false,
        'notif.smtp_pass' => true, 'notif.smtp_from' => false, 'notif.slack_webhook' => false,
        'integ.webhook_url' => false, 'integ.jira_url' => false, 'integ.jira_user' => false,
        'integ.jira_token' => true,
    ];

    public function __construct(private readonly SettingService $s = new SettingService())
    {
    }

    public function index(): string
    {
        $vals = [];
        foreach (array_keys(self::FIELDS) as $k) {
            $vals[$k] = (string) $this->s->get($k, '');
        }

        return $this->adminView('App\Modules\Integrations\Views\index', [
            'title' => 'Integrasi & Notifikasi',
            'v'     => $vals,
        ], 'integrations');
    }

    public function save(): ResponseInterface
    {
        foreach (self::FIELDS as $k => $secret) {
            $post = $this->request->getPost(str_replace('.', '_', $k));
            // Field rahasia: kosong = jangan ubah (biar tak menimpa dgn kosong).
            if ($secret && ($post === null || $post === '')) {
                continue;
            }
            $this->s->set($k, (string) $post, $secret);
        }

        return $this->ok(['message' => 'Tersimpan.']);
    }
}
