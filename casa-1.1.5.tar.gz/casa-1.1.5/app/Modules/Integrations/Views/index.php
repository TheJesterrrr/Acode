<?= $this->extend('layouts/admin') ?>
<?= $this->section('content') ?>
<?php
/** @var array $v */
$secretPh = static fn (string $val): string => $val !== '' ? '•••• (tersimpan — isi untuk mengganti)' : '';
?>
<div class="casa-page-head"><h1 class="h4 mb-0"><i class="bi bi-plug me-1"></i>Integrasi &amp; Notifikasi</h1></div>

<form id="intForm">
<div class="row g-3">
  <!-- Notifikasi -->
  <div class="col-lg-6">
    <div class="casa-card p-4 h-100">
      <h2 class="h6 mb-3"><i class="bi bi-bell me-1"></i>Notifikasi</h2>
      <h3 class="small text-muted text-uppercase">Email (SMTP)</h3>
      <div class="row g-2 mb-2">
        <div class="col-8"><label class="form-label small">SMTP Host</label><input name="notif_smtp_host" class="form-control form-control-sm" value="<?= esc($v['notif.smtp_host']) ?>" placeholder="smtp.gmail.com"></div>
        <div class="col-4"><label class="form-label small">Port</label><input name="notif_smtp_port" class="form-control form-control-sm" value="<?= esc($v['notif.smtp_port']) ?>" placeholder="587"></div>
        <div class="col-6"><label class="form-label small">Username</label><input name="notif_smtp_user" class="form-control form-control-sm" value="<?= esc($v['notif.smtp_user']) ?>"></div>
        <div class="col-6"><label class="form-label small">Password</label><input name="notif_smtp_pass" type="password" class="form-control form-control-sm" placeholder="<?= esc($secretPh($v['notif.smtp_pass'])) ?>"></div>
        <div class="col-12"><label class="form-label small">From</label><input name="notif_smtp_from" class="form-control form-control-sm" value="<?= esc($v['notif.smtp_from']) ?>" placeholder="no-reply@domain.com"></div>
      </div>
      <h3 class="small text-muted text-uppercase mt-3">Slack</h3>
      <label class="form-label small">Webhook URL</label>
      <input name="notif_slack_webhook" class="form-control form-control-sm" value="<?= esc($v['notif.slack_webhook']) ?>" placeholder="https://hooks.slack.com/services/…">
    </div>
  </div>
  <!-- Integrasi -->
  <div class="col-lg-6">
    <div class="casa-card p-4 h-100">
      <h2 class="h6 mb-3"><i class="bi bi-diagram-3 me-1"></i>Integrasi</h2>
      <h3 class="small text-muted text-uppercase">Webhook keluar</h3>
      <label class="form-label small">URL webhook (temuan baru dikirim ke sini)</label>
      <input name="integ_webhook_url" class="form-control form-control-sm mb-3" value="<?= esc($v['integ.webhook_url']) ?>" placeholder="https://…">
      <h3 class="small text-muted text-uppercase">Jira</h3>
      <div class="row g-2">
        <div class="col-12"><label class="form-label small">Base URL</label><input name="integ_jira_url" class="form-control form-control-sm" value="<?= esc($v['integ.jira_url']) ?>" placeholder="https://you.atlassian.net"></div>
        <div class="col-6"><label class="form-label small">User/Email</label><input name="integ_jira_user" class="form-control form-control-sm" value="<?= esc($v['integ.jira_user']) ?>"></div>
        <div class="col-6"><label class="form-label small">API Token</label><input name="integ_jira_token" type="password" class="form-control form-control-sm" placeholder="<?= esc($secretPh($v['integ.jira_token'])) ?>"></div>
      </div>
    </div>
  </div>
</div>
<div class="mt-3"><button class="btn btn-primary" id="intBtn"><i class="bi bi-save me-1"></i>Save</button><span id="intMsg" class="small ms-2"></span></div>
</form>
<?= $this->endSection() ?>

<?= $this->section('page_scripts') ?>
<script>
document.getElementById('intForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const b = document.getElementById('intBtn'), m = document.getElementById('intMsg'); b.disabled = true;
  const d = await casaPost('<?= esc(site_url('casaadmin/integrations/save')) ?>', new FormData(e.target));
  b.disabled = false;
  m.className = 'small ms-2 ' + (d.ok ? 'text-success' : 'text-danger');
  m.textContent = d.ok ? (d.message || 'Tersimpan.') : (d.error || 'Gagal.');
});
</script>
<?= $this->endSection() ?>
