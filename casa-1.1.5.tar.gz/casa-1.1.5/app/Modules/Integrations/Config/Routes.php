<?php

declare(strict_types=1);

use CodeIgniter\Router\RouteCollection;

/** Rute Integrasi & Notifikasi (admin). */

/** @var RouteCollection $routes */
$routes->group('casaadmin/integrations', ['namespace' => 'App\Modules\Integrations\Controllers', 'filter' => 'admin'], static function (RouteCollection $routes): void {
    $routes->get('', 'IntegrationsController::index');
    $routes->post('save', 'IntegrationsController::save', ['filter' => 'audit:INTEGRATIONS_SAVE']);
});
