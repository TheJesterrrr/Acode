<?php

declare(strict_types=1);

use CodeIgniter\Router\RouteCollection;

/** Rute modul Finding — endpoint MEMBER (CES 13.10). */

/** @var RouteCollection $routes */
$routes->group('', ['namespace' => 'App\Modules\Finding\Controllers', 'filter' => 'member'], static function (RouteCollection $routes): void {
    $routes->get('projects/(:num)/findings', 'FindingController::index/$1');
    $routes->get('findings/(:num)',          'FindingController::show/$1');
    $routes->post('findings/(:num)/howto',   'FindingController::howto/$1');
});
