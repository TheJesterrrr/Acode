<?php

declare(strict_types=1);

namespace App\Modules\Finding\Services;

use App\Modules\Ai\Services\AiManager;
use App\Modules\Finding\Models\FindingModel;
use App\Modules\Project\Models\ProjectModel;
use RuntimeException;
use Throwable;

/**
 * FindingService — pintu tunggal Finding (CES 13.4). Menerima hasil ternormalisasi
 * dari Adapter (via Engine), menyimpan sebagai temuan, dan memvalidasi dengan AI
 * (False-Positive Validator) — Master Plan §4/§5, Kitab BAB V 5.2.
 */
final class FindingService
{
    private const SYS_VALIDATE = 'You are a penetration-test false-positive validator. '
        . 'Given one raw scanner finding, answer STRICT JSON only: '
        . '{"verdict":"confirmed|likely|false_positive|needs_review","severity":"crit|high|med|low|info","reason":string}. '
        . 'Be conservative: mark false_positive only when clearly not exploitable.';

    private const SYS_HOWTO = 'You are a senior penetration tester and bug-bounty hunter. '
        . 'Given ONE security finding, explain concretely HOW to MANUALLY verify or exploit it. '
        . 'Output short NUMBERED steps (max 8): what to check, exact requests/params to manipulate, '
        . 'how to use Burp Suite (Repeater/Intruder) for it, and what result CONFIRMS it is real vs a false positive. '
        . 'If the finding is low-value/informational, say so in ONE line, then suggest a higher-value angle on the SAME asset '
        . '(e.g. IDOR, auth bypass, business-logic flaw) and how to test it. Be specific and practical. '
        . 'No preamble, no markdown headings, plain numbered text.';

    /**
     * Bangkitkan panduan "cara uji/exploit" temuan via AI (on-demand, role vuln_analyst).
     * Disimpan di kolom ai_howto; dipakai ulang kecuali $regenerate.
     */
    public function howToVerify(int $id, int $customerId, bool $regenerate = false): string
    {
        $f = $this->get($id, $customerId); // sekaligus cek kepemilikan
        $cached = trim((string) ($f['ai_howto'] ?? ''));
        if (! $regenerate && $cached !== '') {
            return $cached;
        }
        $ctx = "Finding: {$f['title']}\nSeverity: {$f['severity']}\nAsset: " . ($f['asset'] ?? '-') . "\n"
            . 'Tool: ' . ($f['tool'] ?? '-') . "\nCWE: " . ($f['cwe'] ?? '-') . '  OWASP: ' . ($f['owasp'] ?? '-') . "\n"
            . 'Detail: ' . mb_substr((string) ($f['description'] ?? ''), 0, 800);
        $out = trim($this->ai->chatForRole('vuln_analyst', self::SYS_HOWTO, $ctx));
        if ($out !== '') {
            $this->findings->update($id, ['ai_howto' => $out]);
        }

        return $out;
    }

    /** True bila fitur AMD "cara uji (AI)" siap (provider vuln_analyst aktif). */
    public function aiReady(): bool
    {
        return $this->ai->readyForRole('vuln_analyst');
    }

    /**
     * Ambil panduan PoC/exploit manual (`ai_howto`) untuk dipakai di REPORT.
     * Dipanggil ReportService untuk temuan Critical/High. Berbeda dari howToVerify():
     * menerima baris finding apa adanya (tanpa cek kepemilikan — report sudah
     * terotorisasi) dan best-effort: bila `ai_howto` kosong & AI siap, bangkitkan
     * lalu simpan; bila AI mati/gagal, kembalikan '' (report pakai fallback generik).
     */
    public function howtoForReport(array $f): string
    {
        $cached = trim((string) ($f['ai_howto'] ?? ''));
        if ($cached !== '') {
            return $cached;
        }
        if (! $this->aiReady()) {
            return '';
        }
        try {
            $ctx = "Finding: {$f['title']}\nSeverity: {$f['severity']}\nAsset: " . ($f['asset'] ?? '-') . "\n"
                . 'Tool: ' . ($f['tool'] ?? '-') . "\nCWE: " . ($f['cwe'] ?? '-') . '  OWASP: ' . ($f['owasp'] ?? '-') . "\n"
                . 'Detail: ' . mb_substr((string) ($f['description'] ?? ''), 0, 800);
            $out = trim($this->ai->chatForRole('vuln_analyst', self::SYS_HOWTO, $ctx));
            if ($out !== '' && ! empty($f['id'])) {
                $this->findings->update((int) $f['id'], ['ai_howto' => $out]);
            }

            return $out;
        } catch (Throwable $e) {
            return '';
        }
    }

    public function __construct(
        private readonly FindingModel $findings = new FindingModel(),
        private readonly ProjectModel $projects = new ProjectModel(),
        private readonly AiManager $ai = new AiManager(),
    ) {
    }

    /** Rekam temuan dari hasil ternormalisasi. Mengembalikan id. */
    public function record(array $data): int
    {
        $cwe = $data['cwe'] ?? null;
        $id  = (int) $this->findings->insert([
            'project_id'  => (int) $data['project_id'],
            'mission_id'  => $data['mission_id'] ?? null,
            'title'       => mb_substr((string) $data['title'], 0, 200),
            'severity'    => in_array($data['severity'] ?? 'info', ['crit', 'high', 'med', 'low', 'info'], true) ? $data['severity'] : 'info',
            'cvss'        => $data['cvss'] ?? null,
            'cwe'         => $cwe,
            'owasp'       => \App\Libraries\SecurityMap::owaspFor($cwe),
            'attack'      => \App\Libraries\SecurityMap::attackFor($cwe),
            'category'    => $data['category'] ?? null,
            'asset'       => $data['asset'] ?? null,
            'tool'        => $data['tool'] ?? null,
            'description' => $data['description'] ?? null,
            'evidence'    => $data['evidence'] ?? null,
            'remediation' => $data['remediation'] ?? null,
            'status'      => 'new',
        ], true);
        $this->findings->update($id, ['ref' => 'CASA-' . str_pad((string) $id, 4, '0', STR_PAD_LEFT)]);

        return $id;
    }

    /**
     * Validasi satu temuan dengan AI (False-Positive Validator). Aman: bila AI
     * gagal, temuan tetap 'triage' (tidak menggagalkan mission).
     */
    public function validateWithAI(int $findingId): void
    {
        $f = $this->findings->find($findingId);
        if ($f === null) {
            return;
        }
        $user = "Finding: {$f['title']}\nSeverity(raw): {$f['severity']}\nAsset: {$f['asset']}\nTool: {$f['tool']}\nDetail: " . mb_substr((string) $f['description'], 0, 500);
        try {
            $raw = $this->ai->chatForRole('fp_validator', self::SYS_VALIDATE, $user);
            $j   = null;
            if (preg_match('/\{.*\}/s', $raw, $m)) {
                $j = json_decode($m[0], true);
            }
            $verdict  = is_array($j) ? (string) ($j['verdict'] ?? 'needs_review') : 'needs_review';
            $severity = is_array($j) && in_array($j['severity'] ?? '', ['crit', 'high', 'med', 'low', 'info'], true) ? $j['severity'] : $f['severity'];
            $status   = match ($verdict) {
                'confirmed'      => 'validated',
                'false_positive' => 'false_positive',
                default          => 'triage',
            };
            $this->findings->update($findingId, ['ai_verdict' => $verdict, 'status' => $status, 'severity' => $severity]);
        } catch (Throwable $e) {
            $this->findings->update($findingId, ['status' => 'triage', 'ai_verdict' => 'needs_review']);
        }
    }

    public function listForProject(int $projectId, int $customerId): array
    {
        $this->requireOwned($projectId, $customerId);

        return $this->findings->forProject($projectId);
    }

    public function counts(int $projectId): array
    {
        return $this->findings->severityCounts($projectId);
    }

    public function get(int $id, int $customerId): array
    {
        $f = $this->findings->find($id);
        if ($f === null) {
            throw new RuntimeException('Temuan tidak ditemukan.');
        }
        $this->requireOwned((int) $f['project_id'], $customerId);

        return $f;
    }

    private function requireOwned(int $projectId, int $customerId): void
    {
        if ($this->projects->ownedBy($projectId, $customerId) === null) {
            throw new RuntimeException('Project tidak ditemukan.');
        }
    }
}
