<?php

declare(strict_types=1);

namespace App\Modules\Finding\Models;

use CodeIgniter\Model;

/** FindingModel — tabel `finding` (CES 13.3). */
final class FindingModel extends Model
{
    protected $table         = 'finding';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $useTimestamps = false;
    protected $allowedFields = [
        'project_id', 'mission_id', 'ref', 'title', 'severity', 'cvss', 'cwe',
        'owasp', 'attack',
        'category', 'asset', 'tool', 'description', 'evidence', 'remediation',
        'status', 'ai_verdict', 'ai_howto',
        'remediation_status', 'assignee', 'triage_note',
        'excluded', 'vrt',
    ];

    /** Status remediasi yang sah (Vulnerability Management board). */
    public const REM_STATUSES = ['open', 'in_progress', 'fixed', 'risk_accepted', 'false_positive'];

    private const ORDER = "FIELD(severity,'crit','high','med','low','info')";

    /**
     * Temuan milik pelanggan lintas project (untuk Vuln Management board).
     * @return array<int,array<string,mixed>>
     */
    public function forCustomer(int $customerId, array $f = []): array
    {
        $b = $this->select('finding.*, project.name AS project_name')
            ->join('project', 'project.id = finding.project_id')
            ->where('project.customer_id', $customerId)
            ->where('project.deleted_at', null);
        if (! empty($f['severity'])) {
            $b->where('finding.severity', $f['severity']);
        }
        if (! empty($f['rstatus'])) {
            $b->where('finding.remediation_status', $f['rstatus']);
        }
        if (! empty($f['q'])) {
            $b->groupStart()->like('finding.title', $f['q'])->orLike('finding.asset', $f['q'])->orLike('finding.cwe', $f['q'])->groupEnd();
        }

        return $b->orderBy(self::ORDER, '', false)->orderBy('finding.id', 'DESC')->findAll(2000);
    }

    /** Hitung temuan per status remediasi milik pelanggan. @return array<string,int> */
    public function remediationCounts(int $customerId): array
    {
        $out = array_fill_keys(self::REM_STATUSES, 0);
        $rows = $this->select('finding.remediation_status AS s, COUNT(*) AS n')
            ->join('project', 'project.id = finding.project_id')
            ->where('project.customer_id', $customerId)
            ->where('project.deleted_at', null)
            ->groupBy('finding.remediation_status')
            ->findAll();
        foreach ($rows as $r) {
            $out[(string) ($r['s'] ?: 'open')] = (int) $r['n'];
        }

        return $out;
    }

    /** Agregasi OWASP × severity milik pelanggan (untuk Compliance). @return array<int,array<string,mixed>> */
    public function owaspBySeverity(int $customerId): array
    {
        return $this->select('finding.owasp o, finding.severity s, COUNT(*) n')
            ->join('project', 'project.id = finding.project_id')
            ->where('project.customer_id', $customerId)
            ->where('project.deleted_at', null)
            ->where('finding.owasp IS NOT NULL')
            ->where('finding.owasp !=', '')
            ->groupBy('finding.owasp')->groupBy('finding.severity')
            ->findAll();
    }

    /** Top CWE milik pelanggan. @return array<int,array<string,mixed>> */
    public function cweTop(int $customerId): array
    {
        return $this->select('finding.cwe c, COUNT(*) n')
            ->join('project', 'project.id = finding.project_id')
            ->where('project.customer_id', $customerId)
            ->where('project.deleted_at', null)
            ->where('finding.cwe IS NOT NULL')
            ->where('finding.cwe !=', '')
            ->groupBy('finding.cwe')->orderBy('n', 'DESC')
            ->findAll(12);
    }

    /** Ambil satu temuan HANYA bila milik pelanggan (RBAC per objek). */
    public function ownedBy(int $id, int $customerId): ?array
    {
        return $this->select('finding.*')
            ->join('project', 'project.id = finding.project_id')
            ->where('finding.id', $id)
            ->where('project.customer_id', $customerId)
            ->first();
    }

    public function forProject(int $projectId): array
    {
        return $this->where('project_id', $projectId)->orderBy(self::ORDER, '', false)->orderBy('id', 'DESC')->findAll();
    }

    public function forMission(int $missionId): array
    {
        return $this->where('mission_id', $missionId)->orderBy(self::ORDER, '', false)->findAll();
    }

    /** @return array<string,int> severity => jumlah */
    public function severityCounts(int $projectId): array
    {
        $out = ['crit' => 0, 'high' => 0, 'med' => 0, 'low' => 0, 'info' => 0];
        foreach ($this->select('severity, COUNT(*) c')->where('project_id', $projectId)->groupBy('severity')->findAll() as $r) {
            $out[$r['severity']] = (int) $r['c'];
        }

        return $out;
    }

    /** Hitung temuan per severity untuk SATU mission. @return array<string,int> */
    public function severityCountsByMission(int $missionId): array
    {
        $out = ['crit' => 0, 'high' => 0, 'med' => 0, 'low' => 0, 'info' => 0];
        foreach ($this->select('severity, COUNT(*) c')->where('mission_id', $missionId)->groupBy('severity')->findAll() as $r) {
            if (isset($out[$r['severity']])) {
                $out[$r['severity']] = (int) $r['c'];
            }
        }

        return $out;
    }

    /**
     * Severity per tool untuk satu mission → peta tool_code => [crit,high,med,low,info].
     * Dipakai kolom "Temuan" di detail Mission (breakdown per baris tool).
     * @return array<string,array<string,int>>
     */
    public function severityByMissionTool(int $missionId): array
    {
        $out = [];
        foreach ($this->select('tool, severity, COUNT(*) c')->where('mission_id', $missionId)->groupBy('tool')->groupBy('severity')->findAll() as $r) {
            $t = (string) ($r['tool'] ?? '');
            if (! isset($out[$t])) {
                $out[$t] = ['crit' => 0, 'high' => 0, 'med' => 0, 'low' => 0, 'info' => 0];
            }
            if (isset($out[$t][$r['severity']])) {
                $out[$t][$r['severity']] = (int) $r['c'];
            }
        }

        return $out;
    }
}
