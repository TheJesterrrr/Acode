<?php

declare(strict_types=1);

namespace App\Modules\Finding\Database\Migrations;

use CodeIgniter\Database\Migration;

/**
 * Vulnerability Management — kolom triase remediasi pada `finding`.
 * Terpisah dari kolom `status` (yang dipakai lifecycle validasi AI) agar tak
 * bentrok: `remediation_status` = alur perbaikan (open→in_progress→fixed→…).
 */
final class AddFindingTriage extends Migration
{
    public function up(): void
    {
        if ($this->db->fieldExists('remediation_status', 'finding')) {
            return;
        }
        $this->forge->addColumn('finding', [
            'remediation_status' => ['type' => 'VARCHAR', 'constraint' => 20, 'default' => 'open', 'after' => 'status'],
            'assignee'           => ['type' => 'VARCHAR', 'constraint' => 120, 'null' => true, 'after' => 'remediation_status'],
            'triage_note'        => ['type' => 'TEXT', 'null' => true, 'after' => 'assignee'],
        ]);
        $this->db->query('CREATE INDEX idx_finding_remstatus ON ' . $this->db->prefixTable('finding') . ' (remediation_status)');
    }

    public function down(): void
    {
        if ($this->db->fieldExists('remediation_status', 'finding')) {
            $this->forge->dropColumn('finding', ['remediation_status', 'assignee', 'triage_note']);
        }
    }
}
