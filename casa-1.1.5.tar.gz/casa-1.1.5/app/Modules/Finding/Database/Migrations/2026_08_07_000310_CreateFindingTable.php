<?php

declare(strict_types=1);

namespace App\Modules\Finding\Database\Migrations;

use CodeIgniter\Database\Migration;
use CodeIgniter\Database\RawSql;

/**
 * Tabel `finding` — temuan ternormalisasi (Master Plan §5). Diisi dari hasil
 * Adapter/Parser; divalidasi AI. Tertaut ke CWE/CVSS (Kitab BAB V 5.2).
 */
final class CreateFindingTable extends Migration
{
    public function up(): void
    {
        $this->forge->addField([
            'id'          => ['type' => 'BIGINT', 'unsigned' => true, 'auto_increment' => true],
            'project_id'  => ['type' => 'BIGINT', 'unsigned' => true],
            'mission_id'  => ['type' => 'BIGINT', 'unsigned' => true, 'null' => true],
            'ref'         => ['type' => 'VARCHAR', 'constraint' => 20, 'null' => true], // mis. CASA-0417
            'title'       => ['type' => 'VARCHAR', 'constraint' => 200],
            'severity'    => ['type' => 'VARCHAR', 'constraint' => 8, 'default' => 'info'], // crit|high|med|low|info
            'cvss'        => ['type' => 'VARCHAR', 'constraint' => 6, 'null' => true],
            'cwe'         => ['type' => 'VARCHAR', 'constraint' => 16, 'null' => true],
            'category'    => ['type' => 'VARCHAR', 'constraint' => 40, 'null' => true],
            'asset'       => ['type' => 'VARCHAR', 'constraint' => 200, 'null' => true],
            'tool'        => ['type' => 'VARCHAR', 'constraint' => 40, 'null' => true],
            'description' => ['type' => 'TEXT', 'null' => true],
            'evidence'    => ['type' => 'TEXT', 'null' => true],
            'remediation' => ['type' => 'TEXT', 'null' => true],
            'status'      => ['type' => 'VARCHAR', 'constraint' => 16, 'default' => 'new'], // new|validated|false_positive|triage
            'ai_verdict'  => ['type' => 'VARCHAR', 'constraint' => 40, 'null' => true],
            'created_at'  => ['type' => 'TIMESTAMP', 'default' => new RawSql('CURRENT_TIMESTAMP')],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey('project_id');
        $this->forge->addKey('mission_id');
        $this->forge->createTable('finding', true, ['ENGINE' => 'InnoDB', 'DEFAULT CHARSET' => 'utf8mb4', 'COLLATE' => 'utf8mb4_unicode_ci']);
    }

    public function down(): void
    {
        $this->forge->dropTable('finding', true);
    }
}
