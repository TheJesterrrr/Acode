<?php

declare(strict_types=1);

namespace App\Modules\Finding\Database\Migrations;

use CodeIgniter\Database\Migration;

/** Tambah kolom pemetaan standar OWASP Top 10 & MITRE ATT&CK pada `finding` (Kitab 5.2). */
final class AddFindingOwaspAttack extends Migration
{
    public function up(): void
    {
        $add = [];
        if (! $this->db->fieldExists('owasp', 'finding')) {
            $add['owasp'] = ['type' => 'VARCHAR', 'constraint' => 60, 'null' => true, 'after' => 'cwe'];
        }
        if (! $this->db->fieldExists('attack', 'finding')) {
            $add['attack'] = ['type' => 'VARCHAR', 'constraint' => 60, 'null' => true, 'after' => 'owasp'];
        }
        if ($add !== []) {
            $this->forge->addColumn('finding', $add);
        }
    }

    public function down(): void
    {
        foreach (['owasp', 'attack'] as $c) {
            if ($this->db->fieldExists($c, 'finding')) {
                $this->forge->dropColumn('finding', $c);
            }
        }
    }
}
