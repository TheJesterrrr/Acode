<?php

declare(strict_types=1);

namespace App\Modules\Finding\Database\Migrations;

use CodeIgniter\Database\Migration;

/** Tambah kolom ai_howto: panduan "cara uji/exploit" temuan yang dibangkitkan AI (on-demand). */
final class AddFindingAiHowto extends Migration
{
    public function up(): void
    {
        if (! $this->db->fieldExists('ai_howto', 'finding')) {
            $this->forge->addColumn('finding', [
                'ai_howto' => ['type' => 'TEXT', 'null' => true, 'after' => 'ai_verdict'],
            ]);
        }
    }

    public function down(): void
    {
        if ($this->db->fieldExists('ai_howto', 'finding')) {
            $this->forge->dropColumn('finding', 'ai_howto');
        }
    }
}
