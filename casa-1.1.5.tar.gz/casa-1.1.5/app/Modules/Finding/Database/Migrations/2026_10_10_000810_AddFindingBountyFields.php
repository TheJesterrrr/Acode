<?php

declare(strict_types=1);

namespace App\Modules\Finding\Database\Migrations;

use CodeIgniter\Database\Migration;

/** Tambah `excluded` + `vrt` pada `finding` untuk workflow bug bounty. */
final class AddFindingBountyFields extends Migration
{
    public function up(): void
    {
        $cols = [];
        if (! $this->db->fieldExists('excluded', 'finding')) {
            $cols['excluded'] = ['type' => 'TINYINT', 'constraint' => 1, 'default' => 0, 'after' => 'status']; // known-issue/excluded program
        }
        if (! $this->db->fieldExists('vrt', 'finding')) {
            $cols['vrt'] = ['type' => 'VARCHAR', 'constraint' => 10, 'null' => true, 'after' => 'cwe']; // Bugcrowd VRT P1-P5
        }
        if ($cols !== []) {
            $this->forge->addColumn('finding', $cols);
        }
    }

    public function down(): void
    {
        foreach (['excluded', 'vrt'] as $c) {
            if ($this->db->fieldExists($c, 'finding')) {
                $this->forge->dropColumn('finding', $c);
            }
        }
    }
}
