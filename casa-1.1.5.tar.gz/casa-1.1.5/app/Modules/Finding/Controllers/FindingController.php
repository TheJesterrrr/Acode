<?php

declare(strict_types=1);

namespace App\Modules\Finding\Controllers;

use App\Controllers\BaseController;
use App\Modules\Finding\Services\FindingService;
use App\Modules\Project\Models\ProjectModel;
use CodeIgniter\Exceptions\PageNotFoundException;
use RuntimeException;

/** FindingController — daftar/detail temuan milik member (CES 13.2 thin). */
final class FindingController extends BaseController
{
    public function __construct(
        private readonly FindingService $findings = new FindingService(),
        private readonly ProjectModel $projects = new ProjectModel(),
    ) {
    }

    private function me(): int
    {
        return (int) $this->session->get('member_id');
    }

    public function index(int $projectId): string
    {
        $project = $this->projects->ownedBy($projectId, $this->me());
        if ($project === null) {
            throw PageNotFoundException::forPageNotFound('Project tidak ditemukan.');
        }

        return $this->memberView('App\Modules\Finding\Views\index', [
            'title'    => 'Findings — ' . $project['name'],
            'project'  => $project,
            'findings' => $this->findings->listForProject($projectId, $this->me()),
            'counts'   => $this->findings->counts($projectId),
        ], 'projects');
    }

    public function show(int $id): string
    {
        try {
            $finding = $this->findings->get($id, $this->me());
        } catch (RuntimeException $e) {
            throw PageNotFoundException::forPageNotFound($e->getMessage());
        }

        return $this->memberView('App\Modules\Finding\Views\show', [
            'title'   => $finding['ref'] . ' — ' . $finding['title'],
            'finding' => $finding,
            'aiOn'    => $this->findings->aiReady(),
        ], 'projects');
    }

    /** AJAX: bangkitkan panduan "cara uji/exploit" temuan via AI. */
    public function howto(int $id): \CodeIgniter\HTTP\ResponseInterface
    {
        if ($r = $this->denyViewer()) {
            return $r;
        }
        $regen = (bool) $this->request->getPost('regenerate');
        try {
            $text = $this->findings->howToVerify($id, $this->me(), $regen);
        } catch (\Throwable $e) {
            // Termasuk saat AI belum dikonfigurasi (instance baru) — jangan 500.
            return $this->fail($e->getMessage());
        }
        if (trim($text) === '') {
            return $this->fail('AI tidak mengembalikan panduan. Coba lagi.');
        }

        return $this->ok(['text' => $text]);
    }
}
