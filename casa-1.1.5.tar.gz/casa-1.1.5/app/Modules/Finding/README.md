# Modul Finding
Temuan ternormalisasi (Master Plan §5; Kitab BAB V 5.2 — tautan CWE/CVSS).
- `Models/FindingModel` — tabel `finding` (severity/cwe/cvss/status/ai_verdict).
- `Services/FindingService` — `record()` dari hasil Adapter; `validateWithAI()` (False-Positive Validator via AiManager::chatForRole).
- `Controllers/FindingController` (member) + Views list/detail. Rute `projects/(:num)/findings`, `findings/(:num)`.
Di-scope kepemilikan project (member hanya miliknya).
