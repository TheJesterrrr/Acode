<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<?php
/** @var array $finding */
$sev = ['crit' => ['CRITICAL', 'danger'], 'high' => ['HIGH', 'warning'], 'med' => ['MEDIUM', 'info'], 'low' => ['LOW', 'primary'], 'info' => ['INFO', 'secondary']];
[$lbl, $c] = $sev[$finding['severity']] ?? ['INFO', 'secondary'];
// Ekstrak CVE dari teks temuan (deteksi & analisa lebih detail).
$cveText = ($finding['title'] ?? '') . ' ' . ($finding['ref'] ?? '') . ' ' . ($finding['description'] ?? '') . ' ' . ($finding['evidence'] ?? '');
preg_match_all('/CVE-\d{4}-\d{4,7}/i', (string) $cveText, $cm);
$cves   = array_values(array_unique(array_map('strtoupper', $cm[0])));
$cweNum = preg_match('/CWE-(\d+)/i', (string) ($finding['cwe'] ?? ''), $wm) ? $wm[1] : null;
?>
<div class="casa-page-head">
  <a href="<?= esc(site_url('projects/' . $finding['project_id'] . '/findings')) ?>" class="small text-muted text-decoration-none"><i class="bi bi-arrow-left"></i> Findings</a>
  <h1 class="mb-0"><?= esc($finding['title']) ?></h1>
  <div class="d-flex flex-wrap gap-2 mt-2">
    <span class="badge text-bg-<?= $c ?>"><?= $lbl ?></span>
    <?php if ($finding['cvss']): ?><span class="badge text-bg-light border font-monospace">CVSS <?= esc($finding['cvss']) ?></span><?php endif; ?>
    <?php if ($finding['cwe']): ?><span class="badge text-bg-light border font-monospace"><?= esc($finding['cwe']) ?></span><?php endif; ?>
    <?php $fOwasp = $finding['owasp'] ?: \App\Libraries\SecurityMap::owaspFor($finding['cwe'] ?? null);
    $fAttack = $finding['attack'] ?: \App\Libraries\SecurityMap::attackFor($finding['cwe'] ?? null); ?>
    <?php if ($fOwasp): ?><span class="badge text-bg-warning" title="OWASP Top 10 2021"><i class="bi bi-shield-exclamation me-1"></i><?= esc($fOwasp) ?></span><?php endif; ?>
    <?php if ($fAttack): ?><span class="badge text-bg-dark border" title="MITRE ATT&CK"><?= esc($fAttack) ?></span><?php endif; ?>
    <?php if ($finding['category']): ?><span class="badge text-bg-light border"><?= esc($finding['category']) ?></span><?php endif; ?>
    <span class="badge text-bg-<?= $finding['status'] === 'validated' ? 'success' : 'light text-dark border' ?>"><?= esc($finding['status']) ?><?= $finding['ai_verdict'] ? ' · AI: ' . esc($finding['ai_verdict']) : '' ?></span>
    <?php foreach ($cves as $cve): ?>
      <a class="badge text-bg-danger text-decoration-none" href="https://nvd.nist.gov/vuln/detail/<?= esc($cve) ?>" target="_blank" rel="noopener" title="View on NVD"><i class="bi bi-bug me-1"></i><?= esc($cve) ?></a>
    <?php endforeach; ?>
  </div>
</div>

<div class="row g-3">
  <div class="col-lg-8">
    <div class="casa-card p-3 p-lg-4">
      <h2 class="h6">Deskripsi</h2>
      <p class="small" style="white-space:pre-wrap"><?= esc($finding['description'] ?? '—') ?></p>
      <h2 class="h6 mt-4">Evidence</h2>
      <pre class="bg-body-secondary p-3 rounded small" style="white-space:pre-wrap"><?= esc($finding['evidence'] ?? '—') ?></pre>
      <?php if ($finding['remediation']): ?>
        <h2 class="h6 mt-4">Remediation</h2>
        <p class="small" style="white-space:pre-wrap"><?= esc($finding['remediation']) ?></p>
      <?php endif; ?>
    </div>
    <?php /** @var bool $aiOn */ ?>
    <div class="casa-card p-3 p-lg-4 mt-3">
      <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
        <h2 class="h6 mb-0"><i class="bi bi-robot me-1 text-info"></i>Cara uji &amp; exploit <span class="badge text-bg-info align-middle">AI</span></h2>
        <?php if ($aiOn): ?>
          <button id="howtoBtn" class="btn btn-sm btn-outline-info"><i class="bi bi-magic me-1"></i><?= $finding['ai_howto'] ? 'Update' : 'Generate guide' ?></button>
        <?php endif; ?>
      </div>
      <?php if (! $aiOn): ?>
        <p class="small text-muted mb-0 mt-2"><i class="bi bi-info-circle me-1"></i>AI belum terhubung. Aktifkan provider di <b>AI Settings</b> untuk panduan uji otomatis.</p>
      <?php else: ?>
        <div id="howtoMsg" class="small text-muted mt-2"><?= $finding['ai_howto'] ? 'Panduan AI tersimpan — verifikasi manual sebelum lapor.' : 'Klik untuk minta langkah verifikasi/exploit (Burp, IDOR, dll) dari AI.' ?></div>
        <div id="howtoBox" class="small mt-2 p-2 rounded bg-body-secondary" style="white-space:pre-wrap;<?= $finding['ai_howto'] ? '' : 'display:none' ?>"><?= esc($finding['ai_howto'] ?? '') ?></div>
      <?php endif; ?>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="casa-card p-3 p-lg-4">
      <div class="small"><span class="text-muted">Ref</span><div class="font-monospace mb-2"><?= esc($finding['ref']) ?></div>
        <span class="text-muted">Asset</span><div class="font-monospace mb-2"><?= esc($finding['asset'] ?? '—') ?></div>
        <span class="text-muted">Tool</span><div class="font-monospace mb-2"><?= esc(\App\Libraries\ToolLabel::show($finding['tool'] ?? null) ?: '—') ?></div>
        <span class="text-muted">Ditemukan</span><div class="font-monospace"><?= esc($finding['created_at']) ?></div>
      </div>
    </div>
    <div class="casa-card p-3 p-lg-4 mt-3">
      <h2 class="h6 mb-2"><i class="bi bi-link-45deg me-1"></i>Referensi</h2>
      <?php $attackId = preg_match('/T\d{4}(?:\.\d{3})?/', (string) $fAttack, $am) ? $am[0] : null; ?>
      <div class="d-flex flex-column gap-1 small">
        <?php foreach ($cves as $cve): ?>
          <a href="https://nvd.nist.gov/vuln/detail/<?= esc($cve) ?>" target="_blank" rel="noopener"><i class="bi bi-box-arrow-up-right me-1"></i><?= esc($cve) ?> · NVD</a>
        <?php endforeach; ?>
        <?php if ($cweNum): ?><a href="https://cwe.mitre.org/data/definitions/<?= esc($cweNum) ?>.html" target="_blank" rel="noopener"><i class="bi bi-box-arrow-up-right me-1"></i>CWE-<?= esc($cweNum) ?></a><?php endif; ?>
        <?php if ($fOwasp): ?><span class="text-muted"><i class="bi bi-shield-exclamation me-1"></i>OWASP <?= esc($fOwasp) ?></span><?php endif; ?>
        <?php if ($attackId): ?><a href="https://attack.mitre.org/techniques/<?= esc(str_replace('.', '/', $attackId)) ?>/" target="_blank" rel="noopener"><i class="bi bi-box-arrow-up-right me-1"></i>ATT&amp;CK <?= esc($attackId) ?></a><?php endif; ?>
        <?php if ($cves === [] && ! $cweNum && ! $fOwasp): ?><span class="text-muted">Tak ada referensi tertaut.</span><?php endif; ?>
      </div>
    </div>
  </div>
</div>
<?= $this->endSection() ?>
<?php if ($aiOn): ?>
<?= $this->section('page_scripts') ?>
<script>
const _hb = document.getElementById('howtoBtn');
if (_hb) _hb.addEventListener('click', async () => {
  const m = document.getElementById('howtoMsg'), box = document.getElementById('howtoBox'), o = _hb.innerHTML;
  const had = box.textContent.trim() !== '';
  _hb.disabled = true; _hb.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Menganalisa…';
  m.className = 'small text-muted mt-2'; m.textContent = 'AI menyusun langkah uji (bisa ~15–40 detik di CPU)…';
  const fd = new FormData(); if (had) fd.append('regenerate', '1');
  const d = await casaPost('<?= esc(site_url('findings/' . (int) $finding['id'] . '/howto')) ?>', fd);
  _hb.disabled = false; _hb.innerHTML = '<i class="bi bi-magic me-1"></i>Perbarui';
  if (d.ok) { box.style.display = ''; box.textContent = d.text; m.className = 'small text-success mt-2'; m.textContent = 'Panduan dari AI (vuln_analyst) — verifikasi manual sebelum lapor.'; }
  else { m.className = 'small text-danger mt-2'; m.textContent = d.error || 'Gagal.'; }
});
</script>
<?= $this->endSection() ?>
<?php endif; ?>
