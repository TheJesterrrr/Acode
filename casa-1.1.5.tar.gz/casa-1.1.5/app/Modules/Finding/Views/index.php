<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<?php
/** @var array $project @var array $findings @var array $counts */
$pid = (int) $project['id'];
$sev = ['crit' => ['CRITICAL', 'danger'], 'high' => ['HIGH', 'warning'], 'med' => ['MEDIUM', 'info'], 'low' => ['LOW', 'primary'], 'info' => ['INFO', 'secondary']];
?>
<div class="casa-page-head">
  <a href="<?= esc(site_url('projects/' . $pid)) ?>" class="small text-muted text-decoration-none"><i class="bi bi-arrow-left"></i> <?= esc($project['name']) ?></a>
  <h1 class="mb-0"><i class="bi bi-bug me-1"></i>Findings</h1>
  <p class="text-muted small mb-0">Temuan ternormalisasi &amp; divalidasi AI · tertaut CWE/CVSS (Kitab BAB V 5.2).</p>
</div>

<div class="d-flex flex-wrap gap-2 mb-3">
  <?php foreach ($sev as $k => [$lbl, $c]): ?>
    <span class="badge text-bg-<?= $c ?>"><?= $lbl ?>: <?= (int) ($counts[$k] ?? 0) ?></span>
  <?php endforeach; ?>
</div>

<div class="casa-card p-0">
  <div class="table-responsive">
    <table class="table align-middle mb-0">
      <thead><tr><th class="ps-3">Sev</th><th>Temuan</th><th>Kategori</th><th>CWE</th><th>Asset</th><th>CVSS</th><th>Status</th></tr></thead>
      <tbody>
        <?php foreach ($findings as $f): [$lbl, $c] = $sev[$f['severity']] ?? ['INFO', 'secondary']; ?>
          <tr style="cursor:pointer" onclick="location='<?= esc(site_url('findings/' . $f['id'])) ?>'">
            <td class="ps-3"><span class="badge text-bg-<?= $c ?>"><?= $lbl ?></span></td>
            <td><div class="fw-semibold"><?= esc($f['title']) ?></div><div class="small text-muted font-monospace"><?= esc($f['ref']) ?><?php $tl = \App\Libraries\ToolLabel::show($f['tool'] ?? null); ?><?= $tl !== '' ? ' · ' . esc($tl) : '' ?></div></td>
            <td class="small"><?= esc($f['category'] ?? '—') ?></td>
            <td class="small font-monospace"><?= esc($f['cwe'] ?? '—') ?></td>
            <td class="small font-monospace text-muted"><?= esc($f['asset'] ?? '—') ?></td>
            <td class="font-monospace"><?= esc($f['cvss'] ?? '—') ?></td>
            <td><span class="badge text-bg-<?= $f['status'] === 'validated' ? 'success' : ($f['status'] === 'false_positive' ? 'secondary' : 'light text-dark border') ?>"><?= esc($f['status']) ?></span></td>
          </tr>
        <?php endforeach; ?>
        <?php if ($findings === []): ?><tr><td colspan="7" class="text-muted text-center py-4">Belum ada temuan. Jalankan Mission untuk memindai.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?= $this->endSection() ?>
