# Modul Engine (casad)
Inti worker: antrean berbasis tabel + eksekusi. Worker "tidak berpikir":
Task→Run→Collect→Return (Master Plan §4). CI4 tanpa queue bawaan (Kitab 2.6).
- `Models/TaskModel` — tabel `task` (pending/running/done/error/skipped).
- `Services/EngineService` — `enqueue()`, `runPending()`; SETIAP eksekusi lewat
  gerbang `PolicyEngine::isToolAllowed()` (tak terpintas) → Adapter → FindingService.
- Command `casa:work` (app/Commands/CasaWork) dijalankan cron (flock).
