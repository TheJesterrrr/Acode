<?php

declare(strict_types=1);

namespace App\Modules\Engine\Database\Migrations;

use CodeIgniter\Database\Migration;
use CodeIgniter\Database\RawSql;

/**
 * Tabel `task` — unit kerja worker `casad` (Master Plan §5). Antrean berbasis
 * tabel (CI4 tanpa queue bawaan; Kitab 2.6/7.x). Worker: Task→Run→Collect→Return.
 */
final class CreateTaskTable extends Migration
{
    public function up(): void
    {
        $this->forge->addField([
            'id'             => ['type' => 'BIGINT', 'unsigned' => true, 'auto_increment' => true],
            'mission_id'     => ['type' => 'BIGINT', 'unsigned' => true],
            'project_id'     => ['type' => 'BIGINT', 'unsigned' => true],
            'tool_code'      => ['type' => 'VARCHAR', 'constraint' => 30],
            'target'         => ['type' => 'VARCHAR', 'constraint' => 255],
            'status'         => ['type' => 'VARCHAR', 'constraint' => 10, 'default' => 'pending'], // pending|running|done|error|skipped
            'findings_count' => ['type' => 'INT', 'constraint' => 6, 'default' => 0],
            'error'          => ['type' => 'VARCHAR', 'constraint' => 200, 'null' => true],
            'created_at'     => ['type' => 'TIMESTAMP', 'default' => new RawSql('CURRENT_TIMESTAMP')],
            'started_at'     => ['type' => 'TIMESTAMP', 'null' => true],
            'finished_at'    => ['type' => 'TIMESTAMP', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey(['status', 'id']);
        $this->forge->addKey('mission_id');
        $this->forge->createTable('task', true, ['ENGINE' => 'InnoDB', 'DEFAULT CHARSET' => 'utf8mb4', 'COLLATE' => 'utf8mb4_unicode_ci']);
    }

    public function down(): void
    {
        $this->forge->dropTable('task', true);
    }
}
