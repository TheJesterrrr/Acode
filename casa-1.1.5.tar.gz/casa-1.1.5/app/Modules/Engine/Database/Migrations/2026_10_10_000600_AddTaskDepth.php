<?php

declare(strict_types=1);

namespace App\Modules\Engine\Database\Migrations;

use CodeIgniter\Database\Migration;

/** Tambah kolom `depth` pada `task` — Light/Standard/Deep yang dibaca Adapter. */
final class AddTaskDepth extends Migration
{
    public function up(): void
    {
        if (! $this->db->fieldExists('depth', 'task')) {
            $this->forge->addColumn('task', [
                'depth' => ['type' => 'VARCHAR', 'constraint' => 10, 'default' => 'standard', 'after' => 'target'],
            ]);
        }
    }

    public function down(): void
    {
        if ($this->db->fieldExists('depth', 'task')) {
            $this->forge->dropColumn('task', 'depth');
        }
    }
}
