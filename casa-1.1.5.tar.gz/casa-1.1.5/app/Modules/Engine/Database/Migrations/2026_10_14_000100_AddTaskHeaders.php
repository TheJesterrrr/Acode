<?php

declare(strict_types=1);

namespace App\Modules\Engine\Database\Migrations;

use CodeIgniter\Database\Migration;

/**
 * Tambah kolom `headers` pada `task` — header HTTP kustom ("Name: Value" per
 * baris) yang disuntik Adapter ke semua request (mis. kepatuhan bug bounty:
 * X-Request-Purpose: Research). Pola sama dgn `depth`: diset per task, dibaca
 * Adapter via ScanProfile.
 */
final class AddTaskHeaders extends Migration
{
    public function up(): void
    {
        if (! $this->db->fieldExists('headers', 'task')) {
            $this->forge->addColumn('task', [
                'headers' => ['type' => 'TEXT', 'null' => true, 'after' => 'depth'],
            ]);
        }
    }

    public function down(): void
    {
        if ($this->db->fieldExists('headers', 'task')) {
            $this->forge->dropColumn('task', 'headers');
        }
    }
}
