<?php

declare(strict_types=1);

namespace App\Modules\Engine\Services;

use App\Modules\Adapter\Services\AdapterFactory;
use App\Modules\Engine\Models\TaskModel;
use App\Modules\Finding\Services\FindingService;
use App\Modules\Policy\Services\PolicyEngine;
use App\Modules\Project\Models\AssetModel;
use App\Modules\ToolManager\Models\ToolInstallModel;
use Throwable;

/**
 * EngineService — inti `casad`: menjalankan task dari antrean. Worker "tidak
 * berpikir": Task → Run → Collect → Return (Master Plan §4). SETIAP eksekusi
 * WAJIB lolos gerbang Policy — tidak ada jalur yang memintasnya (§4 batas kritis).
 */
final class EngineService
{
    public function __construct(
        private readonly TaskModel $tasks = new TaskModel(),
        private readonly PolicyEngine $policy = new PolicyEngine(),
        private readonly ToolInstallModel $installs = new ToolInstallModel(),
        private readonly FindingService $findings = new FindingService(),
        private readonly AssetModel $assets = new AssetModel(),
    ) {
    }

    public function enqueue(int $missionId, int $projectId, string $toolCode, string $target, string $depth = 'standard', string $headers = ''): int
    {
        return (int) $this->tasks->insert([
            'mission_id' => $missionId,
            'project_id' => $projectId,
            'tool_code'  => $toolCode,
            'target'     => $target,
            'depth'      => $depth,
            'headers'    => $headers !== '' ? $headers : null,
            'status'     => 'pending',
        ], true);
    }

    /** Proses task pending MILIK satu mission (dipakai self-test/isolasi). */
    public function runMission(int $missionId): int
    {
        $n = 0;
        foreach ($this->tasks->where('mission_id', $missionId)->where('status', 'pending')->findAll(50) as $task) {
            $this->runTask($task);
            $n++;
        }

        return $n;
    }

    /** Proses task pending. Kembalikan jumlah yang diproses. */
    public function runPending(int $limit = 20): int
    {
        // Jaring pengaman tiap tick: sapu task 'running' yang nyangkut karena
        // worker crash sebelumnya (lihat TaskModel::reapStale()) sebelum ambil
        // task pending baru — supaya mission yang terkunci bisa pulih sendiri.
        $this->tasks->reapStale();

        $n = 0;
        foreach ($this->tasks->pending($limit) as $task) {
            $this->runTask($task);
            $n++;
        }

        return $n;
    }

    private function runTask(array $task): void
    {
        $id  = (int) $task['id'];
        $pid = (int) $task['project_id'];
        $code = (string) $task['tool_code'];

        // Jaga dari balapan dgn MissionService::cancel(): batch diambil di awal
        // runPending() lalu diiterasi satu per satu — bisa makan waktu menitan
        // untuk batch besar. Bila pengguna klik Batalkan DI TENGAH batch, task
        // ini sudah ditandai 'skipped' di DB walau masih ada di array memori
        // worker. Tanpa cek ini, update status→'running' di bawah MENIMPA
        // BALIK 'skipped' jadi 'running' selamanya (task #518 pernah begini).
        $current = $this->tasks->find($id);
        if (($current['status'] ?? '') !== 'pending') {
            return; // sudah diubah sejak diambil batch (dibatalkan/dihapus) — lewati.
        }
        $this->tasks->update($id, ['status' => 'running', 'started_at' => date('Y-m-d H:i:s')]);

        try {
            // GERBANG kebijakan — wajib.
            if (! $this->policy->isToolAllowed($pid, $code)) {
                $this->finish($id, 'skipped', 0, 'Diblokir Policy / tidak diizinkan');

                return;
            }
            $adapter = AdapterFactory::forCode($code);
            if ($adapter === null) {
                $this->finish($id, 'skipped', 0, 'Adapter belum tersedia');

                return;
            }
            // Tool "builtin" (mis. IDOR) dijalankan CASA sendiri — tak butuh binari.
            $builtin = AdapterFactory::isBuiltin($code);
            $inst    = $this->installs->find($code);
            $bin     = (string) ($inst['bin_path'] ?? '');
            if (! $builtin && (($inst['status'] ?? '') !== 'installed' || $bin === '' || ! is_file($bin))) {
                $this->finish($id, 'skipped', 0, '[CASA-E005] Tool belum terpasang');
                \App\Libraries\CasaLog::log('CASA-E005', "Task #{$id} ({$code}) dilewati — binary tak ditemukan di server (bin_path={$bin})", (int) ($task['mission_id'] ?? 0) ?: null, $id, 'warning');

                return;
            }

            // GATE eksekusi bersyarat: lewati tool yang tak relevan dengan target
            // ini (hemat waktu & kurangi noise). Dievaluasi DI SINI (bukan saat
            // plan) karena bergantung pada hasil recon task sebelumnya — worker
            // memproses tool-major, jadi Probe (whatweb) selesai sebelum Vuln
            // (wpscan/dalfox/sqlmap). Lewati = 'skipped', bukan error.
            $gate = $this->gatedReason($code, (string) $task['target'], $pid);
            if ($gate !== null) {
                $this->finish($id, 'skipped', 0, $gate);
                \App\Libraries\CasaLog::log('CASA-E016', "Task #{$id} ({$code}) dilewati — {$gate}", (int) ($task['mission_id'] ?? 0) ?: null, $id, 'info');

                return;
            }

            // Depth (Light/Standard/Deep) → dibaca Adapter via ScanProfile.
            \App\Libraries\ScanProfile::setDepth((string) ($task['depth'] ?? 'standard'));
            // Header HTTP kustom (mis. bug bounty: X-Request-Purpose: Research) →
            // disuntik Adapter ke semua request. WAJIB diset tiap task (termasuk
            // kosong) agar header task sebelumnya tak bocor.
            \App\Libraries\ScanProfile::setHeaders($task['headers'] ?? null);
            $result = $adapter->run($bin, (string) $task['target']);
            $count  = 0;
            foreach ($result['findings'] as $f) {
                $this->findings->record($f + ['project_id' => $pid, 'mission_id' => (int) $task['mission_id']]);
                $count++;
            }
            // Aset hasil recon → Attack Surface (Master Plan §5 project 1—N asset).
            foreach ($result['assets'] as $a) {
                $this->assets->addUnique($pid, (string) ($a['type'] ?? 'host'), (string) ($a['value'] ?? ''), (string) ($a['source'] ?? $code));
            }
            $this->finish($id, 'done', $count, null);
        } catch (Throwable $e) {
            $this->finish($id, 'error', 0, mb_substr($e->getMessage(), 0, 200));
        }
    }

    private function finish(int $id, string $status, int $count, ?string $error): void
    {
        $this->tasks->update($id, [
            'status'         => $status,
            'findings_count' => $count,
            'error'          => $error,
            'finished_at'    => date('Y-m-d H:i:s'),
        ]);
    }

    /**
     * Gate eksekusi bersyarat. Kembalikan alasan-skip (string) bila tool TAK
     * relevan dengan target, atau null bila boleh jalan. Konservatif: hanya
     * tool yang jelas butuh prasyarat yang di-gate; sisanya selalu lolos.
     */
    private function gatedReason(string $code, string $target, int $projectId): ?string
    {
        if ($code === 'wpscan') {
            // Audit WordPress hanya masuk akal bila teknologi WordPress terdeteksi
            // (aset 'tech' dari whatweb, dijadwalkan sebelum wpscan). Juga selaras
            // dengan rencana wpscan opt-in (lisensi komersial).
            if (! $this->wordpressDetected($projectId)) {
                return 'Dilewati gate: WordPress tidak terdeteksi pada target';
            }
        } elseif ($code === 'dalfox' || $code === 'sqlmap') {
            // Uji XSS/SQLi butuh titik injeksi: URL dengan parameter query.
            if (! preg_match('/[?&][^=&]+=/', $target)) {
                return 'Dilewati gate: target tanpa parameter query (tak ada titik uji)';
            }
        }

        return null;
    }

    /** True bila ada aset teknologi WordPress tercatat utk project (dari whatweb dll). */
    private function wordpressDetected(int $projectId): bool
    {
        return $this->assets->where('project_id', $projectId)
            ->where('type', 'tech')
            ->like('value', 'wordpress')
            ->countAllResults() > 0;
    }
}
