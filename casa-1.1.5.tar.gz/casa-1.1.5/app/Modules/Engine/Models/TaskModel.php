<?php

declare(strict_types=1);

namespace App\Modules\Engine\Models;

use CodeIgniter\Model;

/** TaskModel — tabel `task` (CES 13.3). Antrean worker. */
final class TaskModel extends Model
{
    protected $table         = 'task';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $useTimestamps = false;
    protected $allowedFields = ['mission_id', 'project_id', 'tool_code', 'target', 'depth', 'headers', 'status', 'findings_count', 'error', 'started_at', 'finished_at'];

    /** @return array<int,array<string,mixed>> tugas pending tertua dulu */
    public function pending(int $limit = 20): array
    {
        return $this->where('status', 'pending')->orderBy('id', 'ASC')->findAll($limit);
    }

    public function forMission(int $missionId): array
    {
        return $this->where('mission_id', $missionId)->orderBy('id', 'ASC')->findAll();
    }

    /**
     * Sapu task yang "nyangkut" di status running melampaui batas wajar. Fatal
     * PHP murni (mis. OOM "Allowed memory size exhausted") TIDAK tertangkap
     * oleh try/catch Throwable di EngineService::runTask() — proses mati
     * sebelum finish() sempat terpanggil, task tertinggal di 'running' selamanya
     * dan mengunci mission. Dipanggil tiap tick casa:work (lihat
     * EngineService::runPending()) agar task begini pulih sendiri di tick
     * berikutnya, apa pun sebab crash-nya (OOM, SIGKILL, reboot server, dll).
     *
     * @return int jumlah task yang disapu
     */
    public function reapStale(int $thresholdSeconds = 600): int
    {
        $cutoff = date('Y-m-d H:i:s', time() - $thresholdSeconds);
        $stale  = $this->where('status', 'running')->where('started_at <', $cutoff)->findAll();
        foreach ($stale as $t) {
            $this->update((int) $t['id'], [
                'status'      => 'error',
                // Kode di awal pesan ([CASA-E001]) langsung terlihat di panel
                // "Error terbaru" (Engine Health) & halaman Mission tanpa perlu
                // join tambahan — pengguna tinggal cari kode itu di Panduan.
                'error'       => '[CASA-E001] Proses terhenti tak terduga (timeout/crash, mis. kehabisan memori) — disapu otomatis oleh worker',
                'finished_at' => date('Y-m-d H:i:s'),
            ]);
            \App\Libraries\CasaLog::log('CASA-E001', 'Task #' . $t['id'] . ' (' . $t['tool_code'] . ') disapu — nyangkut di running sejak ' . $t['started_at'], (int) ($t['mission_id'] ?? 0) ?: null, (int) $t['id']);
        }

        return count($stale);
    }

    /** @return array{total:int,done:int} */
    public function progress(int $missionId): array
    {
        $rows = $this->forMission($missionId);
        $done = 0;
        $running = 0;
        foreach ($rows as $r) {
            if (in_array($r['status'], ['done', 'error', 'skipped'], true)) {
                $done++;
            } elseif ($r['status'] === 'running') {
                $running++;
            }
        }

        return ['total' => count($rows), 'done' => $done, 'running' => $running];
    }
}
