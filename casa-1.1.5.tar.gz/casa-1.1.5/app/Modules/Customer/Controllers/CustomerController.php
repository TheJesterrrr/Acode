<?php

declare(strict_types=1);

namespace App\Modules\Customer\Controllers;

use App\Controllers\BaseController;
use App\Modules\Billing\Services\SubscriptionService;
use App\Modules\Billing\Services\TopupService;
use App\Modules\Billing\Services\WalletService;
use App\Modules\Customer\Services\CustomerAdminService;
use App\Modules\Licensing\Models\InstanceBindingModel;
use CodeIgniter\Exceptions\PageNotFoundException;
use CodeIgniter\HTTP\ResponseInterface;
use RuntimeException;

/** CustomerController — manajemen pelanggan + billing manual (admin owner; CES 13.2). */
final class CustomerController extends BaseController
{
    public function __construct(
        private readonly CustomerAdminService $customers = new CustomerAdminService(),
        private readonly WalletService $wallet = new WalletService(),
        private readonly SubscriptionService $subs = new SubscriptionService(),
        private readonly TopupService $topup = new TopupService(),
        private readonly InstanceBindingModel $bindings = new InstanceBindingModel(),
    ) {
    }

    public function index(): string
    {
        $this->requireOwnerConsole();
        $q = trim((string) $this->request->getGet('q'));

        return $this->adminView('App\Modules\Customer\Views\index', [
            'title'     => 'Pelanggan',
            'customers' => $this->customers->list($q),
            'stats'     => $this->customers->stats(),
            'q'         => $q,
        ], 'customers');
    }

    public function show(int $id): string
    {
        $this->requireOwnerConsole();
        try {
            $d = $this->customers->detail($id);
        } catch (RuntimeException $e) {
            throw PageNotFoundException::forPageNotFound($e->getMessage());
        }

        return $this->adminView('App\Modules\Customer\Views\show', [
            'title'       => 'Pelanggan — ' . ($d['customer']['name'] ?? ''),
            'customer'    => $d['customer'],
            'projects'    => $d['projects'],
            'by_severity' => $d['by_severity'],
            'balance'     => $this->wallet->balance($id),
            'subs'        => $this->subs->forCustomer($id),
            'durations'   => config(\App\Modules\Billing\Config\Pricing::class)->durations,
            'binding'     => $this->bindings->activeForCustomer($id),
        ], 'customers');
    }

    /** Lepas ikatan instance (owner) — memungkinkan pelanggan pindah/ganti VPS. */
    public function releaseBinding(int $id): ResponseInterface
    {
        $this->requireOwnerConsole();
        $n = $this->bindings->revokeForCustomer($id);

        return $this->ok(['released' => $n]);
    }

    /** Hibah koin ke pelanggan (owner; mis. kompensasi/uji). */
    public function grantCoins(int $id): ResponseInterface
    {
        $this->requireOwnerConsole();
        try {
            $bal = $this->topup->grantManual($id, (int) $this->request->getPost('coins'), 'Hibah owner');
        } catch (RuntimeException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok(['balance' => $bal]);
    }

    /** Terbitkan langganan MANUAL (owner pilih paket + durasi, tanpa koin). */
    public function grantSubscription(int $id): ResponseInterface
    {
        $this->requireOwnerConsole();
        try {
            $sub = $this->subs->grantManual($id, (string) $this->request->getPost('tier'), (int) $this->request->getPost('months'));
        } catch (RuntimeException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok(['sub_id' => $sub['id'], 'tier' => $sub['tier'], 'exp' => $sub['expires_at']]);
    }

    public function setStatus(int $id): ResponseInterface
    {
        $this->requireOwnerConsole();
        try {
            $this->customers->setStatus($id, (string) $this->request->getPost('status'));
        } catch (RuntimeException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok([]);
    }
}
