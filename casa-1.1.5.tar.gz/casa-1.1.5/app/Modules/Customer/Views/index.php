<?= $this->extend('layouts/admin') ?>
<?= $this->section('content') ?>
<?php
/** @var array $customers @var array $stats @var string $q */
$badge = ['active' => 'success', 'suspended' => 'warning', 'banned' => 'danger'];
?>
<div class="casa-page-head">
  <div>
    <h1>Pelanggan</h1>
    <p class="text-muted small mb-0">Member terdaftar di portal CASA — project, mission, & temuan per pelanggan. Kelola status akun.</p>
  </div>
</div>

<div class="row g-2 mb-3">
  <?php foreach ([['Total', $stats['total'], 'amber'], ['Aktif', $stats['active'], 'success'], ['Ditangguhkan', $stats['suspended'], 'warning'], ['Diblokir', $stats['banned'], 'danger']] as [$lbl, $n, $c]): ?>
    <div class="col-6 col-lg-3"><div class="casa-card p-3"><div class="text-muted small"><?= esc($lbl) ?></div><div class="fs-3 fw-semibold text-<?= esc($c) ?>"><?= (int) $n ?></div></div></div>
  <?php endforeach; ?>
</div>

<div class="casa-card p-2 p-lg-3 mb-3">
  <form method="get" class="input-group input-group-sm" style="max-width:360px">
    <span class="input-group-text"><i class="bi bi-search"></i></span>
    <input name="q" value="<?= esc($q) ?>" class="form-control" placeholder="Cari nama / email / perusahaan…">
    <button class="btn btn-outline-secondary">Search</button>
  </form>
</div>

<div class="casa-card p-0">
  <div class="table-responsive">
    <table class="table align-middle mb-0">
      <thead><tr><th class="ps-3">Pelanggan</th><th>Kontak</th><th class="text-center">Project</th><th class="text-center">Mission</th><th class="text-center">Temuan</th><th>Status</th><th>Terdaftar</th><th class="text-end pe-3"></th></tr></thead>
      <tbody>
        <?php if ($customers === []): ?>
          <tr><td colspan="8" class="text-center text-muted py-4">Belum ada pelanggan<?= $q !== '' ? ' untuk "' . esc($q) . '"' : '' ?>.</td></tr>
        <?php else: foreach ($customers as $c): ?>
          <tr>
            <td class="ps-3">
              <a href="<?= esc(site_url('casaadmin/customers/' . (int) $c['id'])) ?>" class="fw-semibold text-decoration-none"><?= esc($c['name']) ?></a>
              <div class="small text-muted"><?= esc($c['company'] ?: '—') ?></div>
            </td>
            <td class="small"><?= esc($c['email']) ?><div class="text-muted"><?= esc($c['phone']) ?></div></td>
            <td class="text-center"><?= (int) $c['project_count'] ?></td>
            <td class="text-center"><?= (int) $c['mission_count'] ?></td>
            <td class="text-center"><span class="badge text-bg-dark border"><?= (int) $c['finding_count'] ?></span></td>
            <td><span class="badge text-bg-<?= esc($badge[$c['status']] ?? 'secondary') ?> text-capitalize"><?= esc($c['status']) ?></span></td>
            <td class="small text-muted"><?= esc(substr((string) $c['created_at'], 0, 10)) ?></td>
            <td class="text-end pe-3"><a class="btn btn-sm btn-outline-primary" href="<?= esc(site_url('casaadmin/customers/' . (int) $c['id'])) ?>"><i class="bi bi-eye"></i></a></td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?= $this->endSection() ?>
