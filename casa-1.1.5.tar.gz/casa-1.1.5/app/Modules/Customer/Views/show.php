<?= $this->extend('layouts/admin') ?>
<?= $this->section('content') ?>
<?php
/** @var array $customer @var array $projects @var array $by_severity */
$cid   = (int) $customer['id'];
$badge = ['active' => 'success', 'suspended' => 'warning', 'banned' => 'danger'];
$sevColor = ['crit' => 'danger', 'high' => 'warning', 'med' => 'info', 'low' => 'secondary', 'info' => 'light'];
$sevLabel = ['crit' => 'Critical', 'high' => 'High', 'med' => 'Medium', 'low' => 'Low', 'info' => 'Info'];
?>
<div class="casa-page-head">
  <div>
    <a href="<?= esc(site_url('casaadmin/customers')) ?>" class="small text-muted text-decoration-none"><i class="bi bi-arrow-left"></i> Pelanggan</a>
    <h1 class="mb-0"><?= esc($customer['name']) ?></h1>
    <div class="small text-muted"><?= esc($customer['company'] ?: 'tanpa perusahaan') ?> · <?= esc($customer['email']) ?> · <?= esc($customer['phone']) ?></div>
  </div>
  <div class="ms-auto d-flex align-items-center gap-2">
    <span class="small text-muted">Status</span>
    <select id="statusSel" class="form-select form-select-sm" style="width:auto">
      <?php foreach (['active' => 'Aktif', 'suspended' => 'Ditangguhkan', 'banned' => 'Diblokir'] as $v => $l): ?>
        <option value="<?= $v ?>" <?= $customer['status'] === $v ? 'selected' : '' ?>><?= $l ?></option>
      <?php endforeach; ?>
    </select>
    <span id="stMsg" class="small"></span>
  </div>
</div>

<div class="row g-3 mb-3">
  <div class="col-lg-4">
    <div class="casa-card p-3 h-100">
      <h2 class="h6 mb-3">Akun</h2>
      <dl class="row small mb-0">
        <dt class="col-5 text-muted">Status</dt><dd class="col-7"><span class="badge text-bg-<?= esc($badge[$customer['status']] ?? 'secondary') ?> text-capitalize"><?= esc($customer['status']) ?></span></dd>
        <dt class="col-5 text-muted">Email terverifikasi</dt><dd class="col-7"><?= $customer['email_verified_at'] ? esc(substr((string) $customer['email_verified_at'], 0, 16)) : '<span class="text-warning">belum</span>' ?></dd>
        <dt class="col-5 text-muted">Terdaftar</dt><dd class="col-7"><?= esc(substr((string) $customer['created_at'], 0, 16)) ?></dd>
        <dt class="col-5 text-muted">Project</dt><dd class="col-7"><?= count($projects) ?></dd>
      </dl>
    </div>
  </div>
  <div class="col-lg-8">
    <div class="casa-card p-3 h-100">
      <h2 class="h6 mb-3">Temuan (semua project)</h2>
      <div class="row g-2">
        <?php foreach ($by_severity as $k => $n): ?>
          <div class="col"><div class="border rounded p-2 text-center" style="border-color:var(--casa-card-brd)!important">
            <div class="fs-4 fw-semibold text-<?= esc($sevColor[$k]) ?>"><?= (int) $n ?></div>
            <div class="small text-muted"><?= esc($sevLabel[$k]) ?></div>
          </div></div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<div class="casa-card p-0">
  <div class="p-3 border-bottom" style="border-color:var(--casa-card-brd)!important"><h2 class="h6 mb-0">Project (<?= count($projects) ?>)</h2></div>
  <div class="table-responsive">
    <table class="table align-middle mb-0">
      <thead><tr><th class="ps-3">Nama</th><th>Program</th><th>Platform</th><th class="text-center">Temuan</th><th>Dibuat</th></tr></thead>
      <tbody>
        <?php if ($projects === []): ?>
          <tr><td colspan="5" class="text-center text-muted py-4">Belum ada project.</td></tr>
        <?php else: foreach ($projects as $p): ?>
          <tr>
            <td class="ps-3 fw-semibold"><?= esc($p['name']) ?></td>
            <td class="small text-muted"><?= esc($p['program_url'] ?: '—') ?></td>
            <td><?= $p['platform'] ? '<span class="badge text-bg-light border">' . esc(ucfirst($p['platform'])) . '</span>' : '—' ?></td>
            <td class="text-center"><span class="badge text-bg-dark border"><?= (int) $p['finding_count'] ?></span></td>
            <td class="small text-muted"><?= esc(substr((string) $p['created_at'], 0, 10)) ?></td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Billing manual (owner) -->
<div class="casa-card p-4 mt-3" style="border:1px solid var(--casa-amber)">
  <h2 class="h6 mb-1"><i class="bi bi-coin text-warning me-1"></i>Billing (manual owner)</h2>
  <p class="text-muted small mb-3">Saldo koin pelanggan: <b class="text-warning"><?= number_format((int) ($balance ?? 0), 0, ',', '.') ?></b></p>
  <div class="row g-3">
    <div class="col-md-5">
      <label class="form-label small">Hibah koin</label>
      <form id="coinForm" class="input-group input-group-sm">
        <input name="coins" type="number" min="1" class="form-control" placeholder="jumlah koin" required>
        <button class="btn btn-outline-warning">Credit</button>
      </form>
    </div>
    <div class="col-md-7">
      <label class="form-label small">Issue manual subscription (no coins)</label>
      <form id="subForm" class="row g-2">
        <div class="col-5"><select name="tier" class="form-select form-select-sm"><option value="pro">Professional</option><option value="enterprise">Enterprise</option></select></div>
        <div class="col-4"><select name="months" class="form-select form-select-sm"><?php foreach (($durations ?? [1,3,6,12]) as $m): ?><option value="<?= (int) $m ?>"><?= (int) $m ?> bln</option><?php endforeach; ?></select></div>
        <div class="col-3"><button class="btn btn-amber btn-sm w-100">Issue</button></div>
      </form>
    </div>
  </div>
  <div id="billMsg" class="small mt-2"></div>
  <?php if (! empty($subs)): ?>
    <div class="mt-3 small"><b>Langganan:</b>
      <?php foreach ($subs as $s): ?>
        <span class="badge text-bg-light border me-1"><?= esc(strtoupper($s['tier'])) ?> <?= (int) $s['months'] ?>bln · <?= esc($s['method']) ?> · s/d <?= esc($s['expires_at'] ?? '∞') ?></span>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<!-- Ikatan instance (node-lock) -->
<div class="casa-card p-4 mt-3">
  <div class="d-flex align-items-center">
    <div>
      <h2 class="h6 mb-1"><i class="bi bi-hdd-network me-1"></i>Ikatan Instance (VPS)</h2>
      <?php if (! empty($binding)): ?>
        <p class="small text-muted mb-0">Terikat ke <code><?= esc($binding['install_id']) ?></code> · sinkron terakhir <?= esc(substr((string) ($binding['last_sync_at'] ?? '—'), 0, 16)) ?><?= $binding['ip'] ? ' · ' . esc($binding['ip']) : '' ?></p>
      <?php else: ?>
        <p class="small text-muted mb-0">Belum ada VPS yang terikat (pelanggan belum sinkron).</p>
      <?php endif; ?>
    </div>
    <?php if (! empty($binding)): ?>
      <button id="relBtn" class="btn btn-outline-danger btn-sm ms-auto"><i class="bi bi-x-circle me-1"></i>Lepas ikatan</button>
    <?php endif; ?>
  </div>
  <div id="relMsg" class="small mt-2"></div>
</div>
<?= $this->endSection() ?>

<?= $this->section('page_scripts') ?>
<script>
const ST = '<?= esc(site_url('casaadmin/customers/' . $cid . '/status')) ?>';
const CBASE = '<?= esc(site_url('casaadmin/customers/' . $cid)) ?>';
document.getElementById('coinForm').addEventListener('submit', async (e)=>{ e.preventDefault();
  const m=document.getElementById('billMsg');
  const d=await casaPost(CBASE+'/grant-coins', new FormData(e.target));
  if(d.ok){ m.className='small mt-2 text-success'; m.textContent='Saldo baru: '+d.balance.toLocaleString('id-ID'); setTimeout(()=>location.reload(),900); }
  else{ m.className='small mt-2 text-danger'; m.textContent=d.error||'Gagal'; }
});
document.getElementById('subForm').addEventListener('submit', async (e)=>{ e.preventDefault();
  const m=document.getElementById('billMsg');
  const d=await casaPost(CBASE+'/grant-sub', new FormData(e.target));
  if(d.ok){ m.className='small mt-2 text-success'; m.textContent='Langganan '+d.tier+' terbit s/d '+(d.exp||'∞'); setTimeout(()=>location.reload(),1000); }
  else{ m.className='small mt-2 text-danger'; m.textContent=d.error||'Gagal'; }
});
document.getElementById('statusSel').addEventListener('change', async (e) => {
  const m = document.getElementById('stMsg');
  const d = await casaPost(ST, { status: e.target.value });
  if (d.ok) { m.className = 'small text-success'; m.textContent = 'Tersimpan'; setTimeout(() => m.textContent = '', 1500); }
  else { m.className = 'small text-danger'; m.textContent = d.error || 'Gagal'; }
});
const relBtn = document.getElementById('relBtn');
if (relBtn) relBtn.addEventListener('click', async () => {
  if (!confirm('Lepas ikatan instance? Pelanggan bisa sinkron di VPS baru setelah ini.')) return;
  const m = document.getElementById('relMsg');
  const d = await casaPost(CBASE + '/release-binding', {});
  if (d.ok) { m.className = 'small mt-2 text-success'; m.textContent = 'Ikatan dilepas (' + d.released + '). Pelanggan dapat sinkron di VPS baru.'; setTimeout(() => location.reload(), 1200); }
  else { m.className = 'small mt-2 text-danger'; m.textContent = d.error || 'Gagal'; }
});
</script>
<?= $this->endSection() ?>
