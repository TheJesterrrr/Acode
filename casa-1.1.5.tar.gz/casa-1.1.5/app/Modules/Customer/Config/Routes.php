<?php

declare(strict_types=1);

use CodeIgniter\Router\RouteCollection;

/** Rute manajemen pelanggan — endpoint ADMIN (CES 13.10). */

/** @var RouteCollection $routes */
$routes->group('casaadmin/customers', ['namespace' => 'App\Modules\Customer\Controllers', 'filter' => 'admin'], static function (RouteCollection $routes): void {
    $routes->get('', 'CustomerController::index');
    $routes->get('(:num)', 'CustomerController::show/$1');
    $routes->post('(:num)/status', 'CustomerController::setStatus/$1', ['filter' => 'audit:CUSTOMER_STATUS']);
    $routes->post('(:num)/grant-coins', 'CustomerController::grantCoins/$1', ['filter' => 'audit:BILLING_GRANT_COINS']);
    $routes->post('(:num)/grant-sub', 'CustomerController::grantSubscription/$1', ['filter' => 'audit:BILLING_GRANT_SUB']);
    $routes->post('(:num)/release-binding', 'CustomerController::releaseBinding/$1', ['filter' => 'audit:INSTANCE_RELEASE']);
});
