<?php

declare(strict_types=1);

namespace App\Modules\Customer\Services;

use App\Modules\Auth\Models\CustomerModel;
use Config\Database;
use RuntimeException;

/**
 * CustomerAdminService — data pelanggan (member) untuk portal admin
 * (Master Plan §12 #27 manajemen pelanggan). Menggabungkan agregat project,
 * finding, & mission per pelanggan. Baca-saja + ubah status (tanpa hapus keras).
 */
final class CustomerAdminService
{
    public function __construct(
        private readonly CustomerModel $customers = new CustomerModel(),
    ) {
    }

    /** @return array<int,array<string,mixed>> daftar pelanggan + agregat */
    public function list(string $q = ''): array
    {
        $db  = Database::connect();
        $sub = $db->table('customers c')
            ->select('c.id, c.name, c.company, c.email, c.phone, c.status, c.created_at, c.email_verified_at')
            ->select('(SELECT COUNT(*) FROM project p WHERE p.customer_id = c.id AND p.deleted_at IS NULL) AS project_count', false)
            ->select('(SELECT COUNT(*) FROM mission m WHERE m.customer_id = c.id) AS mission_count', false)
            ->select('(SELECT COUNT(*) FROM finding f JOIN project p2 ON p2.id = f.project_id WHERE p2.customer_id = c.id) AS finding_count', false)
            ->where('c.deleted_at', null);
        if ($q !== '') {
            $sub->groupStart()->like('c.name', $q)->orLike('c.email', $q)->orLike('c.company', $q)->groupEnd();
        }

        return $sub->orderBy('c.id', 'DESC')->get(200)->getResultArray();
    }

    /** @return array{installed:int,available:int} ringkasan */
    public function stats(): array
    {
        $db = Database::connect();

        return [
            'total'     => (int) $db->table('customers')->where('deleted_at', null)->countAllResults(),
            'active'    => (int) $db->table('customers')->where('deleted_at', null)->where('status', 'active')->countAllResults(),
            'suspended' => (int) $db->table('customers')->where('deleted_at', null)->where('status', 'suspended')->countAllResults(),
            'banned'    => (int) $db->table('customers')->where('deleted_at', null)->where('status', 'banned')->countAllResults(),
        ];
    }

    /** @return array<string,mixed> detail pelanggan + project + finding per severity */
    public function detail(int $id): array
    {
        $c = $this->customers->find($id);
        if ($c === null) {
            throw new RuntimeException('Pelanggan tidak ditemukan.');
        }
        unset($c['password_hash']);
        $db = Database::connect();

        $projects = $db->table('project p')
            ->select('p.id, p.name, p.program_url, p.platform, p.created_at')
            ->select('(SELECT COUNT(*) FROM finding f WHERE f.project_id = p.id) AS finding_count', false)
            ->where('p.customer_id', $id)->where('p.deleted_at', null)
            ->orderBy('p.id', 'DESC')->get(100)->getResultArray();

        $sev = $db->table('finding f')->join('project p', 'p.id = f.project_id')
            ->select('f.severity, COUNT(*) AS n')->where('p.customer_id', $id)
            ->groupBy('f.severity')->get()->getResultArray();
        $bySeverity = ['crit' => 0, 'high' => 0, 'med' => 0, 'low' => 0, 'info' => 0];
        foreach ($sev as $r) {
            $bySeverity[$r['severity']] = (int) $r['n'];
        }

        return ['customer' => $c, 'projects' => $projects, 'by_severity' => $bySeverity];
    }

    /** Ubah status pelanggan (active|suspended|banned). @throws RuntimeException */
    public function setStatus(int $id, string $status): void
    {
        if (! in_array($status, ['active', 'suspended', 'banned'], true)) {
            throw new RuntimeException('Status tidak valid.');
        }
        if ($this->customers->find($id) === null) {
            throw new RuntimeException('Pelanggan tidak ditemukan.');
        }
        $this->customers->update($id, ['status' => $status]);
    }
}
