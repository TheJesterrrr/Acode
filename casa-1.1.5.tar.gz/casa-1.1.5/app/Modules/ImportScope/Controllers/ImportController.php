<?php

declare(strict_types=1);

namespace App\Modules\ImportScope\Controllers;

use App\Controllers\BaseController;
use App\Modules\ImportScope\Services\ScopeExtractor;
use CodeIgniter\HTTP\ResponseInterface;

/**
 * ImportController — endpoint ekstraksi scope untuk "Assessment Baru".
 * OCR dilakukan di PERAMBAN (Tesseract.js) — CASA tak menjalankan tool dari web
 * request (SELinux/httpd hanya lewat worker). Di sini menerima TEKS hasil OCR,
 * lalu regex + AI lokal (Ollama via HTTP) mengekstrak host/URL in-scope.
 */
final class ImportController extends BaseController
{
    public function __construct(
        private readonly ScopeExtractor $extractor = new ScopeExtractor(),
    ) {
    }

    /** Terima teks OCR (dari peramban) → daftar target. @return ResponseInterface JSON */
    public function analyze(): ResponseInterface
    {
        if ($r = $this->denyViewer()) {
            return $r;
        }
        $text = (string) $this->request->getPost('text');
        if (mb_strlen(trim($text)) < 4) {
            return $this->fail('Teks kosong — gambar tak terbaca. Coba screenshot lebih jelas / zoom bagian Scope.');
        }

        $res = $this->extractor->fromText($text);
        if ($res['targets'] === []) {
            return $this->fail('Tak ada host/URL terbaca dari gambar. Coba bagian Scope yang memuat domain.');
        }

        return $this->ok(['targets' => $res['targets'], 'ai' => $res['ai']]);
    }
}
