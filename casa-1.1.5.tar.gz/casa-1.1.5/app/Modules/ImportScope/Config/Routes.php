<?php

declare(strict_types=1);

use CodeIgniter\Router\RouteCollection;

/** Ekstraksi scope dari teks OCR (OCR sendiri di peramban) — dipakai Assessment Baru. */

/** @var RouteCollection $routes */
$routes->group('member/import', ['namespace' => 'App\Modules\ImportScope\Controllers', 'filter' => 'member'], static function (RouteCollection $routes): void {
    $routes->post('analyze', 'ImportController::analyze', ['filter' => 'audit:SCOPE_IMPORT']);
});
