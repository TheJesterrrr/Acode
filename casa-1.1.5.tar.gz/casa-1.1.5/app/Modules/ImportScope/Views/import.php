<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<?php /** @var bool $ocr_ok */ ?>
<div class="casa-page-head">
  <div>
    <h1 class="mb-0"><i class="bi bi-image me-1"></i>Import dari Gambar</h1>
    <div class="small text-muted">Upload screenshot halaman <b>Scope</b> target. Teks pada gambar dibaca untuk mengekstrak host/URL, lalu Anda pilih mana yang di-assess.</div>
  </div>
</div>

<?php if (! $ocr_ok): ?>
  <div class="alert alert-warning small"><i class="bi bi-exclamation-triangle me-1"></i><b>OCR belum aktif</b> di server ini (tesseract belum terpasang). Fitur ini butuh tesseract — hubungi owner untuk mengaktifkan.</div>
<?php endif; ?>

<div class="row g-3">
  <div class="col-lg-5">
    <div class="casa-card p-4">
      <h2 class="h6 mb-3">1 · Upload gambar scope</h2>
      <label class="d-flex flex-column align-items-center justify-content-center text-center p-4 mb-2"
             id="drop" style="border:2px dashed var(--casa-card-brd);border-radius:.6rem;cursor:pointer;min-height:150px">
        <i class="bi bi-cloud-arrow-up fs-2 text-muted"></i>
        <span class="small text-muted mt-1">Klik atau seret gambar ke sini</span>
        <span class="small" id="fileName"></span>
        <input type="file" id="img" accept="image/*" hidden>
      </label>
      <img id="preview" class="img-fluid rounded mb-2 d-none" alt="preview" style="max-height:180px">
      <button id="analyzeBtn" class="btn btn-amber w-100" <?= $ocr_ok ? '' : 'disabled' ?>>
        <i class="bi bi-magic me-1"></i>Baca &amp; ekstrak target
      </button>
      <div id="analyzeMsg" class="small mt-2 text-muted"><i class="bi bi-shield-lock me-1"></i>Gambar diproses lokal (OCR + AI lokal), tidak dikirim ke pihak ketiga; berkas dihapus usai dibaca.</div>
    </div>
  </div>

  <div class="col-lg-7">
    <div class="casa-card p-4">
      <div class="d-flex align-items-center mb-2">
        <h2 class="h6 mb-0">2 · Target terdeteksi</h2>
        <span id="aiBadge" class="badge text-bg-info ms-2 d-none"><i class="bi bi-cpu me-1"></i>disaring AI lokal</span>
        <a href="#" id="selAll" class="small ms-auto d-none">pilih semua</a>
        <span class="mx-1 small text-muted d-none" id="sep">·</span>
        <a href="#" id="selNone" class="small d-none">kosongkan</a>
      </div>
      <div id="targets" class="mb-2"><div class="text-muted small py-4 text-center">Belum ada — upload gambar lalu klik “Baca &amp; ekstrak”.</div></div>

      <div id="createBox" class="d-none">
        <hr>
        <div class="row g-2 align-items-end">
          <div class="col-md-6"><label class="form-label small">Nama project</label>
            <input id="pname" class="form-control" placeholder="mis. Sonic — recon"></div>
          <div class="col-md-6">
            <label class="d-flex align-items-center gap-2 small mb-2">
              <input type="checkbox" id="launch" class="form-check-input mt-0" checked>
              Langsung jalankan assessment
            </label>
          </div>
        </div>
        <div class="alert alert-warning small mt-2 mb-2 py-2"><i class="bi bi-exclamation-triangle me-1"></i>Pastikan semua target <b>in-scope &amp; Anda berwenang</b> mengujinya. Uji di luar scope = ilegal.</div>
        <button id="createBtn" class="btn btn-primary"><i class="bi bi-rocket-takeoff me-1"></i>Create project &amp; assess</button>
        <span id="createMsg" class="small ms-2"></span>
      </div>
    </div>
  </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('page_scripts') ?>
<script>
const $ = (s) => document.querySelector(s);
let picked = null;

$('#drop').addEventListener('click', () => $('#img').click());
['dragover','dragleave','drop'].forEach(ev => $('#drop').addEventListener(ev, (e)=>{ e.preventDefault(); }));
$('#drop').addEventListener('drop', (e) => { if (e.dataTransfer.files[0]) setFile(e.dataTransfer.files[0]); });
$('#img').addEventListener('change', (e) => { if (e.target.files[0]) setFile(e.target.files[0]); });

function setFile(f){
  picked = f;
  $('#fileName').textContent = f.name;
  const r = new FileReader();
  r.onload = () => { const p = $('#preview'); p.src = r.result; p.classList.remove('d-none'); };
  r.readAsDataURL(f);
}

$('#analyzeBtn').addEventListener('click', async () => {
  if (!picked){ $('#analyzeMsg').innerHTML = '<span class="text-danger">Pilih gambar dulu.</span>'; return; }
  const b = $('#analyzeBtn'), m = $('#analyzeMsg');
  b.disabled = true; const o = b.innerHTML; b.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Membaca…';
  const fd = new FormData(); fd.append('image', picked);
  const d = await casaPost('<?= esc(site_url('member/import/analyze')) ?>', fd);
  b.disabled = false; b.innerHTML = o;
  if (!d.ok){ m.innerHTML = '<span class="text-danger">'+(d.error||'Gagal.')+'</span>'; return; }
  m.className = 'small mt-2 text-muted'; m.innerHTML = '<i class="bi bi-check-circle text-success me-1"></i>'+d.targets.length+' target terbaca.';
  render(d.targets, d.ai);
});

function render(targets, ai){
  const box = $('#targets');
  box.innerHTML = '';
  targets.forEach((t, i) => {
    const id = 'tg'+i;
    const row = document.createElement('label');
    row.className = 'd-flex align-items-center gap-2 py-1 small';
    row.innerHTML = `<input type="checkbox" class="form-check-input mt-0 js-t" value="${t.value.replace(/"/g,'&quot;')}" ${t.in_scope?'checked':''}>
      <span class="badge text-bg-${t.type==='url'?'secondary':'dark'}">${t.type}</span>
      <span class="font-monospace">${t.value.replace(/</g,'&lt;')}</span>`;
    box.appendChild(row);
  });
  $('#aiBadge').classList.toggle('d-none', !ai);
  ['#selAll','#sep','#selNone'].forEach(s=>$(s).classList.remove('d-none'));
  $('#createBox').classList.remove('d-none');
}
$('#selAll').addEventListener('click',(e)=>{e.preventDefault();document.querySelectorAll('.js-t').forEach(x=>x.checked=true);});
$('#selNone').addEventListener('click',(e)=>{e.preventDefault();document.querySelectorAll('.js-t').forEach(x=>x.checked=false);});

$('#createBtn').addEventListener('click', async () => {
  const sel = [...document.querySelectorAll('.js-t:checked')].map(x=>x.value);
  const m = $('#createMsg');
  if (!sel.length){ m.className='small ms-2 text-danger'; m.textContent='Pilih minimal satu target.'; return; }
  const b = $('#createBtn'); b.disabled = true; const o = b.innerHTML; b.innerHTML = '<span class="spinner-border spinner-border-sm"></span>';
  const fd = new FormData();
  fd.append('name', $('#pname').value);
  fd.append('launch', $('#launch').checked ? '1' : '0');
  sel.forEach(v => fd.append('targets[]', v));
  const d = await casaPost('<?= esc(site_url('member/import/create')) ?>', fd);
  b.disabled = false; b.innerHTML = o;
  if (d.ok){ m.className='small ms-2 text-success'; m.textContent = d.added+' target ditambah. Mengalihkan…'; setTimeout(()=>location.href=d.redirect, 800); }
  else { m.className='small ms-2 text-danger'; m.textContent = d.error || 'Gagal.'; }
});
</script>
<?= $this->endSection() ?>
