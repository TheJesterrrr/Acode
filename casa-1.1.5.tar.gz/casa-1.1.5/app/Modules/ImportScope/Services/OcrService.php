<?php

declare(strict_types=1);

namespace App\Modules\ImportScope\Services;

/**
 * OcrService — ekstrak teks dari gambar memakai Tesseract (CLI). Ringan & andal
 * di CPU untuk halaman scope yang penuh teks (mis. brief Bugcrowd). Bila tesseract
 * tak terpasang, mengembalikan string kosong (controller memberi pesan ramah).
 */
final class OcrService
{
    private const TIMEOUT = 60;

    public function available(): bool
    {
        return $this->bin() !== '';
    }

    /** Jalankan OCR; kembalikan teks (mungkin kosong bila gagal). */
    public function extract(string $imagePath): string
    {
        $bin = $this->bin();
        if ($bin === '' || ! is_file($imagePath)) {
            return '';
        }
        $cmd = 'timeout ' . self::TIMEOUT . ' ' . escapeshellarg($bin) . ' '
            . escapeshellarg($imagePath) . ' stdout -l eng --psm 6 2>/dev/null';
        $out = shell_exec($cmd);

        return is_string($out) ? $out : '';
    }

    /** Lokasi biner tesseract (PATH umum + $TOOLS_DIR). */
    private function bin(): string
    {
        foreach (['tesseract', '/usr/bin/tesseract', '/usr/local/bin/tesseract'] as $c) {
            $p = @shell_exec('command -v ' . escapeshellarg($c) . ' 2>/dev/null');
            if (is_string($p) && trim($p) !== '') {
                return trim($p);
            }
        }

        return '';
    }
}
