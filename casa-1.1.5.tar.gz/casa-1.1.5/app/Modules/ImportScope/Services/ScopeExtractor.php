<?php

declare(strict_types=1);

namespace App\Modules\ImportScope\Services;

/**
 * ScopeExtractor — dari teks OCR → daftar target ternormalkan (regex, instan &
 * andal). Domain sebelum penanda "out of scope" ditandai terpilih; sesudahnya
 * tidak. Tak memanggil AI di web request (inferensi CPU lambat → 504); pengguna
 * meninjau daftar, dan AI CASA tetap menganalisa saat assessment (di worker).
 */
final class ScopeExtractor
{
    private const CAP = 60;

    /**
     * @return array{targets:array<int,array{type:string,value:string,in_scope:bool}>,ai:bool}
     */
    public function fromText(string $text): array
    {
        $cands = $this->candidates($text);
        if ($cands === []) {
            return ['targets' => [], 'ai' => false];
        }

        // Ekstraksi REGEX (instan & andal). AI lokal (Ollama) TIDAK dipanggil di
        // web request — inferensi CPU terlalu lambat → 504. Pengguna meninjau
        // daftar; AI CASA tetap menganalisa saat assessment (di worker/cron).
        // Heuristik ringan: domain yang muncul SETELAH penanda "out of scope"
        // ditandai tak-terpilih agar pengguna tak sengaja memasukkannya.
        $oosAt = $this->outOfScopeOffset($text);

        $targets = [];
        foreach ($cands as $c) {
            [$type, $value] = $this->classify($c);
            $in = $oosAt < 0 || ($this->firstPos($text, $c) < $oosAt);
            $targets[] = ['type' => $type, 'value' => $value, 'in_scope' => $in];
            if (count($targets) >= self::CAP) {
                break;
            }
        }

        return ['targets' => $targets, 'ai' => false];
    }

    /** Posisi awal penanda bagian "out of scope" (−1 bila tak ada). */
    private function outOfScopeOffset(string $text): int
    {
        $pos = -1;
        foreach (['out of scope', 'out-of-scope', 'out of-scope', 'exclusions', 'not in scope'] as $marker) {
            $p = stripos($text, $marker);
            if ($p !== false && ($pos < 0 || $p < $pos)) {
                $pos = $p;
            }
        }

        return $pos;
    }

    private function firstPos(string $text, string $needle): int
    {
        $host = $this->host($needle);
        $p    = $host !== '' ? stripos($text, $host) : false;

        return $p === false ? PHP_INT_MAX : $p;
    }

    /** Regex: kumpulkan URL + host kandidat, buang duplikat & noise. */
    private function candidates(string $text): array
    {
        $out  = [];
        $seen = [];
        // URL lengkap.
        if (preg_match_all('#https?://[^\s"\'<>)\]]+#i', $text, $m)) {
            foreach ($m[0] as $u) {
                $this->push($out, $seen, rtrim($u, '.,);'));
            }
        }
        // Host telanjang (domain.tld / sub.domain.tld) — TLD 2-24 huruf.
        if (preg_match_all('#\b(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,24}\b#i', $text, $m)) {
            foreach ($m[0] as $h) {
                $h = $this->cleanHost(strtolower($h));
                // Saring OCR sampah: TLD harus masuk akal (buang mm.avios, estore.aerlingus, dst).
                if ($h === '' || $this->isNoise($h) || ! $this->validTld($h)) {
                    continue;
                }
                $this->push($out, $seen, $h);
            }
        }

        return $out;
    }

    /** Koreksi kesalahan OCR umum pada host (mis. ".con" → ".com"). */
    private function cleanHost(string $h): string
    {
        $h = preg_replace('/\.(con|comm|col|cern|coin)$/', '.com', $h);       // .com salah baca
        $h = preg_replace('/\.co\.uk$/', '.co.uk', (string) $h);              // jaga ccTLD ganda
        return trim((string) $h, '.-');
    }

    /** TLD terakhir masuk akal? (ccTLD 2-huruf ATAU gTLD dikenal). */
    private function validTld(string $h): bool
    {
        static $gtld = [
            'com', 'net', 'org', 'info', 'biz', 'io', 'co', 'dev', 'app', 'web',
            'cloud', 'tech', 'xyz', 'online', 'site', 'store', 'digital', 'ai',
            'gov', 'edu', 'mil', 'int', 'name', 'pro', 'mobi', 'tv', 'cc',
        ];
        $tld = strtolower((string) substr((string) strrchr($h, '.'), 1));

        return $tld !== '' && (strlen($tld) === 2 || in_array($tld, $gtld, true));
    }

    private function push(array &$out, array &$seen, string $v): void
    {
        $v = trim($v);
        $k = strtolower(strtok($v, '?'));
        if ($v !== '' && ! isset($seen[$k])) {
            $seen[$k] = true;
            $out[]    = $v;
        }
    }

    /** Buang domain yang jelas bukan target (platform, aset, contoh umum). */
    private function isNoise(string $h): bool
    {
        static $bad = [
            'bugcrowd.com', 'hackerone.com', 'intigriti.com', 'yeswehack.com',
            'github.com', 'gitlab.com', 'google.com', 'gmail.com', 'example.com',
            'w3.org', 'schema.org', 'mozilla.org', 'gstatic.com', 'googleapis.com',
            'cloudflare.com', 'akamai.com', 'amazonaws.com', 'bugcrowdninja.com',
            'veracode.com', 'wikipedia.org', 'twitter.com', 'linkedin.com',
        ];
        foreach ($bad as $b) {
            if ($h === $b || str_ends_with($h, '.' . $b)) {
                return true;
            }
        }

        return in_array(preg_replace('/^www\./', '', $h), ['png', 'jpg', 'js', 'css', 'svg'], true);
    }

    private function host(string $v): string
    {
        $h = preg_replace('#^[a-z]+://#i', '', trim($v));

        return (string) preg_replace('#[/:].*$#', '', (string) $h);
    }

    /** @return array{0:string,1:string} [type,value] — samakan gaya QuickScan. */
    private function classify(string $in): array
    {
        $in = trim($in);
        if (preg_match('#^https?://#i', $in)) {
            return ['url', $in];
        }
        if (str_contains($in, '/')) {
            return ['url', 'https://' . ltrim($in, '/')];
        }

        return ['domain', strtolower($in)];
    }
}
