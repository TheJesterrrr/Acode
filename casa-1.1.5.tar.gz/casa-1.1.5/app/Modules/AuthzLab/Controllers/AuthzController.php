<?php

declare(strict_types=1);

namespace App\Modules\AuthzLab\Controllers;

use App\Controllers\BaseController;
use App\Modules\AuthzLab\Services\AuthzMatrixService;
use App\Modules\Licensing\Services\EditionService;
use App\Modules\Project\Services\ProjectService;
use CodeIgniter\Exceptions\PageNotFoundException;
use CodeIgniter\HTTP\ResponseInterface;
use RuntimeException;

/** AuthzController — AuthZ Matrix lintas-peran (member; CES 13.2 thin). */
final class AuthzController extends BaseController
{
    public function __construct(
        private readonly AuthzMatrixService $matrix = new AuthzMatrixService(),
        private readonly ProjectService $projects = new ProjectService(),
        private readonly EditionService $edition = new EditionService(),
    ) {
    }

    private function me(): int
    {
        return (int) $this->session->get('member_id');
    }

    public function show(int $projectId): string
    {
        if (! $this->edition->can($this->me(), 'authz_matrix')) {
            return $this->memberView('App\Modules\Licensing\Views\upsell', [
                'title'   => 'AuthZ Matrix',
                'feature' => 'AuthZ Matrix (Broken Access Control)',
                'edition' => $this->edition->resolve($this->me()),
            ], 'projects');
        }
        try {
            $project = $this->projects->getProject($projectId, $this->me());
        } catch (RuntimeException $e) {
            throw PageNotFoundException::forPageNotFound($e->getMessage());
        }

        return $this->memberView('App\Modules\AuthzLab\Views\matrix', [
            'title'   => 'AuthZ Matrix — ' . $project['name'],
            'project' => $project,
        ], 'projects');
    }

    public function run(int $projectId): ResponseInterface
    {
        if ($r = $this->denyViewer()) {
            return $r;
        }
        try {
            $this->edition->requireFeature($this->me(), 'authz_matrix');
            $credIds   = array_map('intval', (array) $this->request->getPost('creds'));
            $endpoints = preg_split('/\r?\n/', (string) $this->request->getPost('endpoints')) ?: [];
            $res       = $this->matrix->run($projectId, $this->me(), $credIds, $endpoints);
        } catch (RuntimeException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok($res);
    }
}
