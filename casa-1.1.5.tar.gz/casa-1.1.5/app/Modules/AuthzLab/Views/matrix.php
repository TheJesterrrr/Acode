<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<?php
/** @var array $project */
$pid   = (int) $project['id'];
$creds = $project['credentials'] ?? [];
?>
<div class="casa-page-head">
  <div>
    <a href="<?= esc(site_url('projects/' . $pid)) ?>" class="small text-muted text-decoration-none"><i class="bi bi-arrow-left"></i> <?= esc($project['name']) ?></a>
    <h1 class="mb-0"><i class="bi bi-grid-3x3-gap me-1"></i>AuthZ Matrix <span class="badge text-bg-warning align-middle"><i class="bi bi-lock-fill"></i> Pro</span></h1>
    <div class="small text-muted">Uji otorisasi lintas-peran (BFLA/BOLA). Setiap endpoint ditembak sebagai tiap akun + Anonymous → matriks akses → AI menandai Broken Access Control (CWE-863).</div>
  </div>
</div>

<div class="row g-3">
  <div class="col-lg-5">
    <div class="casa-card p-3 p-lg-4">
      <h2 class="h6 mb-3">Konfigurasi</h2>
      <form id="azForm">
        <div class="mb-3">
          <label class="form-label small">Akun uji (peran)</label>
          <?php if ($creds === []): ?>
            <div class="small text-muted">Belum ada Test Accounts. <a href="<?= esc(site_url('projects/' . $pid)) ?>">Tambah di project</a>. Uji Anonymous tetap bisa dijalankan.</div>
          <?php else: foreach ($creds as $c): ?>
            <div class="form-check">
              <input class="form-check-input" type="checkbox" name="creds[]" value="<?= (int) $c['id'] ?>" id="c<?= (int) $c['id'] ?>" checked>
              <label class="form-check-label small" for="c<?= (int) $c['id'] ?>"><?= esc($c['label']) ?> <span class="badge text-bg-light border"><?= esc($c['role'] ?: 'user') ?></span> · <?= esc($c['scheme']) ?></label>
            </div>
          <?php endforeach; endif; ?>
        </div>
        <div class="mb-3"><label class="form-label small">Endpoint (satu per baris, opsional prefix METHOD)</label>
          <textarea name="endpoints" class="form-control font-monospace" rows="7" placeholder="http://127.0.0.1:3000/rest/user/whoami&#10;GET http://127.0.0.1:3000/api/Users&#10;http://127.0.0.1:3000/rest/basket/1"></textarea></div>
        <button id="azBtn" class="btn btn-primary"><i class="bi bi-play-fill me-1"></i>Run matrix</button>
        <span id="azMsg" class="small ms-2"></span>
      </form>
    </div>
  </div>
  <div class="col-lg-7">
    <div class="casa-card p-3 p-lg-4 h-100">
      <h2 class="h6 mb-3">Matriks &amp; temuan</h2>
      <div id="azResult" class="text-muted small">Jalankan untuk melihat matriks akses & pelanggaran.</div>
    </div>
  </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('page_scripts') ?>
<script>
const RUN = '<?= esc(site_url('projects/' . $pid . '/authz/run')) ?>';
function cell(c){
  if (c.skip) return '<span class="text-muted">skip</span>';
  if (c.status === 0) return '<span class="text-muted">—</span>';
  const ok = c.status >= 200 && c.status < 300;
  const cls = ok ? 'text-success' : (c.status === 401 || c.status === 403 ? 'text-danger' : 'text-warning');
  return `<span class="${cls}">${c.status}</span><span class="text-muted small">/${c.len}b</span>`;
}
document.getElementById('azForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const b = document.getElementById('azBtn'), m = document.getElementById('azMsg'), out = document.getElementById('azResult');
  b.disabled = true; const o = b.innerHTML; b.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Menguji…'; m.textContent = '';
  const d = await casaPost(RUN, new FormData(e.target));
  b.disabled = false; b.innerHTML = o;
  if (!d.ok) { m.className = 'small ms-2 text-danger'; m.textContent = d.error || 'Gagal.'; return; }
  let h = '<div class="table-responsive"><table class="table table-sm align-middle"><thead><tr><th>Endpoint</th>';
  d.columns.forEach(c => h += `<th class="text-center small">${c.label}<div class="text-muted fw-normal">${c.role}</div></th>`);
  h += '</tr></thead><tbody>';
  d.rows.forEach(r => {
    h += `<tr><td class="font-monospace small">${r.method} ${r.url.replace(/</g,'&lt;')}</td>`;
    d.columns.forEach(c => h += `<td class="text-center small">${cell(r.cells[c.key])}</td>`);
    h += '</tr>';
  });
  h += '</tbody></table></div>';
  if (d.violations.length) {
    h += '<div class="mt-2"><b class="text-danger">Pelanggaran (' + d.violations.length + ')</b>';
    d.violations.forEach((v, i) => {
      const sc = v.severity === 'crit' ? 'danger' : (v.severity === 'high' ? 'warning' : 'secondary');
      h += `<div class="alert alert-${sc} py-2 my-2"><span class="badge text-bg-${sc} text-uppercase me-1">${v.severity}</span>
        <b>${v.role}</b> → <span class="font-monospace">${(v.endpoint||'').replace(/</g,'&lt;')}</span>
        <div class="small">${(v.reason||'').replace(/</g,'&lt;')}</div>
        ${d.finding_ids[i] ? `<a href="/findings/${d.finding_ids[i]}" class="small">Lihat finding #${d.finding_ids[i]}</a>` : ''}</div>`;
    });
    h += '</div>';
  } else {
    h += '<div class="alert alert-success mt-2 py-2"><i class="bi bi-shield-check me-1"></i>Tidak ada pelanggaran otorisasi terdeteksi.</div>';
  }
  out.innerHTML = h;
});
</script>
<?= $this->endSection() ?>
