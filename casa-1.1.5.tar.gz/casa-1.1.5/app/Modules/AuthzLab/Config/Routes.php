<?php

declare(strict_types=1);

use CodeIgniter\Router\RouteCollection;

/** Rute AuthZ Matrix — endpoint MEMBER (CES 13.10). */

/** @var RouteCollection $routes */
$routes->group('projects/(:num)/authz', ['namespace' => 'App\Modules\AuthzLab\Controllers', 'filter' => 'member'], static function (RouteCollection $routes): void {
    $routes->get('', 'AuthzController::show/$1');
    $routes->post('run', 'AuthzController::run/$1', ['filter' => 'audit:AUTHZ_MATRIX']);
});
