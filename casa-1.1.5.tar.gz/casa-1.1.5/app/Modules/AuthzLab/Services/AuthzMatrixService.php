<?php

declare(strict_types=1);

namespace App\Modules\AuthzLab\Services;

use App\Modules\Ai\Services\AiManager;
use App\Modules\Finding\Services\FindingService;
use App\Modules\Project\Models\ProjectCredentialModel;
use App\Modules\Project\Models\ProjectModel;
use App\Modules\Project\Services\AuthContextResolver;
use Config\Services;
use RuntimeException;
use Throwable;

/**
 * AuthzMatrixService — Authorization Matrix (BOLA/BFLA lintas-peran, Master Plan
 * value-add). Menembak tiap endpoint sebagai tiap Test Account (+ Anonymous),
 * menyusun matriks akses, lalu AI menandai Broken Access Control (peran rendah
 * mengakses sumber daya yang seharusnya dibatasi). Catat Finding CWE-863.
 */
final class AuthzMatrixService
{
    private const MAX_ENDPOINTS = 20;

    private const SYS = 'You are a Broken Access Control (BOLA/BFLA) analyst. Given an access matrix '
        . "(endpoints x roles, each cell = HTTP status + body length), identify authorization violations: "
        . "a lower-privilege role (guest/user) or Anonymous obtaining 2xx access to a resource that should be "
        . "restricted (esp. when a higher role also gets it, or when the path implies admin/privileged). "
        . 'Answer STRICT JSON only: {"violations":[{"endpoint":string,"role":string,"severity":"crit|high|med|low","reason":string}]}. Empty list if none.';

    public function __construct(
        private readonly ProjectModel $projects = new ProjectModel(),
        private readonly ProjectCredentialModel $creds = new ProjectCredentialModel(),
        private readonly AuthContextResolver $auth = new AuthContextResolver(),
        private readonly AiManager $ai = new AiManager(),
        private readonly FindingService $findings = new FindingService(),
    ) {
    }

    /**
     * Jalankan matriks otorisasi.
     * @param int[]   $credIds  akun uji yang dipilih
     * @param string[] $endpoints daftar URL (opsional prefix "METHOD ")
     * @return array{columns:array,rows:array,violations:array,finding_ids:array}
     * @throws RuntimeException
     */
    public function run(int $projectId, int $customerId, array $credIds, array $endpoints): array
    {
        if ($this->projects->ownedBy($projectId, $customerId) === null) {
            throw new RuntimeException('Project tidak ditemukan.');
        }
        $endpoints = $this->parseEndpoints($endpoints);
        if ($endpoints === []) {
            throw new RuntimeException('Masukkan minimal satu endpoint (URL).');
        }

        // Kolom: Anonymous + tiap akun terpilih.
        $columns = [['key' => 'anon', 'label' => 'Anonymous', 'role' => 'anonymous', 'headers' => []]];
        foreach ($credIds as $cid) {
            $c = $this->creds->find((int) $cid);
            if ($c === null || (int) $c['project_id'] !== $projectId) {
                continue;
            }
            try {
                $columns[] = ['key' => 'c' . $c['id'], 'label' => $c['label'], 'role' => $c['role'] ?: 'user', 'headers' => $this->auth->headersFor($c)];
            } catch (Throwable $e) {
                $columns[] = ['key' => 'c' . $c['id'], 'label' => $c['label'], 'role' => $c['role'] ?: 'user', 'headers' => null, 'error' => mb_substr($e->getMessage(), 0, 80)];
            }
        }

        $client = Services::curlrequest(['timeout' => 10, 'connect_timeout' => 5, 'http_errors' => false], null, null, false);
        $rows   = [];
        foreach ($endpoints as $ep) {
            $cells = [];
            foreach ($columns as $col) {
                if (($col['headers'] ?? null) === null) {
                    $cells[$col['key']] = ['status' => 0, 'len' => 0, 'skip' => true];
                    continue;
                }
                [$st, $len] = $this->probe($client, $ep['method'], $ep['url'], $col['headers']);
                $cells[$col['key']] = ['status' => $st, 'len' => $len];
            }
            $rows[] = ['method' => $ep['method'], 'url' => $ep['url'], 'cells' => $cells];
        }

        $violations = $this->analyze($columns, $rows);
        $findingIds = $this->record($projectId, $columns, $violations);

        return ['columns' => $columns, 'rows' => $rows, 'violations' => $violations, 'finding_ids' => $findingIds];
    }

    /** @return array<int,array{method:string,url:string}> */
    private function parseEndpoints(array $lines): array
    {
        $out = [];
        foreach ($lines as $line) {
            $line = trim((string) $line);
            if ($line === '') {
                continue;
            }
            $method = 'GET';
            if (preg_match('/^(GET|POST|PUT|DELETE|PATCH)\s+(.+)$/i', $line, $m)) {
                $method = strtoupper($m[1]);
                $line   = trim($m[2]);
            }
            if (! preg_match('#^https?://#i', $line)) {
                continue;
            }
            $out[] = ['method' => $method, 'url' => $line];
            if (count($out) >= self::MAX_ENDPOINTS) {
                break;
            }
        }

        return $out;
    }

    /** @return array{0:int,1:int} [status, bodyLen] */
    private function probe($client, string $method, string $url, array $headers): array
    {
        try {
            $res = $client->request($method, $url, ['headers' => ['Accept' => 'application/json'] + $headers]);

            return [$res->getStatusCode(), mb_strlen((string) $res->getBody())];
        } catch (Throwable $e) {
            return [0, 0];
        }
    }

    /** Path yang lazim publik → JANGAN dianggap pelanggaran hanya karena anon 2xx. */
    private const PUBLIC_RE = '#(product|catalog|category|search|/home|/about|/faq|version|status|health|/login|/register|captcha|/rest/products|/i18n|/assets|/public|robots|sitemap)#i';

    /** Path yang menyiratkan data sensitif/terbatas → kuatkan sinyal pelanggaran. */
    private const SENSITIVE_RE = '#(admin|/users?|/accounts?|/orders?|basket|cart|/me\b|profile|config|secret|token|payment|invoice|address|/card|wallet|balance|saldo|/feedback|private|internal|/export|/download|/delete)#i';

    /**
     * Deteksi pelanggaran: heuristik terarah (bukan sekadar anon 2xx), lalu AI perhalus.
     * @return array<int,array{endpoint:string,role:string,severity:string,reason:string}>
     */
    private function analyze(array $columns, array $rows): array
    {
        $heur = [];
        foreach ($rows as $r) {
            $ep        = $r['method'] . ' ' . $r['url'];
            $isPublic  = (bool) preg_match(self::PUBLIC_RE, $r['url']);
            $sensitive = (bool) preg_match(self::SENSITIVE_RE, $r['url']);

            // 1) Anonymous mengakses data — hanya kandidat bila TIDAK terlihat publik
            //    (endpoint sensitif = severity lebih tinggi).
            $anon = $r['cells']['anon'] ?? null;
            if ($anon && $anon['status'] >= 200 && $anon['status'] < 300 && $anon['len'] > 40 && ! $isPublic) {
                $heur[] = ['endpoint' => $ep, 'role' => 'anonymous', 'severity' => $sensitive ? 'high' : 'med', 'reason' => 'Anonymous memperoleh 2xx berdata pada endpoint non-publik — kemungkinan otorisasi hilang.'];
            }

            // 2) Eskalasi vertikal: peran rendah (guest/user) 2xx pada path yang
            //    menyiratkan admin/privileged, sementara idealnya terbatas.
            if ($sensitive && preg_match('#(admin|internal|/export|/config)#i', $r['url'])) {
                foreach ($columns as $col) {
                    if (in_array($col['role'], ['guest', 'user'], true)) {
                        $c = $r['cells'][$col['key']] ?? null;
                        if ($c && ! ($c['skip'] ?? false) && $c['status'] >= 200 && $c['status'] < 300 && $c['len'] > 40) {
                            $heur[] = ['endpoint' => $ep, 'role' => $col['role'], 'severity' => 'high', 'reason' => "Peran '{$col['role']}' ({$col['label']}) mengakses endpoint privileged — dugaan eskalasi hak (BFLA)."];
                        }
                    }
                }
            }
        }

        // AI memperhalus/menambah berdasarkan matriks lengkap.
        try {
            $matrix = [];
            foreach ($rows as $r) {
                $line = $r['method'] . ' ' . $r['url'] . ' => ';
                foreach ($columns as $col) {
                    $c = $r['cells'][$col['key']];
                    $line .= "[{$col['role']}:{$col['label']}=" . ($c['skip'] ?? false ? 'skip' : "{$c['status']}/{$c['len']}b") . '] ';
                }
                $matrix[] = $line;
            }
            $raw = $this->ai->chatForRole('vuln_analyst', self::SYS, implode("\n", $matrix));
            if (preg_match('/\{.*\}/s', $raw, $mm)) {
                $j = json_decode($mm[0], true);
                if (is_array($j) && isset($j['violations']) && is_array($j['violations'])) {
                    // Grounding: buang halusinasi AI — peran yang tak diuji, atau
                    // endpoint publik (bukan pelanggaran meski 2xx berdata).
                    $roles = array_map(static fn (array $c): string => $c['role'], $columns);
                    $ai    = array_filter($this->normalize($j['violations']), static function (array $v) use ($roles): bool {
                        if (preg_match(self::PUBLIC_RE, $v['endpoint'])) {
                            return false;
                        }

                        return in_array($v['role'], $roles, true);
                    });

                    return $this->dedupe(array_merge($heur, array_values($ai)));
                }
            }
        } catch (Throwable $e) {
            // pakai heuristik saja
        }

        return $this->dedupe($heur);
    }

    private function normalize(array $vios): array
    {
        $out = [];
        foreach ($vios as $v) {
            if (! is_array($v) || empty($v['endpoint'])) {
                continue;
            }
            $out[] = [
                'endpoint' => (string) $v['endpoint'],
                'role'     => (string) ($v['role'] ?? 'user'),
                'severity' => in_array($v['severity'] ?? '', ['crit', 'high', 'med', 'low'], true) ? $v['severity'] : 'med',
                'reason'   => (string) ($v['reason'] ?? 'Broken access control terdeteksi.'),
            ];
        }

        return $out;
    }

    private function dedupe(array $vios): array
    {
        $seen = [];
        $out  = [];
        foreach ($vios as $v) {
            $k = $v['endpoint'] . '|' . $v['role'];
            if (isset($seen[$k])) {
                continue;
            }
            $seen[$k] = true;
            $out[]    = $v;
        }

        return $out;
    }

    /** @return int[] */
    private function record(int $projectId, array $columns, array $violations): array
    {
        $ids = [];
        foreach ($violations as $v) {
            $sev   = $v['severity'] === 'crit' ? 'crit' : ($v['severity'] === 'low' ? 'low' : $v['severity']);
            $ids[] = $this->findings->record([
                'project_id'  => $projectId,
                'title'       => 'Broken Access Control — ' . $v['role'] . ' → ' . $v['endpoint'],
                'severity'    => $sev,
                'cwe'         => 'CWE-863',
                'cvss'        => $v['severity'] === 'crit' ? '9.0' : ($v['severity'] === 'high' ? '7.5' : '5.3'),
                'category'    => 'Broken Access Control (BFLA/BOLA)',
                'asset'       => $v['endpoint'],
                'tool'        => 'authz-matrix',
                'description' => "Otorisasi bermasalah: {$v['reason']} Peran: {$v['role']}.",
                'evidence'    => 'AuthZ Matrix lintas-peran (' . count($columns) . ' identitas diuji).',
                'remediation' => 'Terapkan pemeriksaan otorisasi per fungsi & per objek di sisi server (deny-by-default). Verifikasi peran/kepemilikan untuk setiap endpoint sensitif; jangan andalkan penyembunyian di UI.',
            ]);
        }

        return $ids;
    }
}
