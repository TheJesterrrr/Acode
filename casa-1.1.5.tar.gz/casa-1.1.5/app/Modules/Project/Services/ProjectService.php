<?php

declare(strict_types=1);

namespace App\Modules\Project\Services;

use App\Modules\Licensing\Services\EditionService;
use App\Modules\Project\Models\AssetModel;
use App\Modules\Project\Models\ProjectCredentialModel;
use App\Modules\Project\Models\ProjectModel;
use App\Modules\Project\Models\ScopeModel;
use App\Modules\Project\Models\TargetModel;
use RuntimeException;

/**
 * ProjectService — pintu tunggal Project/Target/Scope (CES 13.4). SETIAP operasi
 * di-scope ke pemilik (`customer_id`): member hanya dapat menyentuh miliknya
 * (Master Plan §3; RBAC berbasis kepemilikan, Kitab 5.4). Bukan hanya menu.
 */
final class ProjectService
{
    public const TARGET_TYPES = ['domain', 'subdomain', 'ip', 'cidr', 'url', 'api', 'asn', 'mobile', 'cloud', 'repo', 'image'];
    public const PLATFORMS     = ['hackerone', 'bugcrowd', 'intigriti', 'yeswehack', 'synack', 'private'];
    /** Skema auth akun uji + peran (auth-context untuk IDOR/injection). */
    public const CRED_SCHEMES = ['bearer', 'cookie', 'basic', 'form_json'];
    public const CRED_ROLES   = ['admin', 'user', 'guest', 'editor', 'support'];

    public function __construct(
        private readonly ProjectModel $projects = new ProjectModel(),
        private readonly TargetModel $targets = new TargetModel(),
        private readonly ScopeModel $scopes = new ScopeModel(),
        private readonly AssetModel $assets = new AssetModel(),
        private readonly ProjectCredentialModel $creds = new ProjectCredentialModel(),
        private readonly EditionService $edition = new EditionService(),
    ) {
    }

    /** @return array<int,array<string,mixed>> */
    /** Daftar project untuk satu mode (default pentest; bounty punya listnya sendiri). */
    public function listProjects(int $customerId, string $mode = 'pentest'): array
    {
        $rows = $this->projects->forCustomerMode($customerId, $mode);
        foreach ($rows as &$p) {
            $p['target_count'] = count($this->targets->forProject((int) $p['id']));
        }

        return $rows;
    }

    public function createProject(int $customerId, array $in): int
    {
        $name = trim((string) ($in['name'] ?? ''));
        if ($name === '') {
            throw new RuntimeException('Nama project wajib diisi.');
        }
        $mode = (($in['mode'] ?? '') === 'bounty') ? 'bounty' : 'pentest';
        // Gerbang kuota edisi (Community/Pro/Enterprise) — dihitung PER MODE.
        $this->edition->requireQuota($customerId, 'projects', $this->projects->countForCustomerMode($customerId, $mode));
        $platform = (string) ($in['platform'] ?? '');

        return (int) $this->projects->insert([
            'customer_id' => $customerId,
            'mode'        => $mode,
            'name'        => $name,
            'program_url' => trim((string) ($in['program_url'] ?? '')) ?: null,
            'platform'    => in_array($platform, self::PLATFORMS, true) ? $platform : null,
            'status'      => 'active',
        ], true);
    }

    /** Project lengkap (target, scope, jumlah asset). @throws RuntimeException 404 */
    public function getProject(int $id, int $customerId): array
    {
        $p = $this->requireOwned($id, $customerId);
        $p['targets']     = $this->targets->forProject($id);
        $p['scopes']      = $this->scopes->forProject($id);
        $p['asset_count'] = $this->assets->countForProject($id);
        $p['credentials'] = $this->creds->forProjectSafe($id);

        return $p;
    }

    public function deleteProject(int $id, int $customerId): void
    {
        $this->requireOwned($id, $customerId);
        $this->projects->delete($id); // soft delete
    }

    public function addTarget(int $projectId, int $customerId, string $type, string $value, string $note = ''): void
    {
        $this->requireOwned($projectId, $customerId);
        $type  = strtolower(trim($type));
        $value = trim($value);
        if (! in_array($type, self::TARGET_TYPES, true)) {
            throw new RuntimeException('Jenis target tidak dikenal.');
        }
        if ($value === '') {
            throw new RuntimeException('Nilai target wajib diisi.');
        }
        $this->targets->insert(['project_id' => $projectId, 'type' => $type, 'value' => $value, 'note' => $note ?: null]);
    }

    public function deleteTarget(int $projectId, int $customerId, int $targetId): void
    {
        $this->requireOwned($projectId, $customerId);
        $t = $this->targets->find($targetId);
        if ($t === null || (int) $t['project_id'] !== $projectId) {
            throw new RuntimeException('Target tidak ditemukan.');
        }
        $this->targets->delete($targetId);
    }

    public function addScope(int $projectId, int $customerId, string $kind, string $pattern, string $note = ''): void
    {
        $this->requireOwned($projectId, $customerId);
        $kind    = strtolower(trim($kind));
        $pattern = trim($pattern);
        if (! in_array($kind, ['in', 'out'], true)) {
            throw new RuntimeException('Jenis scope harus in atau out.');
        }
        if ($pattern === '') {
            throw new RuntimeException('Pola scope wajib diisi.');
        }
        $this->scopes->insert(['project_id' => $projectId, 'kind' => $kind, 'pattern' => $pattern, 'note' => $note ?: null]);
    }

    public function deleteScope(int $projectId, int $customerId, int $scopeId): void
    {
        $this->requireOwned($projectId, $customerId);
        $s = $this->scopes->find($scopeId);
        if ($s === null || (int) $s['project_id'] !== $projectId) {
            throw new RuntimeException('Entri scope tidak ditemukan.');
        }
        $this->scopes->delete($scopeId);
    }

    public function saveSettings(int $projectId, int $customerId, array $in): void
    {
        $this->requireOwned($projectId, $customerId);
        $rate = $in['rate_limit'] ?? '';
        $this->projects->update($projectId, [
            'rate_limit'        => ($rate === '' || $rate === null) ? null : max(0, (int) $rate),
            'auth_required'     => ! empty($in['auth_required']) ? 1 : 0,
            'business_critical' => trim((string) ($in['business_critical'] ?? '')) ?: null,
            'program_url'       => trim((string) ($in['program_url'] ?? '')) ?: null,
            'platform'          => in_array((string) ($in['platform'] ?? ''), self::PLATFORMS, true) ? $in['platform'] : null,
        ]);
    }

    /** Tambah akun uji (auth-context). Rahasia disimpan terenkripsi. */
    public function addCredential(int $projectId, int $customerId, array $in): void
    {
        $this->requireOwned($projectId, $customerId);
        $label  = trim((string) ($in['label'] ?? ''));
        $scheme = (string) ($in['scheme'] ?? '');
        if ($label === '') {
            throw new RuntimeException('Label akun wajib diisi.');
        }
        if (! in_array($scheme, self::CRED_SCHEMES, true)) {
            throw new RuntimeException('Skema auth tidak dikenal.');
        }
        $role   = (string) ($in['role'] ?? '');
        $secret = (string) ($in['secret'] ?? '');
        if ($secret === '') {
            throw new RuntimeException('Rahasia (token/cookie/password) wajib diisi.');
        }
        $this->creds->add([
            'project_id' => $projectId,
            'label'      => $label,
            'role'       => in_array($role, self::CRED_ROLES, true) ? $role : null,
            'scheme'     => $scheme,
            'login_url'  => trim((string) ($in['login_url'] ?? '')) ?: null,
            'username'   => trim((string) ($in['username'] ?? '')) ?: null,
            'note'       => trim((string) ($in['note'] ?? '')) ?: null,
        ], $secret);
    }

    public function deleteCredential(int $projectId, int $customerId, int $credId): void
    {
        $this->requireOwned($projectId, $customerId);
        $c = $this->creds->find($credId);
        if ($c === null || (int) $c['project_id'] !== $projectId) {
            throw new RuntimeException('Akun uji tidak ditemukan.');
        }
        $this->creds->delete($credId);
    }

    /** Aset hasil recon untuk Attack Surface. */
    public function listAssets(int $projectId, int $customerId): array
    {
        $this->requireOwned($projectId, $customerId);

        return $this->assets->forProject($projectId);
    }

    /** Rahasia terdekripsi satu akun (pemakaian internal adapter). */
    public function credentialSecret(int $projectId, int $customerId, int $credId): string
    {
        $this->requireOwned($projectId, $customerId);
        $c = $this->creds->find($credId);
        if ($c === null || (int) $c['project_id'] !== $projectId) {
            return '';
        }

        return $this->creds->secretFor($credId);
    }

    /** @return array<string,mixed> @throws RuntimeException bila bukan milik member */
    private function requireOwned(int $id, int $customerId): array
    {
        $p = $this->projects->ownedBy($id, $customerId);
        if ($p === null) {
            throw new RuntimeException('Project tidak ditemukan.');
        }

        return $p;
    }
}
