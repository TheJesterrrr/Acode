<?php

declare(strict_types=1);

namespace App\Modules\Project\Services;

use App\Modules\Project\Models\ProjectCredentialModel;
use Config\Services;
use RuntimeException;
use Throwable;

/**
 * AuthContextResolver — ubah Test Account (project_credential terenkripsi) menjadi
 * header auth siap-pakai untuk uji terautentikasi (IDOR/BOLA, AuthZ Matrix, dst.).
 * Mendukung skema bearer/cookie/basic/form_json (auto-login → ekstrak token).
 */
final class AuthContextResolver
{
    public function __construct(
        private readonly ProjectCredentialModel $creds = new ProjectCredentialModel(),
    ) {
    }

    /**
     * Header auth untuk sebuah kredensial.
     * @return array<string,string>
     * @throws RuntimeException
     */
    public function headersFor(array $cred): array
    {
        $secret = $this->creds->secretFor((int) $cred['id']);
        if ($secret === '') {
            throw new RuntimeException("Rahasia akun '{$cred['label']}' kosong.");
        }

        return match ($cred['scheme']) {
            'bearer'    => ['Authorization' => 'Bearer ' . $secret],
            'cookie'    => ['Cookie' => $secret],
            'basic'     => ['Authorization' => 'Basic ' . base64_encode(($cred['username'] ?? '') . ':' . $secret)],
            'form_json' => ['Authorization' => 'Bearer ' . $this->login((string) $cred['login_url'], (string) ($cred['username'] ?? ''), $secret)],
            default     => throw new RuntimeException('Skema auth tidak didukung.'),
        };
    }

    /** Auto-login (form JSON) → ekstrak token. */
    private function login(string $url, string $user, string $pass): string
    {
        if ($url === '') {
            throw new RuntimeException('login_url wajib untuk skema form_json.');
        }
        $client = Services::curlrequest(['timeout' => 12, 'http_errors' => false], null, null, false);
        try {
            $res = $client->post($url, ['headers' => ['Content-Type' => 'application/json', 'Accept' => 'application/json'], 'body' => json_encode(['email' => $user, 'username' => $user, 'password' => $pass])]);
            $j   = json_decode((string) $res->getBody(), true);
        } catch (Throwable $e) {
            throw new RuntimeException('Login akun gagal: ' . mb_substr($e->getMessage(), 0, 80));
        }
        $token = $this->digToken(is_array($j) ? $j : []);
        if ($token === '') {
            throw new RuntimeException('Token tak ditemukan pada respons login.');
        }

        return $token;
    }

    private function digToken(array $j): string
    {
        foreach ([$j['authentication']['token'] ?? null, $j['token'] ?? null, $j['access_token'] ?? null, $j['data']['token'] ?? null, $j['jwt'] ?? null] as $t) {
            if (is_string($t) && $t !== '') {
                return $t;
            }
        }

        return '';
    }
}
