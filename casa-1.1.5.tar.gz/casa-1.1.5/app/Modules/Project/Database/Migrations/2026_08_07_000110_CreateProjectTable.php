<?php

declare(strict_types=1);

namespace App\Modules\Project\Database\Migrations;

use CodeIgniter\Database\Migration;
use CodeIgniter\Database\RawSql;

/** Tabel `project` — cakupan kerja member (Master Plan §5; CES 13.8). Soft delete. */
final class CreateProjectTable extends Migration
{
    public function up(): void
    {
        $this->forge->addField([
            'id'                => ['type' => 'BIGINT', 'unsigned' => true, 'auto_increment' => true],
            'customer_id'       => ['type' => 'BIGINT', 'unsigned' => true], // pemilik (member)
            'name'              => ['type' => 'VARCHAR', 'constraint' => 120],
            'program_url'       => ['type' => 'VARCHAR', 'constraint' => 200, 'null' => true],
            'platform'          => ['type' => 'VARCHAR', 'constraint' => 20, 'null' => true], // hackerone|bugcrowd|intigriti|yeswehack|synack|private
            'rate_limit'        => ['type' => 'INT', 'constraint' => 6, 'null' => true],        // req/s
            'auth_required'     => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 0],
            'business_critical' => ['type' => 'VARCHAR', 'constraint' => 200, 'null' => true],
            'status'            => ['type' => 'VARCHAR', 'constraint' => 12, 'default' => 'active'], // active|archived
            'created_at'        => ['type' => 'TIMESTAMP', 'default' => new RawSql('CURRENT_TIMESTAMP')],
            'updated_at'        => ['type' => 'TIMESTAMP', 'default' => new RawSql('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP')],
            'deleted_at'        => ['type' => 'TIMESTAMP', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey('customer_id');
        $this->forge->createTable('project', true, ['ENGINE' => 'InnoDB', 'DEFAULT CHARSET' => 'utf8mb4', 'COLLATE' => 'utf8mb4_unicode_ci']);
    }

    public function down(): void
    {
        $this->forge->dropTable('project', true);
    }
}
