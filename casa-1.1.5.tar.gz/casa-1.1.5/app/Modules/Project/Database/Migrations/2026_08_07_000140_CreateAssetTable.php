<?php

declare(strict_types=1);

namespace App\Modules\Project\Database\Migrations;

use CodeIgniter\Database\Migration;
use CodeIgniter\Database\RawSql;

/**
 * Tabel `asset` — aset yang ditemukan di bawah target (Master Plan §5).
 * Umumnya diisi hasil recon (Asset/DNS/Port/Service/Tech discovery), bukan input
 * manual. Dibuat sekarang untuk melengkapi relasi project→target→asset.
 */
final class CreateAssetTable extends Migration
{
    public function up(): void
    {
        $this->forge->addField([
            'id'         => ['type' => 'BIGINT', 'unsigned' => true, 'auto_increment' => true],
            'project_id' => ['type' => 'BIGINT', 'unsigned' => true],
            'target_id'  => ['type' => 'BIGINT', 'unsigned' => true, 'null' => true],
            'type'       => ['type' => 'VARCHAR', 'constraint' => 20], // host|service|url|tech|dns|port
            'value'      => ['type' => 'VARCHAR', 'constraint' => 255],
            'source'     => ['type' => 'VARCHAR', 'constraint' => 40, 'null' => true], // tool asal
            'created_at' => ['type' => 'TIMESTAMP', 'default' => new RawSql('CURRENT_TIMESTAMP')],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey('project_id');
        $this->forge->createTable('asset', true, ['ENGINE' => 'InnoDB', 'DEFAULT CHARSET' => 'utf8mb4', 'COLLATE' => 'utf8mb4_unicode_ci']);
    }

    public function down(): void
    {
        $this->forge->dropTable('asset', true);
    }
}
