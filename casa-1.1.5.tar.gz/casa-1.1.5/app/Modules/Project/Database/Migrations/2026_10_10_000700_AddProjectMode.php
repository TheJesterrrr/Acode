<?php

declare(strict_types=1);

namespace App\Modules\Project\Database\Migrations;

use CodeIgniter\Database\Migration;

/** Tambah `mode` pada `project` — pentest | bounty (portal dua-mode). */
final class AddProjectMode extends Migration
{
    public function up(): void
    {
        if (! $this->db->fieldExists('mode', 'project')) {
            $this->forge->addColumn('project', [
                'mode' => ['type' => 'ENUM', 'constraint' => ['pentest', 'bounty'], 'default' => 'pentest', 'after' => 'customer_id'],
            ]);
        }
    }

    public function down(): void
    {
        if ($this->db->fieldExists('mode', 'project')) {
            $this->forge->dropColumn('project', 'mode');
        }
    }
}
