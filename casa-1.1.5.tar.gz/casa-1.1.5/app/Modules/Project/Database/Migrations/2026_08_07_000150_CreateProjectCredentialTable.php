<?php

declare(strict_types=1);

namespace App\Modules\Project\Database\Migrations;

use CodeIgniter\Database\Migration;
use CodeIgniter\Database\RawSql;

/**
 * Tabel `project_credential` — akun uji per project (auth-context). Menyimpan
 * kredensial untuk pengujian terautentikasi (IDOR/BOLA cross-role, injection
 * POST). Rahasia (token/cookie/password) DISIMPAN TERENKRIPSI (Crypto, Kitab 5.6);
 * tidak pernah dikembalikan ke tampilan.
 */
final class CreateProjectCredentialTable extends Migration
{
    public function up(): void
    {
        $this->forge->addField([
            'id'         => ['type' => 'BIGINT', 'unsigned' => true, 'auto_increment' => true],
            'project_id' => ['type' => 'BIGINT', 'unsigned' => true],
            'label'      => ['type' => 'VARCHAR', 'constraint' => 60],   // mis. "User A"
            'role'       => ['type' => 'VARCHAR', 'constraint' => 24, 'null' => true], // admin|user|guest|editor|support
            'scheme'     => ['type' => 'VARCHAR', 'constraint' => 12],   // bearer|cookie|basic|form_json
            'login_url'  => ['type' => 'VARCHAR', 'constraint' => 200, 'null' => true],
            'username'   => ['type' => 'VARCHAR', 'constraint' => 120, 'null' => true],
            'secret_enc' => ['type' => 'TEXT', 'null' => true],          // token/cookie/password (terenkripsi)
            'note'       => ['type' => 'VARCHAR', 'constraint' => 150, 'null' => true],
            'created_at' => ['type' => 'TIMESTAMP', 'default' => new RawSql('CURRENT_TIMESTAMP')],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey('project_id');
        $this->forge->createTable('project_credential', true, ['ENGINE' => 'InnoDB', 'DEFAULT CHARSET' => 'utf8mb4', 'COLLATE' => 'utf8mb4_unicode_ci']);
    }

    public function down(): void
    {
        $this->forge->dropTable('project_credential', true);
    }
}
