<?php

declare(strict_types=1);

namespace App\Modules\Project\Models;

use CodeIgniter\Model;

/** TargetModel — tabel `target` (CES 13.3). */
final class TargetModel extends Model
{
    protected $table         = 'target';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $useTimestamps = false;
    protected $allowedFields = ['project_id', 'type', 'value', 'note'];

    public function forProject(int $projectId): array
    {
        return $this->where('project_id', $projectId)->orderBy('id', 'ASC')->findAll();
    }
}
