<?php

declare(strict_types=1);

namespace App\Modules\Project\Models;

use CodeIgniter\Model;

/** AssetModel — tabel `asset` (CES 13.3). Umumnya diisi hasil recon. */
final class AssetModel extends Model
{
    protected $table         = 'asset';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $useTimestamps = false;
    protected $allowedFields = ['project_id', 'target_id', 'type', 'value', 'source'];

    public function countForProject(int $projectId): int
    {
        return $this->where('project_id', $projectId)->countAllResults();
    }

    /** @return array<int,array<string,mixed>> aset project (untuk Attack Surface) */
    public function forProject(int $projectId): array
    {
        return $this->where('project_id', $projectId)->orderBy('type', 'ASC')->orderBy('id', 'DESC')->findAll();
    }

    /**
     * Semua aset milik pelanggan lintas project (untuk Attack Surface global).
     * @return array<int,array<string,mixed>>
     */
    public function forCustomer(int $customerId, string $type = '', string $q = ''): array
    {
        $b = $this->select('asset.*, project.name AS project_name, target.value AS target_value')
            ->join('project', 'project.id = asset.project_id')
            ->join('target', 'target.id = asset.target_id', 'left')
            ->where('project.customer_id', $customerId)
            ->where('project.deleted_at', null);
        if ($type !== '') {
            $b->where('asset.type', $type);
        }
        if ($q !== '') {
            $b->like('asset.value', $q);
        }

        return $b->orderBy('asset.type', 'ASC')->orderBy('asset.id', 'DESC')->findAll(3000);
    }

    /** Hitung aset per tipe milik pelanggan. @return array<string,int> */
    public function typeStatsForCustomer(int $customerId): array
    {
        $rows = $this->select('asset.type AS t, COUNT(*) AS n')
            ->join('project', 'project.id = asset.project_id')
            ->where('project.customer_id', $customerId)
            ->where('project.deleted_at', null)
            ->groupBy('asset.type')
            ->findAll();
        $out = [];
        foreach ($rows as $r) {
            $out[(string) $r['t']] = (int) $r['n'];
        }

        return $out;
    }

    /** Sisipkan bila belum ada (dedup per project+type+value). */
    public function addUnique(int $projectId, string $type, string $value, ?string $source = null, ?int $targetId = null): void
    {
        $value = mb_substr(trim($value), 0, 255);
        if ($value === '') {
            return;
        }
        if ($this->where('project_id', $projectId)->where('type', $type)->where('value', $value)->countAllResults() === 0) {
            $this->insert(['project_id' => $projectId, 'target_id' => $targetId, 'type' => $type, 'value' => $value, 'source' => $source]);
        }
    }
}
