<?php

declare(strict_types=1);

namespace App\Modules\Project\Models;

use CodeIgniter\Model;

/** ProjectModel — tabel `project` (CES 13.3). Soft delete; scope kepemilikan di service. */
final class ProjectModel extends Model
{
    protected $table         = 'project';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $useTimestamps = false;
    protected $useSoftDeletes = true;
    protected $deletedField   = 'deleted_at';
    protected $allowedFields  = [
        'customer_id', 'mode', 'name', 'program_url', 'platform', 'rate_limit',
        'auth_required', 'business_critical', 'status',
    ];

    /** @return array<int,array<string,mixed>> project milik satu member */
    public function forCustomer(int $customerId): array
    {
        return $this->where('customer_id', $customerId)->orderBy('id', 'DESC')->findAll();
    }

    /** Project milik member untuk satu mode (pentest|bounty). */
    public function forCustomerMode(int $customerId, string $mode): array
    {
        return $this->where('customer_id', $customerId)->where('mode', $mode)->orderBy('id', 'DESC')->findAll();
    }

    /** Jumlah project aktif (belum dihapus) per mode — untuk kuota per-mode. */
    public function countForCustomerMode(int $customerId, string $mode): int
    {
        return $this->where('customer_id', $customerId)->where('mode', $mode)->countAllResults();
    }

    /** Satu project milik member (null bila bukan miliknya/tak ada). */
    public function ownedBy(int $id, int $customerId): ?array
    {
        return $this->where('customer_id', $customerId)->find($id);
    }
}
