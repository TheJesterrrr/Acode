<?php

declare(strict_types=1);

namespace App\Modules\Project\Models;

use App\Libraries\Crypto;
use CodeIgniter\Model;
use Throwable;

/**
 * ProjectCredentialModel — akun uji per project (`project_credential`). Rahasia
 * (`secret_enc`) terenkripsi AES-256-GCM; HANYA didekripsi via {@see secretFor()}
 * untuk pemakaian internal (login/attach header saat scan). Tidak pernah
 * dikembalikan ke tampilan (Kitab 5.6/5.7).
 */
final class ProjectCredentialModel extends Model
{
    protected $table         = 'project_credential';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $useTimestamps = false;
    protected $allowedFields = ['project_id', 'label', 'role', 'scheme', 'login_url', 'username', 'secret_enc', 'note'];

    /** Daftar akun uji project TANPA rahasia (hanya flag has_secret). */
    public function forProjectSafe(int $projectId): array
    {
        $out = [];
        foreach ($this->where('project_id', $projectId)->orderBy('id', 'ASC')->findAll() as $r) {
            $r['has_secret'] = ((string) ($r['secret_enc'] ?? '')) !== '';
            unset($r['secret_enc']);
            $out[] = $r;
        }

        return $out;
    }

    /** Simpan; rahasia dienkripsi. */
    public function add(array $fields, ?string $plainSecret): int
    {
        if ($plainSecret !== null && $plainSecret !== '') {
            $fields['secret_enc'] = Crypto::encryptText($plainSecret);
        }

        return (int) $this->insert($fields, true);
    }

    /** Rahasia terdekripsi untuk pemakaian internal; '' bila kosong/gagal. */
    public function secretFor(int $id): string
    {
        $row = $this->find($id);
        $enc = (string) ($row['secret_enc'] ?? '');
        if ($enc === '') {
            return '';
        }
        try {
            return Crypto::decryptText($enc);
        } catch (Throwable $e) {
            log_message('error', "Gagal mendekripsi kredensial {$id}: " . $e->getMessage());

            return '';
        }
    }
}
