<?php

declare(strict_types=1);

namespace App\Modules\Project\Models;

use CodeIgniter\Model;

/** ScopeModel — tabel `scope` (CES 13.3). */
final class ScopeModel extends Model
{
    protected $table         = 'scope';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $useTimestamps = false;
    protected $allowedFields = ['project_id', 'kind', 'pattern', 'note'];

    public function forProject(int $projectId): array
    {
        return $this->where('project_id', $projectId)->orderBy('kind', 'ASC')->orderBy('id', 'ASC')->findAll();
    }
}
