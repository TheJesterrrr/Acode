<?php

declare(strict_types=1);

namespace App\Modules\Project\Controllers;

use App\Controllers\BaseController;
use App\Modules\Project\Services\ProjectService;
use CodeIgniter\Exceptions\PageNotFoundException;
use CodeIgniter\HTTP\ResponseInterface;
use RuntimeException;

/**
 * ProjectController — Project/Target/Scope milik member (CES 13.2 thin). Semua
 * aksi memakai `member_id` dari sesi; service menegakkan kepemilikan.
 */
final class ProjectController extends BaseController
{
    public function __construct(
        private readonly ProjectService $projects = new ProjectService(),
    ) {
    }

    private function me(): int
    {
        return (int) $this->session->get('member_id');
    }

    public function index(): string
    {
        return $this->memberView('App\Modules\Project\Views\index', [
            'title'    => 'Projects',
            'projects' => $this->projects->listProjects($this->me()),
        ], 'projects');
    }

    public function store(): ResponseInterface
    {
        if ($r = $this->denyViewer()) {
            return $r;
        }
        try {
            $id = $this->projects->createProject($this->me(), [
                'name'        => $this->request->getPost('name'),
                'platform'    => $this->request->getPost('platform'),
                'program_url' => $this->request->getPost('program_url'),
            ]);
        } catch (RuntimeException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok(['message' => 'Project dibuat.', 'redirect' => site_url('projects/' . $id)]);
    }

    public function show(int $id): string
    {
        try {
            $project = $this->projects->getProject($id, $this->me());
        } catch (RuntimeException $e) {
            throw PageNotFoundException::forPageNotFound($e->getMessage());
        }

        return $this->memberView('App\Modules\Project\Views\show', [
            'title'       => $project['name'],
            'project'     => $project,
            'types'       => ProjectService::TARGET_TYPES,
            'platforms'   => ProjectService::PLATFORMS,
            'credSchemes' => ProjectService::CRED_SCHEMES,
            'credRoles'   => ProjectService::CRED_ROLES,
        ], 'projects');
    }

    public function attackSurface(int $id): string
    {
        try {
            $project = $this->projects->getProject($id, $this->me());
            $assets  = $this->projects->listAssets($id, $this->me());
        } catch (RuntimeException $e) {
            throw PageNotFoundException::forPageNotFound($e->getMessage());
        }

        return $this->memberView('App\Modules\Project\Views\attack_surface', [
            'title'   => 'Attack Surface — ' . $project['name'],
            'project' => $project,
            'assets'  => $assets,
        ], 'projects');
    }

    public function destroy(int $id): ResponseInterface
    {
        if ($r = $this->denyViewer()) {
            return $r;
        }
        try {
            $this->projects->deleteProject($id, $this->me());
        } catch (RuntimeException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok(['message' => 'Project dihapus.', 'redirect' => site_url('projects')]);
    }

    public function addTarget(int $id): ResponseInterface
    {
        if ($r = $this->denyViewer()) {
            return $r;
        }
        try {
            $this->projects->addTarget($id, $this->me(), (string) $this->request->getPost('type'), (string) $this->request->getPost('value'), (string) $this->request->getPost('note'));
        } catch (RuntimeException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok(['message' => 'Target ditambahkan.']);
    }

    public function delTarget(int $id, int $targetId): ResponseInterface
    {
        if ($r = $this->denyViewer()) {
            return $r;
        }
        try {
            $this->projects->deleteTarget($id, $this->me(), $targetId);
        } catch (RuntimeException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok(['message' => 'Target dihapus.']);
    }

    public function addScope(int $id): ResponseInterface
    {
        if ($r = $this->denyViewer()) {
            return $r;
        }
        try {
            $this->projects->addScope($id, $this->me(), (string) $this->request->getPost('kind'), (string) $this->request->getPost('pattern'), (string) $this->request->getPost('note'));
        } catch (RuntimeException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok(['message' => 'Scope ditambahkan.']);
    }

    public function delScope(int $id, int $scopeId): ResponseInterface
    {
        if ($r = $this->denyViewer()) {
            return $r;
        }
        try {
            $this->projects->deleteScope($id, $this->me(), $scopeId);
        } catch (RuntimeException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok(['message' => 'Scope dihapus.']);
    }

    public function addCred(int $id): ResponseInterface
    {
        if ($r = $this->denyViewer()) {
            return $r;
        }
        try {
            $this->projects->addCredential($id, $this->me(), [
                'label'     => $this->request->getPost('label'),
                'role'      => $this->request->getPost('role'),
                'scheme'    => $this->request->getPost('scheme'),
                'login_url' => $this->request->getPost('login_url'),
                'username'  => $this->request->getPost('username'),
                'secret'    => $this->request->getPost('secret'),
                'note'      => $this->request->getPost('note'),
            ]);
        } catch (RuntimeException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok(['message' => 'Akun uji ditambahkan.']);
    }

    public function delCred(int $id, int $credId): ResponseInterface
    {
        if ($r = $this->denyViewer()) {
            return $r;
        }
        try {
            $this->projects->deleteCredential($id, $this->me(), $credId);
        } catch (RuntimeException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok(['message' => 'Akun uji dihapus.']);
    }

    public function saveSettings(int $id): ResponseInterface
    {
        if ($r = $this->denyViewer()) {
            return $r;
        }
        try {
            $this->projects->saveSettings($id, $this->me(), [
                'rate_limit'        => $this->request->getPost('rate_limit'),
                'auth_required'     => $this->request->getPost('auth_required'),
                'business_critical' => $this->request->getPost('business_critical'),
                'program_url'       => $this->request->getPost('program_url'),
                'platform'          => $this->request->getPost('platform'),
            ]);
        } catch (RuntimeException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok(['message' => 'Pengaturan scope disimpan.']);
    }
}
