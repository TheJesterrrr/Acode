# Modul Project — Project / Target / Scope / Asset

Fondasi cakupan kerja member (Master Plan §4/§5). Menyediakan Target Management
dan Scope Management (Plan Feature #1–#2); menjadi sumber bagi Policy Engine dan
Mission. **Modul MEMBER** (endpoint member), di-scope per pemilik (`customer_id`).

## Isi
- Migrasi `project` (soft delete), `target`, `scope`, `asset`.
- `Models/` ProjectModel, TargetModel, ScopeModel, AssetModel.
- `Services/ProjectService` — pintu tunggal; **menegakkan kepemilikan** pada setiap operasi (member hanya miliknya, Kitab 5.4 — bukan hanya menu).
- `Controllers/ProjectController` — thin (13.2), memakai `member_id` sesi + `memberView`.
- `Config/Routes.php` — grup `projects`, filter `member` + `audit:*`.
- `Views/index.php` (daftar + buat) & `Views/show.php` (target, scope, aturan).

## Model data (Master Plan §5)
`project 1—N target`, `project 1—N scope`, `project 1—N asset`.
- **Target**: type ∈ {domain, subdomain, ip, cidr, url, api, asn, mobile, cloud} + value.
- **Scope**: kind ∈ {in, out} + pattern (mis. `*.example.com`) → sumber Policy.
- **Aturan scope** (project): rate_limit (req/s), auth_required, business_critical,
  platform, program_url — batas yang dibaca Policy Engine sebelum eksekusi.
- **Asset**: umumnya diisi hasil recon (bukan input manual); tabel disiapkan.

## Keamanan
Setiap query di-filter `customer_id` pemilik; akses lintas-member ditolak di
service (404), bukan hanya disembunyikan dari menu (RBAC per objek, Kitab 5.4).
Aksi mengubah data lewat CSRF + filter `audit:*`.

## Roadmap
Impor scope otomatis dari halaman program (via AI Rule Parser — modul Policy),
tampilan asset hasil recon, dan dasbor scan berjalan per project.
