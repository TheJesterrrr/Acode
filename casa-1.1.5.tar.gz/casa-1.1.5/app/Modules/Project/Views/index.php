<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<?php /** @var array $projects */ ?>
<div class="casa-page-head d-flex flex-wrap align-items-center gap-2">
  <div>
    <h1>Projects</h1>
    <p class="text-muted small mb-0">Cakupan kerja Anda — target dan scope per program.</p>
  </div>
  <button class="btn btn-primary ms-auto" data-bs-toggle="collapse" data-bs-target="#newProj"><i class="bi bi-plus-lg me-1"></i>Project baru</button>
</div>

<div class="collapse mb-3" id="newProj">
  <div class="casa-card p-3 p-lg-4">
    <form id="projForm" class="row g-2 align-items-end">
      <div class="col-lg-4"><label class="form-label small">Nama project</label>
        <input name="name" class="form-control" placeholder="mis. Acme Shop — HackerOne" required></div>
      <div class="col-lg-3"><label class="form-label small">Platform</label>
        <select name="platform" class="form-select">
          <option value="">— pilih —</option>
          <?php foreach (['hackerone', 'bugcrowd', 'intigriti', 'yeswehack', 'synack', 'private'] as $p): ?>
            <option value="<?= $p ?>"><?= ucfirst($p) ?></option>
          <?php endforeach; ?>
        </select></div>
      <div class="col-lg-4"><label class="form-label small">URL program</label>
        <input name="program_url" class="form-control" placeholder="https://hackerone.com/acme-shop"></div>
      <div class="col-lg-1"><button class="btn btn-primary w-100">Create</button></div>
    </form>
    <div id="projMsg" class="small mt-2"></div>
  </div>
</div>

<?php if ($projects === []): ?>
  <div class="casa-card p-5 text-center text-muted">
    <i class="bi bi-folder2-open fs-1 d-block mb-2"></i>
    Belum ada project. Klik <b>Project baru</b> untuk memulai.
  </div>
<?php else: ?>
  <div class="row g-3">
    <?php foreach ($projects as $p): ?>
      <div class="col-lg-4 col-md-6">
        <a href="<?= esc(site_url('projects/' . $p['id'])) ?>" class="text-decoration-none">
          <div class="casa-card p-3 h-100">
            <div class="d-flex align-items-center gap-2">
              <span class="fw-semibold text-body"><?= esc($p['name']) ?></span>
              <?php if (! empty($p['platform'])): ?><span class="badge text-bg-light border ms-auto"><?= esc(ucfirst($p['platform'])) ?></span><?php endif; ?>
            </div>
            <div class="small text-muted mt-1 text-truncate"><?= esc($p['program_url'] ?: 'tanpa URL program') ?></div>
            <div class="d-flex gap-3 mt-3 small text-muted">
              <span><i class="bi bi-bullseye me-1"></i><?= (int) $p['target_count'] ?> target</span>
              <span class="ms-auto badge text-bg-<?= $p['status'] === 'active' ? 'success' : 'secondary' ?>"><?= esc($p['status']) ?></span>
            </div>
          </div>
        </a>
      </div>
    <?php endforeach; ?>
  </div>
<?php endif; ?>
<?= $this->endSection() ?>

<?= $this->section('page_scripts') ?>
<script>
document.getElementById('projForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const d = await casaPost('<?= esc(site_url('projects')) ?>', new FormData(e.target));
  const m = document.getElementById('projMsg');
  if (d.ok) { window.location = d.redirect; }
  else { m.className = 'small mt-2 text-danger'; m.textContent = d.error || 'Gagal.'; }
});
</script>
<?= $this->endSection() ?>
