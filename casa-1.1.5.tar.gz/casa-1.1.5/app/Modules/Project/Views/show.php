<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<?php
/** @var array $project @var array $types @var array $platforms */
$pid = (int) $project['id'];
$base = site_url('projects/' . $pid);
$inScope  = array_filter($project['scopes'], static fn ($s) => $s['kind'] === 'in');
$outScope = array_filter($project['scopes'], static fn ($s) => $s['kind'] === 'out');
?>
<div class="casa-page-head d-flex flex-wrap align-items-center gap-2">
  <div>
    <a href="<?= esc(site_url('projects')) ?>" class="small text-muted text-decoration-none"><i class="bi bi-arrow-left"></i> Projects</a>
    <h1 class="mb-0"><?= esc($project['name']) ?></h1>
    <div class="small text-muted"><?= esc($project['program_url'] ?: 'tanpa URL program') ?><?= $project['platform'] ? ' · ' . esc(ucfirst($project['platform'])) : '' ?></div>
  </div>
  <?php helper('edition'); ?>
  <div class="ms-auto d-flex gap-2 flex-wrap align-items-center">
    <a class="btn btn-outline-primary btn-sm" href="<?= esc(site_url('projects/' . $pid . '/attack-surface')) ?>"><i class="bi bi-globe2 me-1"></i>Attack Surface <span class="badge text-bg-light border ms-1"><?= (int) $project['asset_count'] ?></span></a>
    <a class="btn btn-outline-primary btn-sm" href="<?= esc(site_url('projects/' . $pid . '/policy')) ?>"><i class="bi bi-shield-lock me-1"></i>Policy</a>
    <a class="btn btn-outline-primary btn-sm <?= edition_can('idor_workbench') ? '' : 'opacity-75' ?>" href="<?= esc(site_url('projects/' . $pid . '/idor')) ?>"><i class="bi bi-arrow-left-right me-1"></i>IDOR Workbench<?= edition_lock_badge('idor_workbench') ?></a>
    <a class="btn btn-outline-primary btn-sm <?= edition_can('authz_matrix') ? '' : 'opacity-75' ?>" href="<?= esc(site_url('projects/' . $pid . '/authz')) ?>"><i class="bi bi-grid-3x3-gap me-1"></i>AuthZ Matrix<?= edition_lock_badge('authz_matrix') ?></a>
    <a class="btn btn-outline-primary btn-sm <?= edition_can('business_logic') ? '' : 'opacity-75' ?>" href="<?= esc(site_url('projects/' . $pid . '/bizlogic')) ?>"><i class="bi bi-diagram-3 me-1"></i>Business Logic<?= edition_lock_badge('business_logic') ?></a>
    <a class="btn btn-outline-primary btn-sm <?= edition_can('automation') ? '' : 'opacity-75' ?>" href="<?= esc(site_url('projects/' . $pid . '/automation')) ?>"><i class="bi bi-clock-history me-1"></i>Automation<?= edition_lock_badge('automation') ?></a>
    <a class="btn btn-outline-primary btn-sm" href="<?= esc(site_url('projects/' . $pid . '/findings')) ?>"><i class="bi bi-bug me-1"></i>Findings</a>
    <a class="btn btn-outline-primary btn-sm" href="<?= esc(site_url('projects/' . $pid . '/reports')) ?>"><i class="bi bi-file-earmark-text me-1"></i>Reports</a>
    <button class="btn btn-outline-danger btn-sm" onclick="hapusProject()"><i class="bi bi-trash"></i></button>
  </div>
</div>

<div class="row g-3">
  <!-- Targets -->
  <div class="col-lg-7">
    <div class="casa-card p-3 p-lg-4 h-100">
      <h2 class="h6 mb-3"><i class="bi bi-bullseye me-1"></i>Target <span class="text-muted fw-normal">(<?= count($project['targets']) ?>)</span></h2>
      <div class="table-responsive">
        <table class="table table-sm align-middle">
          <tbody>
            <?php foreach ($project['targets'] as $t): ?>
              <tr>
                <td style="width:90px"><span class="badge text-bg-secondary"><?= esc($t['type']) ?></span></td>
                <td class="font-monospace small"><?= esc($t['value']) ?><?php if ($t['note']): ?><span class="text-muted"> — <?= esc($t['note']) ?></span><?php endif; ?></td>
                <td class="text-end"><button class="btn btn-sm btn-link text-danger p-0" onclick="delItem('target/<?= (int) $t['id'] ?>')"><i class="bi bi-x-lg"></i></button></td>
              </tr>
            <?php endforeach; ?>
            <?php if ($project['targets'] === []): ?><tr><td colspan="3" class="text-muted small">Belum ada target.</td></tr><?php endif; ?>
          </tbody>
        </table>
      </div>
      <form class="row g-2 mt-1" onsubmit="return addTarget(event)">
        <div class="col-3"><select name="type" class="form-select form-select-sm">
          <?php foreach ($types as $ty): ?><option value="<?= $ty ?>"><?= $ty ?></option><?php endforeach; ?>
        </select></div>
        <div class="col-5"><input name="value" class="form-control form-control-sm" placeholder="mis. shop.example.com" required></div>
        <div class="col-3"><input name="note" class="form-control form-control-sm" placeholder="catatan"></div>
        <div class="col-1"><button class="btn btn-sm btn-primary w-100"><i class="bi bi-plus"></i></button></div>
      </form>
    </div>
  </div>

  <!-- Scope -->
  <div class="col-lg-5">
    <div class="casa-card p-3 p-lg-4 h-100">
      <h2 class="h6 mb-3"><i class="bi bi-shield-check me-1"></i>Scope</h2>
      <div class="mb-2"><span class="badge text-bg-success">In-Scope</span></div>
      <ul class="list-unstyled small mb-3">
        <?php foreach ($inScope as $s): ?>
          <li class="d-flex align-items-center gap-2 mb-1"><span class="font-monospace text-truncate"><?= esc($s['pattern']) ?></span>
            <button class="btn btn-sm btn-link text-danger p-0 ms-auto" onclick="delItem('scope/<?= (int) $s['id'] ?>')"><i class="bi bi-x"></i></button></li>
        <?php endforeach; ?>
        <?php if ($inScope === []): ?><li class="text-muted">—</li><?php endif; ?>
      </ul>
      <div class="mb-2"><span class="badge text-bg-danger">Out-of-Scope</span></div>
      <ul class="list-unstyled small mb-3">
        <?php foreach ($outScope as $s): ?>
          <li class="d-flex align-items-center gap-2 mb-1"><span class="font-monospace text-truncate"><?= esc($s['pattern']) ?></span>
            <button class="btn btn-sm btn-link text-danger p-0 ms-auto" onclick="delItem('scope/<?= (int) $s['id'] ?>')"><i class="bi bi-x"></i></button></li>
        <?php endforeach; ?>
        <?php if ($outScope === []): ?><li class="text-muted">—</li><?php endif; ?>
      </ul>
      <form class="row g-2" onsubmit="return addScope(event)">
        <div class="col-3"><select name="kind" class="form-select form-select-sm"><option value="in">in</option><option value="out">out</option></select></div>
        <div class="col-7"><input name="pattern" class="form-control form-control-sm" placeholder="*.example.com" required></div>
        <div class="col-2"><button class="btn btn-sm btn-primary w-100"><i class="bi bi-plus"></i></button></div>
      </form>
    </div>
  </div>

  <!-- Settings (sumber untuk Policy) -->
  <div class="col-12">
    <div class="casa-card p-3 p-lg-4">
      <h2 class="h6 mb-1"><i class="bi bi-sliders me-1"></i>Aturan scope</h2>
      <p class="text-muted small">Menjadi sumber Policy Engine — batas eksekusi (rate limit, autentikasi, aset kritis).</p>
      <form id="setForm" class="row g-3 align-items-end">
        <div class="col-lg-2"><label class="form-label small">Rate limit (req/s)</label>
          <input name="rate_limit" type="number" min="0" class="form-control" value="<?= esc((string) ($project['rate_limit'] ?? '')) ?>"></div>
        <div class="col-lg-2"><label class="form-label small">Platform</label>
          <select name="platform" class="form-select">
            <option value="">—</option>
            <?php foreach ($platforms as $p): ?><option value="<?= $p ?>" <?= ($project['platform'] ?? '') === $p ? 'selected' : '' ?>><?= ucfirst($p) ?></option><?php endforeach; ?>
          </select></div>
        <div class="col-lg-4"><label class="form-label small">URL program</label>
          <input name="program_url" class="form-control" value="<?= esc((string) ($project['program_url'] ?? '')) ?>"></div>
        <div class="col-lg-3"><label class="form-label small">Aset kritis (catatan)</label>
          <input name="business_critical" class="form-control" value="<?= esc((string) ($project['business_critical'] ?? '')) ?>" placeholder="mis. payment, checkout"></div>
        <div class="col-lg-1">
          <div class="form-check mb-2"><input type="checkbox" name="auth_required" value="1" id="authReq" class="form-check-input" <?= ! empty($project['auth_required']) ? 'checked' : '' ?>>
            <label for="authReq" class="form-check-label small">Auth</label></div>
          <button class="btn btn-primary w-100 btn-sm">Save</button>
        </div>
      </form>
      <div id="setMsg" class="small mt-2"></div>
    </div>
  </div>

  <!-- Test Accounts (auth-context untuk IDOR/injection terautentikasi) -->
  <div class="col-12">
    <div class="casa-card p-3 p-lg-4">
      <h2 class="h6 mb-1"><i class="bi bi-key me-1"></i>Test Accounts <span class="text-muted fw-normal">(auth-context)</span></h2>
      <p class="text-muted small">Kredensial uji untuk pengujian <b>terautentikasi</b> (IDOR/BOLA cross-role, injection POST). Rahasia disimpan <b>terenkripsi</b> &amp; tak pernah ditampilkan kembali.</p>
      <div class="table-responsive">
        <table class="table table-sm align-middle">
          <tbody>
            <?php foreach (($project['credentials'] ?? []) as $c): ?>
              <tr>
                <td class="fw-semibold" style="width:130px"><?= esc($c['label']) ?></td>
                <td style="width:90px"><?php if ($c['role']): ?><span class="badge text-bg-secondary"><?= esc($c['role']) ?></span><?php endif; ?></td>
                <td style="width:100px"><span class="badge text-bg-light border font-monospace"><?= esc($c['scheme']) ?></span></td>
                <td class="small font-monospace text-muted"><?= esc($c['username'] ?? '') ?><?= $c['login_url'] ? ' @ ' . esc($c['login_url']) : '' ?></td>
                <td class="small"><?= ! empty($c['has_secret']) ? '<span class="text-success">✓ rahasia tersimpan</span>' : '<span class="text-danger">—</span>' ?></td>
                <td class="text-end"><button class="btn btn-sm btn-link text-danger p-0" onclick="delItem('cred/<?= (int) $c['id'] ?>')"><i class="bi bi-x-lg"></i></button></td>
              </tr>
            <?php endforeach; ?>
            <?php if (($project['credentials'] ?? []) === []): ?><tr><td colspan="6" class="text-muted small">Belum ada akun uji. Tambahkan mis. "User A" &amp; "User B" untuk uji IDOR cross-role.</td></tr><?php endif; ?>
          </tbody>
        </table>
      </div>
      <form class="row g-2" onsubmit="return addCred(event)">
        <div class="col-6 col-lg-2"><input name="label" class="form-control form-control-sm" placeholder="Label (User A)" required></div>
        <div class="col-6 col-lg-2"><select name="role" class="form-select form-select-sm"><option value="">peran…</option><?php foreach ($credRoles as $r): ?><option value="<?= $r ?>"><?= $r ?></option><?php endforeach; ?></select></div>
        <div class="col-6 col-lg-2"><select name="scheme" class="form-select form-select-sm"><?php foreach ($credSchemes as $s): ?><option value="<?= $s ?>"><?= $s ?></option><?php endforeach; ?></select></div>
        <div class="col-6 col-lg-2"><input name="username" class="form-control form-control-sm" placeholder="username/email"></div>
        <div class="col-8 col-lg-3"><input name="secret" type="password" class="form-control form-control-sm" placeholder="token / cookie / password" required></div>
        <div class="col-4 col-lg-1"><button class="btn btn-sm btn-primary w-100"><i class="bi bi-plus"></i></button></div>
        <div class="col-12"><input name="login_url" class="form-control form-control-sm" placeholder="login_url (untuk skema form_json — mis. http://host/rest/user/login)"></div>
      </form>
      <div class="alert alert-light border small mt-2 mb-0"><i class="bi bi-info-circle me-1"></i><b>bearer/cookie</b>: tempel token/cookie langsung. <b>form_json/basic</b>: isi username+password (+login_url) — CASA login untuk memperoleh sesi saat scan terautentikasi.</div>
      <div id="credMsg" class="small mt-2"></div>
    </div>
  </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('page_scripts') ?>
<script>
const BASE = '<?= esc($base) ?>';
function flash(id, text, ok){ const m = document.getElementById(id); if(!m) return; m.className='small mt-2 '+(ok?'text-success':'text-danger'); m.textContent=text; }

async function addTarget(e){ e.preventDefault();
  const d = await casaPost(BASE + '/target', new FormData(e.target));
  if (d.ok) location.reload(); else alert(d.error || 'Gagal.'); return false; }
async function addScope(e){ e.preventDefault();
  const d = await casaPost(BASE + '/scope', new FormData(e.target));
  if (d.ok) location.reload(); else alert(d.error || 'Gagal.'); return false; }
async function addCred(e){ e.preventDefault();
  const d = await casaPost(BASE + '/cred', new FormData(e.target));
  const m = document.getElementById('credMsg');
  if (d.ok) location.reload();
  else { m.className = 'small mt-2 text-danger'; m.textContent = d.error || 'Gagal.'; } return false; }
async function delItem(path){
  const d = await casaPost(BASE + '/' + path + '/delete', {});
  if (d.ok) location.reload(); else alert(d.error || 'Gagal.'); }
async function hapusProject(){
  if (!confirm('Hapus project ini?')) return;
  const d = await casaPost(BASE + '/delete', {});
  if (d.ok) window.location = d.redirect; else alert(d.error || 'Gagal.'); }
document.getElementById('setForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const d = await casaPost(BASE + '/settings', new FormData(e.target));
  flash('setMsg', d.ok ? (d.message || 'Tersimpan.') : (d.error || 'Gagal.'), !!d.ok);
});
</script>
<?= $this->endSection() ?>
