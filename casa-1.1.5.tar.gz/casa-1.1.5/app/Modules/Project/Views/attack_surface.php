<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<?php
/** @var array $project @var array $assets */
$pid = (int) $project['id'];
$groups = [];
foreach ($assets as $a) {
    $groups[$a['type']][] = $a;
}
$icon = ['host' => 'bi-hdd-network', 'service' => 'bi-plug', 'url' => 'bi-link-45deg', 'tech' => 'bi-cpu', 'dns' => 'bi-diagram-3', 'port' => 'bi-ethernet'];
?>
<div class="casa-page-head">
  <div>
    <a href="<?= esc(site_url('projects/' . $pid)) ?>" class="small text-muted text-decoration-none"><i class="bi bi-arrow-left"></i> <?= esc($project['name']) ?></a>
    <h1 class="mb-0"><i class="bi bi-globe2 me-1"></i>Attack Surface</h1>
    <div class="small text-muted"><?= count($assets) ?> aset ditemukan lewat recon (httpx, subfinder, naabu, katana…)</div>
  </div>
  <a href="<?= esc(site_url('missions')) ?>" class="btn btn-amber"><i class="bi bi-lightning-charge me-1"></i>Scan lagi</a>
</div>

<?php if ($assets === []): ?>
  <div class="casa-card p-5 text-center text-muted">
    <i class="bi bi-globe2 fs-1 d-block mb-2"></i>
    Belum ada aset. Luncurkan <b>Mission</b> (recon) untuk memetakan attack surface.
    <div class="mt-3"><a href="<?= esc(site_url('missions')) ?>" class="btn btn-primary btn-sm">Start Mission</a></div>
  </div>
<?php else: ?>
  <div class="row g-3">
    <?php foreach ($groups as $type => $items): ?>
      <div class="col-lg-6">
        <div class="casa-card p-3 p-lg-4 h-100">
          <h2 class="h6 mb-3"><i class="bi <?= esc($icon[$type] ?? 'bi-box') ?> me-1"></i><?= esc(ucfirst($type)) ?> <span class="text-muted fw-normal">(<?= count($items) ?>)</span></h2>
          <div class="d-flex flex-wrap gap-2">
            <?php foreach ($items as $a): ?>
              <span class="badge text-bg-light border font-monospace" title="sumber: <?= esc($a['source'] ?? '') ?>"><?= esc($a['value']) ?></span>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
<?php endif; ?>
<?= $this->endSection() ?>
