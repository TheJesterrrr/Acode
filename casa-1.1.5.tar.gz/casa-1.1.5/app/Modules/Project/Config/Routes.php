<?php

declare(strict_types=1);

use CodeIgniter\Router\RouteCollection;

/** Rute modul Project — endpoint MEMBER (CES 13.10). Member hanya project miliknya. */

/** @var RouteCollection $routes */
$routes->group('projects', ['namespace' => 'App\Modules\Project\Controllers', 'filter' => 'member'], static function (RouteCollection $routes): void {
    $routes->get('',   'ProjectController::index');
    $routes->post('',  'ProjectController::store', ['filter' => 'audit:PROJECT_CREATE']);
    $routes->get('(:num)', 'ProjectController::show/$1');
    $routes->get('(:num)/attack-surface', 'ProjectController::attackSurface/$1');
    $routes->post('(:num)/delete', 'ProjectController::destroy/$1', ['filter' => 'audit:PROJECT_DELETE']);
    $routes->post('(:num)/target', 'ProjectController::addTarget/$1', ['filter' => 'audit:TARGET_ADD']);
    $routes->post('(:num)/target/(:num)/delete', 'ProjectController::delTarget/$1/$2');
    $routes->post('(:num)/scope', 'ProjectController::addScope/$1', ['filter' => 'audit:SCOPE_ADD']);
    $routes->post('(:num)/scope/(:num)/delete', 'ProjectController::delScope/$1/$2');
    $routes->post('(:num)/settings', 'ProjectController::saveSettings/$1', ['filter' => 'audit:SCOPE_SETTINGS']);
    $routes->post('(:num)/cred', 'ProjectController::addCred/$1', ['filter' => 'audit:CRED_ADD']);
    $routes->post('(:num)/cred/(:num)/delete', 'ProjectController::delCred/$1/$2', ['filter' => 'audit:CRED_DELETE']);
});
