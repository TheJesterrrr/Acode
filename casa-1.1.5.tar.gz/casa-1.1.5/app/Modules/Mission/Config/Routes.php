<?php

declare(strict_types=1);

use CodeIgniter\Router\RouteCollection;

/** Rute modul Mission — endpoint MEMBER (CES 13.10). */

/** @var RouteCollection $routes */
$routes->group('missions', ['namespace' => 'App\Modules\Mission\Controllers', 'filter' => 'member'], static function (RouteCollection $routes): void {
    $routes->get('',  'MissionController::index');
    $routes->post('', 'MissionController::store', ['filter' => 'audit:MISSION_LAUNCH']);
    $routes->get('(:num)', 'MissionController::show/$1');
    $routes->post('(:num)/cancel', 'MissionController::cancel/$1');
    $routes->post('(:num)/repair', 'MissionController::repair/$1');
});
