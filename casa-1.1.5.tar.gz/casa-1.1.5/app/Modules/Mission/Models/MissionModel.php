<?php

declare(strict_types=1);

namespace App\Modules\Mission\Models;

use CodeIgniter\Model;

/** MissionModel — tabel `mission` (CES 13.3). */
final class MissionModel extends Model
{
    protected $table         = 'mission';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $useTimestamps = false;
    protected $allowedFields = ['project_id', 'customer_id', 'brief', 'state', 'template', 'depth', 'workflow', 'report_id', 'note'];

    public function forCustomer(int $customerId): array
    {
        return $this->where('customer_id', $customerId)->orderBy('id', 'DESC')->findAll();
    }

    public function ownedBy(int $id, int $customerId): ?array
    {
        return $this->where('customer_id', $customerId)->find($id);
    }

    /** Mission yang masih berjalan (untuk worker). */
    public function active(): array
    {
        return $this->whereIn('state', ['executing', 'validating', 'reporting'])->findAll();
    }

    /** Mission terakhir milik project (untuk buat ulang laporan). */
    public function latestForProject(int $projectId): ?array
    {
        return $this->where('project_id', $projectId)->orderBy('id', 'DESC')->first();
    }
}
