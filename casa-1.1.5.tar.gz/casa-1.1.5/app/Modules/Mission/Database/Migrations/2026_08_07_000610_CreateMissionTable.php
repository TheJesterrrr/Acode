<?php

declare(strict_types=1);

namespace App\Modules\Mission\Database\Migrations;

use CodeIgniter\Database\Migration;
use CodeIgniter\Database\RawSql;

/**
 * Tabel `mission` — AI Mission (Master Plan §5). Menerima instruksi bahasa alami
 * dan menjalankan siklus Mission→Planning→Execution→Validation→Reporting.
 */
final class CreateMissionTable extends Migration
{
    public function up(): void
    {
        $this->forge->addField([
            'id'          => ['type' => 'BIGINT', 'unsigned' => true, 'auto_increment' => true],
            'project_id'  => ['type' => 'BIGINT', 'unsigned' => true],
            'customer_id' => ['type' => 'BIGINT', 'unsigned' => true],
            'brief'       => ['type' => 'TEXT', 'null' => true],
            'state'       => ['type' => 'VARCHAR', 'constraint' => 12, 'default' => 'planning'], // planning|executing|validating|reporting|done|error
            'workflow'    => ['type' => 'TEXT', 'null' => true], // JSON daftar tool
            'report_id'   => ['type' => 'BIGINT', 'unsigned' => true, 'null' => true],
            'note'        => ['type' => 'VARCHAR', 'constraint' => 200, 'null' => true],
            'created_at'  => ['type' => 'TIMESTAMP', 'default' => new RawSql('CURRENT_TIMESTAMP')],
            'updated_at'  => ['type' => 'TIMESTAMP', 'default' => new RawSql('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP')],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey('customer_id');
        $this->forge->addKey('state');
        $this->forge->createTable('mission', true, ['ENGINE' => 'InnoDB', 'DEFAULT CHARSET' => 'utf8mb4', 'COLLATE' => 'utf8mb4_unicode_ci']);
    }

    public function down(): void
    {
        $this->forge->dropTable('mission', true);
    }
}
