<?php

declare(strict_types=1);

namespace App\Modules\Mission\Database\Migrations;

use CodeIgniter\Database\Migration;

/** Tambah `depth` + `template` pada `mission` (rekam profil scan yang dipakai). */
final class AddMissionProfile extends Migration
{
    public function up(): void
    {
        $cols = [];
        if (! $this->db->fieldExists('depth', 'mission')) {
            $cols['depth'] = ['type' => 'VARCHAR', 'constraint' => 10, 'default' => 'standard', 'after' => 'state'];
        }
        if (! $this->db->fieldExists('template', 'mission')) {
            $cols['template'] = ['type' => 'VARCHAR', 'constraint' => 20, 'null' => true, 'after' => 'state'];
        }
        if ($cols !== []) {
            $this->forge->addColumn('mission', $cols);
        }
    }

    public function down(): void
    {
        foreach (['depth', 'template'] as $c) {
            if ($this->db->fieldExists($c, 'mission')) {
                $this->forge->dropColumn('mission', $c);
            }
        }
    }
}
