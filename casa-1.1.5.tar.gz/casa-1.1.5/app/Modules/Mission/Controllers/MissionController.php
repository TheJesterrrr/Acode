<?php

declare(strict_types=1);

namespace App\Modules\Mission\Controllers;

use App\Controllers\BaseController;
use App\Modules\Mission\Models\MissionModel;
use App\Modules\Mission\Services\MissionService;
use App\Modules\Project\Models\ProjectModel;
use CodeIgniter\Exceptions\PageNotFoundException;
use CodeIgniter\HTTP\ResponseInterface;
use RuntimeException;

/** MissionController — AI Mission milik member (CES 13.2 thin, endpoint member). */
final class MissionController extends BaseController
{
    public function __construct(
        private readonly MissionService $missions = new MissionService(),
        private readonly MissionModel $model = new MissionModel(),
        private readonly ProjectModel $projects = new ProjectModel(),
    ) {
    }

    private function me(): int
    {
        return (int) $this->session->get('member_id');
    }

    public function index(): string
    {
        return $this->memberView('App\Modules\Mission\Views\index', [
            'title'    => 'Missions',
            'missions' => $this->model->forCustomer($this->me()),
            'projects' => $this->projects->forCustomer($this->me()),
        ], 'missions');
    }

    public function store(): ResponseInterface
    {
        if ($r = $this->denyViewer()) {
            return $r;
        }
        try {
            $id = $this->missions->launch(
                (int) $this->request->getPost('project_id'),
                $this->me(),
                (string) $this->request->getPost('brief'),
            );
        } catch (RuntimeException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok(['message' => 'Mission diluncurkan.', 'redirect' => site_url('missions/' . $id)]);
    }

    public function cancel(int $id): ResponseInterface
    {
        if ($r = $this->denyViewer()) {
            return $r;
        }
        try {
            $this->missions->cancel($id, $this->me());
        } catch (RuntimeException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok(['redirect' => site_url('missions/' . $id)]);
    }

    /** Tombol "Perbaiki" — sapu task macet (worker crash) & coba majukan mission. */
    public function repair(int $id): ResponseInterface
    {
        if ($r = $this->denyViewer()) {
            return $r;
        }
        try {
            $res = $this->missions->repair($id, $this->me());
        } catch (RuntimeException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok($res + ['redirect' => site_url('missions/' . $id)]);
    }

    public function show(int $id): string
    {
        $mission = $this->model->ownedBy($id, $this->me());
        if ($mission === null) {
            throw PageNotFoundException::forPageNotFound('Mission tidak ditemukan.');
        }
        $project = $this->projects->find((int) $mission['project_id']);

        return $this->memberView('App\Modules\Mission\Views\show', [
            'title'    => 'Mission #' . $id,
            'mission'  => $mission,
            'project'  => $project,
            'tasks'    => $this->missions->tasksOf($id),
            'progress' => $this->missions->progress($id),
            'sevTotals' => $this->missions->severityTotals($id),
            'sevByTool' => $this->missions->severityByTool($id),
        ], 'missions');
    }
}
