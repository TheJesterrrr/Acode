# Modul Mission (killer feature)
AI Mission: siklus Mission→Planning→Execution→Validation→Reporting sebagai satu
unit kerja (Master Plan §4). Endpoint member.
- `Models/MissionModel` — tabel `mission` (state machine + workflow).
- `Services/MissionService` — `launch()` (gerbang: Policy wajib ada) + Planner
  (workflow = Allowed ∩ terpasang ∩ Adapter, urut preferensi) + `advanceAll()`
  (executing→validating[AI]→reporting[Report]→done) dipanggil worker `casa:work`.
- `Controllers/MissionController` (member) + Views list/timeline.
