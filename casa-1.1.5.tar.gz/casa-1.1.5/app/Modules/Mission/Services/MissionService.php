<?php

declare(strict_types=1);

namespace App\Modules\Mission\Services;

use App\Modules\Adapter\Services\AdapterFactory;
use App\Modules\Engine\Models\TaskModel;
use App\Modules\Engine\Services\EngineService;
use App\Modules\Finding\Models\FindingModel;
use App\Modules\Finding\Services\FindingService;
use App\Modules\Licensing\Services\EditionService;
use App\Modules\Mission\Models\MissionModel;
use App\Modules\Policy\Services\PolicyEngine;
use App\Modules\Project\Models\ProjectModel;
use App\Modules\Project\Models\TargetModel;
use App\Modules\Report\Services\ReportService;
use App\Modules\ToolManager\Models\ToolInstallModel;
use App\Modules\ToolManager\Models\ToolModel;
use RuntimeException;

/**
 * MissionService — AI Mission (killer feature, Master Plan §4). Menjalankan
 * siklus Mission→Planning→Execution→Validation→Reporting sebagai satu unit kerja.
 * Planner memilih workflow dari Policy(Allowed) ∩ tool terpasang ∩ Adapter.
 */
final class MissionService
{
    /**
     * Urutan preferensi workflow (recon → enum → vuln scan). Catatan: `amass`
     * (butuh API key, lambat) & `gowitness` (butuh browser headless) tetap
     * ber-Adapter & bisa dipasang, namun DILUAR workflow default agar misi lab
     * tetap cepat; subfinder sudah menutup Asset Discovery.
     */
    // Urutan kill-chain: recon → probe → crawl → content → vuln → eksploit → secrets/deps.
    // Mencakup SEMUA adapter (tool yang terpasang tapi tak tercantum di sini tak akan dijadwalkan).
    private const ORDER = [
        // amass DIBUANG: amass v4 spawn daemon `amass engine` yang tak mati oleh
        // `timeout` → menggantung berjam-jam & menahan flock worker. subfinder
        // sudah menutup Subdomain Discovery.
        'dnsx', 'subfinder', 'waybackurls', 'gau',
        'httpx', 'whatweb', 'wafw00f', 'naabu', 'nmap', 'testssl',
        'katana', 'hakrawler', 'gowitness', 'ffuf', 'feroxbuster', 'arjun',
        'nuclei', 'nikto', 'wpscan', 'dalfox', 'sqlmap', 'idor',
        'trufflehog', 'gitleaks', 'trivy',
    ];

    public function __construct(
        private readonly MissionModel $missions = new MissionModel(),
        private readonly ProjectModel $projects = new ProjectModel(),
        private readonly TargetModel $targets = new TargetModel(),
        private readonly PolicyEngine $policy = new PolicyEngine(),
        private readonly ToolInstallModel $installs = new ToolInstallModel(),
        private readonly EngineService $engine = new EngineService(),
        private readonly TaskModel $tasks = new TaskModel(),
        private readonly FindingModel $findingModel = new FindingModel(),
        private readonly FindingService $findings = new FindingService(),
        private readonly ReportService $reports = new ReportService(),
        private readonly ToolModel $tools = new ToolModel(),
        private readonly EditionService $edition = new EditionService(),
    ) {
    }

    /**
     * Terima misi bahasa alami, susun rencana, jadwalkan task. @throws RuntimeException
     */
    public function launch(int $projectId, int $customerId, string $brief, array $capsFilter = [], string $depth = 'standard', string $template = '', string $headers = ''): int
    {
        $project = $this->projects->ownedBy($projectId, $customerId);
        if ($project === null) {
            throw new RuntimeException('Project tidak ditemukan.');
        }
        // GERBANG: policy wajib ada sebelum eksekusi (Master Plan §4).
        $policy = $this->policy->getPolicy($projectId, $customerId);
        if (empty($policy['exists'])) {
            throw new RuntimeException('Buat Policy dulu (Policy Engine) — gerbang wajib sebelum Mission.');
        }
        $targets = $this->targets->forProject($projectId);
        if ($targets === []) {
            throw new RuntimeException('Tambahkan minimal satu target pada project.');
        }

        $depth     = in_array($depth, ['light', 'standard', 'deep'], true) ? $depth : 'standard';
        $workflow  = $this->plan($policy['allowed'] ?? [], $customerId, $capsFilter, $depth);
        if ($workflow === []) {
            throw new RuntimeException('Tidak ada tool siap untuk template ini (Allowed ∩ terpasang ∩ Adapter ∩ edisi). Coba template lain atau pasang tool via Tool Manager.');
        }
        $missionId = (int) $this->missions->insert([
            'project_id'  => $projectId,
            'customer_id' => $customerId,
            'brief'       => $brief !== '' ? $brief : 'Audit ' . $project['name'],
            'state'       => 'executing',
            'template'    => $template !== '' ? $template : null,
            'depth'       => $depth,
            'workflow'    => json_encode($workflow, JSON_UNESCAPED_SLASHES),
        ], true);

        // Pra-hitung tipe & URL tiap target sekali (dipakai berulang di loop tool).
        $resolved = [];
        foreach ($targets as $t) {
            $resolved[] = [
                'type'  => (string) ($t['type'] ?? ''),
                'value' => $this->buildUrl($t),
            ];
        }
        // Jadwalkan TOOL-MAJOR (breadth-first per tahap): satu tool disapu ke SEMUA
        // target lebih dulu, baru lanjut tool berikutnya. Worker memproses task urut
        // id ASC, jadi urutan insert ini = urutan eksekusi: tool1→(target1..N),
        // tool2→(target1..N), dst. Efeknya hanya SATU jenis tool aktif per tahap →
        // beban (RAM/CPU) seragam & terprediksi, menghindari banyak tool berat
        // berbarengan (penyebab lonjakan memori). Bandingkan pola lama target-major
        // yang menuntaskan seluruh kill-chain satu target dulu.
        $enq = 0;
        foreach ($workflow as $tool) {
            foreach ($resolved as $r) {
                // Planner sadar-tipe: tool hanya dijalankan pada tipe target yang cocok
                // (mis. gitleaks/trivy hanya untuk repo/image, bukan domain).
                if (! AdapterFactory::appliesTo($tool, $r['type'])) {
                    continue;
                }
                $this->engine->enqueue($missionId, $projectId, $tool, $r['value'], $depth, $headers);
                $enq++;
            }
        }
        // Tak ada tool cocok utk tipe target → tandai error, jangan gantung di executing.
        if ($enq === 0) {
            $this->missions->update($missionId, ['state' => 'error', 'note' => 'Tak ada tool cocok untuk tipe target ini.']);
        }

        return $missionId;
    }

    /**
     * Planner: tool yang Allowed ∩ terpasang ∩ punya Adapter ∩ diizinkan edisi
     * pelanggan (kategori tool per tier), urut preferensi.
     */
    /**
     * Kapabilitas per depth (BREADTH). Light = esensial cepat saja; Standard =
     * + recon lanjutan; Deep = semua ([] = tanpa batas). Dipakai hanya bila
     * TAK ada template (Assessment Baru). Dengan template, breadth = caps template
     * dan depth hanya mengatur intensitas (port/severity via ScanProfile).
     * @return list<string>
     */
    private function depthCaps(string $depth): array
    {
        return match ($depth) {
            'light'    => ['DNS Resolution', 'HTTP Probing', 'Port Scanning', 'Fingerprinting'],
            'standard' => ['DNS Resolution', 'HTTP Probing', 'Port Scanning', 'Service Detection', 'Fingerprinting', 'Subdomain Discovery', 'URL Discovery', 'TLS/SSL Assessment', 'Web Crawling', 'Screenshotting'],
            default    => [], // deep = semua kapabilitas
        };
    }

    private function plan(array $allowed, int $customerId, array $capsFilter = [], string $depth = 'standard'): array
    {
        $installedCodes = [];
        foreach ($this->installs->findAll() as $i) {
            if (($i['status'] ?? '') === 'installed') {
                $installedCodes[] = $i['tool_code'];
            }
        }
        // Tool builtin (mis. IDOR) dijalankan CASA sendiri — tak butuh biner/baris DB,
        // jadi selalu dianggap terpasang.
        foreach (AdapterFactory::supported() as $code) {
            if (AdapterFactory::isBuiltin($code)) {
                $installedCodes[] = $code;
            }
        }
        $installedCodes = array_values(array_unique($installedCodes));
        // Peta kode → kategori untuk gate edisi.
        $category = [];
        foreach ($this->tools->findAll() as $t) {
            $category[$t['code']] = (string) ($t['category'] ?? '');
        }

        $ready = array_intersect($allowed, $installedCodes, AdapterFactory::supported());
        // Allowlist OWNER (Detection Feed): HANYA tool tercentang yang diizinkan
        // (literal; centang=izin, kosong=tak ada izin). Dikonfigurasi (array,
        // termasuk []) → terapkan apa adanya. Belum pernah dikonfigurasi/sinkron
        // (null) → tanpa batas, agar instance baru tetap bisa scan sebelum sync.
        $feedTools = json_decode((string) (new \App\Modules\Setting\Services\SettingService())->get('feed.tools_allowed', ''), true);
        if (is_array($feedTools)) {
            $ready = array_intersect($ready, $feedTools);
        }
        $out     = [];
        $seenCap = [];
        foreach (self::ORDER as $code) {
            if (! in_array($code, $ready, true)) {
                continue;
            }
            // Gerbang edisi: tier Community hanya boleh kategori recon tertentu.
            if (! $this->edition->toolCategoryAllowed($customerId, $category[$code] ?? '')) {
                continue;
            }
            // Dedupe per-kapabilitas: cukup SATU tool per kapabilitas (mis.
            // subfinder ATAU amass untuk Subdomain Discovery; gau ATAU waybackurls
            // untuk URL Discovery). ORDER menentukan preferensi — yang pertama menang.
            $cap = \App\Libraries\ToolLabel::capability($code);
            // Breadth efektif: template (bila ada) ATAU batas depth (Assessment Baru).
            // [] = tanpa batas (Full template / depth Deep).
            $effective = $capsFilter !== [] ? $capsFilter : $this->depthCaps($depth);
            if ($effective !== [] && ! in_array($cap, $effective, true)) {
                continue;
            }
            if ($cap !== '' && isset($seenCap[$cap])) {
                continue;
            }
            $seenCap[$cap] = true;
            $out[]         = $code;
        }

        return $out;
    }

    private function buildUrl(array $target): string
    {
        $v = trim((string) $target['value']);
        // Target repo/image dipakai apa adanya (URL git / ref image), bukan URL web.
        if (in_array($target['type'] ?? '', ['repo', 'image'], true)) {
            return $v;
        }
        if (($target['type'] ?? '') === 'url') {
            return preg_match('#^[a-z]+://#i', $v) ? $v : 'http://' . $v;
        }
        $host = preg_replace('#^[a-z]+://#i', '', $v);
        $host = preg_replace('#[/].*$#', '', (string) $host);

        return 'http://' . $host;
    }

    /**
     * Batalkan mission (pengguna). Tandai task pending/running → skipped, mission
     * → error. Tool yang sedang berjalan akan berhenti sendiri saat exec-timeout.
     * @throws RuntimeException
     */
    public function cancel(int $missionId, int $customerId): void
    {
        $m = $this->missions->ownedBy($missionId, $customerId);
        if ($m === null) {
            throw new RuntimeException('Mission tidak ditemukan.');
        }
        if (in_array($m['state'], ['done', 'error'], true)) {
            throw new RuntimeException('Mission sudah berhenti (tak perlu dibatalkan).');
        }
        $this->tasks->where('mission_id', $missionId)
            ->whereIn('status', ['pending', 'running'])
            ->set(['status' => 'skipped', 'error' => 'Dibatalkan pengguna', 'finished_at' => date('Y-m-d H:i:s')])
            ->update();
        $this->missions->update($missionId, ['state' => 'error', 'note' => 'Dibatalkan pengguna']);
    }

    /**
     * Perbaikan manual oleh pengguna (tombol "Perbaiki" di halaman Mission).
     * Untuk kasus worker macet/crash (mis. OOM saat scan situs besar) — task
     * tertinggal di status 'running' padahal prosesnya sudah mati, mengunci
     * mission selamanya. Dipicu PENGGUNA alih-alih menunggu tick cron
     * berikutnya (sapu otomatis sama persis juga berjalan tiap tick
     * casa:work — lihat EngineService::runPending()/TaskModel::reapStale()).
     * Ambang 10 menit sama dgn sapu otomatis: task yang genuinely masih
     * berjalan wajar (mis. nmap -p- deep) tak ikut tersapu.
     *
     * @return array{reaped:int,state:string} jumlah task yg disapu & state akhir
     * @throws RuntimeException
     */
    public function repair(int $missionId, int $customerId): array
    {
        $m = $this->missions->ownedBy($missionId, $customerId);
        if ($m === null) {
            throw new RuntimeException('Mission tidak ditemukan.');
        }
        if (in_array($m['state'], ['done', 'error'], true)) {
            throw new RuntimeException('Mission sudah berhenti (tak ada yang perlu diperbaiki).');
        }
        $n = $this->tasks->reapStale();
        $this->advanceAll();
        $after = $this->missions->ownedBy($missionId, $customerId);

        return ['reaped' => $n, 'state' => (string) ($after['state'] ?? $m['state'])];
    }

    /** Dipanggil worker: majukan mission aktif sesuai kemajuan task. */
    public function advanceAll(): void
    {
        foreach ($this->missions->active() as $m) {
            $this->advance($m);
        }
    }

    private function advance(array $m): void
    {
        $id  = (int) $m['id'];
        $pid = (int) $m['project_id'];

        if ($m['state'] === 'executing') {
            $p = $this->tasks->progress($id);
            if ($p['total'] > 0 && $p['done'] >= $p['total']) {
                $this->missions->update($id, ['state' => 'validating']);
                $m['state'] = 'validating';
            } else {
                return;
            }
        }

        if ($m['state'] === 'validating') {
            // Validasi AI untuk SEMUA temuan crit/high/med (bukan cuma 2). Low/info
            // ditandai validated tanpa AI. Batas atas $aiCap menjaga fase validasi
            // tak kelamaan di CPU (mis. program dgn ratusan temuan med+).
            $aiCount = 0;
            $aiCap   = 15;
            foreach ($this->findingModel->forMission($id) as $f) {
                if ($f['status'] !== 'new') {
                    continue;
                }
                $highValue = in_array($f['severity'], ['crit', 'high', 'med'], true);
                if ($highValue && $aiCount < $aiCap) {
                    $this->findings->validateWithAI((int) $f['id']);
                    $aiCount++;
                } else {
                    $this->findingModel->update((int) $f['id'], ['status' => 'validated']);
                }
            }
            $this->missions->update($id, ['state' => 'reporting']);
            $m['state'] = 'reporting';
        }

        if ($m['state'] === 'reporting') {
            $reportId = $this->reports->generate($id, $pid, 'technical');
            $this->missions->update($id, ['state' => 'done', 'report_id' => $reportId]);
        }
    }

    /** @return array{total:int,done:int} */
    public function progress(int $missionId): array
    {
        return $this->tasks->progress($missionId);
    }

    public function tasksOf(int $missionId): array
    {
        return $this->tasks->forMission($missionId);
    }

    /** Total temuan per severity untuk satu mission (ringkasan detail Mission). @return array<string,int> */
    public function severityTotals(int $missionId): array
    {
        return $this->findingModel->severityCountsByMission($missionId);
    }

    /** Severity per tool untuk satu mission (breakdown kolom "Temuan"). @return array<string,array<string,int>> */
    public function severityByTool(int $missionId): array
    {
        return $this->findingModel->severityByMissionTool($missionId);
    }
}
