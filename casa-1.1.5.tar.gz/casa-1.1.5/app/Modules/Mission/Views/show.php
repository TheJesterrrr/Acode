<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<?php
/** @var array $mission @var array $project @var array $tasks @var array $progress */
helper('casa_log');
$stateBadge = ['planning' => 'secondary', 'executing' => 'primary', 'validating' => 'info', 'reporting' => 'warning', 'done' => 'success', 'error' => 'danger'];
$phases = ['planning' => 'Planning', 'executing' => 'Execution', 'validating' => 'Validation', 'reporting' => 'Reporting', 'done' => 'Done'];
$order  = array_keys($phases);
$curIdx = array_search($mission['state'], $order, true);
$curIdx = $curIdx === false ? 0 : $curIdx;
$workflow = json_decode((string) $mission['workflow'], true) ?: [];
$pct = $progress['total'] > 0 ? (int) round($progress['done'] / $progress['total'] * 100) : 0;
$tstBadge = ['pending' => 'secondary', 'running' => 'primary', 'done' => 'success', 'error' => 'danger', 'skipped' => 'warning'];
$auto = ! in_array($mission['state'], ['done', 'error'], true);
// Severity vuln: label, warna badge Bootstrap, & huruf ringkas utk kolom Temuan.
$sevMap    = ['crit' => ['Critical', 'danger', 'C'], 'high' => ['High', 'warning', 'H'], 'med' => ['Medium', 'info', 'M'], 'low' => ['Low', 'secondary', 'L'], 'info' => ['Info', 'light', 'I']];
$sevTotals = $sevTotals ?? ['crit' => 0, 'high' => 0, 'med' => 0, 'low' => 0, 'info' => 0];
$sevByTool = $sevByTool ?? [];
$sevTotal  = array_sum($sevTotals);
$sevDark   = static fn (string $c): string => in_array($c, ['warning', 'info', 'light'], true) ? ' text-dark' : '';
?>
<div class="casa-page-head d-flex flex-wrap align-items-center gap-2">
  <div>
    <a href="<?= esc(site_url('missions')) ?>" class="small text-muted text-decoration-none"><i class="bi bi-arrow-left"></i> Missions</a>
    <h1 class="mb-0">Mission M-<?= (int) $mission['id'] ?> <span class="badge text-bg-<?= $stateBadge[$mission['state']] ?? 'secondary' ?> align-middle"><?= esc($mission['state']) ?></span></h1>
    <div class="small text-muted"><?= esc($project['name'] ?? '') ?></div>
  </div>
  <div class="ms-auto d-flex gap-2">
    <?php if ($auto): ?>
      <button id="repairBtn" class="btn btn-outline-warning btn-sm" title="Sweep tasks stuck in 'running' (worker crash/OOM) &amp; try to advance the mission — use this when a mission is stuck not progressing"><i class="bi bi-tools me-1"></i>Repair</button>
      <button id="cancelBtn" class="btn btn-outline-danger btn-sm"><i class="bi bi-x-circle me-1"></i>Cancel</button>
    <?php endif; ?>
    <a class="btn btn-outline-secondary btn-sm" href="<?= esc(site_url('projects/' . $mission['project_id'] . '/findings')) ?>"><i class="bi bi-bug me-1"></i>Findings</a>
    <?php if (! empty($mission['report_id'])): ?>
      <a class="btn btn-outline-primary btn-sm" href="<?= esc(site_url('reports/' . $mission['report_id'])) ?>"><i class="bi bi-file-earmark-text me-1"></i>Report</a>
    <?php endif; ?>
  </div>
</div>

<div class="casa-card p-3 p-lg-4 mb-3">
  <p class="fst-italic text-muted mb-3">"<?= esc($mission['brief']) ?>"</p>
  <!-- Fase -->
  <div class="d-flex flex-wrap align-items-center gap-2 mb-3">
    <?php foreach ($phases as $k => $lbl): $i = array_search($k, $order, true); ?>
      <span class="badge rounded-pill text-bg-<?= $i < $curIdx ? 'success' : ($i === $curIdx ? ($stateBadge[$mission['state']] ?? 'primary') : 'light') ?> <?= $i > $curIdx ? 'text-dark border' : '' ?>">
        <?= $i < $curIdx ? '✓ ' : '' ?><?= esc($lbl) ?>
      </span>
      <?php if ($k !== 'done'): ?><i class="bi bi-arrow-right text-muted small"></i><?php endif; ?>
    <?php endforeach; ?>
  </div>
  <?php
  $running  = (int) ($progress['running'] ?? 0);
  $barColor = $mission['state'] === 'done' ? 'success' : ($mission['state'] === 'error' ? 'danger' : 'primary');
  $live     = ! in_array($mission['state'], ['done', 'error'], true);
  ?>
  <div class="d-flex align-items-center gap-2">
    <div class="progress flex-grow-1" style="height:18px">
      <div class="progress-bar fw-semibold bg-<?= $barColor ?> <?= $live ? 'progress-bar-striped progress-bar-animated' : '' ?>"
           role="progressbar" style="width:<?= max($pct, 6) ?>%" aria-valuenow="<?= $pct ?>" aria-valuemin="0" aria-valuemax="100"><?= $pct ?>%</div>
    </div>
    <span class="small fw-semibold" style="min-width:52px;text-align:right"><?= (int) $progress['done'] ?>/<?= (int) $progress['total'] ?></span>
  </div>
  <div class="small text-muted mt-1">
    <?php if ($live): ?>
      <span class="text-primary"><i class="bi bi-arrow-repeat me-1"></i>Berjalan<?= $running > 0 ? ' — ' . $running . ' task aktif' : '' ?>…</span> ·
    <?php elseif ($mission['state'] === 'done'): ?>
      <span class="text-success"><i class="bi bi-check-circle me-1"></i>Selesai</span> ·
    <?php endif; ?>
    alur: <span class="font-monospace"><?= esc(implode(' → ', \App\Libraries\ToolLabel::showListDedup($workflow))) ?></span>
  </div>
  <!-- Ringkasan severity vuln (Critical/High/Medium/Low/Info) -->
  <div class="d-flex flex-wrap align-items-center gap-2 mt-3">
    <span class="small text-muted me-1"><i class="bi bi-shield-exclamation me-1"></i>Severity temuan:</span>
    <?php foreach ($sevMap as $k => [$lbl, $c, $ab]): ?>
      <span class="badge rounded-pill text-bg-<?= $c . $sevDark($c) ?><?= $sevTotals[$k] === 0 ? ' opacity-50' : '' ?>"><?= esc($lbl) ?>: <?= (int) $sevTotals[$k] ?></span>
    <?php endforeach; ?>
    <?php if ($sevTotal === 0): ?><span class="small text-muted">belum ada temuan</span><?php endif; ?>
  </div>
  <?php if ($mission['note']): ?><div class="alert alert-warning small mt-2 mb-0"><?= esc($mission['note']) ?></div><?php endif; ?>
</div>

<div class="casa-card p-0">
  <div class="table-responsive"><table class="table align-middle mb-0">
    <thead><tr><th class="ps-3">Tool</th><th>Target</th><th>Status</th><th>Temuan</th><th>Catatan</th></tr></thead>
    <tbody>
      <?php foreach ($tasks as $t): ?>
        <tr>
          <td class="ps-3 font-monospace fw-semibold"><?= esc(\App\Libraries\ToolLabel::show($t['tool_code'] ?? null) ?: '—') ?></td>
          <td class="font-monospace small text-muted"><?= esc($t['target']) ?></td>
          <td><span class="badge text-bg-<?= $tstBadge[$t['status']] ?? 'secondary' ?>"><?= esc($t['status']) ?></span></td>
          <td>
            <?php $st = $sevByTool[$t['tool_code'] ?? ''] ?? null; ?>
            <?php if ($st !== null && array_sum($st) > 0): ?>
              <?php foreach ($sevMap as $k => [$lbl, $c, $ab]): ?>
                <?php if ($st[$k] > 0): ?><span class="badge text-bg-<?= $c . $sevDark($c) ?> me-1" title="<?= esc($lbl) ?>"><?= $ab ?> <?= (int) $st[$k] ?></span><?php endif; ?>
              <?php endforeach; ?>
            <?php else: ?>
              <span class="font-monospace text-muted"><?= (int) $t['findings_count'] ?></span>
            <?php endif; ?>
          </td>
          <td class="small text-muted"><?= $t['error'] ? casaCodeBadge((string) $t['error']) : '' ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if ($tasks === []): ?><tr><td colspan="5" class="text-muted text-center py-4">Belum ada task.</td></tr><?php endif; ?>
    </tbody>
  </table></div>
</div>

<?php if ($auto): ?>
<div class="alert alert-info small mt-3"><i class="bi bi-hourglass-split me-1"></i>Mission berjalan di worker <code>casad</code> (cron <code>casa:work</code>). Halaman ini menyegar otomatis.</div>
<script>
let _rl = setTimeout(() => location.reload(), 6000);
const _cb = document.getElementById('cancelBtn');
if (_cb) _cb.addEventListener('click', async () => {
  if (!confirm('Batalkan mission ini? Task yang belum selesai akan dilewati.')) return;
  clearTimeout(_rl); _cb.disabled = true; _cb.innerHTML = '<span class="spinner-border spinner-border-sm"></span>';
  const d = await casaPost('<?= esc(site_url('missions/' . (int) $mission['id'] . '/cancel')) ?>', new FormData());
  if (d.ok && d.redirect) { location.href = d.redirect; } else { _cb.disabled = false; _cb.innerHTML = '<i class="bi bi-x-circle me-1"></i>Batalkan'; alert(d.error || 'Gagal membatalkan.'); _rl = setTimeout(() => location.reload(), 6000); }
});
const _rb = document.getElementById('repairBtn');
if (_rb) _rb.addEventListener('click', async () => {
  if (!confirm("Sapu task yang nyangkut di status 'running' (mis. worker crash/OOM) & coba majukan mission? Task yang masih benar-benar berjalan wajar (<10 menit) tak akan disentuh.")) return;
  clearTimeout(_rl); _rb.disabled = true; _rb.innerHTML = '<span class="spinner-border spinner-border-sm"></span>';
  const d = await casaPost('<?= esc(site_url('missions/' . (int) $mission['id'] . '/repair')) ?>', new FormData());
  if (d.ok) {
    alert((d.reaped > 0 ? `${d.reaped} task macet disapu. ` : 'Tidak ada task yang macet. ') + `Status mission sekarang: ${d.state}.`);
    location.href = d.redirect || location.href;
  } else {
    _rb.disabled = false; _rb.innerHTML = '<i class="bi bi-tools me-1"></i>Perbaiki';
    alert(d.error || 'Gagal memperbaiki.');
    _rl = setTimeout(() => location.reload(), 6000);
  }
});
</script>
<?php endif; ?>
<?= $this->endSection() ?>
