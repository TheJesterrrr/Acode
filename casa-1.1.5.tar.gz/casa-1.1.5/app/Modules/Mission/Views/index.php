<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<?php
/** @var array $missions @var array $projects */
$stateBadge = ['planning' => 'secondary', 'executing' => 'primary', 'validating' => 'info', 'reporting' => 'warning', 'done' => 'success', 'error' => 'danger'];
?>
<div class="casa-page-head d-flex flex-wrap align-items-center gap-2">
  <div>
    <h1><i class="bi bi-lightning-charge me-1"></i>Missions</h1>
    <p class="text-muted small mb-0">Beri misi bahasa alami — CASA memilih workflow, mengeksekusi lewat Adapter (lolos Policy), memvalidasi, lalu melapor.</p>
  </div>
  <button class="btn btn-primary ms-auto" data-bs-toggle="collapse" data-bs-target="#newM"><i class="bi bi-plus-lg me-1"></i>New Mission</button>
</div>

<div class="collapse mb-3 show" id="newM">
  <div class="casa-card p-3 p-lg-4">
    <form id="mForm" class="row g-2">
      <div class="col-lg-4"><label class="form-label small">Project</label>
        <select name="project_id" class="form-select" required>
          <option value="">— pilih project —</option>
          <?php foreach ($projects as $p): ?><option value="<?= (int) $p['id'] ?>"><?= esc($p['name']) ?></option><?php endforeach; ?>
        </select>
        <div class="form-text">Project harus punya <b>Policy</b> (gerbang wajib) &amp; target.</div>
      </div>
      <div class="col-lg-6"><label class="form-label small">Brief (bahasa alami)</label>
        <textarea name="brief" class="form-control" rows="2" placeholder="mis. Audit sesuai scope, fokus recon & HTTP, jangan brute force, buat laporan HackerOne."></textarea></div>
      <div class="col-lg-2 d-flex align-items-end"><button class="btn btn-primary w-100"><i class="bi bi-lightning-charge me-1"></i>Launch</button></div>
    </form>
    <div id="mMsg" class="small mt-2"></div>
  </div>
</div>

<div class="casa-card p-0">
  <div class="table-responsive"><table class="table align-middle mb-0">
    <thead><tr><th class="ps-3">#</th><th>Brief</th><th>State</th><th>Dibuat</th></tr></thead>
    <tbody>
      <?php foreach ($missions as $m): ?>
        <tr style="cursor:pointer" onclick="location='<?= esc(site_url('missions/' . $m['id'])) ?>'">
          <td class="ps-3 font-monospace">M-<?= (int) $m['id'] ?></td>
          <td class="small"><?= esc(mb_substr((string) $m['brief'], 0, 90)) ?></td>
          <td><span class="badge text-bg-<?= $stateBadge[$m['state']] ?? 'secondary' ?>"><?= esc($m['state']) ?></span></td>
          <td class="small font-monospace text-muted"><?= esc($m['created_at']) ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if ($missions === []): ?><tr><td colspan="4" class="text-muted text-center py-4">Belum ada mission.</td></tr><?php endif; ?>
    </tbody>
  </table></div>
</div>
<?= $this->endSection() ?>
<?= $this->section('page_scripts') ?>
<script>
document.getElementById('mForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const d = await casaPost('<?= esc(site_url('missions')) ?>', new FormData(e.target));
  const m = document.getElementById('mMsg');
  if (d.ok) window.location = d.redirect;
  else { m.className = 'small mt-2 text-danger'; m.textContent = d.error || 'Gagal.'; }
});
</script>
<?= $this->endSection() ?>
