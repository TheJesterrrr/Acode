<?php

declare(strict_types=1);

namespace App\Modules\Auth\Models;

use CodeIgniter\Model;

/**
 * LoginAttemptModel — pencatat percobaan login gagal (tabel `login_attempts`).
 * Dipakai AuthService untuk throttle brute-force (CES 5.4).
 */
final class LoginAttemptModel extends Model
{
    protected $table         = 'login_attempts';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $useTimestamps = false;
    protected $allowedFields  = ['identifier', 'scope', 'ip', 'attempted_at'];

    /** Jumlah percobaan gagal dalam jendela waktu (detik) terakhir. */
    public function countRecent(string $identifier, string $scope, int $windowSeconds): int
    {
        $since = date('Y-m-d H:i:s', time() - $windowSeconds);

        return $this->where('identifier', $identifier)
            ->where('scope', $scope)
            ->where('attempted_at >=', $since)
            ->countAllResults();
    }

    public function record(string $identifier, string $scope, string $ip): void
    {
        $this->insert([
            'identifier'   => $identifier,
            'scope'        => $scope,
            'ip'           => $ip,
            'attempted_at' => date('Y-m-d H:i:s'),
        ], false);
    }

    /** Bersihkan percobaan setelah login sukses. */
    public function clear(string $identifier, string $scope): void
    {
        $this->where('identifier', $identifier)->where('scope', $scope)->delete();
    }

    /** Dipanggil cron pembersih (CES 2.9). */
    public function purgeOlderThan(int $seconds): int
    {
        $before = date('Y-m-d H:i:s', time() - $seconds);
        $this->where('attempted_at <', $before)->delete();

        return $this->db->affectedRows();
    }
}
