<?php

declare(strict_types=1);

namespace App\Modules\Auth\Models;

use CodeIgniter\Model;

/**
 * CustomerModel — akses data member (tabel `customers`).
 * Soft delete WAJIB untuk entitas bisnis (CES 2.6).
 */
final class CustomerModel extends Model
{
    protected $table            = 'customers';
    protected $primaryKey       = 'id';
    protected $returnType       = 'array';
    protected $useSoftDeletes   = true;
    protected $deletedField     = 'deleted_at';
    protected $useTimestamps    = true;
    protected $createdField     = 'created_at';
    protected $updatedField     = 'updated_at';

    protected $allowedFields = [
        'name', 'company', 'email', 'phone', 'password_hash',
        'email_verified_at', 'status',
        'sync_secret_enc', 'sync_secret_hash',
    ];

    /** Cari pelanggan berdasarkan hash kode sinkron (untuk endpoint sync). */
    public function findBySyncHash(string $hash): ?array
    {
        return $this->where('sync_secret_hash', $hash)
            ->whereIn('status', ['active', 'suspended'])
            ->first();
    }

    protected $validationRules = [
        'name'          => 'required|max_length[120]',
        'company'       => 'permit_empty|max_length[150]',
        'email'         => 'required|valid_email|max_length[150]|is_unique[customers.email,id,{id}]',
        'phone'         => 'required|max_length[30]',
        'password_hash' => 'required|max_length[255]',
        'status'        => 'permit_empty|in_list[active,suspended,banned]',
    ];

    public function findActiveByEmail(string $email): ?array
    {
        return $this->where('email', $email)
            ->whereIn('status', ['active', 'suspended'])
            ->first();
    }

    public function emailExists(string $email): bool
    {
        return $this->where('email', $email)->countAllResults() > 0;
    }
}
