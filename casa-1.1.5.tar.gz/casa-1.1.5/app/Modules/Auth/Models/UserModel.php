<?php

declare(strict_types=1);

namespace App\Modules\Auth\Models;

use CodeIgniter\Model;

/**
 * UserModel — akses data admin (tabel `users`). CES 13.3: HANYA akses data.
 * Logika login/kunci ada di AuthService (13.4).
 */
final class UserModel extends Model
{
    protected $table            = 'users';
    protected $primaryKey       = 'id';
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $useTimestamps    = true;
    protected $createdField     = 'created_at';
    protected $updatedField     = 'updated_at';

    protected $allowedFields = [
        'name', 'email', 'password_hash', 'role', 'is_active', 'last_login_at',
    ];

    protected $validationRules = [
        'name'          => 'required|max_length[100]',
        'email'         => 'required|valid_email|max_length[150]',
        'password_hash' => 'required|max_length[255]',
        'role'          => 'required|in_list[owner,operator]',
    ];

    /** Cari admin aktif berdasarkan email. */
    public function findActiveByEmail(string $email): ?array
    {
        return $this->where('email', $email)
            ->where('is_active', 1)
            ->first();
    }

    public function markLogin(int $id): void
    {
        $this->update($id, ['last_login_at' => date('Y-m-d H:i:s')]);
    }
}
