<?php

declare(strict_types=1);

namespace App\Modules\Auth\Database\Seeds;

use CodeIgniter\Database\Seeder;

/**
 * AdminOwnerSeeder — akun owner pertama (CES 13.8).
 *
 * Kata sandi awal diambil dari env `seed.ownerPassword`; bila kosong,
 * dibangkitkan acak dan DICETAK sekali ke stdout agar operator menyimpannya.
 * DILARANG menuliskan kata sandi tetap di kode (CES 1.6, 5.6).
 */
final class AdminOwnerSeeder extends Seeder
{
    public function run(): void
    {
        $email = strtolower((string) (env('seed.ownerEmail') ?: 'owner@corenet.web.id'));

        if ($this->db->table('users')->where('email', $email)->countAllResults() > 0) {
            return; // idempoten
        }

        $plain = (string) (env('seed.ownerPassword') ?: bin2hex(random_bytes(6)));

        $this->db->table('users')->insert([
            'name'          => 'CoreNet Owner',
            'email'         => $email,
            'password_hash' => password_hash($plain, PASSWORD_DEFAULT),
            'role'          => 'owner',
            'is_active'     => 1,
        ]);

        if (is_cli() && ! env('seed.ownerPassword')) {
            fwrite(STDOUT, "\n[AdminOwnerSeeder] Owner dibuat: {$email}\n");
            fwrite(STDOUT, "[AdminOwnerSeeder] Kata sandi awal: {$plain}\n");
            fwrite(STDOUT, "[AdminOwnerSeeder] SIMPAN sekarang — tidak ditampilkan lagi.\n\n");
        }
    }
}
