<?php

declare(strict_types=1);

namespace App\Modules\Auth\Database\Migrations;

use CodeIgniter\Database\Migration;
use CodeIgniter\Database\RawSql;

/** Tabel `customers` — member. Soft delete (CES 2.6). */
final class CreateCustomersTable extends Migration
{
    public function up(): void
    {
        $this->forge->addField([
            'id'                => ['type' => 'BIGINT', 'unsigned' => true, 'auto_increment' => true],
            'name'              => ['type' => 'VARCHAR', 'constraint' => 120],
            'company'           => ['type' => 'VARCHAR', 'constraint' => 150, 'null' => true],
            'email'             => ['type' => 'VARCHAR', 'constraint' => 150],
            'phone'             => ['type' => 'VARCHAR', 'constraint' => 30],
            'password_hash'     => ['type' => 'VARCHAR', 'constraint' => 255],
            'email_verified_at' => ['type' => 'TIMESTAMP', 'null' => true],
            'status'            => ['type' => 'ENUM', 'constraint' => ['active', 'suspended', 'banned'], 'default' => 'active'],
            'created_at'        => ['type' => 'TIMESTAMP', 'default' => new RawSql('CURRENT_TIMESTAMP')],
            'updated_at'        => ['type' => 'TIMESTAMP', 'default' => new RawSql('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP')],
            'deleted_at'        => ['type' => 'TIMESTAMP', 'null' => true],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addUniqueKey('email');
        $this->forge->addKey(['status', 'deleted_at']);
        $this->forge->createTable('customers', true, ['ENGINE' => 'InnoDB', 'DEFAULT CHARSET' => 'utf8mb4', 'COLLATE' => 'utf8mb4_unicode_ci']);
    }

    public function down(): void
    {
        $this->forge->dropTable('customers', true);
    }
}
