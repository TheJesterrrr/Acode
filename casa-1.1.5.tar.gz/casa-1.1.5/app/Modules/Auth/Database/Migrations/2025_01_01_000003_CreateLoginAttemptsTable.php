<?php

declare(strict_types=1);

namespace App\Modules\Auth\Database\Migrations;

use CodeIgniter\Database\Migration;
use CodeIgniter\Database\RawSql;

/** Tabel `login_attempts` — throttle brute-force (CES 5.4). */
final class CreateLoginAttemptsTable extends Migration
{
    public function up(): void
    {
        $this->forge->addField([
            'id'           => ['type' => 'BIGINT', 'unsigned' => true, 'auto_increment' => true],
            'identifier'   => ['type' => 'VARCHAR', 'constraint' => 150],
            'scope'        => ['type' => 'ENUM', 'constraint' => ['admin', 'member']],
            'ip'           => ['type' => 'VARCHAR', 'constraint' => 45],
            'attempted_at' => ['type' => 'TIMESTAMP', 'default' => new RawSql('CURRENT_TIMESTAMP')],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addKey(['identifier', 'scope', 'attempted_at']);
        $this->forge->createTable('login_attempts', true, ['ENGINE' => 'InnoDB', 'DEFAULT CHARSET' => 'utf8mb4', 'COLLATE' => 'utf8mb4_unicode_ci']);
    }

    public function down(): void
    {
        $this->forge->dropTable('login_attempts', true);
    }
}
