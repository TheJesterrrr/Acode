<?php

declare(strict_types=1);

namespace App\Modules\Auth\Services;

use RuntimeException;

/** AuthFailedException — kegagalan autentikasi yang aman ditampilkan ke pengguna. */
final class AuthFailedException extends RuntimeException
{
}
