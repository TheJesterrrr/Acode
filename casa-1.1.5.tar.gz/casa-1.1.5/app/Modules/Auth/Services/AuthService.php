<?php

declare(strict_types=1);

namespace App\Modules\Auth\Services;

use App\Libraries\Phone;
use App\Modules\Auth\Models\CustomerModel;
use App\Modules\Auth\Models\LoginAttemptModel;
use App\Modules\Auth\Models\UserModel;
use App\Modules\Setting\Services\SettingService;
use RuntimeException;

/**
 * AuthService — seluruh proses bisnis autentikasi (CES 13.4 Service Layer).
 *
 * Controller TIDAK boleh menyentuh Model auth atau menghitung throttle
 * sendiri; semuanya melewati kelas ini. Nilai konfigurasi (batas percobaan,
 * jendela lockout) dibaca dari .env (CES 1.6 Zero Hardcode).
 *
 * Kegagalan dinyatakan lewat exception, bukan nilai balik palsu (CES 2.4):
 *   - AuthThrottleException  → terkunci sementara
 *   - AuthFailedException    → kredensial salah / akun tidak aktif
 */
final class AuthService
{
    public const SCOPE_ADMIN  = 'admin';
    public const SCOPE_MEMBER = 'member';

    public function __construct(
        private readonly UserModel $users = new UserModel(),
        private readonly CustomerModel $customers = new CustomerModel(),
        private readonly LoginAttemptModel $attempts = new LoginAttemptModel(),
    ) {
    }

    /* ------------------------------------------------------------- Akun */

    /** Data profil pelanggan (tanpa hash sandi). */
    public function profile(int $customerId): array
    {
        $row = $this->customers->find($customerId);
        if ($row === null) {
            throw new AuthFailedException('Akun tidak ditemukan.');
        }
        unset($row['password_hash']);

        return $row;
    }

    /** Perbarui profil. Email TIDAK dapat diubah sendiri (identitas login). */
    public function updateProfile(int $customerId, array $data): void
    {
        $bersih = [
            'name'    => trim((string) ($data['name'] ?? '')),
            'company' => trim((string) ($data['company'] ?? '')),
            'phone'   => Phone::normalize((string) ($data['phone'] ?? '')),
        ];
        if ($bersih['name'] === '') {
            throw new AuthFailedException('Nama wajib diisi.');
        }
        if ($bersih['phone'] === '') {
            throw new AuthFailedException('Nomor telepon wajib diisi.');
        }
        $this->customers->update($customerId, $bersih);
    }

    /**
     * Ganti kata sandi sendiri. Sandi lama WAJIB diverifikasi agar sesi yang
     * dibajak tidak bisa mengunci pemilik akun keluar.
     */
    public function changePassword(int $customerId, string $lama, string $baru): void
    {
        if (mb_strlen($baru) < 8) {
            throw new AuthFailedException('Kata sandi baru minimal 8 karakter.');
        }
        $row = $this->customers->find($customerId);
        if ($row === null || ! password_verify($lama, (string) $row['password_hash'])) {
            throw new AuthFailedException('Kata sandi lama tidak sesuai.');
        }
        $this->customers->update($customerId, [
            'password_hash' => password_hash($baru, PASSWORD_BCRYPT),
        ]);
    }

    /* --------------------------------------------------------------- Admin */

    /**
     * Login admin. Mengembalikan baris user pada keberhasilan.
     *
     * @throws AuthThrottleException
     * @throws AuthFailedException
     */
    public function loginAdmin(string $email, string $password, string $ip): array
    {
        $email = strtolower(trim($email));
        $this->guardThrottle($email, self::SCOPE_ADMIN);

        $user = $this->users->findActiveByEmail($email);

        if ($user === null || ! $this->verify($password, (string) $user['password_hash'])) {
            $this->attempts->record($email, self::SCOPE_ADMIN, $ip);
            throw new AuthFailedException('Email atau kata sandi salah.');
        }

        $this->rehashIfNeeded((int) $user['id'], $password, (string) $user['password_hash'], $this->users);
        $this->attempts->clear($email, self::SCOPE_ADMIN);
        $this->users->markLogin((int) $user['id']);

        return $user;
    }

    /* -------------------------------------------------------------- Member */

    /**
     * Login member. Mengembalikan baris customer pada keberhasilan.
     *
     * @throws AuthThrottleException
     * @throws AuthFailedException
     */
    public function loginMember(string $email, string $password, string $ip): array
    {
        $email = strtolower(trim($email));
        $this->guardThrottle($email, self::SCOPE_MEMBER);

        $customer = $this->customers->findActiveByEmail($email);

        if ($customer === null || ! $this->verify($password, (string) $customer['password_hash'])) {
            $this->attempts->record($email, self::SCOPE_MEMBER, $ip);
            throw new AuthFailedException('Email atau kata sandi salah.');
        }

        if (($customer['status'] ?? '') === 'banned') {
            throw new AuthFailedException('Akun Anda diblokir. Hubungi administrator.');
        }

        $this->rehashIfNeeded((int) $customer['id'], $password, (string) $customer['password_hash'], $this->customers);
        $this->attempts->clear($email, self::SCOPE_MEMBER);

        return $customer;
    }

    /**
     * Registrasi member baru. Mengembalikan id customer.
     *
     * @param array{name:string,email:string,phone:string,company:?string,password:string} $data
     * @throws AuthValidationException
     */
    public function register(array $data): int
    {
        $email = strtolower(trim($data['email']));

        if ($this->customers->emailExists($email)) {
            throw new AuthValidationException('Email sudah terdaftar.');
        }

        $db = \Config\Database::connect();
        $db->transException(true);
        $db->transStart();

        $id = (int) $this->customers->insert([
            'name'          => trim($data['name']),
            'company'       => isset($data['company']) ? trim((string) $data['company']) : null,
            'email'         => $email,
            'phone'         => trim($data['phone']),
            'password_hash' => $this->hash($data['password']),
            'status'        => 'active',
        ], true);

        if ($id === 0) {
            throw new RuntimeException('Gagal membuat akun. Silakan coba lagi.');
        }

        // Kait untuk modul bisnis: apa pun yang harus terjadi bersamaan dengan
        // pembuatan akun (dompet, profil, saldo awal) dipasang di sini, di dalam
        // transaksi yang sama, agar gagal-total bila salah satunya gagal.

        $db->transComplete();

        return $id;
    }

    /* --------------------------------------------------------- Throttle/util */

    /** @throws AuthThrottleException */
    private function guardThrottle(string $identifier, string $scope): void
    {
        $max    = (int) (env('auth.maxAttempts') ?: 5);
        $window = (int) (env('auth.lockoutWindow') ?: 900);

        if ($this->attempts->countRecent($identifier, $scope, $window) >= $max) {
            $minutes = (int) ceil($window / 60);
            throw new AuthThrottleException(
                "Terlalu banyak percobaan gagal. Coba lagi dalam {$minutes} menit."
            );
        }
    }

    private function hash(string $password): string
    {
        return password_hash($password, PASSWORD_DEFAULT);
    }

    private function verify(string $password, string $hash): bool
    {
        return $hash !== '' && password_verify($password, $hash);
    }

    /** Perbarui hash bila algoritma default berubah — transparan bagi pengguna. */
    private function rehashIfNeeded(int $id, string $password, string $hash, object $model): void
    {
        if (password_needs_rehash($hash, PASSWORD_DEFAULT)) {
            $model->update($id, ['password_hash' => $this->hash($password)]);
        }
    }
}
