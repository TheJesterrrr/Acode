<?php

declare(strict_types=1);

namespace App\Modules\Auth\Services;

use RuntimeException;

/** AuthThrottleException — kegagalan autentikasi yang aman ditampilkan ke pengguna. */
final class AuthThrottleException extends RuntimeException
{
}
