<?php

declare(strict_types=1);

namespace App\Modules\Auth\Controllers;

use App\Controllers\BaseController;
use App\Modules\Auth\Services\AuthFailedException;
use App\Modules\Auth\Services\AuthService;
use App\Modules\Licensing\Services\SyncSecretService;
use CodeIgniter\HTTP\ResponseInterface;

/** AccountController — halaman "Akun Saya" milik member (CES 13.2 thin). */
final class AccountController extends BaseController
{
    public function __construct(
        private readonly AuthService $auth = new AuthService(),
        private readonly SyncSecretService $syncSecret = new SyncSecretService(),
        private readonly \App\Modules\Licensing\Models\InstanceBindingModel $bindings = new \App\Modules\Licensing\Models\InstanceBindingModel(),
    ) {
    }

    private function cid(): int
    {
        return (int) $this->session->get('member_id');
    }

    public function index(): string
    {
        // Di hub casamember, tampilkan kode sinkron + instance yang sedang terikat.
        $hub        = $this->isOwnerConsole();
        $syncSecret = $hub ? $this->syncSecret->ensure($this->cid()) : null;

        return $this->memberView('App\Modules\Auth\Views\account', [
            'title'          => 'Akun Saya',
            'profile'        => $this->auth->profile($this->cid()),
            'sync_secret'    => $syncSecret,
            'binding'        => $hub ? $this->bindings->activeForCustomer($this->cid()) : null,
            'cooldown_min'   => \App\Modules\Licensing\Models\InstanceBindingModel::RELEASE_COOLDOWN_MIN,
        ], 'akun');
    }

    /**
     * Lepas ikatan instance SENDIRI (self-service) — pelanggan pindah VPS/OS
     * tanpa perlu menghubungi owner. Hanya di hub (console owner).
     */
    public function releaseBinding(): ResponseInterface
    {
        $this->requireOwnerConsole();
        $n = $this->bindings->revokeForCustomer($this->cid());
        if ($n === 0) {
            return $this->fail('Tidak ada instance yang sedang terikat.');
        }

        return $this->ok([
            'released' => $n,
            'cooldown' => \App\Modules\Licensing\Models\InstanceBindingModel::RELEASE_COOLDOWN_MIN,
        ]);
    }

    /** Rotasi kode sinkron (invalidasi VPS lama). Hanya di console owner. */
    public function rotateSecret(): ResponseInterface
    {
        $this->requireOwnerConsole();

        return $this->ok(['secret' => $this->syncSecret->rotate($this->cid())]);
    }

    public function update(): ResponseInterface
    {
        try {
            $this->auth->updateProfile($this->cid(), [
                'name'    => $this->request->getPost('name'),
                'company' => $this->request->getPost('company'),
                'phone'   => $this->request->getPost('phone'),
            ]);
        } catch (AuthFailedException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok(['message' => 'Profil diperbarui.']);
    }

    public function password(): ResponseInterface
    {
        try {
            $this->auth->changePassword(
                $this->cid(),
                (string) $this->request->getPost('current_password'),
                (string) $this->request->getPost('new_password'),
            );
        } catch (AuthFailedException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok(['message' => 'Kata sandi diperbarui.']);
    }
}
