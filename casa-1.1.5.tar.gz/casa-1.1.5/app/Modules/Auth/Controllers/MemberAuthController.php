<?php

declare(strict_types=1);

namespace App\Modules\Auth\Controllers;

use App\Controllers\BaseController;
use App\Libraries\Cer;
use App\Modules\Auth\Services\AuthFailedException;
use App\Modules\Auth\Services\AuthService;
use App\Modules\Auth\Services\AuthThrottleException;
use App\Modules\Auth\Services\AuthValidationException;
use App\Modules\Team\Services\TeamService;
use CodeIgniter\HTTP\ResponseInterface;

/**
 * MemberAuthController — autentikasi member (CES 13.2 thin controller).
 * Hanya menerima request, memvalidasi (13.6), memanggil AuthService (13.4),
 * dan mengembalikan response. TIDAK ada logika bisnis di sini.
 */
final class MemberAuthController extends BaseController
{
    public function __construct(
        private readonly AuthService $auth = new AuthService(),
        private readonly TeamService $team = new TeamService(),
    ) {
    }

    /** GET /login */
    public function loginForm(): string|ResponseInterface
    {
        if ((int) $this->session->get('member_id') > 0) {
            return redirect()->to(Cer::baseUrl() . 'member');
        }

        return view('App\Modules\Auth\Views\login_member', [
            'title' => 'Masuk',
        ]);
    }

    /** POST /login */
    public function login(): ResponseInterface
    {
        $rules = [
            'email'    => 'required|valid_email',
            'password' => 'required',
        ];

        if (! $this->validate($rules)) {
            return $this->fail(implode(' ', $this->validator->getErrors()));
        }

        $email    = (string) $this->request->getPost('email');
        $password = (string) $this->request->getPost('password');

        try {
            $customer = $this->auth->loginMember($email, $password, (string) $this->request->getIPAddress());
        } catch (AuthThrottleException $e) {
            // Batasi laju: jangan lewati throttle via jalur tim.
            return $this->fail($e->getMessage(), ResponseInterface::HTTP_UNAUTHORIZED);
        } catch (AuthFailedException $e) {
            // Fallback: anggota tim (RBAC) — login di bawah akun induk.
            $ctx = $this->team->login($email, $password);
            if ($ctx === null) {
                return $this->fail($e->getMessage(), ResponseInterface::HTTP_UNAUTHORIZED);
            }
            $this->session->regenerate(true);
            $this->session->set([
                'member_id'      => $ctx['customer_id'],
                'member_name'    => $ctx['name'],
                'member_email'   => $ctx['email'],
                'team_role'      => $ctx['role'],
                'team_member_id' => $ctx['team_member_id'],
            ]);

            return $this->ok(['redirect' => Cer::baseUrl() . 'member']);
        }

        // Owner (akun pelanggan) — peran penuh.
        $this->session->regenerate(true);
        $this->session->set([
            'member_id'      => (int) $customer['id'],
            'member_name'    => $customer['name'],
            'member_email'   => $customer['email'],
            'team_role'      => 'owner',
            'team_member_id' => 0,
        ]);

        return $this->ok(['redirect' => Cer::baseUrl() . 'member']);
    }

    /** GET /register */
    public function registerForm(): string|ResponseInterface
    {
        if ((int) $this->session->get('member_id') > 0) {
            return redirect()->to(Cer::baseUrl() . 'member');
        }

        return view('App\Modules\Auth\Views\register', [
            'title' => 'Daftar',
        ]);
    }

    /** POST /register */
    public function register(): ResponseInterface
    {
        $rules = [
            'name'     => 'required|max_length[120]',
            'company'  => 'permit_empty|max_length[150]',
            'email'    => 'required|valid_email|max_length[150]',
            'phone'    => 'required|max_length[30]',
            'password' => 'required|min_length[8]|max_length[72]',
            'password_confirm' => 'required|matches[password]',
        ];

        if (! $this->validate($rules)) {
            return $this->fail(implode(' ', $this->validator->getErrors()));
        }

        try {
            $id = $this->auth->register([
                'name'     => (string) $this->request->getPost('name'),
                'company'  => (string) $this->request->getPost('company'),
                'email'    => (string) $this->request->getPost('email'),
                'phone'    => (string) $this->request->getPost('phone'),
                'password' => (string) $this->request->getPost('password'),
            ]);
        } catch (AuthValidationException $e) {
            return $this->fail($e->getMessage());
        }

        // Auto-login setelah daftar.
        $this->session->regenerate(true);
        $this->session->set([
            'member_id'    => $id,
            'member_name'  => (string) $this->request->getPost('name'),
            'member_email' => strtolower((string) $this->request->getPost('email')),
        ]);

        return $this->ok(['redirect' => Cer::baseUrl() . 'member']);
    }

    /** GET /register/check-email — validasi ketersediaan email secara async. */
    public function checkEmail(): ResponseInterface
    {
        $email = strtolower(trim((string) $this->request->getGet('email')));

        return $this->ok([
            'available' => $email !== '' && ! (new \App\Modules\Auth\Models\CustomerModel())->emailExists($email),
        ]);
    }

    /** POST /logout */
    public function logout(): ResponseInterface
    {
        $this->session->destroy();

        // Topbar memanggil lewat AJAX; balas JSON agar JS tahu tujuannya.
        // Permintaan biasa (mis. form fallback) tetap dialihkan seperti semula.
        if ($this->request->isAJAX()) {
            return $this->ok(['redirect' => Cer::baseUrl() . 'login']);
        }

        return redirect()->to(Cer::baseUrl() . 'login');
    }
}
