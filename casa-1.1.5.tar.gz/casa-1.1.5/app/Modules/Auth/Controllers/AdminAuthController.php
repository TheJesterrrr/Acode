<?php

declare(strict_types=1);

namespace App\Modules\Auth\Controllers;

use App\Controllers\BaseController;
use App\Libraries\Cer;
use App\Modules\Auth\Services\AuthFailedException;
use App\Modules\Auth\Services\AuthService;
use App\Modules\Auth\Services\AuthThrottleException;
use CodeIgniter\HTTP\ResponseInterface;

/**
 * AdminAuthController — autentikasi admin pada host admin (CES 13.2).
 */
final class AdminAuthController extends BaseController
{
    public function __construct(private readonly AuthService $auth = new AuthService())
    {
    }

    /** GET /login (host admin) */
    public function loginForm(): string|ResponseInterface
    {
        if ((int) $this->session->get('admin_id') > 0) {
            return redirect()->to(Cer::adminUrl() . 'casaadmin');
        }

        return view('App\Modules\Auth\Views\login_admin', [
            'title' => 'Masuk Admin',
        ]);
    }

    /** POST /login (host admin) */
    public function login(): ResponseInterface
    {
        $rules = [
            'email'    => 'required|valid_email',
            'password' => 'required',
        ];

        if (! $this->validate($rules)) {
            return $this->fail(implode(' ', $this->validator->getErrors()));
        }

        try {
            $user = $this->auth->loginAdmin(
                (string) $this->request->getPost('email'),
                (string) $this->request->getPost('password'),
                (string) $this->request->getIPAddress(),
            );
        } catch (AuthThrottleException | AuthFailedException $e) {
            return $this->fail($e->getMessage(), ResponseInterface::HTTP_UNAUTHORIZED);
        }

        $this->session->regenerate(true);
        $this->session->set([
            'admin_id'    => (int) $user['id'],
            'admin_name'  => $user['name'],
            'admin_email' => $user['email'],
            'admin_role'  => $user['role'],
        ]);

        return $this->ok(['redirect' => Cer::adminUrl() . 'casaadmin']);
    }

    /** POST /logout (host admin) */
    public function logout(): ResponseInterface
    {
        $this->session->destroy();

        // Topbar memanggil lewat AJAX; balas JSON agar JS tahu tujuannya.
        // Permintaan biasa (mis. form fallback) tetap dialihkan seperti semula.
        if ($this->request->isAJAX()) {
            return $this->ok(['redirect' => Cer::adminUrl() . 'login']);
        }

        return redirect()->to(Cer::adminUrl() . 'login');
    }
}
