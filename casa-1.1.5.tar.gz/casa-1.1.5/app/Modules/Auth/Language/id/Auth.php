<?php

declare(strict_types=1);

/** Terjemahan modul Auth (CES 13.10). */
return [
    'loginTitle'      => 'Masuk',
    'registerTitle'   => 'Daftar Akun',
    'invalidCredentials' => 'Email atau kata sandi salah.',
    'throttled'       => 'Terlalu banyak percobaan gagal. Silakan coba lagi nanti.',
    'emailTaken'      => 'Email sudah terdaftar.',
    'accountBanned'   => 'Akun Anda diblokir. Hubungi administrator.',
];
