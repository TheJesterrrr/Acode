# Modul Auth

Autentikasi & registrasi untuk dua endpoint CoreNet Remote Platform: **member**
(`remote.*`) dan **admin** (`casaadmin.*`). Disusun mengikuti CES-001 v1.7
Bab XIII (Standar Framework CodeIgniter 4) butir 13.2–13.10.

## Tujuan
- Login member & admin dengan hash bcrypt (`PASSWORD_DEFAULT`) + rehash otomatis.
- Registrasi member (auto-login setelah daftar).
- Throttle brute-force berbasis tabel `login_attempts` (CES 5.4).
- Pemisahan sesi per endpoint via cookie berbeda (CES 11.5.3).

## Struktur (CES 13.10)
```
Auth/
├── Controllers/   MemberAuthController, AdminAuthController  (thin, 13.2)
├── Models/        UserModel, CustomerModel, LoginAttemptModel (13.3)
├── Services/      AuthService (+ 3 exception domain)          (13.4)
├── Views/         login_member, register, login_admin, layout
├── Database/      Migrations (users, customers, login_attempts) + Seeder (13.8)
├── Config/        Routes.php (auto-discovered)
├── Language/id/   Auth.php
└── README.md
```

## Ketergantungan
| Butuh | Dari | Status |
|---|---|---|
| Sesi & CSRF | Inti CI4 (`Config\Session`, filter `csrf`) | ✅ tersedia |
| Nama cookie sesi per endpoint | `App\Libraries\Cer` (CES 11.5.3) | ✅ tersedia |
| Pencatatan audit login | `AuditService` (modul Audit) | ⏳ **belum diport** — lihat `AUD-1` |

## Kait untuk modul bisnis
`AuthService::register()` menyediakan satu titik di dalam transaksi pembuatan
akun untuk pekerjaan lanjutan milik modul bisnis — pembuatan dompet, profil,
atau saldo awal. Pasang di sana, bukan sesudah `transComplete()`, agar seluruhnya
gagal bersama bila salah satu gagal.

Pekerjaan yang boleh berulang (mis. pemberian bonus) WAJIB idempoten: sediakan
kolom penjaga di tabel dan periksa nilainya sebelum bertindak.

## Cara pakai (dev)
```bash
php spark migrate --all
php spark db:seed 'App\Modules\Auth\Database\Seeds\AdminOwnerSeeder'
```
Kata sandi owner awal dibaca dari `.env` `seed.ownerPassword`; bila kosong,
dibangkitkan acak dan dicetak sekali ke terminal.
