<?php

declare(strict_types=1);

use App\Libraries\Cer;
use CodeIgniter\Router\RouteCollection;

/**
 * Rute modul Auth (CES 13.10). Ditemukan otomatis oleh Config\Modules.
 *
 * Member dan admin BERBAGI path '/login' tetapi memakai controller berbeda.
 * Berkas rute dimuat pada SETIAP request, sehingga pemilihan controller
 * dilakukan di sini berdasarkan endpoint aktif (Cer membaca HTTP_HOST).
 * Mendaftarkan keduanya sekaligus mustahil: satu path hanya boleh menunjuk
 * satu controller.
 *
 * PENTING: endpoint admin hanya dikenali bila `app.adminURL` terisi di .env.
 * Bila kosong, Cer menganggap seluruh host sebagai member (aman secara default).
 */

/** @var RouteCollection $routes */

$ns = 'App\Modules\Auth\Controllers';

if (Cer::isAdmin()) {
    // ------------------------------------------------------------------ ADMIN
    $routes->group('', ['namespace' => $ns], static function (RouteCollection $routes): void {
        $routes->get('login',  'AdminAuthController::loginForm');
        $routes->post('login', 'AdminAuthController::login');
        $routes->post('logout', 'AdminAuthController::logout', ['filter' => 'admin']);
    });
} else {
    // ----------------------------------------------------------------- MEMBER
    $routes->group('', ['namespace' => $ns], static function (RouteCollection $routes): void {
        $routes->get('login',  'MemberAuthController::loginForm');
        $routes->post('login', 'MemberAuthController::login');

        $routes->get('register',  'MemberAuthController::registerForm');
        $routes->post('register', 'MemberAuthController::register');
        $routes->get('register/check-email', 'MemberAuthController::checkEmail');
    });

    $routes->group('', ['namespace' => $ns, 'filter' => 'member'], static function (RouteCollection $routes): void {
        $routes->post('logout', 'MemberAuthController::logout');

        // Akun Saya
        $routes->get('member/akun',           'AccountController::index');
        $routes->post('member/akun',          'AccountController::update');
        $routes->post('member/akun/password', 'AccountController::password');
        $routes->post('member/akun/sync-secret', 'AccountController::rotateSecret');
        $routes->post('member/akun/lepas-ikatan', 'AccountController::releaseBinding');
    });
}
