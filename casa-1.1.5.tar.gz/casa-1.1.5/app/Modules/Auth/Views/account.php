<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<?php /** @var array $profile @var ?string $sync_secret */ ?>
<div class="casa-page-head"><h1>Akun Saya</h1></div>

<div class="row g-3">
  <div class="col-lg-7">
    <div class="casa-card p-3 p-lg-4">
      <h2 class="h6 mb-3"><i class="bi bi-person me-1"></i> Data Profil</h2>
      <div class="mb-3">
        <label class="form-label small">Email <span class="text-muted">(tidak dapat diubah)</span></label>
        <input class="form-control" value="<?= esc($profile['email']) ?>" disabled>
      </div>
      <div class="mb-3"><label class="form-label small">Nama</label>
        <input id="p_name" class="form-control" value="<?= esc($profile['name']) ?>"></div>
      <div class="mb-3"><label class="form-label small">Perusahaan <span class="text-muted">(opsional)</span></label>
        <input id="p_company" class="form-control" value="<?= esc($profile['company'] ?? '') ?>"></div>
      <div class="mb-3"><label class="form-label small">Telepon / WhatsApp</label>
        <input id="p_phone" class="form-control" value="<?= esc($profile['phone']) ?>"></div>
      <button class="btn btn-primary" onclick="simpanProfil(this)"><i class="bi bi-save me-1"></i> Simpan Profil</button>
      <span id="p_msg" class="small ms-2"></span>
    </div>
  </div>

  <div class="col-lg-5">
    <div class="casa-card p-3 p-lg-4">
      <h2 class="h6 mb-3"><i class="bi bi-key me-1"></i> Ganti Kata Sandi</h2>
      <div class="mb-3"><label class="form-label small">Kata Sandi Lama</label>
        <input id="c_old" type="password" class="form-control" autocomplete="current-password"></div>
      <div class="mb-3"><label class="form-label small">Kata Sandi Baru</label>
        <input id="c_new" type="password" class="form-control" autocomplete="new-password">
        <div class="form-text">Minimal 8 karakter.</div></div>
      <button class="btn btn-outline-primary" onclick="gantiSandi(this)">Update Password</button>
      <span id="c_msg" class="small ms-2"></span>
    </div>

    <div class="casa-card p-3 p-lg-4 mt-3">
      <h2 class="h6 mb-2">Status Akun</h2>
      <p class="small mb-1">Status: <span class="badge bg-<?= ($profile['status'] ?? '') === 'active' ? 'success' : 'warning' ?>"><?= esc($profile['status'] ?? '-') ?></span></p>
      <p class="small text-muted mb-0">Terdaftar sejak <?= esc(substr((string) ($profile['created_at'] ?? ''), 0, 10)) ?></p>
    </div>

    <?php if (($sync_secret ?? null) !== null): ?>
    <div class="casa-card p-3 p-lg-4 mt-3" style="border:1px solid var(--casa-amber)">
      <h2 class="h6 mb-2"><i class="bi bi-arrow-repeat text-warning me-1"></i>Kode Sinkron Instance</h2>
      <p class="small text-muted mb-2">Tempel kode ini <b>sekali</b> di CASA VPS Anda (<b>Lisensi &amp; Aktivasi → Sinkron Online</b>). Instance akan menarik lisensi sesuai langganan secara otomatis — tanpa salin-tempel license key.</p>
      <div class="input-group input-group-sm mb-2">
        <input id="syncSecret" class="form-control font-monospace" value="<?= esc($sync_secret) ?>" readonly>
        <button class="btn btn-outline-secondary" type="button" onclick="copySync(this)"><i class="bi bi-clipboard"></i></button>
      </div>
      <button class="btn btn-outline-warning btn-sm" onclick="rotateSync(this)"><i class="bi bi-arrow-repeat me-1"></i>Rotasi kode</button>
      <span id="sy_msg" class="small ms-2"></span>
      <div class="form-text"><i class="bi bi-exclamation-triangle me-1"></i>Rotasi membuat VPS lama harus disinkron ulang dengan kode baru.</div>
    </div>

    <?php /** @var array|null $binding */ ?>
    <div class="casa-card p-3 p-lg-4 mt-3">
      <h2 class="h6 mb-2"><i class="bi bi-hdd-network me-1"></i>Instance Terikat</h2>
      <?php if (($binding ?? null) === null): ?>
        <p class="small text-muted mb-0">Belum ada instance yang terikat. Instance pertama yang melakukan <b>Sinkron Online</b> akan otomatis terikat ke akun ini.</p>
      <?php else: ?>
        <p class="small text-muted mb-2">Lisensi Anda sedang terkunci ke instance di bawah ini. Untuk pindah ke VPS/OS lain, lepas ikatannya dulu.</p>
        <div class="small mb-2">
          <div>Install ID: <code class="font-monospace"><?= esc(substr((string) $binding['install_id'], 0, 16)) ?>…</code></div>
          <div>IP terakhir: <span class="font-monospace"><?= esc($binding['ip'] ?? '-') ?></span></div>
          <div>Terikat sejak: <?= esc($binding['bound_at'] ?? '-') ?></div>
          <div>Sinkron terakhir: <?= esc($binding['last_sync_at'] ?? '-') ?></div>
        </div>
        <button id="relBtn" class="btn btn-outline-danger btn-sm" onclick="lepasIkatan(this)"><i class="bi bi-x-circle me-1"></i>Lepas ikatan &amp; pindah instance</button>
        <span id="rel_msg" class="small ms-2"></span>
        <div class="form-text"><i class="bi bi-exclamation-triangle me-1"></i><b>Matikan dulu instance lama</b> sebelum melepas. Setelah dilepas, instance lama itu diblokir mengikat lagi selama <?= (int) ($cooldown_min ?? 15) ?> menit supaya tidak merebut slot sebelum instance baru sempat sinkron.</div>
      <?php endif; ?>
    </div>
    <?php endif; ?>
  </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('page_scripts') ?>
<script>
async function simpanProfil(btn){
  var m = document.getElementById('p_msg'); m.textContent = ''; btn.disabled = true;
  var d = await casaPost('<?= esc(site_url('member/akun')) ?>', {
    name: document.getElementById('p_name').value,
    company: document.getElementById('p_company').value,
    phone: document.getElementById('p_phone').value
  });
  m.className = 'small ms-2 ' + (d.ok ? 'text-success' : 'text-danger');
  m.textContent = d.ok ? (d.message || 'Tersimpan.') : (d.error || 'Gagal.');
  btn.disabled = false;
}
async function gantiSandi(btn){
  var m = document.getElementById('c_msg'); m.textContent = ''; btn.disabled = true;
  var d = await casaPost('<?= esc(site_url('member/akun/password')) ?>', {
    current_password: document.getElementById('c_old').value,
    new_password: document.getElementById('c_new').value
  });
  m.className = 'small ms-2 ' + (d.ok ? 'text-success' : 'text-danger');
  m.textContent = d.ok ? (d.message || 'Tersimpan.') : (d.error || 'Gagal.');
  if (d.ok) { document.getElementById('c_old').value = ''; document.getElementById('c_new').value = ''; }
  btn.disabled = false;
}
function copySync(btn){
  var i = document.getElementById('syncSecret'); i.select(); i.setSelectionRange(0, 99999);
  navigator.clipboard ? navigator.clipboard.writeText(i.value) : document.execCommand('copy');
  var o = btn.innerHTML; btn.innerHTML = '<i class="bi bi-check2"></i>'; setTimeout(function(){ btn.innerHTML = o; }, 1200);
}
async function rotateSync(btn){
  if (!confirm('Rotasi kode sinkron? VPS lama harus disinkron ulang dengan kode baru.')) return;
  var m = document.getElementById('sy_msg'); m.textContent = ''; btn.disabled = true;
  var d = await casaPost('<?= esc(site_url('member/akun/sync-secret')) ?>', {});
  btn.disabled = false;
  if (d.ok) { document.getElementById('syncSecret').value = d.secret; m.className = 'small ms-2 text-success'; m.textContent = 'Kode baru dibuat.'; }
  else { m.className = 'small ms-2 text-danger'; m.textContent = d.error || 'Gagal.'; }
}
async function lepasIkatan(btn){
  if (!confirm('Lepas ikatan instance?\n\nPastikan instance LAMA sudah dimatikan. Setelah ini, instance BARU tinggal Sinkron Online dan akan terikat otomatis.')) return;
  var m = document.getElementById('rel_msg'); m.textContent = ''; btn.disabled = true;
  var d = await casaPost('<?= esc(site_url('member/akun/lepas-ikatan')) ?>', {});
  if (d.ok) {
    m.className = 'small ms-2 text-success';
    m.textContent = 'Ikatan dilepas. Sinkron dari instance baru sekarang.';
    setTimeout(function(){ location.reload(); }, 1500);
  } else {
    btn.disabled = false;
    m.className = 'small ms-2 text-danger'; m.textContent = d.error || 'Gagal.';
  }
}
</script>
<?= $this->endSection() ?>
