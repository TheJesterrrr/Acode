<?php
/**
 * Layout autentikasi CASA (CES 2.5: responsif, dark-mode, ikon SVG).
 * Gaya split-panel: brand navy + aksen teal (selaras mockup produk).
 * @var string $title
 * @var string $slot
 * @var string $role  'member'|'admin' (opsional, untuk label endpoint)
 */
$role = $role ?? 'member';
?>
<!doctype html>
<html lang="id" data-bs-theme="dark">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= esc($title) ?> · CASA</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        :root{--casa-teal:#12b5a5;--casa-teal-d:#0d9488;--casa-navy:#0e1b2e}
        body{min-height:100vh;display:grid;place-items:center;background:#eef1f5;margin:0}
        [data-bs-theme=dark] body{background:#0b1420}
        .auth-wrap{width:100%;max-width:900px;padding:20px}
        .auth-split{display:grid;grid-template-columns:1.05fr .95fr;border-radius:18px;overflow:hidden;
            box-shadow:0 24px 70px rgba(16,27,45,.20);background:var(--bs-body-bg)}
        .auth-brandpane{background:var(--casa-navy);color:#eaf1fa;padding:44px 38px;display:flex;flex-direction:column}
        .auth-logo{width:46px;height:46px;border-radius:13px;background:linear-gradient(150deg,var(--casa-teal),var(--casa-teal-d));
            display:grid;place-items:center;color:#04231f;box-shadow:0 6px 18px rgba(18,181,165,.4)}
        .auth-brandpane h1{font-size:1.55rem;font-weight:700;line-height:1.25;margin-top:34px;color:#fff}
        .auth-brandpane .lead2{color:#9fb0c6;font-size:.95rem;margin-top:10px}
        .auth-eyebrow{font-family:ui-monospace,SFMono-Regular,Consolas,monospace;font-size:.6rem;letter-spacing:.22em;color:#6c7f97;text-transform:uppercase}
        .auth-tags{margin-top:auto;padding-top:26px;display:flex;gap:8px;flex-wrap:wrap}
        .auth-tags span{background:rgba(255,255,255,.06);border:1px solid #22344d;color:#c6d2e2;border-radius:20px;padding:4px 11px;font-size:.72rem}
        .auth-formpane{padding:44px 38px;position:relative}
        .auth-formpane .btn-primary{background:var(--casa-teal-d);border-color:var(--casa-teal-d)}
        .auth-formpane .btn-primary:hover{background:var(--casa-teal);border-color:var(--casa-teal)}
        .auth-formpane a{color:var(--casa-teal-d);text-decoration:none}
        .auth-formpane .form-control:focus{border-color:var(--casa-teal);box-shadow:0 0 0 .2rem rgba(18,181,165,.22)}
        .auth-role-pill{display:inline-flex;align-items:center;gap:6px;font-size:.72rem;font-weight:600;color:var(--casa-teal-d);
            background:rgba(18,181,165,.1);border:1px solid rgba(18,181,165,.3);border-radius:20px;padding:3px 10px}
        @media(max-width:720px){.auth-split{grid-template-columns:1fr}.auth-brandpane{padding:30px}.auth-brandpane h1{margin-top:18px;font-size:1.3rem}.auth-tags{display:none}}
    </style>
</head>
<body>
<div class="auth-wrap">
  <div class="auth-split">
    <div class="auth-brandpane">
      <div class="d-flex align-items-center gap-3">
        <div class="auth-logo">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2">
            <path d="M12 2l8 3v6c0 5-3.5 9-8 11-4.5-2-8-6-8-11V5l8-3z"/><path d="M9 12l2 2 4-4"/>
          </svg>
        </div>
        <div><div class="fs-4 fw-bold text-white" style="letter-spacing:.02em">CASA</div><div class="auth-eyebrow">Security Agent</div></div>
      </div>
      <h1>Pentest dalam<br>satu portal.</h1>
      <p class="lead2">Recon, scan Vulnerability, validasi, sampai Report — satu alur Mission: Planning → Execution → Validation → Reporting.</p>
      <div class="auth-tags"><span>CodeIgniter 4 · Class A</span><span>Community edition</span></div>
    </div>
    <div class="auth-formpane">
      <span class="auth-role-pill"><i class="bi bi-<?= $role === 'admin' ? 'shield-lock' : 'person' ?>"></i><?= $role === 'admin' ? 'Administrator' : 'Member' ?></span>
      <div class="mt-3"><?= $slot ?></div>
    </div>
  </div>
  <p class="text-center text-secondary small mt-3 mb-0">CASA · CoreNet Autonomous Security Agent · v<?= esc(casa_version()) ?></p>
</div>

<button id="themeToggle" class="btn btn-sm btn-outline-secondary position-fixed top-0 end-0 m-3" type="button" aria-label="Toggle theme">◐</button>
<script>
(function () {
    var key = 'casa-theme', saved = localStorage.getItem(key);
    if (saved) document.documentElement.setAttribute('data-bs-theme', saved);
    document.getElementById('themeToggle').addEventListener('click', function () {
        var cur = document.documentElement.getAttribute('data-bs-theme') === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-bs-theme', cur);
        localStorage.setItem(key, cur);
    });
})();
</script>
</body>
</html>
