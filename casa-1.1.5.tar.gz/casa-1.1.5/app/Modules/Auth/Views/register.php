<?php
/** @var string $title */
ob_start(); ?>
<h1 class="h5 mb-1">Buat Akun Baru</h1>

<div id="alert" class="alert alert-danger d-none" role="alert"></div>

<form id="loginForm" method="post" action="<?= esc(endpoint_base('register')) ?>" novalidate>
    <?= csrf_field() ?>
    <div class="mb-3">
        <label class="form-label" for="name">Nama Lengkap</label>
        <input type="text" class="form-control" id="name" name="name" required autofocus>
    </div>
    <div class="mb-3">
        <label class="form-label" for="company">Perusahaan <span class="text-secondary">(opsional)</span></label>
        <input type="text" class="form-control" id="company" name="company">
    </div>
    <div class="mb-3">
        <label class="form-label" for="email">Email</label>
        <input type="email" class="form-control" id="email" name="email" required autocomplete="email">
    </div>
    <div class="mb-3">
        <label class="form-label" for="phone">No. WhatsApp</label>
        <input type="text" class="form-control" id="phone" name="phone" required inputmode="tel">
    </div>
    <div class="row g-3">
        <div class="col-6">
            <label class="form-label" for="password">Kata Sandi</label>
            <input type="password" class="form-control" id="password" name="password" required minlength="8" autocomplete="new-password">
        </div>
        <div class="col-6">
            <label class="form-label" for="password_confirm">Ulangi</label>
            <input type="password" class="form-control" id="password_confirm" name="password_confirm" required autocomplete="new-password">
        </div>
    </div>
    <button class="btn btn-primary w-100 mt-4" type="submit" id="submitBtn">Register</button>
</form>

<p class="text-center small mt-3 mb-0">
    Sudah punya akun? <a href="<?= esc(endpoint_base('login')) ?>">Masuk</a>
</p>

<?php require __DIR__ . '/_auth_form.js.php'; ?>
<?php $slot = ob_get_clean();
require __DIR__ . '/_auth_layout.php'; ?>
