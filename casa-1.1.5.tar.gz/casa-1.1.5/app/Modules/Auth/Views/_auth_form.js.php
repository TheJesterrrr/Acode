<script>
// Pengiriman form via fetch — controller membalas JSON {ok, redirect|error}.
(function () {
    var form = document.getElementById('loginForm');
    var alertBox = document.getElementById('alert');
    var btn = document.getElementById('submitBtn');
    if (!form) return;

    form.addEventListener('submit', async function (e) {
        e.preventDefault();
        alertBox.classList.add('d-none');
        btn.disabled = true;

        try {
            var res = await fetch(form.action, {
                method: 'POST',
                headers: { 'X-Requested-With': 'XMLHttpRequest' },
                body: new FormData(form)
            });
            var data = await res.json();
            if (data.ok && data.redirect) {
                window.location.assign(data.redirect);
                return;
            }
            alertBox.textContent = data.error || 'Terjadi kesalahan. Coba lagi.';
            alertBox.classList.remove('d-none');
        } catch (err) {
            alertBox.textContent = 'Tidak dapat terhubung ke server.';
            alertBox.classList.remove('d-none');
        } finally {
            btn.disabled = false;
        }
    });
})();
</script>
