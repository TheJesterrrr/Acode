<?php
/** @var string $title */
ob_start(); ?>
<h1 class="h5 mb-1">Masuk Administrator</h1>
<p class="text-secondary small mb-4">Konfigurasi platform CASA — AI, tool, dan setelan.</p>

<div id="alert" class="alert alert-danger d-none" role="alert"></div>

<form id="loginForm" method="post" action="<?= esc(endpoint_base('login')) ?>" novalidate>
    <?= csrf_field() ?>
    <div class="mb-3">
        <label class="form-label" for="email">Email</label>
        <input type="email" class="form-control" id="email" name="email" required autocomplete="username" autofocus>
    </div>
    <div class="mb-3">
        <label class="form-label" for="password">Kata Sandi</label>
        <input type="password" class="form-control" id="password" name="password" required autocomplete="current-password">
    </div>
    <button class="btn btn-primary w-100" type="submit" id="submitBtn">Log In</button>
</form>

<?php require __DIR__ . '/_auth_form.js.php'; ?>
<?php $slot = ob_get_clean();
$role = 'admin';
require __DIR__ . '/_auth_layout.php'; ?>
