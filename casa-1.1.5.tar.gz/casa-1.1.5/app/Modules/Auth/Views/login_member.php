<?php
/** @var string $title */
ob_start(); ?>
<h1 class="h5 mb-1">Masuk ke CASA</h1>
<p class="text-secondary small mb-4">Portal member — kelola project, mission, dan laporan.</p>

<div id="alert" class="alert alert-danger d-none" role="alert"></div>

<form id="loginForm" method="post" action="<?= esc(endpoint_base('login')) ?>" novalidate>
    <?= csrf_field() ?>
    <div class="mb-3">
        <label class="form-label" for="email">Email</label>
        <input type="email" class="form-control" id="email" name="email" required autocomplete="email" autofocus>
    </div>
    <div class="mb-3">
        <label class="form-label" for="password">Kata Sandi</label>
        <input type="password" class="form-control" id="password" name="password" required autocomplete="current-password">
    </div>
    <button class="btn btn-primary w-100" type="submit" id="submitBtn">Log In</button>
</form>

<?php
// Pemulihan kata sandi mandiri belum tersedia di v1.0 — arahkan ke admin via
// WhatsApp (nomor dari Pengaturan). Tautan disembunyikan bila nomor kosong,
// agar tidak ada tautan mati.
$waNomor = (string) (setting_value('whatsapp_number') ?: '');
$waLink  = $waNomor !== ''
    ? 'https://wa.me/' . preg_replace('/\D+/', '', $waNomor)
        . '?text=' . rawurlencode('Halo, saya lupa kata sandi akun member saya.')
    : '';
?>
<div class="d-flex justify-content-between mt-3 small">
    <a href="<?= esc(endpoint_base('register')) ?>">Daftar</a>
    <?php if ($waLink !== ''): ?>
        <a href="<?= esc($waLink) ?>" target="_blank" rel="noopener">Lupa kata sandi?</a>
    <?php endif; ?>
</div>

<?php require __DIR__ . '/_auth_form.js.php'; ?>
<?php $slot = ob_get_clean();
require __DIR__ . '/_auth_layout.php'; ?>
