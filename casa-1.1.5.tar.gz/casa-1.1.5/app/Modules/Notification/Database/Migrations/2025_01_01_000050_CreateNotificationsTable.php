<?php

declare(strict_types=1);

namespace App\Modules\Notification\Database\Migrations;

use CodeIgniter\Database\Migration;
use CodeIgniter\Database\RawSql;

/** Tabel `notifications` — kotak in-app (CES 13.8). */
final class CreateNotificationsTable extends Migration
{
    public function up(): void
    {
        $this->forge->addField([
            'id'          => ['type' => 'BIGINT', 'unsigned' => true, 'auto_increment' => true],
            'audience'    => ['type' => 'ENUM', 'constraint' => ['customer', 'admin']],
            'customer_id' => ['type' => 'BIGINT', 'unsigned' => true, 'null' => true],
            'type'        => ['type' => 'VARCHAR', 'constraint' => 40],
            'title'       => ['type' => 'VARCHAR', 'constraint' => 120],
            'body'        => ['type' => 'VARCHAR', 'constraint' => 500],
            'is_read'     => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 0],
            'created_at'  => ['type' => 'TIMESTAMP', 'default' => new RawSql('CURRENT_TIMESTAMP')],
        ]);
        $this->forge->addPrimaryKey('id');
        $this->forge->addKey(['audience', 'customer_id', 'is_read']);
        $this->forge->createTable('notifications', true, ['ENGINE' => 'InnoDB', 'DEFAULT CHARSET' => 'utf8mb4', 'COLLATE' => 'utf8mb4_unicode_ci']);
    }

    public function down(): void
    {
        $this->forge->dropTable('notifications', true);
    }
}
