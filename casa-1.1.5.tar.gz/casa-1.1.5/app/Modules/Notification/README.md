# Modul Notification

Pengiriman notifikasi berbasis peristiwa + driver (CES 1.6 Extensible).

- `NotificationService::send('event', [...])` — pemanggil menyebut peristiwa;
  service menentukan penerima, kanal, dan isi. Menggantikan facade lama.
- Driver: `InAppDriver` (tabel `notifications`) + `EmailDriver` (CI4 email).
  Kanal WhatsApp (v2) cukup tambah driver — pemanggil tak berubah.
- Kanal aktif dibaca dari setelan `notify_channels_admin/customer`.
- Kegagalan kirim tidak pernah dilempar ke pemanggil.

Skeleton hanya memuat satu peristiwa fondasi: `password_reset` dari modul Auth.

Menambah peristiwa: daftarkan namanya pada konstanta `EVENTS` beserta metode
`buildX()` penyusun pesannya. Peristiwa yang tidak terdaftar sengaja diabaikan
dan dicatat sebagai peringatan, supaya salah ketik tidak membuat notifikasi
hilang tanpa jejak.
Panel notifikasi (bell) dibangun bersama shell.
