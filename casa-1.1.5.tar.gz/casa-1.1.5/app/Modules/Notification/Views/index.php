<?= $this->extend(($shell['role'] ?? '') === 'Member' ? 'layouts/member' : 'layouts/admin') ?>
<?= $this->section('content') ?>
<?php /** @var array $rows @var string $base */ ?>
<div class="casa-page-head">
  <h1>Notifikasi</h1>
  <?php if ($rows !== []): ?>
    <button class="btn btn-sm btn-outline-secondary" onclick="bacaSemua()"><i class="bi bi-check2-all me-1"></i>Mark all as read</button>
  <?php endif; ?>
</div>

<div class="casa-card p-3 p-lg-4">
  <?php if ($rows === []): ?>
    <p class="text-muted mb-0 text-center py-4"><i class="bi bi-bell-slash me-1"></i> Belum ada notifikasi.</p>
  <?php else: ?>
    <div class="list-group list-group-flush">
      <?php foreach ($rows as $r): $baru = (int) $r['is_read'] === 0; ?>
        <div class="list-group-item d-flex gap-3 <?= $baru ? 'bg-body-tertiary' : '' ?>" id="notif-<?= (int) $r['id'] ?>">
          <div class="pt-1"><i class="bi <?= $baru ? 'bi-envelope-fill text-primary' : 'bi-envelope-open text-muted' ?>"></i></div>
          <div class="flex-grow-1">
            <div class="fw-600"><?= esc($r['title']) ?></div>
            <div class="small text-muted"><?= nl2br(esc($r['body'])) ?></div>
            <div class="small text-muted mt-1"><?= esc(substr((string) $r['created_at'], 0, 16)) ?></div>
          </div>
          <?php if ($baru): ?>
            <div><button class="btn btn-sm btn-outline-primary" onclick="baca(<?= (int) $r['id'] ?>)">Mark as read</button></div>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>
<?= $this->endSection() ?>

<?= $this->section('page_scripts') ?>
<script>
var NOTIF_BASE = '<?= esc($base) ?>';
async function baca(id){
  var d = await casaPost(NOTIF_BASE + '/' + id + '/baca', {});
  if (d.ok) { location.reload(); } else { alert(d.error || 'Gagal.'); }
}
async function bacaSemua(){
  var d = await casaPost(NOTIF_BASE + '/baca-semua', {});
  if (d.ok) { location.reload(); } else { alert(d.error || 'Gagal.'); }
}
</script>
<?= $this->endSection() ?>
