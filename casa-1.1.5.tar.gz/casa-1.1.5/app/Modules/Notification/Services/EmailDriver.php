<?php

declare(strict_types=1);

namespace App\Modules\Notification\Services;

use App\Modules\Auth\Models\CustomerModel;
use App\Modules\Setting\Services\SettingService;

/**
 * EmailDriver — mengirim notifikasi via email (CI4 Email service).
 *
 * Alamat tujuan: admin → notify_admin_email (fallback company_email);
 * customer → email pesan bila diisi, jika tidak diambil dari data pelanggan.
 * Belum dikonfigurasi bila alamat pengirim kosong — dilewati diam-diam.
 */
final class EmailDriver implements NotificationDriver
{
    public function __construct(
        private readonly SettingService $setting = new SettingService(),
        private readonly CustomerModel $customers = new CustomerModel(),
    ) {
    }

    public function name(): string
    {
        return 'email';
    }

    public function isConfigured(): bool
    {
        return (string) $this->setting->get('notify_email_from', '') !== '';
    }

    public function send(NotificationMessage $message): bool
    {
        $to = $this->recipient($message);
        if ($to === '') {
            return false;
        }

        $email = service('email');
        $email->setFrom(
            (string) $this->setting->get('notify_email_from'),
            (string) $this->setting->get('notify_email_from_name', 'CoreNet Remote Platform')
        );
        $email->setTo($to);
        $email->setSubject($message->title);
        $email->setMessage($this->render($message));

        return $email->send(false);
    }

    private function recipient(NotificationMessage $message): string
    {
        if ($message->isForAdmin()) {
            $to = (string) $this->setting->get('notify_admin_email', '');

            return $to !== '' ? $to : (string) $this->setting->get('company_email', '');
        }

        if ($message->email) {
            return $message->email;
        }
        if ($message->customerId) {
            $row = $this->customers->select('email')->find($message->customerId);

            return (string) ($row['email'] ?? '');
        }

        return '';
    }

    private function render(NotificationMessage $message): string
    {
        $html = '<p>' . nl2br(esc($message->body)) . '</p>';
        if ($message->actionUrl) {
            $label = esc($message->actionLabel ?? 'Buka');
            $html .= '<p><a href="' . esc($message->actionUrl, 'attr') . '">' . $label . '</a></p>';
        }

        return $html;
    }
}
