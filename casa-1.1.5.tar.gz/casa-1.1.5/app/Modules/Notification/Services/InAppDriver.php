<?php

declare(strict_types=1);

namespace App\Modules\Notification\Services;

use App\Modules\Notification\Models\NotificationModel;

/** InAppDriver — menulis notifikasi ke tabel `notifications`. Selalu siap. */
final class InAppDriver implements NotificationDriver
{
    public function __construct(private readonly NotificationModel $model = new NotificationModel())
    {
    }

    public function name(): string
    {
        return 'inapp';
    }

    public function isConfigured(): bool
    {
        return true;
    }

    public function send(NotificationMessage $message): bool
    {
        return (bool) $this->model->insert([
            'audience'    => $message->audience,
            'customer_id' => $message->isForCustomer() ? $message->customerId : null,
            'type'        => $message->event,
            'title'       => mb_substr($message->title, 0, 120),
            'body'        => mb_substr($message->body, 0, 500),
            'is_read'     => 0,
        ], false);
    }
}
