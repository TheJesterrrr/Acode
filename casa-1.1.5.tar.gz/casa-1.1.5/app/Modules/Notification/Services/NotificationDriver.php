<?php

declare(strict_types=1);

namespace App\Modules\Notification\Services;

/** Kontrak kanal notifikasi (CES 1.6 Extensible — kanal baru tanpa ubah pemanggil). */
interface NotificationDriver
{
    public function name(): string;

    public function isConfigured(): bool;

    public function send(NotificationMessage $message): bool;
}
