<?php

declare(strict_types=1);

namespace App\Modules\Notification\Services;

/**
 * NotificationMessage — satu notifikasi siap kirim (objek nilai imutabel).
 * Tiap driver mengambil bagian yang relevan: InApp (title/body), Email
 * (+actionUrl), WhatsApp nanti (phone).
 */
final class NotificationMessage
{
    public function __construct(
        public readonly string $event,
        public readonly string $audience,
        public readonly string $title,
        public readonly string $body,
        public readonly ?int $customerId = null,
        public readonly ?string $email = null,
        public readonly ?string $phone = null,
        public readonly ?string $actionUrl = null,
        public readonly ?string $actionLabel = null,
    ) {
    }

    public function isForAdmin(): bool
    {
        return $this->audience === 'admin';
    }

    public function isForCustomer(): bool
    {
        return $this->audience === 'customer';
    }
}
