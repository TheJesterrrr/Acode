<?php

declare(strict_types=1);

namespace App\Modules\Notification\Services;

use App\Libraries\Cer;
use App\Modules\Notification\Models\NotificationModel;
use App\Modules\Setting\Services\SettingService;
use Throwable;

/**
 * NotificationService — pengatur pengiriman notifikasi (CES 13.4).
 * Menggantikan facade `Notification` lama.
 *
 * Pemanggil cukup menyebut peristiwa + data; kelas ini menentukan penerima,
 * kanal, dan bunyinya. Menambah kanal (WhatsApp v2) cukup mendaftarkan driver —
 * tidak ada pemanggil yang berubah. Kegagalan kirim TIDAK pernah dilempar ke
 * pemanggil (aksi bisnis yang sudah sah tidak boleh gagal karena email).
 */
final class NotificationService
{
    /**
     * Registry peristiwa: nama peristiwa => metode penyusun pesan.
     *
     * Peristiwa yang tidak terdaftar di sini diabaikan dan dicatat sebagai
     * peringatan — sengaja, agar salah ketik nama peristiwa tidak diam-diam
     * membuat notifikasi hilang tanpa jejak.
     *
     * Tambahkan peristiwa milik modul bisnis di sini beserta metode buildX-nya.
     */
    private const EVENTS = [
        'password_reset' => 'buildPasswordReset',
    ];

    /** @var NotificationDriver[]|null */
    private ?array $drivers = null;

    public function __construct(
        private readonly SettingService $setting = new SettingService(),
        private readonly NotificationModel $model = new NotificationModel(),
    ) {
    }

    public function send(string $event, array $data = []): bool
    {
        if (! isset(self::EVENTS[$event])) {
            log_message('warning', "Peristiwa notifikasi tidak dikenal: {$event}");

            return false;
        }

        try {
            $message = $this->{self::EVENTS[$event]}($data);
        } catch (Throwable $e) {
            log_message('error', "Gagal menyusun notifikasi '{$event}': " . $e->getMessage());

            return false;
        }

        return $message === null ? false : $this->dispatch($message);
    }

    private function dispatch(NotificationMessage $message): bool
    {
        $channels = $this->channelsFor($message->audience);
        $anyOk    = false;

        foreach ($this->drivers() as $driver) {
            if (! in_array($driver->name(), $channels, true)) {
                continue;
            }
            if (! $driver->isConfigured()) {
                log_message('warning', "Kanal '{$driver->name()}' aktif tetapi belum dikonfigurasi.");
                continue;
            }
            if ($driver->send($message)) {
                $anyOk = true;
            }
        }

        return $anyOk;
    }

    private function channelsFor(string $audience): array
    {
        $key = $audience === 'admin' ? 'notify_channels_admin' : 'notify_channels_customer';

        return $this->setting->list($key, $audience === 'admin' ? ['inapp', 'email'] : ['inapp']);
    }

    /** @return NotificationDriver[] */
    private function drivers(): array
    {
        return $this->drivers ??= [new InAppDriver(), new EmailDriver()];
    }

    /* ---------------------------------------------------- read APIs (in-app) */

    public function unreadCount(string $audience, ?int $customerId = null): int
    {
        return $this->model->unreadCount($audience, $customerId);
    }

    public function listFor(string $audience, ?int $customerId = null, int $limit = 20): array
    {
        return $this->model->listFor($audience, $customerId, $limit);
    }

    public function markRead(int $id, string $audience, ?int $customerId = null): void
    {
        $this->model->markRead($id, $audience, $customerId);
    }

    public function markAllRead(string $audience, ?int $customerId = null): void
    {
        $this->model->markAllRead($audience, $customerId);
    }

    /* -------------------------------------------------- event message builders */

    private function buildPasswordReset(array $d): NotificationMessage
    {
        return new NotificationMessage(
            event: 'password_reset',
            audience: 'customer',
            title: 'Atur ulang password CoreNet Anda',
            body: "Kami menerima permintaan pemulihan password untuk akun Anda.\n\n"
                . "Tautan berlaku selama 1 jam dan hanya dapat dipakai sekali.\n\n"
                . "Bila Anda tidak meminta ini, abaikan email ini — password Anda tidak berubah.",
            email: (string) ($d['email'] ?? ''),
            actionUrl: (string) ($d['url'] ?? ''),
            actionLabel: 'Atur ulang password',
        );
    }
}
