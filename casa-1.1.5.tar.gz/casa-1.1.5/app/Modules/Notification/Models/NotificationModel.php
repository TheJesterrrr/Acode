<?php

declare(strict_types=1);

namespace App\Modules\Notification\Models;

use CodeIgniter\Model;

/** NotificationModel — kotak notifikasi in-app (tabel `notifications`). */
final class NotificationModel extends Model
{
    protected $table         = 'notifications';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $useTimestamps = false;
    protected $allowedFields  = ['audience', 'customer_id', 'type', 'title', 'body', 'is_read'];

    public function unreadCount(string $audience, ?int $customerId = null): int
    {
        $b = $this->where('audience', $audience)->where('is_read', 0);
        if ($audience !== 'admin') {
            $b->where('customer_id', $customerId);
        }

        return $b->countAllResults();
    }

    public function listFor(string $audience, ?int $customerId = null, int $limit = 20): array
    {
        $b = $this->select('id, type, title, body, is_read, created_at')
            ->where('audience', $audience)
            ->orderBy('id', 'DESC');
        if ($audience !== 'admin') {
            $b->where('customer_id', $customerId);
        }

        return $b->findAll($limit);
    }

    public function markRead(int $id, string $audience, ?int $customerId = null): void
    {
        $b = $this->where('id', $id)->where('audience', $audience);
        if ($audience !== 'admin') {
            $b->where('customer_id', $customerId);
        }
        $b->set('is_read', 1)->update();
    }

    public function markAllRead(string $audience, ?int $customerId = null): void
    {
        $b = $this->where('audience', $audience)->where('is_read', 0);
        if ($audience !== 'admin') {
            $b->where('customer_id', $customerId);
        }
        $b->set('is_read', 1)->update();
    }
}
