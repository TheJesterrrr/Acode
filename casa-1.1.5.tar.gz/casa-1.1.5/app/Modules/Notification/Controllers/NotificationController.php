<?php

declare(strict_types=1);

namespace App\Modules\Notification\Controllers;

use App\Controllers\BaseController;
use App\Modules\Notification\Services\NotificationService;
use CodeIgniter\HTTP\ResponseInterface;

/**
 * NotificationController — kotak notifikasi member & admin (CES 13.2 thin).
 *
 * Satu controller melayani dua audiens; pemisahan dilakukan lewat rute yang
 * berbeda (member/* vs casaadmin/*) beserta filternya, sehingga tak ada
 * percabangan peran di dalam kode.
 */
final class NotificationController extends BaseController
{
    public function __construct(private readonly NotificationService $notify = new NotificationService())
    {
    }

    /* ------------------------------------------------------------------ MEMBER */

    public function member(): string
    {
        $customerId = (int) $this->session->get('member_id');

        return $this->memberView('App\Modules\Notification\Views\index', [
            'title' => 'Notifikasi',
            'rows'  => $this->notify->listFor('customer', $customerId, 50),
            'base'  => site_url('member/notifikasi'),
        ], 'notifikasi');
    }

    public function memberRead(int $id): ResponseInterface
    {
        $this->notify->markRead($id, 'customer', (int) $this->session->get('member_id'));

        return $this->ok();
    }

    public function memberReadAll(): ResponseInterface
    {
        $this->notify->markAllRead('customer', (int) $this->session->get('member_id'));

        return $this->ok();
    }

    /* ------------------------------------------------------------------- ADMIN */

    public function admin(): string
    {
        return $this->adminView('App\Modules\Notification\Views\index', [
            'title' => 'Notifikasi',
            'rows'  => $this->notify->listFor('admin', null, 50),
            'base'  => site_url('casaadmin/notifikasi'),
        ], 'notifikasi');
    }

    public function adminRead(int $id): ResponseInterface
    {
        $this->notify->markRead($id, 'admin');

        return $this->ok();
    }

    public function adminReadAll(): ResponseInterface
    {
        $this->notify->markAllRead('admin');

        return $this->ok();
    }
}
