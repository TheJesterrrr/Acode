<?php

declare(strict_types=1);

use CodeIgniter\Router\RouteCollection;

/** Rute modul Notification (CES 13.10). */

/** @var RouteCollection $routes */
$ns = 'App\Modules\Notification\Controllers';

$routes->group('member/notifikasi', ['namespace' => $ns, 'filter' => 'member'], static function (RouteCollection $routes): void {
    $routes->get('',                'NotificationController::member');
    $routes->post('baca-semua',     'NotificationController::memberReadAll');
    $routes->post('(:num)/baca',    'NotificationController::memberRead/$1');
});

$routes->group('casaadmin/notifikasi', ['namespace' => $ns, 'filter' => 'admin'], static function (RouteCollection $routes): void {
    $routes->get('',                'NotificationController::admin');
    $routes->post('baca-semua',     'NotificationController::adminReadAll');
    $routes->post('(:num)/baca',    'NotificationController::adminRead/$1');
});
