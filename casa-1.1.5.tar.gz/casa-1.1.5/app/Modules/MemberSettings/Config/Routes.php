<?php

declare(strict_types=1);

use CodeIgniter\Router\RouteCollection;

/** Rute Pengaturan di portal member (unified, Owner-only). */

/** @var RouteCollection $routes */
$routes->group('member/pengaturan', ['namespace' => 'App\Modules\MemberSettings\Controllers', 'filter' => 'member'], static function (RouteCollection $routes): void {
    $routes->get('lisensi', 'SettingsLicenseController::index');
    $routes->post('lisensi/activate', 'SettingsLicenseController::activate', ['filter' => 'audit:LICENSE_ACTIVATE']);
    $routes->post('lisensi/sync-secret', 'SettingsLicenseController::saveSyncSecret');
    $routes->post('lisensi/sync', 'SettingsLicenseController::sync', ['filter' => 'audit:LICENSE_SYNC']);
    $routes->post('lisensi/update/download', 'SettingsLicenseController::downloadUpdate', ['filter' => 'audit:LICENSE_UPDATE_DOWNLOAD']);
    $routes->post('lisensi/update/upload', 'SettingsLicenseController::uploadUpdate', ['filter' => 'audit:LICENSE_UPDATE_UPLOAD']);
    $routes->post('lisensi/update/preflight', 'SettingsLicenseController::preflight');
    $routes->post('lisensi/update/run', 'SettingsLicenseController::runUpgrade', ['filter' => 'audit:LICENSE_UPDATE_RUN']);
    $routes->get('lisensi/update/status', 'SettingsLicenseController::upgradeStatus');
    $routes->get('lisensi/troubleshoot-export', 'SettingsLicenseController::exportTroubleshoot');

    $routes->get('tools', 'SettingsToolsController::index');
    $routes->post('tools/update', 'SettingsToolsController::update', ['filter' => 'audit:TOOLS_UPDATE']);
});
