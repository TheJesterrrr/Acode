<?php

declare(strict_types=1);

namespace App\Modules\MemberSettings\Controllers;

use App\Controllers\BaseController;
use App\Libraries\ToolLabel;
use App\Modules\Feed\Services\FeedSyncService;
use App\Modules\Setting\Services\SettingService;
use CodeIgniter\Exceptions\PageNotFoundException;
use CodeIgniter\HTTP\ResponseInterface;
use Config\Database;

/**
 * SettingsToolsController — "Tools & Kapabilitas" di portal member (Owner-only).
 * Menampilkan KAPABILITAS aktif (bukan nama tool — rahasia dagang) + tombol
 * Update untuk menarik konten deteksi terbaru dari owner (Detection Feed).
 */
final class SettingsToolsController extends BaseController
{
    private function gate(): void
    {
        if ((string) $this->session->get('team_role') !== 'owner') {
            throw PageNotFoundException::forPageNotFound();
        }
    }

    public function index(): string
    {
        $this->gate();
        $s     = new SettingService();
        $db    = Database::connect();
        $codes = [];
        foreach ($db->query("SELECT tool_code FROM tool_install WHERE status='installed'")->getResultArray() as $r) {
            $codes[] = (string) $r['tool_code'];
        }
        // Builtin (mis. IDOR) selalu tersedia — dijalankan CASA sendiri tanpa biner.
        foreach (\App\Modules\Adapter\Services\AdapterFactory::supported() as $c) {
            if (\App\Modules\Adapter\Services\AdapterFactory::isBuiltin($c)) {
                $codes[] = $c;
            }
        }
        $codes = array_values(array_unique($codes));
        // Allowlist owner (via feed): bila di-set, hanya tampilkan kapabilitas yang diizinkan.
        $allow = json_decode((string) $s->get('feed.tools_allowed', ''), true);
        if (is_array($allow) && $allow !== []) {
            $codes = array_values(array_intersect($codes, $allow));
        }
        // Kode tool → label kapabilitas (di produk otomatis menyembunyikan nama asli), dedup.
        $caps = ToolLabel::showListDedup($codes);
        sort($caps);

        return $this->memberView('App\Modules\MemberSettings\Views\tools', [
            'title'        => 'Tools & Kapabilitas',
            'caps'         => $caps,
            'feed_version' => $s->int('feed.local_version', 0),
            'feed_synced'  => (string) $s->get('feed.local_synced_at', ''),
        ], 'set_tools');
    }

    /**
     * Minta update konten deteksi (feed) dari owner. TIDAK dijalankan di web
     * (SELinux memblok shell/tar dari httpd) — ditunda ke worker (casa:cron),
     * sama seperti scan. Worker menjalankan feed-sync di CLI lalu versi naik.
     */
    public function update(): ResponseInterface
    {
        $this->gate();
        (new SettingService())->set('feed.sync_requested', date('Y-m-d H:i:s'));

        return $this->ok(['message' => 'Permintaan pembaruan dikirim — worker menyinkronkan dalam ±1 menit. Muat ulang halaman untuk melihat versi terbaru.']);
    }
}
