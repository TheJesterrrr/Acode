<?php

declare(strict_types=1);

namespace App\Modules\MemberSettings\Controllers;

use App\Controllers\BaseController;
use App\Modules\Licensing\Config\Edition;
use App\Modules\Licensing\Services\LicenseKeyService;
use App\Modules\Licensing\Services\LicenseSyncService;
use CodeIgniter\Exceptions\PageNotFoundException;
use CodeIgniter\HTTP\ResponseInterface;
use RuntimeException;

/**
 * SettingsLicenseController — Lisensi & Aktivasi di dalam PORTAL MEMBER (unified),
 * hanya untuk peran Owner. Bagian dari "Pengaturan" agar instance produk cukup
 * satu portal (tak perlu buka konsol admin terpisah). Reuse service Licensing.
 */
final class SettingsLicenseController extends BaseController
{
    public function __construct(
        private readonly LicenseKeyService $keys = new LicenseKeyService(),
        private readonly LicenseSyncService $syncSvc = new LicenseSyncService(),
    ) {
    }

    /** Gerbang: hanya Owner (team_role) yang boleh masuk Pengaturan. */
    private function gate(): void
    {
        if ((string) $this->session->get('team_role') !== 'owner') {
            throw PageNotFoundException::forPageNotFound();
        }
    }

    public function index(): string
    {
        $this->gate();
        $eff   = $this->keys->effective();
        $tiers = config(Edition::class)->tiers;

        return $this->memberView('App\Modules\MemberSettings\Views\license', [
            'title'           => 'Lisensi & Aktivasi',
            'eff'             => $eff,
            'tierLbl'         => $tiers[$eff['tier']]['label'] ?? ucfirst((string) $eff['tier']),
            'sync_secret_set' => $this->syncSvc->hasSecret(),
            'cur_version'     => config(Edition::class)->version,
            'pending_update'  => $this->syncSvc->pendingUpdate(),
        ], 'set_license');
    }

    /** Unduh paket update yang tercatat dari sync terakhir ke writable/releases/pending/. */
    public function downloadUpdate(): ResponseInterface
    {
        $this->gate();
        $res = $this->syncSvc->downloadUpdate();

        return empty($res['ok']) ? $this->fail((string) ($res['error'] ?? 'Gagal.')) : $this->ok($res);
    }

    /**
     * Unggah paket update MANUAL (cadangan bila Download Update gagal, mis. jaringan/
     * IPv6). Berkas disimpan ke writable/releases/pending/ sama seperti jalur unduh,
     * lalu diterapkan dgn `php spark casa:apply-update <file>` (semi-otomatis, backup
     * wajib). Validasi nama ketat (anti path-traversal).
     */
    public function uploadUpdate(): ResponseInterface
    {
        $this->gate();

        $file = $this->request->getFile('package');
        if ($file === null || ! $file->isValid()) {
            return $this->fail('Berkas tidak valid / gagal diunggah (cek batas upload PHP: upload_max_filesize & post_max_size).');
        }
        if ($file->getSize() > 200 * 1024 * 1024) {
            return $this->fail('Berkas terlalu besar (maks 200 MB).');
        }
        $name = basename((string) $file->getClientName());
        if (! preg_match('/^casa-[A-Za-z0-9._-]+\.tar\.gz$/', $name)) {
            return $this->fail('Nama berkas harus seperti casa-1.2.3.tar.gz.');
        }

        $dir      = rtrim(WRITEPATH, '/\\') . DIRECTORY_SEPARATOR . 'releases' . DIRECTORY_SEPARATOR . 'pending';
        $permHint = 'Perbaiki izin di server (sekali): cd /var/www/casa && sudo chown -R corenet:apache writable/releases && sudo chmod -R 775 writable/releases.';
        if (! is_dir($dir)) {
            @mkdir($dir, 0775, true);
            @chmod($dir, 0775);
        }
        if (! is_dir($dir) || ! is_writable($dir)) {
            return $this->fail('Folder writable/releases/pending/ tak bisa ditulis. ' . $permHint);
        }
        try {
            $file->move($dir, $name, true);
        } catch (\Throwable $e) {
            return $this->fail('Gagal menyimpan berkas. ' . $permHint);
        }
        $path = $dir . DIRECTORY_SEPARATOR . $name;
        @file_put_contents($path . '.sha256', (string) (hash_file('sha256', $path) ?: ''));

        return $this->ok(['file' => $name, 'message' => 'Paket terunggah. Terapkan lewat SSH.']);
    }

    /** Cek kesiapan upgrade (preflight) — tampilkan daftar syarat lolos/gagal. */
    public function preflight(): ResponseInterface
    {
        $this->gate();

        return $this->ok((new \App\Modules\Licensing\Services\UpdatePreflightService())->check());
    }

    /**
     * Jalankan upgrade DARI GUI — di LATAR BELAKANG (proses terpisah), bukan di
     * request web, agar penimpaan kode tak mengganggu request yang sedang jalan.
     * GUI memantau lewat upgradeStatus(). Hanya lanjut bila preflight siap.
     */
    public function runUpgrade(): ResponseInterface
    {
        $this->gate();

        $pre = (new \App\Modules\Licensing\Services\UpdatePreflightService())->check();
        if (empty($pre['ready'])) {
            return $this->fail('Belum siap upgrade — perbaiki dulu item yang gagal di Cek Kesiapan.');
        }
        if (! function_exists('exec')) {
            return $this->fail('Fungsi exec() dinonaktifkan — upgrade dari GUI tak bisa; jalankan via SSH.');
        }

        $root    = dirname(rtrim(APPPATH, '/\\'));
        $pendDir = rtrim(WRITEPATH, '/\\') . DIRECTORY_SEPARATOR . 'releases' . DIRECTORY_SEPARATOR . 'pending';
        $file    = (string) ($pre['file'] ?? '');
        if ($file === '' || ! is_file($pendDir . DIRECTORY_SEPARATOR . $file)) {
            return $this->fail('Paket belum ada di server. Klik Download Update atau unggah paket manual dulu.');
        }

        $log = rtrim(WRITEPATH, '/\\') . DIRECTORY_SEPARATOR . 'logs' . DIRECTORY_SEPARATOR . 'update-run.log';
        @file_put_contents($log, '[' . date('Y-m-d H:i:s') . "] Memulai upgrade ke {$file} ...\n");

        $inner = 'cd ' . escapeshellarg($root) . ' && php spark casa:apply-update ' . escapeshellarg($file) . ' >> ' . escapeshellarg($log) . ' 2>&1';
        @exec('nohup bash -c ' . escapeshellarg($inner) . ' >/dev/null 2>&1 &');

        return $this->ok(['started' => true, 'file' => $file]);
    }

    /** Status upgrade latar belakang (polling dari GUI): running|done|failed + cuplikan log. */
    public function upgradeStatus(): ResponseInterface
    {
        $this->gate();

        $log = rtrim(WRITEPATH, '/\\') . DIRECTORY_SEPARATOR . 'logs' . DIRECTORY_SEPARATOR . 'update-run.log';
        if (! is_file($log)) {
            return $this->ok(['state' => 'idle', 'log' => '']);
        }
        $text  = (string) file_get_contents($log);
        $state = 'running';
        if (str_contains($text, 'Selesai —')) {
            $state = 'done';
        } elseif (str_contains($text, 'GAGAL') || str_contains($text, 'Checksum tak cocok') || str_contains($text, 'dibatalkan')) {
            $state = 'failed';
        }
        $lines = explode("\n", rtrim($text));
        $tail  = implode("\n", array_slice($lines, -40));

        return $this->ok(['state' => $state, 'log' => $tail]);
    }

    /** Unduh berkas diagnosa (troubleshoot export) berisi error & lingkungan. */
    public function exportTroubleshoot(): ResponseInterface
    {
        $this->gate();
        $txt  = (new \App\Modules\Licensing\Services\TroubleshootExportService())->build();
        $name = 'casa-troubleshoot-' . date('Ymd-His') . '.txt';

        return $this->response
            ->setHeader('Content-Type', 'text/plain; charset=utf-8')
            ->setHeader('Content-Disposition', 'attachment; filename="' . $name . '"')
            ->setBody($txt);
    }

    public function activate(): ResponseInterface
    {
        $this->gate();
        try {
            $p = $this->keys->activate((string) $this->request->getPost('token'));
        } catch (RuntimeException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok(['tier' => $p['tier'] ?? '?', 'exp' => $p['exp'] ?? null]);
    }

    public function saveSyncSecret(): ResponseInterface
    {
        $this->gate();
        $secret = trim((string) $this->request->getPost('secret'));
        if ($secret === '') {
            return $this->fail('Kode sinkron kosong.');
        }
        $this->syncSvc->saveSecret($secret);

        return $this->ok(['message' => 'Kode sinkron tersimpan.']);
    }

    public function sync(): ResponseInterface
    {
        $this->gate();
        $res = $this->syncSvc->sync();

        return empty($res['ok']) ? $this->fail((string) ($res['error'] ?? 'Gagal.')) : $this->ok($res);
    }
}
