<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<?php
/** @var array $caps @var int $feed_version @var string $feed_synced */
$icons = [
    'DNS Resolution' => 'bi-hdd-network', 'Subdomain Discovery' => 'bi-diagram-3', 'URL Discovery' => 'bi-link-45deg',
    'HTTP Probing' => 'bi-globe2', 'Port Scanning' => 'bi-hdd-rack', 'Web Crawling' => 'bi-bug',
    'Content Discovery' => 'bi-folder2-open', 'Vulnerability Assessment' => 'bi-shield-exclamation',
    'XSS Assessment' => 'bi-code-slash', 'SQL Injection Assessment' => 'bi-database-exclamation',
    'Secret Scanning' => 'bi-key', 'Dependency & Container Scanning' => 'bi-box-seam',
    'TLS/SSL Assessment' => 'bi-lock', 'Access Control Testing' => 'bi-person-lock', 'Parameter Discovery' => 'bi-sliders',
];
?>
<div class="casa-page-head">
  <div>
    <h1 class="mb-0"><i class="bi bi-tools me-1"></i>Tools &amp; Kapabilitas</h1>
    <div class="small text-muted"><?= count($caps) ?> kapabilitas aktif · konten deteksi feed v<?= (int) $feed_version ?><?= $feed_synced ? ' · sinkron ' . esc(substr($feed_synced, 0, 16)) : '' ?></div>
  </div>
  <button id="updBtn" class="btn btn-amber"><i class="bi bi-arrow-repeat me-1"></i>Update detection content</button>
</div>
<span id="updMsg" class="small text-muted d-block mb-2"></span>

<div class="row g-2">
  <?php foreach ($caps as $cap): ?>
    <div class="col-6 col-md-4 col-lg-3">
      <div class="casa-card p-3 h-100 d-flex align-items-center gap-2">
        <i class="bi <?= esc($icons[$cap] ?? 'bi-check2-circle') ?> fs-5 text-success"></i>
        <div><div class="small fw-semibold" style="line-height:1.2"><?= esc($cap) ?></div><div class="small text-success">Aktif</div></div>
      </div>
    </div>
  <?php endforeach; ?>
  <?php if ($caps === []): ?>
    <div class="col-12"><div class="casa-card p-4 text-center text-muted">Belum ada kapabilitas aktif. Klik <b>Update detection content</b>.</div></div>
  <?php endif; ?>
</div>

<div class="casa-card p-3 mt-3 small text-muted">
  <i class="bi bi-info-circle me-1"></i>Kapabilitas diperbarui otomatis dari pusat. Deteksi kerentanan (template) diperbarui via tombol di atas atau otomatis harian.
</div>
<?= $this->endSection() ?>

<?= $this->section('page_scripts') ?>
<script>
document.getElementById('updBtn').addEventListener('click', async () => {
  const b = document.getElementById('updBtn'), m = document.getElementById('updMsg');
  b.disabled = true; const o = b.innerHTML; b.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Memperbarui…';
  const d = await casaPost('<?= esc(site_url('member/pengaturan/tools/update')) ?>', {});
  b.disabled = false; b.innerHTML = o;
  m.className = 'small d-block mb-2 ' + (d.ok ? 'text-success' : 'text-danger');
  m.textContent = d.ok ? (d.message || 'Konten deteksi diperbarui.') : (d.error || 'Gagal.');
  if (d.ok && d.updated) setTimeout(() => location.reload(), 1200);
});
</script>
<?= $this->endSection() ?>
