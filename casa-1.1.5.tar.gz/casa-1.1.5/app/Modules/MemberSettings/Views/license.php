<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<?php
/** @var array $eff @var string $tierLbl @var bool $sync_secret_set */
$tierColor = ['community' => 'secondary', 'pro' => 'info', 'enterprise' => 'warning'];
$active    = ! empty($eff['active']);
$expired   = ! empty($eff['expired']);
?>
<div class="casa-page-head"><h1 class="mb-0"><i class="bi bi-key me-1"></i>Lisensi &amp; Aktivasi</h1></div>

<div class="row g-3">
  <div class="col-lg-5">
    <div class="casa-card p-4 h-100">
      <h2 class="h6 mb-3">Status instance</h2>
      <div class="d-flex align-items-center gap-2 mb-3">
        <span class="badge text-bg-<?= esc($tierColor[$eff['tier']] ?? 'secondary') ?> fs-6 text-uppercase"><?= esc($tierLbl) ?></span>
        <?php if ($active): ?><span class="badge text-bg-success">Aktif</span>
        <?php elseif ($expired): ?><span class="badge text-bg-danger">Kedaluwarsa → Community</span>
        <?php else: ?><span class="badge text-bg-secondary">Community</span><?php endif; ?>
      </div>
      <dl class="row small mb-0">
        <dt class="col-5 text-muted">Customer</dt><dd class="col-7"><?= esc($eff['customer'] ?? '—') ?></dd>
        <dt class="col-5 text-muted">License ID</dt><dd class="col-7 font-monospace"><?= esc($eff['license_id'] ?? '—') ?></dd>
        <dt class="col-5 text-muted">Kedaluwarsa</dt><dd class="col-7"><?= esc($eff['exp'] ?? '∞') ?></dd>
      </dl>
    </div>
    <div class="casa-card p-4 mt-3">
      <h2 class="h6 mb-3"><i class="bi bi-box-arrow-in-down me-1"></i>Update Aplikasi</h2>
      <div class="small text-muted mb-2">Versi berjalan: <b class="text-body"><?= esc($cur_version ?? '?') ?></b></div>
      <?php if ($pending_update): ?>
        <div class="alert alert-warning py-2 px-3 small mb-2">
          Versi <b><?= esc($pending_update['version']) ?></b> tersedia (<?= number_format(($pending_update['size'] ?? 0) / 1048576, 1) ?> MB).
        </div>
        <button id="dlUpdateBtn" class="btn btn-warning btn-sm"><i class="bi bi-cloud-download me-1"></i>Download Update</button>
        <span id="dlUpdateMsg" class="small ms-2"></span>
        <div id="dlUpdateCmd" class="d-none mt-2">
          <div class="small text-muted mb-1">Berkas sudah di server. Terapkan lewat SSH (wajib backup otomatis dulu, lalu migrasi):</div>
          <code class="d-block p-2 rounded" style="background:var(--casa-bg-2,#0d1117);white-space:pre-wrap"></code>
        </div>
      <?php else: ?>
        <div class="small text-success"><i class="bi bi-check-circle me-1"></i>Sudah versi terbaru (menurut sync terakhir).</div>
      <?php endif; ?>
      <div class="small text-muted mt-2">Klik <b>Sync now</b> di atas dulu kalau ingin cek ulang versi terbaru.</div>

      <hr class="my-3">
      <div class="small text-muted mb-2"><i class="bi bi-cloud-upload me-1"></i><b>Atau unggah paket manual</b> — cadangan bila Download Update gagal (mis. jaringan). Unduh <code>casa-&lt;versi&gt;.tar.gz</code> dari <b>Download App</b> di portal member, lalu unggah di sini.</div>
      <form id="upForm" enctype="multipart/form-data" class="d-flex gap-2 align-items-center flex-wrap">
        <input type="file" name="package" accept=".gz,.tgz" class="form-control form-control-sm" style="max-width:260px" required>
        <button id="upBtn" class="btn btn-outline-warning btn-sm"><i class="bi bi-cloud-upload me-1"></i>Unggah paket</button>
        <span id="upMsg" class="small"></span>
      </form>
      <div id="upCmd" class="d-none mt-2">
        <div class="small text-muted mb-1">Paket siap di server. Terapkan lewat SSH (backup otomatis dulu, lalu migrasi):</div>
        <code class="d-block p-2 rounded" style="background:var(--casa-bg-2,#0d1117);white-space:pre-wrap"></code>
      </div>

      <hr class="my-3">
      <div class="d-flex align-items-center flex-wrap gap-2 mb-2">
        <button id="preBtn" class="btn btn-outline-info btn-sm"><i class="bi bi-clipboard-check me-1"></i>Cek Kesiapan Upgrade</button>
        <button id="runUpBtn" class="btn btn-success btn-sm d-none"><i class="bi bi-rocket-takeoff me-1"></i>Upgrade Sekarang</button>
        <span id="preMsg" class="small"></span>
      </div>
      <div class="small text-muted mb-2">Cek dulu apakah server siap — baru upgrade otomatis (backup dibuat dulu). Kalau ada yang gagal, tampil cara perbaikannya.</div>
      <ul id="preList" class="list-unstyled small mb-2 d-none"></ul>
      <div id="runLog" class="d-none mt-2">
        <div class="small text-muted mb-1">Proses upgrade (otomatis di server):</div>
        <code id="runLogBox" class="d-block p-2 rounded" style="background:var(--casa-bg-2,#0d1117);white-space:pre-wrap;max-height:220px;overflow:auto"></code>
      </div>

      <hr class="my-3">
      <div class="small text-muted mb-2"><i class="bi bi-life-preserver me-1"></i><b>Ada masalah?</b> Unduh berkas diagnosa (versi, lingkungan, error terbaru) untuk dikirim ke support.</div>
      <a id="tsBtn" class="btn btn-outline-secondary btn-sm" href="<?= esc(site_url('member/pengaturan/lisensi/troubleshoot-export')) ?>"><i class="bi bi-download me-1"></i>Export Troubleshoot</a>
    </div>
  </div>

  <div class="col-lg-7">
    <div class="casa-card p-4 mb-3" style="border:1px solid var(--casa-amber)">
      <h2 class="h6 mb-1"><i class="bi bi-arrow-repeat text-warning me-1"></i>Sinkron Online <span class="text-muted small">(disarankan)</span></h2>
      <p class="text-muted small mb-3">Tempel <b>Kode Sinkron</b> dari akun member online Anda → fitur terbuka otomatis sesuai langganan.</p>
      <div class="row g-2 align-items-end">
        <div class="col-md-7"><label class="form-label small">Kode Sinkron<?= $sync_secret_set ? ' <span class="badge text-bg-success">tersimpan</span>' : '' ?></label>
          <div class="input-group">
            <input id="syncSecret" class="form-control" placeholder="<?= $sync_secret_set ? '•••• (tersimpan)' : 'Tempel kode…' ?>">
            <button class="btn btn-outline-secondary" type="button" id="saveSecretBtn">Save</button>
          </div>
        </div>
        <div class="col-md-5"><button id="syncBtn" class="btn btn-amber"<?= $sync_secret_set ? '' : ' disabled' ?>><i class="bi bi-cloud-download me-1"></i>Sync now</button>
          <span id="syncMsg" class="small ms-2"></span></div>
      </div>
    </div>
    <div class="casa-card p-4">
      <h2 class="h6 mb-3">Aktivasi manual (paste key)</h2>
      <form id="actForm">
        <textarea name="token" class="form-control font-monospace mb-2" rows="3" placeholder="Tempel license key dari owner…" required></textarea>
        <button id="actBtn" class="btn btn-primary"><i class="bi bi-unlock me-1"></i>Activate</button>
        <span id="actMsg" class="small ms-2"></span>
      </form>
    </div>
  </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('page_scripts') ?>
<script>
const L = { activate: '<?= esc(site_url('member/pengaturan/lisensi/activate')) ?>', secret: '<?= esc(site_url('member/pengaturan/lisensi/sync-secret')) ?>', sync: '<?= esc(site_url('member/pengaturan/lisensi/sync')) ?>', dlUpdate: '<?= esc(site_url('member/pengaturan/lisensi/update/download')) ?>', upUpdate: '<?= esc(site_url('member/pengaturan/lisensi/update/upload')) ?>', preflight: '<?= esc(site_url('member/pengaturan/lisensi/update/preflight')) ?>', runUp: '<?= esc(site_url('member/pengaturan/lisensi/update/run')) ?>', upStatus: '<?= esc(site_url('member/pengaturan/lisensi/update/status')) ?>' };

// --- Cek kesiapan (preflight) + upgrade otomatis dari GUI ---
const preBtn = document.getElementById('preBtn');
if (preBtn) {
  preBtn.addEventListener('click', async () => {
    const list = document.getElementById('preList'), msg = document.getElementById('preMsg'), runBtn = document.getElementById('runUpBtn');
    preBtn.disabled = true; const o = preBtn.innerHTML; preBtn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Mengecek…';
    const d = await casaPost(L.preflight, {});
    preBtn.innerHTML = o; preBtn.disabled = false;
    if (!d.ok) { msg.className = 'small text-danger'; msg.textContent = d.error || 'Gagal.'; return; }
    list.classList.remove('d-none'); list.innerHTML = '';
    (d.checks || []).forEach(c => {
      const ic = c.ok ? '<i class="bi bi-check-circle-fill text-success"></i>' : (c.critical ? '<i class="bi bi-x-circle-fill text-danger"></i>' : '<i class="bi bi-exclamation-triangle-fill text-warning"></i>');
      let html = '<li class="mb-1">' + ic + ' ' + c.label + ' — <span class="text-muted">' + c.detail + '</span>';
      if (!c.ok) html += '<br><span class="text-warning" style="font-size:.85em">↳ ' + c.fix + '</span>';
      list.insertAdjacentHTML('beforeend', html + '</li>');
    });
    if (d.ready) {
      msg.className = 'small text-success'; msg.textContent = 'Server SIAP upgrade' + (d.target ? ' ke ' + d.target : '') + '.';
      runBtn.classList.remove('d-none');
    } else {
      msg.className = 'small text-danger'; msg.textContent = 'Belum siap — perbaiki item merah dulu.';
      runBtn.classList.add('d-none');
    }
  });
}
const runUpBtn = document.getElementById('runUpBtn');
if (runUpBtn) {
  runUpBtn.addEventListener('click', async () => {
    if (!confirm('Mulai upgrade sekarang? Backup app + database dibuat otomatis dulu.')) return;
    runUpBtn.disabled = true; const o = runUpBtn.innerHTML; runUpBtn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Memulai…';
    const d = await casaPost(L.runUp, {});
    if (!d.ok) { runUpBtn.disabled = false; runUpBtn.innerHTML = o; document.getElementById('preMsg').textContent = d.error || 'Gagal.'; return; }
    const box = document.getElementById('runLog'), logBox = document.getElementById('runLogBox');
    box.classList.remove('d-none'); runUpBtn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Mengupgrade…';
    const poll = setInterval(async () => {
      const s = await fetch(L.upStatus, {headers:{'X-Requested-With':'XMLHttpRequest'}}).then(r=>r.json()).catch(()=>null);
      if (!s) return;
      logBox.textContent = s.log || ''; logBox.scrollTop = logBox.scrollHeight;
      if (s.state === 'done') { clearInterval(poll); runUpBtn.innerHTML = '<i class="bi bi-check-circle me-1"></i>Selesai — muat ulang'; runUpBtn.classList.replace('btn-success','btn-primary'); runUpBtn.disabled = false; runUpBtn.onclick = () => location.reload(); }
      else if (s.state === 'failed') { clearInterval(poll); runUpBtn.disabled = false; runUpBtn.innerHTML = o; document.getElementById('preMsg').className='small text-danger'; document.getElementById('preMsg').textContent = 'Upgrade gagal — lihat log + Export Troubleshoot.'; }
    }, 3000);
  });
}
const upForm = document.getElementById('upForm');
if (upForm) {
  upForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const b = document.getElementById('upBtn'), m = document.getElementById('upMsg');
    b.disabled = true; const o = b.innerHTML; b.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Mengunggah…';
    const d = await casaPost(L.upUpdate, new FormData(upForm));
    b.innerHTML = o; b.disabled = false;
    if (d.ok) {
      m.className = 'small text-success'; m.textContent = 'Terunggah.';
      const box = document.getElementById('upCmd'); box.classList.remove('d-none');
      box.querySelector('code').textContent = 'cd /var/www/casa\nphp spark casa:apply-update ' + d.file;
    } else {
      m.className = 'small text-danger'; m.textContent = d.error || 'Gagal.';
    }
  });
}
const dlBtn = document.getElementById('dlUpdateBtn');
if (dlBtn) {
  dlBtn.addEventListener('click', async () => {
    const m = document.getElementById('dlUpdateMsg'); dlBtn.disabled = true;
    const o = dlBtn.innerHTML; dlBtn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Mengunduh…';
    const d = await casaPost(L.dlUpdate, {});
    dlBtn.innerHTML = o;
    if (d.ok) {
      m.className = 'small ms-2 text-success'; m.textContent = 'Terunduh.';
      const box = document.getElementById('dlUpdateCmd');
      box.classList.remove('d-none');
      box.querySelector('code').textContent = 'cd /var/www/casa\nphp spark casa:apply-update ' + d.file;
      dlBtn.remove();
    } else {
      dlBtn.disabled = false; m.className = 'small ms-2 text-danger'; m.textContent = d.error || 'Gagal.';
    }
  });
}
document.getElementById('actForm').addEventListener('submit', async (e) => { e.preventDefault();
  const b = document.getElementById('actBtn'), m = document.getElementById('actMsg'); b.disabled = true;
  const d = await casaPost(L.activate, new FormData(e.target));
  if (d.ok) { m.className='small ms-2 text-success'; m.textContent='Aktif: '+d.tier+(d.exp?' s/d '+d.exp:''); setTimeout(()=>location.reload(),900); }
  else { b.disabled=false; m.className='small ms-2 text-danger'; m.textContent=d.error||'Gagal.'; }
});
document.getElementById('saveSecretBtn').addEventListener('click', async () => {
  const m=document.getElementById('syncMsg'), v=document.getElementById('syncSecret').value.trim();
  if(!v){m.className='small ms-2 text-danger';m.textContent='Isi kode.';return;}
  const d=await casaPost(L.secret,{secret:v});
  if(d.ok){m.className='small ms-2 text-success';m.textContent='Tersimpan.';document.getElementById('syncBtn').disabled=false;}
  else{m.className='small ms-2 text-danger';m.textContent=d.error||'Gagal.';}
});
document.getElementById('syncBtn').addEventListener('click', async () => {
  const b=document.getElementById('syncBtn'), m=document.getElementById('syncMsg'); b.disabled=true; const o=b.innerHTML; b.innerHTML='<span class="spinner-border spinner-border-sm"></span>';
  const d=await casaPost(L.sync,{}); b.disabled=false; b.innerHTML=o;
  if(d.ok){m.className='small ms-2 text-success';m.textContent=d.community?'Community.':('Aktif: '+d.tier+(d.exp?' s/d '+d.exp:'')); setTimeout(()=>location.reload(),1200);}
  else{m.className='small ms-2 text-danger';m.textContent=d.error||'Gagal.';}
});
</script>
<?= $this->endSection() ?>
