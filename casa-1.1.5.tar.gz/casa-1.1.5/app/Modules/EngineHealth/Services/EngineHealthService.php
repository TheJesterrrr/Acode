<?php

declare(strict_types=1);

namespace App\Modules\EngineHealth\Services;

use App\Modules\Setting\Services\SettingService;
use CodeIgniter\Database\BaseConnection;
use Config\Database;
use Throwable;

/**
 * EngineHealthService — kondisi mesin scan: antrean task, status mission, tool
 * terpasang, penyedia AI, dan denyut worker (cron). Membantu admin memastikan
 * pemindaian berjalan sehat.
 */
final class EngineHealthService
{
    private BaseConnection $db;

    public function __construct(?BaseConnection $db = null, private readonly SettingService $settings = new SettingService())
    {
        $this->db = $db ?? Database::connect();
    }

    /** @return array<string,mixed> */
    public function status(): array
    {
        return [
            'audit_enabled'      => $this->settings->bool('event_audit_enabled', false),
            'audit_interval_min' => $this->settings->int('event_audit_interval_min', 15),
            'audit_last_run'     => $this->row("SELECT status, message, ran_at FROM cron_logs WHERE job='infra-audit' ORDER BY id DESC LIMIT 1"),
            'task_by_status' => $this->pairs("SELECT status k, COUNT(*) n FROM task GROUP BY status"),
            'tasks_24h'      => $this->one("SELECT COUNT(*) n FROM task WHERE created_at>=DATE_SUB(NOW(),INTERVAL 1 DAY)"),
            'mission_state'  => $this->pairs("SELECT state k, COUNT(*) n FROM mission GROUP BY state"),
            'tools_installed'=> $this->one("SELECT COUNT(*) n FROM tool_install WHERE status='installed'"),
            'tools_total'    => $this->one("SELECT COUNT(*) n FROM tool"),
            'ai_enabled'     => $this->one("SELECT COUNT(*) n FROM ai_provider WHERE enabled=1"),
            'ai_total'       => $this->one("SELECT COUNT(*) n FROM ai_provider"),
            'worker_last'    => $this->row("SELECT job, status, ran_at, duration_ms FROM cron_logs WHERE job LIKE '%work%' ORDER BY id DESC LIMIT 1"),
            'recent_cron'    => $this->rows("SELECT job, status, message, duration_ms, ran_at FROM cron_logs ORDER BY id DESC LIMIT 12"),
            'recent_errors'  => $this->rows("SELECT id, tool_code, target, error, finished_at FROM task WHERE status='error' ORDER BY id DESC LIMIT 8"),
            'running_now'    => $this->rows("SELECT id, tool_code, target, started_at FROM task WHERE status='running' ORDER BY id DESC LIMIT 8"),
            'event_log'      => \App\Libraries\CasaLog::recent(100),
        ];
    }

    private function one(string $sql): int
    {
        try {
            return (int) ($this->db->query($sql)->getRowArray()['n'] ?? 0);
        } catch (Throwable $e) {
            return 0;
        }
    }

    /** @return array<string,int> */
    private function pairs(string $sql): array
    {
        $out = [];
        try {
            foreach ($this->db->query($sql)->getResultArray() as $r) {
                $out[(string) $r['k']] = (int) $r['n'];
            }
        } catch (Throwable $e) {
        }

        return $out;
    }

    private function row(string $sql): ?array
    {
        try {
            return $this->db->query($sql)->getRowArray();
        } catch (Throwable $e) {
            return null;
        }
    }

    /** @return array<int,array<string,mixed>> */
    private function rows(string $sql): array
    {
        try {
            return $this->db->query($sql)->getResultArray();
        } catch (Throwable $e) {
            return [];
        }
    }
}
