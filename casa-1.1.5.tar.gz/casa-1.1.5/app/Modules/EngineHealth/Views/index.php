<?= $this->extend('layouts/admin') ?>
<?= $this->section('content') ?>
<?php
/** @var array $s */
$tc = ['pending' => 'secondary', 'running' => 'primary', 'done' => 'success', 'error' => 'danger', 'skipped' => 'warning'];
$mc = ['planning' => 'secondary', 'executing' => 'primary', 'validating' => 'info', 'reporting' => 'warning', 'done' => 'success', 'error' => 'danger'];
$wl = $s['worker_last'] ?? null;
$workerFresh = $wl && strtotime((string) $wl['ran_at']) >= strtotime('-5 minutes');

/**
 * Ambil kode "[CASA-Exxx]" di awal sebuah pesan (kalau ada) lalu render jadi
 * badge yang ngelink langsung ke artikel Panduan yang cocok. Satu fungsi kecil
 * ini yang bikin "lihat error → tahu harus buka menu/panduan apa" instan,
 * tanpa pengguna menebak-nebak dari teks error mentah.
 */
helper('casa_log');
?>
<div class="casa-page-head"><h1 class="h4 mb-0"><i class="bi bi-hdd-network me-1"></i>Engine Health</h1></div>

<div class="row g-3 mb-1">
  <div class="col-12 col-lg-4"><div class="casa-card p-3 h-100">
    <div class="d-flex align-items-center justify-content-between"><h2 class="h6 mb-0">Worker (casa:work)</h2>
      <span class="badge text-bg-<?= $workerFresh ? 'success' : ($wl ? 'warning' : 'secondary') ?>"><?= $workerFresh ? 'Sehat' : ($wl ? 'Terlambat' : 'Belum jalan') ?></span></div>
    <?php if (! $wl): ?>
      <div class="small text-muted mt-2"><?= casaCodeBadge('[CASA-E003] Belum ada catatan cron. Pastikan cron casa:work terpasang.') ?></div>
    <?php else: ?>
      <div class="small text-muted mt-2">Terakhir: <?= esc(substr((string) $wl['ran_at'], 0, 19)) ?> · <?= esc($wl['status']) ?> · <?= (int) $wl['duration_ms'] ?>ms</div>
    <?php endif; ?>
  </div></div>
  <div class="col-6 col-lg-2"><div class="casa-card p-3 h-100"><div class="small text-muted">Task 24 jam</div><div class="fs-3 fw-bold"><?= (int) $s['tasks_24h'] ?></div></div></div>
  <div class="col-6 col-lg-2"><div class="casa-card p-3 h-100"><div class="small text-muted">Tools</div><div class="fs-3 fw-bold"><?= (int) $s['tools_installed'] ?><small class="fs-6 text-muted">/<?= (int) $s['tools_total'] ?></small></div></div></div>
  <div class="col-6 col-lg-2"><div class="casa-card p-3 h-100"><div class="small text-muted">AI aktif</div><div class="fs-3 fw-bold"><?= (int) $s['ai_enabled'] ?><small class="fs-6 text-muted">/<?= (int) $s['ai_total'] ?></small></div></div></div>
  <div class="col-6 col-lg-2"><div class="casa-card p-3 h-100"><div class="small text-muted">Task error</div><div class="fs-3 fw-bold text-danger"><?= (int) ($s['task_by_status']['error'] ?? 0) ?></div></div></div>
</div>

<div class="row g-3 mt-0">
  <div class="col-lg-6"><div class="casa-card p-3 p-lg-4 h-100"><h2 class="h6 mb-3">Queue task</h2>
    <div class="d-flex flex-wrap gap-2">
      <?php foreach (['pending', 'running', 'done', 'error', 'skipped'] as $k): ?>
        <span class="badge text-bg-<?= $tc[$k] ?> px-3 py-2"><?= ucfirst($k) ?>: <?= (int) ($s['task_by_status'][$k] ?? 0) ?></span>
      <?php endforeach; ?>
    </div>
    <?php if (($s['running_now'] ?? []) !== []): ?>
      <h3 class="h6 mt-3 mb-2">Sedang berjalan</h3>
      <table class="table table-sm mb-0"><tbody>
        <?php foreach ($s['running_now'] as $t): ?><tr><td class="font-monospace small"><?= esc(\App\Libraries\ToolLabel::show($t['tool_code'] ?? null)) ?></td><td class="small text-truncate" style="max-width:220px"><?= esc($t['target']) ?></td></tr><?php endforeach; ?>
      </tbody></table>
    <?php endif; ?>
  </div></div>
  <div class="col-lg-6"><div class="casa-card p-3 p-lg-4 h-100"><h2 class="h6 mb-3">Status mission</h2>
    <div class="d-flex flex-wrap gap-2">
      <?php foreach ($mc as $k => $c): ?><span class="badge text-bg-<?= $c ?> px-3 py-2"><?= ucfirst($k) ?>: <?= (int) ($s['mission_state'][$k] ?? 0) ?></span><?php endforeach; ?>
    </div>
  </div></div>
</div>

<div class="row g-3 mt-0">
  <div class="col-lg-6"><div class="casa-card p-0 h-100">
    <div class="p-3 border-bottom" style="border-color:var(--casa-card-brd)!important"><h2 class="h6 mb-0 text-danger">Error terbaru</h2></div>
    <div class="table-responsive"><table class="table table-sm align-middle mb-0"><tbody>
      <?php foreach (($s['recent_errors'] ?? []) as $e): ?>
        <tr><td class="ps-3 font-monospace small"><?= esc(\App\Libraries\ToolLabel::show($e['tool_code'] ?? null)) ?></td><td class="small text-muted" style="max-width:320px"><?= casaCodeBadge((string) ($e['error'] ?: $e['target'])) ?></td></tr>
      <?php endforeach; ?>
      <?php if (($s['recent_errors'] ?? []) === []): ?><tr><td class="text-success small py-3 ps-3"><i class="bi bi-check-circle me-1"></i>Tak ada error.</td></tr><?php endif; ?>
    </tbody></table></div>
  </div></div>
  <div class="col-lg-6"><div class="casa-card p-0 h-100">
    <div class="p-3 border-bottom" style="border-color:var(--casa-card-brd)!important"><h2 class="h6 mb-0">Riwayat cron</h2></div>
    <div class="table-responsive"><table class="table table-sm align-middle mb-0"><tbody>
      <?php foreach (($s['recent_cron'] ?? []) as $c): ?>
        <tr><td class="ps-3 font-monospace small"><?= esc($c['job']) ?></td><td><span class="badge text-bg-<?= ($c['status'] ?? '') === 'ok' ? 'success' : 'warning' ?>"><?= esc($c['status']) ?></span></td><td class="small text-muted pe-3"><?= esc(substr((string) $c['ran_at'], 0, 19)) ?></td></tr>
      <?php endforeach; ?>
      <?php if (($s['recent_cron'] ?? []) === []): ?><tr><td class="text-muted small py-3 ps-3">Belum ada catatan cron.</td></tr><?php endif; ?>
    </tbody></table></div>
  </div></div>
</div>

<div class="row g-3 mt-0">
  <div class="col-12"><div class="casa-card p-3">
    <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-2">
      <h2 class="h6 mb-0"><i class="bi bi-activity me-1"></i>Audit Infrastruktur Terjadwal</h2>
      <?php $ar = $s['audit_last_run'] ?? null; ?>
      <span class="small text-muted">
        <?php if ($ar): ?>Audit terakhir: <?= esc(substr((string) $ar['ran_at'], 0, 19)) ?> — <?= esc(mb_substr((string) $ar['message'], 0, 80)) ?>
        <?php else: ?>Belum pernah berjalan.<?php endif; ?>
      </span>
    </div>
    <p class="small text-muted mb-3">Kalau DIMATIKAN, sistem cuma mendeteksi event saat ada scan berjalan (seperti biasa). Kalau DINYALAKAN, server diaudit berkala (disk, koneksi DB, sertifikat TLS, tool hilang, cron mati) walau tak ada scan — supaya kendala sisi server tak "di balik layar".</p>
    <form id="auditForm" class="d-flex flex-wrap align-items-center gap-3">
      <div class="form-check form-switch">
        <input class="form-check-input" type="checkbox" id="auditEnabled" <?= ($s['audit_enabled'] ?? false) ? 'checked' : '' ?>>
        <label class="form-check-label small" for="auditEnabled">Aktifkan audit berkala</label>
      </div>
      <div class="d-flex align-items-center gap-2">
        <label class="small text-muted" for="auditInterval">Interval</label>
        <select id="auditInterval" class="form-select form-select-sm" style="width:auto">
          <?php foreach ([5, 15, 30, 60] as $m): ?>
            <option value="<?= $m ?>" <?= (int) ($s['audit_interval_min'] ?? 15) === $m ? 'selected' : '' ?>><?= $m ?> menit</option>
          <?php endforeach; ?>
        </select>
      </div>
      <button type="button" id="auditSaveBtn" class="btn btn-sm btn-primary">Simpan</button>
      <span id="auditMsg" class="small"></span>
    </form>
  </div></div>
</div>

<div class="row g-3 mt-0">
  <div class="col-12"><div class="casa-card p-0">
    <div class="p-3 border-bottom d-flex align-items-center justify-content-between" style="border-color:var(--casa-card-brd)!important">
      <h2 class="h6 mb-0"><i class="bi bi-terminal me-1"></i>Log Sistem (kode CASA-Exxx)</h2>
      <span class="small text-muted">Maks 100 baris terakhir — otomatis terhapus, tak pernah membebani disk</span>
    </div>
    <div class="table-responsive" style="max-height:400px;overflow-y:auto">
      <table class="table table-sm align-middle mb-0"><tbody>
        <?php foreach (($s['event_log'] ?? []) as $ev): ?>
          <?php $lvlColor = ['error' => 'danger', 'warning' => 'warning', 'info' => 'info'][$ev['level'] ?? 'error'] ?? 'secondary'; ?>
          <tr>
            <td class="ps-3 small text-muted text-nowrap"><?= esc(substr((string) $ev['created_at'], 0, 19)) ?></td>
            <td><span class="badge text-bg-<?= $lvlColor ?>"><?= esc(strtoupper((string) ($ev['level'] ?? ''))) ?></span></td>
            <td>
              <?php $slug = \App\Libraries\CasaLog::guideSlug((string) $ev['code']); ?>
              <?php if ($slug !== null): ?>
                <a href="<?= esc(site_url('panduan/' . $slug)) ?>" target="_blank" class="text-decoration-none"><span class="badge text-bg-dark font-monospace"><?= esc($ev['code']) ?></span></a>
              <?php else: ?>
                <span class="badge text-bg-dark font-monospace"><?= esc($ev['code']) ?></span>
              <?php endif; ?>
            </td>
            <td class="small text-muted pe-3"><?= esc(mb_substr((string) $ev['message'], 0, 140)) ?></td>
          </tr>
        <?php endforeach; ?>
        <?php if (($s['event_log'] ?? []) === []): ?><tr><td colspan="4" class="text-success small py-3 ps-3"><i class="bi bi-check-circle me-1"></i>Belum ada event tercatat — semua normal.</td></tr><?php endif; ?>
      </tbody></table>
    </div>
  </div></div>
</div>
<script>
// Segarkan halaman otomatis supaya log & status bisa dipantau LANGSUNG selagi
// scan berjalan, tanpa perlu refresh manual berulang-ulang.
setTimeout(() => location.reload(), 15000);

document.getElementById('auditSaveBtn').addEventListener('click', async function () {
  this.disabled = true;
  var msg = document.getElementById('auditMsg');
  msg.className = 'small';
  msg.textContent = '';
  var fd = new FormData();
  fd.append('enabled', document.getElementById('auditEnabled').checked ? '1' : '0');
  fd.append('interval', document.getElementById('auditInterval').value);
  var d = await casaPost('<?= esc(site_url('casaadmin/engine/audit')) ?>', fd);
  if (d.ok) {
    msg.className = 'small text-success';
    msg.textContent = d.message || 'Tersimpan.';
  } else {
    msg.className = 'small text-danger';
    msg.textContent = d.error || 'Gagal menyimpan.';
  }
  this.disabled = false;
});
</script>
<?= $this->endSection() ?>
