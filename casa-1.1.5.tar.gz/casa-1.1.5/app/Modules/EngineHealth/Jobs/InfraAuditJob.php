<?php

declare(strict_types=1);

namespace App\Modules\EngineHealth\Jobs;

use App\Libraries\CasaLog;
use App\Modules\Cron\Jobs\CronJob;
use App\Modules\Cron\Models\CronLogModel;
use App\Modules\Licensing\Services\LicenseSyncService;
use App\Modules\Setting\Services\SettingService;
use App\Modules\ToolManager\Models\ToolInstallModel;
use Config\Database;
use Throwable;

/**
 * InfraAuditJob — audit infrastruktur server (CronJob, CES 13.9), TERPISAH dari
 * aktivitas scan. CasaWork/EngineService hanya mendeteksi masalah SAAT scan
 * berjalan; job ini berjalan berkala lewat `casa:cron` (CronRunner) supaya
 * kendala server (disk, DB, TLS, tool hilang, cron mati total) terlihat
 * walau tak ada mission aktif sama sekali.
 *
 * On/off + interval diatur lewat Setting (bukan crontab) — satu baris cron
 * `casa:cron` yang sudah ada cukup selamanya; nonaktif = `intervalMinutes()`
 * dibuat sangat besar sehingga CronRunner praktis tak pernah menganggapnya
 * jatuh tempo lagi (tanpa mengubah baris crontab).
 */
final class InfraAuditJob implements CronJob
{
    private const SETTING_ENABLED  = 'event_audit_enabled';
    private const SETTING_INTERVAL = 'event_audit_interval_min';

    /** Dipakai bila nonaktif — jauh lebih besar dari pilihan interval terbesar (60 menit). */
    private const DISABLED_INTERVAL_MIN = 60 * 24 * 365;

    public function __construct(private readonly SettingService $settings = new SettingService())
    {
    }

    public function name(): string
    {
        return 'infra-audit';
    }

    public function label(): string
    {
        return 'Audit Infrastruktur (disk/DB/TLS/tool/worker)';
    }

    public function intervalMinutes(): int
    {
        if (! $this->settings->bool(self::SETTING_ENABLED, false)) {
            return self::DISABLED_INTERVAL_MIN;
        }

        $min = $this->settings->int(self::SETTING_INTERVAL, 15);

        return max(5, min(60, $min));
    }

    public function run(): string
    {
        if (! $this->settings->bool(self::SETTING_ENABLED, false)) {
            return 'nonaktif — tak diaudit.';
        }

        $warnings = [];
        $warnings[] = $this->checkWorker();
        $warnings[] = $this->checkTools();
        $warnings[] = $this->checkDisk();
        $warnings[] = $this->checkWebProcesses();
        $warnings[] = $this->checkLicenseSync();
        $warnings[] = $this->checkDatabase();
        $warnings[] = $this->checkTls();
        $warnings = array_values(array_filter($warnings));

        if ($warnings === []) {
            CasaLog::log('CASA-E000', 'Audit infrastruktur berjalan — disk, DB, TLS, tool, worker: semua normal.', null, null, 'info');

            return 'semua normal.';
        }

        return implode(' | ', $warnings);
    }

    /** E003 — worker (casa:work) tak jalan sama sekali, bukan hanya terlambat sesaat (sudah dideteksi CasaWork sendiri lewat lock-streak). */
    private function checkWorker(): ?string
    {
        try {
            $row = (new CronLogModel())
                ->where('job', 'like', '%work%')
                ->orderBy('id', 'DESC')
                ->first();
        } catch (Throwable $e) {
            return null;
        }

        $staleMinutes = 10; // casa:work dijadwalkan tiap menit; 10x berturut-turut hilang = cron kemungkinan mati.
        if ($row === null || strtotime((string) $row['ran_at']) < strtotime("-{$staleMinutes} minutes")) {
            CasaLog::log('CASA-E003', "Tak ada catatan casa:work dalam {$staleMinutes} menit terakhir — cron kemungkinan tak terpasang/berhenti.");

            return 'worker tak jalan';
        }

        return null;
    }

    /** E005 — tool terdaftar tapi file biner hilang (dirangkum satu baris, bukan per-tool, agar log 100-baris tak cepat penuh). */
    private function checkTools(): ?string
    {
        try {
            $rows = (new ToolInstallModel())->where('status', 'installed')->findAll();
        } catch (Throwable $e) {
            return null;
        }

        $missing = [];
        foreach ($rows as $r) {
            $bin = (string) ($r['bin_path'] ?? '');
            if ($bin !== '' && (! is_file($bin) || ! is_executable($bin))) {
                $missing[] = $r['tool_code'];
            }
        }
        if ($missing === []) {
            return null;
        }
        CasaLog::log('CASA-E005', 'Tool terdaftar "installed" tapi biner hilang/tak bisa dieksekusi: ' . implode(', ', $missing));

        return count($missing) . ' tool hilang';
    }

    /** E006 — ruang disk menipis. */
    private function checkDisk(): ?string
    {
        $free = @disk_free_space('/');
        $total = @disk_total_space('/');
        if ($free === false || $total === false || $total <= 0) {
            return null;
        }
        $pct = $free / $total * 100;
        if ($pct < 10 || $free < 1_073_741_824) { // <10% ATAU <1GB bebas
            CasaLog::log('CASA-E006', sprintf('Disk tersisa %.1f%% (%.2f GB) — mendekati penuh.', $pct, $free / 1_073_741_824), null, null, 'warning');

            return 'disk menipis';
        }

        return null;
    }

    /** E007 — heuristik kasar jumlah proses httpd/php-fpm. Lewati diam-diam kalau exec() tak tersedia (umum di shared hosting). */
    private function checkWebProcesses(): ?string
    {
        if (! function_exists('exec') || in_array('exec', array_map('trim', explode(',', (string) ini_get('disable_functions'))), true)) {
            return null;
        }
        try {
            @exec('ps aux 2>/dev/null | grep -E "httpd|php-fpm|apache2" | grep -v grep | wc -l', $out);
        } catch (Throwable $e) {
            return null;
        }
        $n = isset($out[0]) ? (int) trim($out[0]) : 0;
        if ($n <= 0) {
            return null; // perintah tak tersedia/gagal — jangan menebak-nebak, lewati diam-diam.
        }
        // Ambang kasar — bukan perbandingan ke MaxRequestWorkers/pm.max_children sesungguhnya
        // (letak file config berbeda tiap server), sekadar sinyal "mencurigakan banyak".
        if ($n >= 150) {
            CasaLog::log('CASA-E007', "Proses httpd/php-fpm terdeteksi {$n} — mendekati kemungkinan batas, berisiko 502/503.", null, null, 'warning');

            return 'proses web banyak';
        }

        return null;
    }

    /** E008 — sinkron lisensi tak pernah sukses dalam waktu lama (bukan cuma sekali gagal). Lewati kalau instance ini tak dikonfigurasi utk sinkron sama sekali. */
    private function checkLicenseSync(): ?string
    {
        $svc = new LicenseSyncService();
        if (! $svc->hasSecret()) {
            return null; // instance tak disetel utk sinkron (mis. console owner sendiri) — bukan error.
        }
        $last = (string) ($this->settings->get('license.last_sync_ok_at', '') ?? '');
        $staleHours = 40; // dijadwalkan harian; beri jeda sebelum dianggap "diam gagal".
        if ($last === '' || strtotime($last) < strtotime("-{$staleHours} hours")) {
            CasaLog::log('CASA-E008', $last === '' ? 'Belum pernah ada sinkron lisensi sukses tercatat.' : "Sinkron lisensi sukses terakhir: {$last} (lebih dari {$staleHours} jam lalu).", null, null, 'warning');

            return 'sinkron lisensi basi';
        }

        return null;
    }

    /** E010 — utilisasi koneksi MySQL/MariaDB. */
    private function checkDatabase(): ?string
    {
        try {
            $db = Database::connect();
            $connected = (int) ($db->query("SHOW STATUS LIKE 'Threads_connected'")->getRowArray()['Value'] ?? 0);
            $max = (int) ($db->query("SHOW VARIABLES LIKE 'max_connections'")->getRowArray()['Value'] ?? 0);
        } catch (Throwable $e) {
            return null;
        }
        if ($max <= 0) {
            return null;
        }
        $pct = $connected / $max * 100;
        if ($pct >= 80) {
            CasaLog::log('CASA-E010', sprintf('Koneksi database %d/%d (%.0f%%) — mendekati batas max_connections.', $connected, $max, $pct), null, null, 'warning');

            return 'DB mendekati batas';
        }

        return null;
    }

    /** E012 — sertifikat TLS mendekati/sudah kedaluwarsa. No-op kalau baseURL bukan https (mis. lab VM di :8008 HTTP). */
    private function checkTls(): ?string
    {
        $base = (string) (config(\Config\App::class)->baseURL ?? '');
        $host = parse_url($base, PHP_URL_HOST);
        $scheme = parse_url($base, PHP_URL_SCHEME);
        if ($host === null || $scheme !== 'https') {
            return null;
        }

        $cert = null;
        try {
            $ctx = stream_context_create(['ssl' => ['capture_peer_cert' => true, 'verify_peer' => false, 'verify_peer_name' => false]]);
            $fp  = @stream_socket_client("ssl://{$host}:443", $errno, $errstr, 5, STREAM_CLIENT_CONNECT, $ctx);
            if ($fp !== false) {
                $params = stream_context_get_params($fp);
                $cert   = $params['options']['ssl']['peer_certificate'] ?? null;
                fclose($fp);
            }
        } catch (Throwable $e) {
            return null;
        }
        if ($cert === null) {
            return null; // tak bisa diperiksa (host tak terjangkau dari CLI, dll) — jangan menebak.
        }
        $info = openssl_x509_parse($cert);
        $exp  = $info['validTo_time_t'] ?? null;
        if ($exp === null) {
            return null;
        }
        $daysLeft = (int) floor(($exp - time()) / 86400);
        if ($daysLeft < 14) {
            CasaLog::log('CASA-E012', $daysLeft < 0 ? 'Sertifikat TLS SUDAH kedaluwarsa.' : "Sertifikat TLS tersisa {$daysLeft} hari.", null, null, $daysLeft < 0 ? 'error' : 'warning');

            return 'TLS mendekati kedaluwarsa';
        }

        return null;
    }
}
