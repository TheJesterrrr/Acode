<?php

declare(strict_types=1);

namespace App\Modules\EngineHealth\Database\Migrations;

use CodeIgniter\Database\Migration;

/**
 * Tabel `event_log` — log diagnostik ringkas berkode (CASA-Exxx), DIBATASI
 * 100 baris terakhir (CasaLog::log() menghapus baris tertua tiap insert
 * melewati batas). Tujuannya beda dari `task`/`cron_logs` (riwayat penuh,
 * tak boleh dihapus) — ini cuma jejak CEPAT buat "lagi ada masalah apa
 * sekarang", jadi aman dibatasi kecil tanpa pernah membebani disk.
 */
final class CreateEventLogTable extends Migration
{
    public function up(): void
    {
        $this->forge->addField([
            'id'         => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'code'       => ['type' => 'VARCHAR', 'constraint' => 20], // mis. CASA-E001
            'level'      => ['type' => 'VARCHAR', 'constraint' => 10, 'default' => 'error'], // error|warning|info
            'message'    => ['type' => 'VARCHAR', 'constraint' => 255],
            'mission_id' => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'null' => true],
            'task_id'    => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'null' => true],
            'created_at' => ['type' => 'TIMESTAMP', 'default' => new \CodeIgniter\Database\RawSql('CURRENT_TIMESTAMP')],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey('code');
        $this->forge->createTable('event_log', true, ['ENGINE' => 'InnoDB', 'DEFAULT CHARSET' => 'utf8mb4', 'COLLATE' => 'utf8mb4_unicode_ci']);
    }

    public function down(): void
    {
        $this->forge->dropTable('event_log', true);
    }
}
