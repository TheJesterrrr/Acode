<?php

declare(strict_types=1);

namespace App\Modules\EngineHealth\Controllers;

use App\Controllers\BaseController;
use App\Modules\EngineHealth\Services\EngineHealthService;
use App\Modules\Setting\Services\SettingService;
use CodeIgniter\HTTP\ResponseInterface;

/** EngineHealthController — kondisi mesin scan (admin). */
final class EngineHealthController extends BaseController
{
    /** Pilihan interval (menit) yang diizinkan dari GUI — jaga agar tak terlalu sering (beban server) atau terlalu longgar (telat ketahuan). */
    private const INTERVAL_CHOICES = [5, 15, 30, 60];

    public function __construct(
        private readonly EngineHealthService $svc = new EngineHealthService(),
        private readonly SettingService $settings = new SettingService(),
    ) {
    }

    public function index(): string
    {
        return $this->adminView('App\Modules\EngineHealth\Views\index', [
            'title' => 'Engine Health',
            's'     => $this->svc->status(),
        ], 'engine');
    }

    /** Simpan on/off + interval audit infrastruktur terjadwal (CASA-E000, lihat InfraAuditJob). */
    public function saveAudit(): ResponseInterface
    {
        $enabled  = $this->request->getPost('enabled') === '1';
        $interval = (int) $this->request->getPost('interval');
        if (! in_array($interval, self::INTERVAL_CHOICES, true)) {
            $interval = 15;
        }

        $this->settings->set('event_audit_enabled', $enabled ? '1' : '0');
        $this->settings->set('event_audit_interval_min', (string) $interval);

        return $this->ok(['message' => $enabled ? "Audit infrastruktur AKTIF tiap {$interval} menit." : 'Audit infrastruktur dimatikan — hanya mendeteksi event saat scan.']);
    }
}
