<?php

declare(strict_types=1);

use CodeIgniter\Router\RouteCollection;

/** Rute Engine Health (admin). */

/** @var RouteCollection $routes */
$routes->group('casaadmin/engine', ['namespace' => 'App\Modules\EngineHealth\Controllers', 'filter' => 'admin'], static function (RouteCollection $routes): void {
    $routes->get('', 'EngineHealthController::index');
    $routes->post('audit', 'EngineHealthController::saveAudit', ['filter' => 'audit:ENGINE_AUDIT_UPDATE']);
});
