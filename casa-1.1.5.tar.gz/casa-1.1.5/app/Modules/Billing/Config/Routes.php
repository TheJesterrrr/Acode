<?php

declare(strict_types=1);

use CodeIgniter\Router\RouteCollection;

/** Rute Billing — portal langganan/koin (member, di console owner) + webhook. */

/** @var RouteCollection $routes */
$routes->group('billing', ['namespace' => 'App\Modules\Billing\Controllers', 'filter' => 'member'], static function (RouteCollection $routes): void {
    $routes->get('', 'BillingController::index');
    $routes->post('topup', 'BillingController::topup', ['filter' => 'audit:BILLING_TOPUP']);
    $routes->post('subscribe', 'BillingController::subscribe', ['filter' => 'audit:BILLING_SUBSCRIBE']);
    $routes->get('key/(:num)', 'BillingController::key/$1');
});

/** Download App — hub casamember menyajikan paket installer (owner-console). */
$routes->group('download', ['namespace' => 'App\Modules\Billing\Controllers', 'filter' => 'member'], static function (RouteCollection $routes): void {
    $routes->get('', 'DownloadController::index');
    $routes->get('installer/(:segment)', 'DownloadController::installer/$1');
});

/** Kelola Rilis — konsol OWNER (casaadmin) mengunggah/menghapus paket rilis. */
$routes->group('casaadmin/releases', ['namespace' => 'App\Modules\Billing\Controllers', 'filter' => 'admin'], static function (RouteCollection $routes): void {
    $routes->get('', 'AdminReleaseController::index');
    $routes->post('upload', 'AdminReleaseController::upload', ['filter' => 'audit:RELEASE_UPLOAD']);
    $routes->post('delete', 'AdminReleaseController::delete', ['filter' => 'audit:RELEASE_DELETE']);
});

/** Webhook Mayar (public, api/* bebas CSRF). */
$routes->post('api/mayar/webhook', '\App\Modules\Billing\Controllers\MayarWebhookController::receive');

/** Rilis komunitas PUBLIK — landing menarik versi/sha & unduh dari sini (auto-sync). */
$routes->get('api/community/latest', '\App\Modules\Billing\Controllers\CommunityDownloadController::latest');
$routes->get('api/community/download', '\App\Modules\Billing\Controllers\CommunityDownloadController::download');
