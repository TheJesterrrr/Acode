<?php

declare(strict_types=1);

namespace App\Modules\Billing\Config;

use CodeIgniter\Config\BaseConfig;

/**
 * Pricing — harga langganan dalam KOIN (1 koin = Rp 1, konvensi CoreNet).
 * Kunci: tier => [bulan => koin]. Owner dapat menyetel di sini. Durasi yang
 * ditawarkan: 1/3/6/12 bulan untuk Pro & Enterprise (Community gratis, tanpa key).
 */
class Pricing extends BaseConfig
{
    /** @var array<string,array<int,int>> tier => (months => coins) */
    public array $plans = [
        'pro' => [
            1  => 150000,
            3  => 405000,   // ~10% hemat
            6  => 765000,   // ~15% hemat
            12 => 1440000,  // ~20% hemat
        ],
        'enterprise' => [
            1  => 500000,
            3  => 1350000,
            6  => 2550000,
            12 => 4800000,
        ],
    ];

    /** Durasi yang ditawarkan (bulan). */
    public array $durations = [1, 3, 6, 12];

    /** Biaya koin untuk tier+bulan, atau null bila tak valid. */
    public function cost(string $tier, int $months): ?int
    {
        return $this->plans[$tier][$months] ?? null;
    }

    /** @return array<string,array<string,mixed>> tier meta untuk UI */
    public function tiersMeta(): array
    {
        return [
            'pro'        => ['label' => 'Professional', 'color' => 'info'],
            'enterprise' => ['label' => 'Enterprise', 'color' => 'warning'],
        ];
    }
}
