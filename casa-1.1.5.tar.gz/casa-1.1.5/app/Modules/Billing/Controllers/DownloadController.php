<?php

declare(strict_types=1);

namespace App\Modules\Billing\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\Exceptions\PageNotFoundException;
use CodeIgniter\HTTP\ResponseInterface;

/**
 * DownloadController — halaman "Download App" di hub casamember (console owner).
 * Pelanggan yang login mengunduh paket installer CASA untuk dipasang di VPS-nya,
 * lalu mengaktivasi lisensi dari menu Langganan & Koin.
 *
 * Gated owner-console: hanya ada di server owner (punya private key). Di instance
 * produk pelanggan menu ini tak relevan (aplikasinya sudah terpasang) → 404.
 *
 * Berkas rilis diletakkan owner di writable/releases/ (di luar webroot). File
 * di-stream lewat controller ber-auth, BUKAN tautan statis publik.
 */
final class DownloadController extends BaseController
{
    private function releasesDir(): string
    {
        return rtrim(WRITEPATH, '/\\') . DIRECTORY_SEPARATOR . 'releases';
    }

    private function guard(): void
    {
        if ((string) (env('license.privateKey') ?: '') === '') {
            throw PageNotFoundException::forPageNotFound();
        }
    }

    /** Pola nama berkas rilis yang diizinkan (anti path-traversal). */
    private const NAME_RE = '/^casa-[A-Za-z0-9._-]+\.(tar\.gz|zip|exe)$/';

    /** Klasifikasi jenis paket dari nama berkas → {kind,label,icon}. */
    private function classify(string $name): array
    {
        if (str_ends_with($name, '.exe')) {
            return ['kind' => 'windows', 'label' => 'Windows (1-click)', 'icon' => 'bi-windows'];
        }
        if (str_contains($name, 'docker') && str_ends_with($name, '.zip')) {
            return ['kind' => 'docker', 'label' => 'Docker (Win/Mac/Linux)', 'icon' => 'bi-box-seam'];
        }
        if (str_ends_with($name, '.tar.gz')) {
            return ['kind' => 'vps', 'label' => 'VPS / Linux (native)', 'icon' => 'bi-hdd-stack'];
        }

        return ['kind' => 'other', 'label' => 'Package', 'icon' => 'bi-box'];
    }

    /** Daftar rilis yang tersedia (terbaru dulu). */
    public function index(): string
    {
        $this->guard();

        $releases = [];
        $dir      = $this->releasesDir();
        if (is_dir($dir)) {
            foreach (glob($dir . DIRECTORY_SEPARATOR . 'casa-*') ?: [] as $path) {
                $name = basename($path);
                if (! is_file($path) || ! preg_match(self::NAME_RE, $name)) {
                    continue;
                }
                $releases[] = [
                    'file'    => $name,
                    'version' => preg_match('/(\d+\.\d+\.\d+)/', $name, $m) ? $m[1] : '—',
                    'size'    => (int) (filesize($path) ?: 0),
                    'sha256'  => (string) (hash_file('sha256', $path) ?: ''),
                    'mtime'   => (int) (filemtime($path) ?: 0),
                ] + $this->classify($name);
            }
            usort($releases, static fn (array $a, array $b): int => $b['mtime'] <=> $a['mtime']);
        }

        return $this->memberView('App\Modules\Billing\Views\download', [
            'title'    => 'Download App',
            'releases' => $releases,
        ], 'download');
    }

    /** Stream berkas installer (validasi nama ketat → cegah path traversal). */
    public function installer(string $file): ResponseInterface
    {
        $this->guard();

        if (! preg_match(self::NAME_RE, $file)) {
            return $this->response->setStatusCode(404)->setBody('Berkas tidak valid.');
        }
        $path = $this->releasesDir() . DIRECTORY_SEPARATOR . $file;
        if (! is_file($path)) {
            return $this->response->setStatusCode(404)->setBody('Rilis tidak ditemukan.');
        }

        return $this->response->download($path, null)->setFileName($file);
    }
}
