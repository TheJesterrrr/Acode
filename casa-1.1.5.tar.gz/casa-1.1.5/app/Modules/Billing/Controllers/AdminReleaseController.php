<?php

declare(strict_types=1);

namespace App\Modules\Billing\Controllers;

use App\Controllers\BaseController;
use App\Libraries\Cer;
use CodeIgniter\HTTP\ResponseInterface;

/**
 * AdminReleaseController — kelola RILIS aplikasi dari konsol OWNER (casaadmin).
 *
 * Satu folder, dua arah: berkas diunggah ke writable/releases/ (di luar webroot),
 * lalu dibaca OTOMATIS oleh (a) DownloadController "Download App" di casamember dan
 * (b) InstanceSyncService/ReleaseRegistry yang memberi tahu instance pelanggan ada
 * update. Jadi owner cukup unggah di sini → casamember & pelanggan langsung ikut,
 * tanpa FTP. Setiap unggahan otomatis dibuatkan sidecar .sha256 yang dipakai
 * `casa:apply-update` memverifikasi paket di sisi instance.
 *
 * Gated: hanya berarti di server owner (punya license.privateKey); di instance
 * produk pelanggan menu ini tak relevan.
 */
final class AdminReleaseController extends BaseController
{
    /** Pola nama berkas rilis (anti path-traversal) — sama dgn DownloadController/ReleaseRegistry. */
    private const NAME_RE = '/^casa-[A-Za-z0-9._-]+\.(tar\.gz|zip|exe)$/';

    /** Batas ukuran unggah (byte). Paket VPS penuh ~6 MB; longgar utk docker/exe. */
    private const MAX_BYTES = 200 * 1024 * 1024;

    private function releasesDir(): string
    {
        return rtrim(WRITEPATH, '/\\') . DIRECTORY_SEPARATOR . 'releases';
    }

    private function guardOwner(): void
    {
        if ((string) (env('license.privateKey') ?: '') === '') {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
    }

    private function back(): ResponseInterface
    {
        return redirect()->to(Cer::adminUrl() . 'casaadmin/releases');
    }

    private function classify(string $name): array
    {
        if (str_ends_with($name, '.exe')) {
            return ['kind' => 'windows', 'label' => 'Windows (1-click)', 'icon' => 'bi-windows'];
        }
        if (str_contains($name, 'docker') && str_ends_with($name, '.zip')) {
            return ['kind' => 'docker', 'label' => 'Docker', 'icon' => 'bi-box-seam'];
        }
        if (str_ends_with($name, '.tar.gz')) {
            return ['kind' => 'vps', 'label' => 'VPS / Linux', 'icon' => 'bi-hdd-stack'];
        }

        return ['kind' => 'other', 'label' => 'Package', 'icon' => 'bi-box'];
    }

    public function index(): string
    {
        $this->guardOwner();

        $dir       = $this->releasesDir();
        $releases  = [];
        $latestVer = '0.0.0';
        if (is_dir($dir)) {
            foreach (glob($dir . DIRECTORY_SEPARATOR . 'casa-*') ?: [] as $path) {
                $name = basename($path);
                if (! is_file($path) || ! preg_match(self::NAME_RE, $name)) {
                    continue; // lewati sidecar .sha256/.notes.md & nama tak sah
                }
                $ver   = preg_match('/(\d+\.\d+\.\d+)/', $name, $m) ? $m[1] : '—';
                $notes = $path . '.notes.md';
                $releases[] = [
                    'file'    => $name,
                    'version' => $ver,
                    'size'    => (int) (filesize($path) ?: 0),
                    'sha256'  => (string) (hash_file('sha256', $path) ?: ''),
                    'mtime'   => (int) (filemtime($path) ?: 0),
                    'notes'   => is_file($notes) ? (string) file_get_contents($notes) : '',
                ] + $this->classify($name);
                if (str_ends_with($name, '.tar.gz') && $ver !== '—' && version_compare($ver, $latestVer, '>')) {
                    $latestVer = $ver;
                }
            }
            usort($releases, static fn (array $a, array $b): int => $b['mtime'] <=> $a['mtime']);
        }

        return $this->adminView('App\Modules\Billing\Views\admin_releases', [
            'title'     => 'Rilis Aplikasi',
            'releases'  => $releases,
            'latestVer' => $latestVer === '0.0.0' ? '' : $latestVer,
        ], 'releases');
    }

    public function upload(): ResponseInterface
    {
        $this->guardOwner();

        $file = $this->request->getFile('package');
        if ($file === null || ! $file->isValid()) {
            return $this->back()->with('flash_error', 'Berkas tidak valid atau gagal diunggah (cek batas upload PHP).');
        }
        if ($file->getSize() > self::MAX_BYTES) {
            return $this->back()->with('flash_error', 'Berkas melebihi batas ' . (self::MAX_BYTES / 1024 / 1024) . ' MB.');
        }
        // Nama dari sisi klien WAJIB cocok pola rilis — baru dipakai sbg nama simpan.
        $name = basename((string) $file->getClientName());
        if (! preg_match(self::NAME_RE, $name)) {
            return $this->back()->with('flash_error', 'Nama berkas harus seperti casa-1.2.3.tar.gz / .zip / .exe.');
        }

        $dir = $this->releasesDir();
        if (! is_dir($dir) && ! @mkdir($dir, 0770, true)) {
            return $this->back()->with('flash_error', 'Tak dapat membuat folder releases.');
        }

        try {
            $file->move($dir, $name, true); // overwrite bila nama sama
        } catch (\Throwable $e) {
            return $this->back()->with('flash_error', 'Gagal menyimpan berkas: ' . $e->getMessage());
        }

        $path = $dir . DIRECTORY_SEPARATOR . $name;
        $sha  = (string) (hash_file('sha256', $path) ?: '');
        @file_put_contents($path . '.sha256', $sha . '  ' . $name . "\n");

        $notes = trim((string) $this->request->getPost('notes'));
        if ($notes !== '') {
            @file_put_contents($path . '.notes.md', $notes);
        } else {
            @unlink($path . '.notes.md');
        }

        \App\Libraries\CasaLog::log('CASA-I100', "Rilis diunggah owner: {$name} (sha256 {$sha})", null, null, 'info');

        return $this->back()->with('flash_success', "Rilis {$name} terunggah. casamember & instance pelanggan akan melihatnya otomatis. sha256: {$sha}");
    }

    public function delete(): ResponseInterface
    {
        $this->guardOwner();

        $name = basename((string) $this->request->getPost('file'));
        if (! preg_match(self::NAME_RE, $name)) {
            return $this->back()->with('flash_error', 'Nama berkas tidak sah.');
        }
        $path = $this->releasesDir() . DIRECTORY_SEPARATOR . $name;
        if (! is_file($path)) {
            return $this->back()->with('flash_error', 'Rilis tidak ditemukan.');
        }
        @unlink($path);
        @unlink($path . '.sha256');
        @unlink($path . '.notes.md');

        return $this->back()->with('flash_success', "Rilis {$name} dihapus.");
    }
}
