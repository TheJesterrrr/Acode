<?php

declare(strict_types=1);

namespace App\Modules\Billing\Controllers;

use App\Controllers\BaseController;
use App\Modules\Billing\Config\Pricing;
use App\Modules\Billing\Models\CoinPackageModel;
use App\Modules\Billing\Services\SubscriptionService;
use App\Modules\Billing\Services\TopupService;
use App\Modules\Billing\Services\WalletService;
use CodeIgniter\HTTP\ResponseInterface;
use RuntimeException;

/**
 * BillingController — portal langganan & koin untuk pelanggan (HANYA di console
 * owner). Self-service: topup koin (Mayar) → langganan (potong koin → license key)
 * → unduh key untuk diaktivasi di instance. Gated owner-console.
 */
final class BillingController extends BaseController
{
    public function __construct(
        private readonly WalletService $wallet = new WalletService(),
        private readonly TopupService $topup = new TopupService(),
        private readonly SubscriptionService $subs = new SubscriptionService(),
        private readonly CoinPackageModel $packages = new CoinPackageModel(),
    ) {
    }

    private function me(): int
    {
        return (int) $this->session->get('member_id');
    }

    private function guard(): void
    {
        // Billing hanya ada di console owner (butuh private key utk terbitkan key).
        if ((string) (env('license.privateKey') ?: '') === '') {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
    }

    public function index(): string
    {
        $this->guard();
        $pricing = config(Pricing::class);

        return $this->memberView('App\Modules\Billing\Views\index', [
            'title'     => 'Langganan & Koin',
            'balance'   => $this->wallet->balance($this->me()),
            'packages'  => $this->packages->active(),
            'plans'     => $pricing->plans,
            'durations' => $pricing->durations,
            'meta'      => $pricing->tiersMeta(),
            'subs'      => $this->subs->forCustomer($this->me()),
            'history'   => $this->wallet->history($this->me()),
        ], 'billing');
    }

    public function topup(): ResponseInterface
    {
        $this->guard();
        if ($r = $this->denyViewer()) {
            return $r;
        }
        try {
            $res = $this->topup->start($this->me(), (int) $this->request->getPost('package_id'));
        } catch (RuntimeException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok(['link' => $res['link'], 'pending' => $res['link'] === null]);
    }

    public function subscribe(): ResponseInterface
    {
        $this->guard();
        if ($r = $this->denyViewer()) {
            return $r;
        }
        try {
            $sub = $this->subs->subscribeWithCoin($this->me(), (string) $this->request->getPost('tier'), (int) $this->request->getPost('months'));
        } catch (RuntimeException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok(['sub_id' => $sub['id'], 'tier' => $sub['tier'], 'exp' => $sub['expires_at']]);
    }

    /** Unduh license key sebuah langganan (milik sendiri). */
    public function key(int $id): ResponseInterface
    {
        $this->guard();
        $sub = (new \App\Modules\Billing\Models\SubscriptionModel())->find($id);
        if ($sub === null || (int) $sub['customer_id'] !== $this->me()) {
            return $this->response->setStatusCode(404)->setBody('Tidak ditemukan.');
        }

        return $this->response
            ->setHeader('Content-Type', 'text/plain; charset=UTF-8')
            ->setHeader('Content-Disposition', 'attachment; filename="casa-license-' . $sub['license_id'] . '.key"')
            ->setBody((string) $sub['license_token']);
    }
}
