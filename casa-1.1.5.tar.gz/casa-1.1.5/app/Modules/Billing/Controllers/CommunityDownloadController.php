<?php

declare(strict_types=1);

namespace App\Modules\Billing\Controllers;

use App\Controllers\BaseController;
use App\Libraries\ReleaseRegistry;
use CodeIgniter\HTTP\ResponseInterface;

/**
 * CommunityDownloadController — endpoint PUBLIK (tanpa login) agar landing publik
 * `casa.corenet.web.id` menarik rilis terbaru langsung dari hub, bukan menyimpan
 * salinan file sendiri. Sumbernya folder rilis yang sama (`writable/releases/`)
 * yang diisi owner lewat casaadmin → "Rilis Aplikasi". Jadi SEKALI unggah di
 * casaadmin, landing + casamember + instance semuanya ikut otomatis.
 *
 * Paket komunitas memang sudah dimaksudkan publik (landing lama pun menyajikannya
 * sebagai unduhan statis), jadi tak ada ekspos baru. Hanya rilis .tar.gz versi
 * TERTINGGI yang disajikan; tak ada parameter nama berkas (anti path-traversal).
 */
final class CommunityDownloadController extends BaseController
{
    /** Metadata rilis terbaru (JSON) untuk mengisi versi/sha/ukuran di landing. */
    public function latest(): ResponseInterface
    {
        $l   = ReleaseRegistry::latestVps();
        $out = $l ?? ['version' => null, 'file' => null, 'size' => 0, 'sha256' => null];

        return $this->response
            ->setHeader('Access-Control-Allow-Origin', '*') // dibaca lintas-origin oleh landing
            ->setHeader('Cache-Control', 'public, max-age=300')
            ->setJSON($out);
    }

    /** Stream paket rilis .tar.gz terbaru; nama berkas konsisten casa-X.Y.Z.tar.gz. */
    public function download(): ResponseInterface
    {
        $l = ReleaseRegistry::latestVps();
        if ($l === null) {
            return $this->response->setStatusCode(404)->setBody('Belum ada rilis.');
        }
        $path = ReleaseRegistry::path((string) $l['file']);
        if ($path === null) {
            return $this->response->setStatusCode(404)->setBody('Rilis tidak ditemukan.');
        }

        return $this->response->download($path, null)->setFileName((string) $l['file']);
    }
}
