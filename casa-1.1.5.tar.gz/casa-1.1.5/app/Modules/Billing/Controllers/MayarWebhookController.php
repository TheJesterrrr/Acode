<?php

declare(strict_types=1);

namespace App\Modules\Billing\Controllers;

use App\Controllers\BaseController;
use App\Modules\Billing\Services\MayarService;
use App\Modules\Billing\Services\TopupService;
use CodeIgniter\HTTP\ResponseInterface;

/**
 * MayarWebhookController — penerima webhook Mayar (public, api/* bebas CSRF).
 * Webhook hanya PEMICU: TopupService re-verifikasi ke API Mayar sebelum kredit
 * koin (anti-manipulasi). Idempoten.
 */
final class MayarWebhookController extends BaseController
{
    public function receive(): ResponseInterface
    {
        $raw     = (string) $this->request->getBody();
        $sig     = (string) ($this->request->getHeaderLine('X-Signature') ?: $this->request->getHeaderLine('x-mayar-signature'));
        $mayar   = new MayarService();
        if (! $mayar->verifySignature($raw, $sig)) {
            return $this->response->setStatusCode(401)->setJSON(['ok' => false]);
        }
        $p   = json_decode($raw, true);
        $ref = '';
        if (is_array($p)) {
            $ref = (string) ($p['data']['transactionId'] ?? $p['transactionId'] ?? $p['data']['id'] ?? '');
        }
        $credited = $ref !== '' ? (new TopupService())->confirmByRef($ref) : false;

        return $this->response->setJSON(['ok' => true, 'credited' => $credited]);
    }
}
