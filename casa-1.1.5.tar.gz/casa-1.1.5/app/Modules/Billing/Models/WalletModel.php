<?php
declare(strict_types=1);
namespace App\Modules\Billing\Models;
use CodeIgniter\Model;
/** WalletModel — saldo koin per pelanggan (`wallet`). */
final class WalletModel extends Model
{
    protected $table = 'wallet';
    protected $primaryKey = 'id';
    protected $returnType = 'array';
    protected $useTimestamps = true;
    protected $allowedFields = ['customer_id', 'balance'];
    public function forCustomer(int $cid): ?array { return $this->where('customer_id', $cid)->first(); }
}
