<?php
declare(strict_types=1);
namespace App\Modules\Billing\Models;
use CodeIgniter\Model;
/** WalletTransactionModel — mutasi koin (`wallet_transaction`). */
final class WalletTransactionModel extends Model
{
    protected $table = 'wallet_transaction';
    protected $primaryKey = 'id';
    protected $returnType = 'array';
    protected $useTimestamps = true;
    protected $updatedField = '';
    protected $allowedFields = ['customer_id', 'type', 'amount', 'balance_after', 'ref', 'note'];
    public function forCustomer(int $cid, int $limit = 30): array { return $this->where('customer_id', $cid)->orderBy('id', 'DESC')->findAll($limit); }
}
