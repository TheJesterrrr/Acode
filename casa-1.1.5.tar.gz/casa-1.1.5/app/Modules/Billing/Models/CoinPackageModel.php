<?php
declare(strict_types=1);
namespace App\Modules\Billing\Models;
use CodeIgniter\Model;
/** CoinPackageModel — paket topup koin (`coin_package`). */
final class CoinPackageModel extends Model
{
    protected $table = 'coin_package';
    protected $primaryKey = 'id';
    protected $returnType = 'array';
    protected $useTimestamps = false;
    protected $allowedFields = ['label', 'price_rp', 'coin_amount', 'bonus_coin', 'is_active', 'sort_order'];
    public function active(): array { return $this->where('is_active', 1)->orderBy('sort_order', 'ASC')->findAll(); }
}
