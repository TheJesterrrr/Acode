<?php
declare(strict_types=1);
namespace App\Modules\Billing\Models;
use CodeIgniter\Model;
/** SubscriptionModel — riwayat langganan + license key (`subscription`). */
final class SubscriptionModel extends Model
{
    protected $table = 'subscription';
    protected $primaryKey = 'id';
    protected $returnType = 'array';
    protected $useTimestamps = true;
    protected $updatedField = '';
    protected $allowedFields = ['customer_id', 'tier', 'months', 'coins_spent', 'method', 'license_id', 'license_token', 'starts_at', 'expires_at', 'status'];
    public function forCustomer(int $cid): array { return $this->where('customer_id', $cid)->orderBy('id', 'DESC')->findAll(50); }
    public function activeFor(int $cid): ?array { return $this->where('customer_id', $cid)->where('status', 'active')->orderBy('id', 'DESC')->first(); }
}
