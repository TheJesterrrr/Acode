<?php
declare(strict_types=1);
namespace App\Modules\Billing\Models;
use CodeIgniter\Model;
/** TopupOrderModel — order topup koin via gateway (`topup_order`). */
final class TopupOrderModel extends Model
{
    protected $table = 'topup_order';
    protected $primaryKey = 'id';
    protected $returnType = 'array';
    protected $useTimestamps = true;
    protected $updatedField = '';
    protected $allowedFields = ['customer_id', 'package_id', 'coins', 'price_rp', 'gateway', 'gateway_ref', 'status', 'paid_at'];
    public function byRef(string $ref): ?array { return $this->where('gateway_ref', $ref)->first(); }
}
