<?php

declare(strict_types=1);

namespace App\Modules\Billing\Services;

use App\Modules\Billing\Models\WalletModel;
use App\Modules\Billing\Models\WalletTransactionModel;
use Config\Database;
use RuntimeException;

/**
 * WalletService — saldo koin (server owner). Kredit hanya dari sumber tepercaya
 * (topup terverifikasi Mayar, hibah admin). Debit untuk langganan. Atomik + catat
 * mutasi. Saldo TIDAK PERNAH diubah dari input member langsung.
 */
final class WalletService
{
    public function __construct(
        private readonly WalletModel $wallets = new WalletModel(),
        private readonly WalletTransactionModel $tx = new WalletTransactionModel(),
    ) {
    }

    public function balance(int $customerId): int
    {
        $w = $this->wallets->forCustomer($customerId);

        return $w !== null ? (int) $w['balance'] : 0;
    }

    /** Tambah koin (topup/grant/refund). @return int saldo baru */
    public function credit(int $customerId, int $amount, string $type, ?string $ref = null, ?string $note = null): int
    {
        if ($amount <= 0) {
            throw new RuntimeException('Jumlah kredit harus > 0.');
        }

        return $this->apply($customerId, $amount, $type, $ref, $note);
    }

    /** Kurangi koin (spend). @throws RuntimeException bila saldo kurang */
    public function debit(int $customerId, int $amount, string $type, ?string $ref = null, ?string $note = null): int
    {
        if ($amount <= 0) {
            throw new RuntimeException('Jumlah debit harus > 0.');
        }
        if ($this->balance($customerId) < $amount) {
            throw new RuntimeException('Saldo koin tidak cukup. Silakan topup dulu.');
        }

        return $this->apply($customerId, -$amount, $type, $ref, $note);
    }

    /** @return array<int,array<string,mixed>> mutasi terbaru */
    public function history(int $customerId): array
    {
        return $this->tx->forCustomer($customerId);
    }

    private function apply(int $customerId, int $delta, string $type, ?string $ref, ?string $note): int
    {
        $db = Database::connect();
        $db->transException(true);
        $db->transStart();

        $w = $this->wallets->forCustomer($customerId);
        if ($w === null) {
            $this->wallets->insert(['customer_id' => $customerId, 'balance' => 0]);
            $w = $this->wallets->forCustomer($customerId);
        }
        $after = (int) $w['balance'] + $delta;
        if ($after < 0) {
            throw new RuntimeException('Saldo tidak cukup.');
        }
        $this->wallets->update((int) $w['id'], ['balance' => $after]);
        $this->tx->insert([
            'customer_id'   => $customerId,
            'type'          => $type,
            'amount'        => $delta,
            'balance_after' => $after,
            'ref'           => $ref,
            'note'          => $note,
        ]);

        $db->transComplete();

        return $after;
    }
}
