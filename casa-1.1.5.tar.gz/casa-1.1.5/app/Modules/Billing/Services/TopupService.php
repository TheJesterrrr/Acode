<?php

declare(strict_types=1);

namespace App\Modules\Billing\Services;

use App\Modules\Auth\Models\CustomerModel;
use App\Modules\Billing\Models\CoinPackageModel;
use App\Modules\Billing\Models\TopupOrderModel;
use RuntimeException;

/**
 * TopupService — beli koin. Buat order → invoice Mayar → member bayar → webhook/
 * konfirmasi → RE-VERIFIKASI via API → kredit koin (idempoten, sekali saja).
 */
final class TopupService
{
    public function __construct(
        private readonly TopupOrderModel $orders = new TopupOrderModel(),
        private readonly CoinPackageModel $packages = new CoinPackageModel(),
        private readonly WalletService $wallet = new WalletService(),
        private readonly MayarService $mayar = new MayarService(),
        private readonly CustomerModel $customers = new CustomerModel(),
    ) {
    }

    /**
     * Mulai topup. @return array{order:array,link:?string}
     * @throws RuntimeException
     */
    public function start(int $customerId, int $packageId): array
    {
        $pkg = $this->packages->find($packageId);
        if ($pkg === null || (int) $pkg['is_active'] !== 1) {
            throw new RuntimeException('Paket koin tidak tersedia.');
        }
        $coins = (int) $pkg['coin_amount'] + (int) $pkg['bonus_coin'];
        $id    = (int) $this->orders->insert([
            'customer_id' => $customerId,
            'package_id'  => $packageId,
            'coins'       => $coins,
            'price_rp'    => (int) $pkg['price_rp'],
            'gateway'     => 'mayar',
            'status'      => 'pending',
        ], true);

        $link = null;
        if ($this->mayar->active()) {
            $cust = $this->customers->find($customerId);
            $inv  = $this->mayar->createInvoice([
                'name'        => (string) ($cust['name'] ?? 'Pelanggan'),
                'email'       => (string) ($cust['email'] ?? 'noreply@casa.local'),
                'mobile'      => (string) ($cust['phone'] ?? '08000000000'),
                'amount'      => (int) $pkg['price_rp'],
                'description' => 'Topup ' . $pkg['label'] . ' (CASA)',
            ]);
            if ($inv !== null) {
                $this->orders->update($id, ['gateway_ref' => $inv['ref']]);
                $link = $inv['link'];
            }
        }

        return ['order' => $this->orders->find($id), 'link' => $link];
    }

    /**
     * Konfirmasi pembayaran (dipanggil webhook / polling). Kredit sekali saja
     * SETELAH re-verifikasi ke Mayar. @return bool ter-kredit
     */
    public function confirmByRef(string $ref): bool
    {
        $order = $this->orders->byRef($ref);
        if ($order === null || $order['status'] === 'paid') {
            return false; // tak ada / sudah dikredit (idempoten)
        }
        if (! $this->mayar->isPaid($ref)) {
            return false; // Mayar belum konfirmasi bayar
        }
        $this->orders->update((int) $order['id'], ['status' => 'paid', 'paid_at' => date('Y-m-d H:i:s')]);
        $this->wallet->credit((int) $order['customer_id'], (int) $order['coins'], 'topup', $ref, 'Topup koin');

        return true;
    }

    /** Hibah koin manual oleh OWNER (mis. uji / kompensasi). */
    public function grantManual(int $customerId, int $coins, string $note = 'Hibah admin'): int
    {
        return $this->wallet->credit($customerId, $coins, 'grant', 'admin', $note);
    }
}
