<?php

declare(strict_types=1);

namespace App\Modules\Billing\Services;

use Config\Services;
use Throwable;

/**
 * MayarService — gateway pembayaran Mayar.id (topup koin). Kunci anti-manipulasi:
 * isi webhook TIDAK dipercaya; sebelum kredit koin, server RE-KONFIRMASI status
 * pembayaran via API Mayar (isPaid). Konfigurasi via .env: mayar.apiKey,
 * mayar.webhookSecret, mayar.baseUrl. (Butuh kunci nyata untuk transaksi live.)
 */
final class MayarService
{
    private const BASE_DEFAULT = 'https://api.mayar.id';

    public function active(): bool
    {
        return $this->apiKey() !== '';
    }

    private function apiKey(): string
    {
        return trim((string) (env('mayar.apiKey') ?: ''));
    }

    public function webhookSecret(): string
    {
        return trim((string) (env('mayar.webhookSecret') ?: ''));
    }

    private function baseUrl(): string
    {
        return rtrim((string) (env('mayar.baseUrl') ?: self::BASE_DEFAULT), '/');
    }

    /**
     * Terbitkan invoice. @return array{link:string,ref:string}|null
     * @param array{name:string,email:string,amount:int,description:string,mobile?:string} $p
     */
    public function createInvoice(array $p): ?array
    {
        if (! $this->active()) {
            return null;
        }
        $body = [
            'name'        => $p['name'],
            'email'       => $p['email'],
            'mobile'      => $p['mobile'] ?? '08000000000',
            'amount'      => (int) $p['amount'],
            'description' => $p['description'],
            'items'       => [['description' => $p['description'], 'quantity' => 1, 'rate' => (int) $p['amount']]],
        ];
        $res = $this->call('POST', '/hl/v2/invoices/create', $body);
        $link = $res['data']['link'] ?? ($res['data']['url'] ?? null);
        $ref  = $res['data']['transactionId'] ?? ($res['data']['id'] ?? null);
        if (! $link || ! $ref) {
            return null;
        }

        return ['link' => (string) $link, 'ref' => (string) $ref];
    }

    /** Re-konfirmasi pembayaran via API (JANGAN percaya webhook saja). */
    public function isPaid(string $ref): bool
    {
        if (! $this->active() || $ref === '') {
            return false;
        }
        $res    = $this->call('GET', '/hl/v2/transactions/' . rawurlencode($ref));
        $status = strtolower((string) ($res['data']['status'] ?? ''));

        return in_array($status, ['success', 'paid', 'settled'], true);
    }

    /** Verifikasi tanda tangan webhook (bila secret dikonfigurasi). */
    public function verifySignature(string $rawBody, string $signature): bool
    {
        $secret = $this->webhookSecret();
        if ($secret === '') {
            return true; // tanpa secret, andalkan isPaid()
        }

        return hash_equals(hash_hmac('sha256', $rawBody, $secret), $signature);
    }

    /** @return array<string,mixed> */
    private function call(string $method, string $path, array $body = []): array
    {
        try {
            $client = Services::curlrequest(['timeout' => 15, 'http_errors' => false], null, null, false);
            $opts   = ['headers' => ['Authorization' => 'Bearer ' . $this->apiKey(), 'Content-Type' => 'application/json', 'Accept' => 'application/json']];
            if ($body !== []) {
                $opts['body'] = json_encode($body);
            }
            $res = $client->request($method, $this->baseUrl() . $path, $opts);
            $j   = json_decode((string) $res->getBody(), true);

            return is_array($j) ? $j : [];
        } catch (Throwable $e) {
            log_message('error', 'Mayar call gagal: ' . $e->getMessage());

            return [];
        }
    }
}
