<?php

declare(strict_types=1);

namespace App\Modules\Billing\Services;

use App\Modules\Billing\Config\Pricing;
use App\Modules\Billing\Models\SubscriptionModel;
use App\Modules\Licensing\Services\LicenseKeyService;
use App\Modules\Auth\Models\CustomerModel;
use RuntimeException;

/**
 * SubscriptionService — langganan (server owner). Self-service: potong koin →
 * terbitkan license key ter-tanda-tangani (LicenseKeyService) dengan masa sesuai
 * durasi. Manual: owner menerbitkan tanpa koin. Member lalu mengunduh key untuk
 * diaktivasi di instance-nya. Tak bisa dimanipulasi member (key ditandatangani owner).
 */
final class SubscriptionService
{
    public function __construct(
        private readonly SubscriptionModel $subs = new SubscriptionModel(),
        private readonly WalletService $wallet = new WalletService(),
        private readonly LicenseKeyService $keys = new LicenseKeyService(),
        private readonly CustomerModel $customers = new CustomerModel(),
        private readonly ?Pricing $pricing = null,
    ) {
    }

    private function price(): Pricing
    {
        return $this->pricing ?? config(Pricing::class);
    }

    /**
     * Langganan self-service dengan koin. @return array subscription tersimpan.
     * @throws RuntimeException
     */
    public function subscribeWithCoin(int $customerId, string $tier, int $months): array
    {
        $cost = $this->price()->cost($tier, $months);
        if ($cost === null) {
            throw new RuntimeException('Paket/durasi tidak valid.');
        }

        // Prorata: bila masih ada langganan AKTIF, kreditkan sisa nilainya (adil saat
        // upgrade/ganti — hanya bayar selisih, bukan harga penuh).
        $current = $this->subs->activeFor($customerId);
        $credit  = $this->prorateCredit($current);
        $net     = max(0, $cost - $credit);

        if ($this->wallet->balance($customerId) < $net) {
            throw new RuntimeException("Saldo koin kurang (butuh {$net}). Silakan topup.");
        }
        if ($net > 0) {
            $desc = $credit > 0
                ? "Langganan {$tier} {$months} bln (prorata −{$credit} sisa)"
                : "Langganan {$tier} {$months} bulan";
            $this->wallet->debit($customerId, $net, 'spend', 'sub', $desc);
        }

        // Ganti langganan lama agar tak ada 2 langganan aktif bertumpuk.
        if ($current !== null && (string) ($current['status'] ?? '') === 'active') {
            $this->subs->update((int) $current['id'], ['status' => 'replaced']);
        }

        return $this->issue($customerId, $tier, $months, $net, 'coin');
    }

    /**
     * Nilai kredit prorata dari langganan aktif yang masih berjalan: bagian sisa
     * waktu × koin yang dibayar. Hibah manual (coins_spent=0) → 0.
     * @param array<string,mixed>|null $sub
     */
    private function prorateCredit(?array $sub): int
    {
        if ($sub === null) {
            return 0;
        }
        $paid = (int) ($sub['coins_spent'] ?? 0);
        if ($paid <= 0) {
            return 0;
        }
        $start = strtotime((string) ($sub['starts_at'] ?? '')) ?: time();
        $end   = strtotime((string) ($sub['expires_at'] ?? '')) ?: 0;
        if ($end <= time()) {
            return 0; // sudah/hampir habis → tak ada sisa
        }
        $totalDays  = max(1.0, ($end - $start) / 86400);
        $remainDays = max(0.0, ($end - time()) / 86400);

        return (int) round($paid * min(1.0, $remainDays / $totalDays));
    }

    /** Langganan manual oleh OWNER (tanpa koin). @throws RuntimeException */
    public function grantManual(int $customerId, string $tier, int $months): array
    {
        if ($this->price()->cost($tier, $months) === null) {
            throw new RuntimeException('Paket/durasi tidak valid.');
        }

        return $this->issue($customerId, $tier, $months, 0, 'manual');
    }

    /** Terbitkan license key + simpan subscription. */
    private function issue(int $customerId, string $tier, int $months, int $coins, string $method): array
    {
        $priv = (string) (env('license.privateKey') ?: '');
        if ($priv === '') {
            throw new RuntimeException('Console ini bukan OWNER (tak ada private key) — tak dapat menerbitkan lisensi.');
        }
        $cust  = $this->customers->find($customerId);
        $days  = (int) round((strtotime("+{$months} months") - time()) / 86400);
        $token = $this->keys->sign([
            'tier'     => $tier,
            'days'     => $days,
            'customer' => (string) ($cust['name'] ?? ('CID-' . $customerId)),
        ], $priv);
        $payload = $this->keys->verify($token) ?? [];

        $id = (int) $this->subs->insert([
            'customer_id'   => $customerId,
            'tier'          => $tier,
            'months'        => $months,
            'coins_spent'   => $coins,
            'method'        => $method,
            'license_id'    => $payload['lid'] ?? null,
            'license_token' => $token,
            'starts_at'     => date('Y-m-d'),
            'expires_at'    => $payload['exp'] ?? null,
            'status'        => 'active',
        ], true);

        return $this->subs->find($id);
    }

    /** @return array<int,array<string,mixed>> langganan pelanggan */
    public function forCustomer(int $customerId): array
    {
        return $this->subs->forCustomer($customerId);
    }

    /**
     * Langganan AKTIF terbaru pelanggan yang BELUM kedaluwarsa (dipakai endpoint
     * sync untuk menyerahkan license_token). null bila tak ada/expired.
     * @return array<string,mixed>|null
     */
    public function activeForCustomer(int $customerId): ?array
    {
        $sub = $this->subs->activeFor($customerId);
        if ($sub === null) {
            return null;
        }
        $exp = (string) ($sub['expires_at'] ?? '');
        if ($exp !== '' && $exp < date('Y-m-d')) {
            return null; // kedaluwarsa → anggap tak ada (VPS turun ke Community)
        }

        return $sub;
    }
}
