<?php

declare(strict_types=1);

namespace App\Modules\Billing\Database\Seeds;

use CodeIgniter\Database\Seeder;

/** Paket topup koin (1 koin = Rp 1). Idempoten. */
final class CoinPackageSeeder extends Seeder
{
    public function run(): void
    {
        $rows = [
            ['label' => 'Koin 150.000',   'price_rp' => 150000,   'coin_amount' => 150000,   'bonus_coin' => 0,      'sort_order' => 1],
            ['label' => 'Koin 500.000',   'price_rp' => 500000,   'coin_amount' => 500000,   'bonus_coin' => 25000,  'sort_order' => 2],
            ['label' => 'Koin 1.000.000', 'price_rp' => 1000000,  'coin_amount' => 1000000,  'bonus_coin' => 75000,  'sort_order' => 3],
            ['label' => 'Koin 2.500.000', 'price_rp' => 2500000,  'coin_amount' => 2500000,  'bonus_coin' => 250000, 'sort_order' => 4],
            ['label' => 'Koin 5.000.000', 'price_rp' => 5000000,  'coin_amount' => 5000000,  'bonus_coin' => 750000, 'sort_order' => 5],
        ];
        $t = $this->db->table('coin_package');
        foreach ($rows as $r) {
            if ($t->where('label', $r['label'])->countAllResults() === 0) {
                $t->insert($r + ['is_active' => 1]);
            }
        }
    }
}
