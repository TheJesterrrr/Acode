<?php

declare(strict_types=1);

namespace App\Modules\Billing\Database\Migrations;

use CodeIgniter\Database\Migration;

/** Paket topup koin (opsi beli koin via Mayar). */
final class CreateCoinPackageTable extends Migration
{
    public function up(): void
    {
        $this->forge->addField([
            'id'          => ['type' => 'INT', 'constraint' => 10, 'unsigned' => true, 'auto_increment' => true],
            'label'       => ['type' => 'VARCHAR', 'constraint' => 60],
            'price_rp'    => ['type' => 'BIGINT', 'constraint' => 15],
            'coin_amount' => ['type' => 'BIGINT', 'constraint' => 15],
            'bonus_coin'  => ['type' => 'BIGINT', 'constraint' => 15, 'default' => 0],
            'is_active'   => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 1],
            'sort_order'  => ['type' => 'INT', 'constraint' => 4, 'default' => 100],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->createTable('coin_package', true, ['ENGINE' => 'InnoDB', 'DEFAULT CHARSET' => 'utf8mb4', 'COLLATE' => 'utf8mb4_unicode_ci']);
    }

    public function down(): void
    {
        $this->forge->dropTable('coin_package', true);
    }
}
