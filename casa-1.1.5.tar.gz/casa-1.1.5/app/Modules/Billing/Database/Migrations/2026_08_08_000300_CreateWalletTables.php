<?php

declare(strict_types=1);

namespace App\Modules\Billing\Database\Migrations;

use CodeIgniter\Database\Migration;

/**
 * Wallet koin (di CONSOLE OWNER). 1 koin = Rp 1 (konvensi CoreNet/CRP). Saldo &
 * mutasi hanya berubah dari sisi server owner (topup terverifikasi / langganan /
 * hibah admin) — tak bisa dimanipulasi member.
 */
final class CreateWalletTables extends Migration
{
    public function up(): void
    {
        $this->forge->addField([
            'id'          => ['type' => 'INT', 'constraint' => 10, 'unsigned' => true, 'auto_increment' => true],
            'customer_id' => ['type' => 'INT', 'constraint' => 10, 'unsigned' => true],
            'balance'     => ['type' => 'BIGINT', 'constraint' => 15, 'default' => 0], // koin
            'updated_at'  => ['type' => 'DATETIME', 'null' => true],
            'created_at'  => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addUniqueKey('customer_id');
        $this->forge->createTable('wallet', true, ['ENGINE' => 'InnoDB', 'DEFAULT CHARSET' => 'utf8mb4', 'COLLATE' => 'utf8mb4_unicode_ci']);

        $this->forge->addField([
            'id'            => ['type' => 'INT', 'constraint' => 10, 'unsigned' => true, 'auto_increment' => true],
            'customer_id'   => ['type' => 'INT', 'constraint' => 10, 'unsigned' => true],
            'type'          => ['type' => 'VARCHAR', 'constraint' => 12], // topup|spend|grant|refund
            'amount'        => ['type' => 'BIGINT', 'constraint' => 15],   // + / -
            'balance_after' => ['type' => 'BIGINT', 'constraint' => 15],
            'ref'           => ['type' => 'VARCHAR', 'constraint' => 60, 'null' => true],
            'note'          => ['type' => 'VARCHAR', 'constraint' => 200, 'null' => true],
            'created_at'    => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey('customer_id');
        $this->forge->createTable('wallet_transaction', true, ['ENGINE' => 'InnoDB', 'DEFAULT CHARSET' => 'utf8mb4', 'COLLATE' => 'utf8mb4_unicode_ci']);
    }

    public function down(): void
    {
        $this->forge->dropTable('wallet_transaction', true);
        $this->forge->dropTable('wallet', true);
    }
}
