<?php

declare(strict_types=1);

namespace App\Modules\Billing\Database\Migrations;

use CodeIgniter\Database\Migration;

/**
 * Langganan (self-service koin ATAU manual owner) + order topup Mayar. License
 * key ter-tanda-tangani disimpan agar member bisa mengunduhnya di portal.
 */
final class CreateSubscriptionTables extends Migration
{
    public function up(): void
    {
        $this->forge->addField([
            'id'            => ['type' => 'INT', 'constraint' => 10, 'unsigned' => true, 'auto_increment' => true],
            'customer_id'   => ['type' => 'INT', 'constraint' => 10, 'unsigned' => true],
            'tier'          => ['type' => 'VARCHAR', 'constraint' => 12],
            'months'        => ['type' => 'INT', 'constraint' => 3],
            'coins_spent'   => ['type' => 'BIGINT', 'constraint' => 15, 'default' => 0],
            'method'        => ['type' => 'VARCHAR', 'constraint' => 10, 'default' => 'coin'], // coin|manual
            'license_id'    => ['type' => 'VARCHAR', 'constraint' => 40, 'null' => true],
            'license_token' => ['type' => 'TEXT', 'null' => true],
            'starts_at'     => ['type' => 'DATE', 'null' => true],
            'expires_at'    => ['type' => 'DATE', 'null' => true],
            'status'        => ['type' => 'VARCHAR', 'constraint' => 10, 'default' => 'active'], // active|expired
            'created_at'    => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey('customer_id');
        $this->forge->createTable('subscription', true, ['ENGINE' => 'InnoDB', 'DEFAULT CHARSET' => 'utf8mb4', 'COLLATE' => 'utf8mb4_unicode_ci']);

        $this->forge->addField([
            'id'          => ['type' => 'INT', 'constraint' => 10, 'unsigned' => true, 'auto_increment' => true],
            'customer_id' => ['type' => 'INT', 'constraint' => 10, 'unsigned' => true],
            'package_id'  => ['type' => 'INT', 'constraint' => 10, 'unsigned' => true, 'null' => true],
            'coins'       => ['type' => 'BIGINT', 'constraint' => 15],
            'price_rp'    => ['type' => 'BIGINT', 'constraint' => 15],
            'gateway'     => ['type' => 'VARCHAR', 'constraint' => 20, 'default' => 'mayar'],
            'gateway_ref' => ['type' => 'VARCHAR', 'constraint' => 120, 'null' => true],
            'status'      => ['type' => 'VARCHAR', 'constraint' => 10, 'default' => 'pending'], // pending|paid|failed
            'created_at'  => ['type' => 'DATETIME', 'null' => true],
            'paid_at'     => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey('gateway_ref');
        $this->forge->createTable('topup_order', true, ['ENGINE' => 'InnoDB', 'DEFAULT CHARSET' => 'utf8mb4', 'COLLATE' => 'utf8mb4_unicode_ci']);
    }

    public function down(): void
    {
        $this->forge->dropTable('topup_order', true);
        $this->forge->dropTable('subscription', true);
    }
}
