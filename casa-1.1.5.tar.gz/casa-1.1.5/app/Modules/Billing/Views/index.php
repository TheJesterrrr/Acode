<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<?php
/** @var int $balance @var array $packages @var array $plans @var array $durations @var array $meta @var array $subs @var array $history */
$durLabel = [1 => '1 bulan', 3 => '3 bulan', 6 => '6 bulan', 12 => '12 bulan'];
?>
<div class="casa-page-head">
  <div>
    <h1 class="mb-0"><i class="bi bi-coin me-1"></i>Langganan &amp; Koin</h1>
    <div class="small text-muted">Topup koin, langganan Pro/Enterprise, lalu unduh license key untuk diaktivasi di instance CASA Anda.</div>
  </div>
  <div class="ms-auto text-end">
    <div class="small text-muted">Saldo koin</div>
    <div class="fs-3 fw-bold text-warning"><i class="bi bi-coin me-1"></i><?= number_format($balance, 0, ',', '.') ?></div>
  </div>
</div>

<!-- Perbandingan paket (kapabilitas, bukan nama tool) -->
<div class="casa-card p-0 mb-3">
  <div class="p-3 border-bottom" style="border-color:var(--casa-card-brd)!important">
    <h2 class="h6 mb-0"><i class="bi bi-columns-gap me-1"></i>Perbandingan paket</h2>
    <div class="small text-muted">Batas kuota, kapabilitas keamanan, dan fitur per paket. Community otomatis terkunci sesuai daftar ini walau aplikasi memuat kapabilitas penuh.</div>
  </div>
  <div class="table-responsive">
    <table class="table align-middle mb-0 text-center small">
      <thead>
        <tr>
          <th class="text-start ps-3" style="min-width:220px">Kemampuan</th>
          <th>Community<div class="text-muted fw-normal">Gratis</div></th>
          <th class="text-warning">Professional</th>
          <th class="text-warning">Enterprise</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $yes = '<i class="bi bi-check-circle-fill text-success"></i>';
        $no  = '<i class="bi bi-dash-lg text-muted"></i>';
        $rows = [
            ['h', 'Kuota'],
            ['Projects', '1', '15', 'Tak terbatas'],
            ['Targets', '5', '100', 'Tak terbatas'],
            ['Scan terjadwal', '0', '20', 'Tak terbatas'],
            ['h', 'Kapabilitas keamanan'],
            ['Recon & pemetaan permukaan', $yes, $yes, $yes],
            ['— Subdomain, DNS, HTTP probing', $yes, $yes, $yes],
            ['— Port &amp; deteksi service', $yes, $yes, $yes],
            ['— Crawling, URL discovery, fingerprint', $yes, $yes, $yes],
            ['— Penilaian TLS/SSL &amp; screenshot', $yes, $yes, $yes],
            ['Vulnerability assessment (web, server, CMS)', $no, $yes, $yes],
            ['Uji eksploitasi (XSS, SQLi, akses/IDOR)', $no, $yes, $yes],
            ['Content &amp; parameter discovery', $no, $yes, $yes],
            ['Secret scanning &amp; dependency/container', $no, $yes, $yes],
            ['API security &amp; deteksi WAF', $no, $yes, $yes],
            ['h', 'Fitur'],
            ['IDOR / BOLA Workbench', $no, $yes, $yes],
            ['Automation (scan terjadwal)', $no, $yes, $yes],
            ['Ekspor laporan PDF', $no, $yes, $yes],
            ['AuthZ Matrix (Broken Access Control)', $no, $yes, $yes],
            ['Business Logic Lab', $no, $yes, $yes],
        ];
        foreach ($rows as $r):
            if ($r[0] === 'h'): ?>
              <tr class="table-active"><td class="text-start ps-3 fw-semibold text-uppercase" colspan="4" style="letter-spacing:.03em"><?= esc($r[1]) ?></td></tr>
            <?php else: ?>
              <tr>
                <td class="text-start ps-3"><?= $r[0] ?></td>
                <td><?= $r[1] ?></td><td><?= $r[2] ?></td><td><?= $r[3] ?></td>
              </tr>
            <?php endif;
        endforeach; ?>
      </tbody>
    </table>
  </div>
  <div class="p-2 small text-muted border-top" style="border-color:var(--casa-card-brd)!important"><i class="bi bi-info-circle me-1"></i>Turun paket = kapabilitas &amp; fitur di atas otomatis menyesuaikan; naik paket membukanya kembali tanpa instal ulang.</div>
</div>

<div class="row g-3">
  <!-- Langganan -->
  <div class="col-lg-7">
    <div class="casa-card p-4">
      <h2 class="h6 mb-3">Berlangganan (bayar koin)</h2>
      <form id="subForm" class="row g-2 align-items-end">
        <div class="col-md-5"><label class="form-label small">Paket</label>
          <select name="tier" id="tier" class="form-select">
            <?php foreach ($plans as $tier => $_): ?><option value="<?= esc($tier) ?>"><?= esc($meta[$tier]['label'] ?? $tier) ?></option><?php endforeach; ?>
          </select></div>
        <div class="col-md-4"><label class="form-label small">Durasi</label>
          <select name="months" id="months" class="form-select">
            <?php foreach ($durations as $m): ?><option value="<?= (int) $m ?>"><?= esc($durLabel[$m] ?? $m . ' bln') ?></option><?php endforeach; ?>
          </select></div>
        <div class="col-md-3"><label class="form-label small">Biaya</label>
          <div class="form-control bg-transparent fw-bold text-warning" id="costBox">—</div></div>
        <div class="col-12 mt-2">
          <button id="subBtn" class="btn btn-amber"><i class="bi bi-patch-check me-1"></i>Langganan sekarang</button>
          <span id="subMsg" class="small ms-2"></span>
        </div>
      </form>
    </div>

    <!-- Langganan saya -->
    <div class="casa-card p-0 mt-3">
      <div class="p-3 border-bottom" style="border-color:var(--casa-card-brd)!important"><h2 class="h6 mb-0">Langganan saya</h2></div>
      <div class="table-responsive"><table class="table align-middle mb-0">
        <thead><tr><th class="ps-3">Paket</th><th>Durasi</th><th>Berlaku s/d</th><th>Status</th><th class="text-end pe-3">License Key</th></tr></thead>
        <tbody>
          <?php if ($subs === []): ?><tr><td colspan="5" class="text-center text-muted py-3">Belum ada langganan.</td></tr><?php endif; ?>
          <?php foreach ($subs as $s): $exp = $s['expires_at'] && $s['expires_at'] < date('Y-m-d'); ?>
            <tr>
              <td class="ps-3 fw-semibold text-uppercase"><?= esc($s['tier']) ?></td>
              <td><?= (int) $s['months'] ?> bln <?= $s['method'] === 'manual' ? '<span class="badge text-bg-light border">manual</span>' : '' ?></td>
              <td class="small"><?= esc($s['expires_at'] ?? '∞') ?></td>
              <td><span class="badge text-bg-<?= $exp ? 'secondary' : 'success' ?>"><?= $exp ? 'kedaluwarsa' : 'aktif' ?></span></td>
              <td class="text-end pe-3"><a class="btn btn-sm btn-outline-primary" href="<?= esc(site_url('billing/key/' . $s['id'])) ?>"><i class="bi bi-download me-1"></i>Download key</a></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table></div>
    </div>
  </div>

  <!-- Topup + riwayat -->
  <div class="col-lg-5">
    <div class="casa-card p-4">
      <h2 class="h6 mb-3">Topup koin</h2>
      <div class="d-flex flex-column gap-2">
        <?php foreach ($packages as $p): ?>
          <button class="btn btn-outline-secondary d-flex justify-content-between align-items-center js-topup" data-id="<?= (int) $p['id'] ?>">
            <span><?= esc($p['label']) ?><?= (int) $p['bonus_coin'] > 0 ? ' <span class="badge text-bg-success">+' . number_format((int) $p['bonus_coin'], 0, ',', '.') . ' bonus</span>' : '' ?></span>
            <span class="fw-semibold">Rp <?= number_format((int) $p['price_rp'], 0, ',', '.') ?></span>
          </button>
        <?php endforeach; ?>
      </div>
      <div id="topupMsg" class="small mt-2 text-muted"><i class="bi bi-shield-lock me-1"></i>Pembayaran via Mayar; koin masuk otomatis setelah lunas (terverifikasi server).</div>
    </div>

    <div class="casa-card p-0 mt-3">
      <div class="p-3 border-bottom" style="border-color:var(--casa-card-brd)!important"><h2 class="h6 mb-0">Riwayat koin</h2></div>
      <div class="table-responsive" style="max-height:260px;overflow:auto"><table class="table table-sm align-middle mb-0">
        <tbody>
          <?php if ($history === []): ?><tr><td class="text-muted small py-3 text-center">Belum ada mutasi.</td></tr><?php endif; ?>
          <?php foreach ($history as $h): ?>
            <tr><td class="ps-3 small"><?= esc($h['note'] ?: $h['type']) ?><div class="text-muted"><?= esc(substr((string) $h['created_at'], 0, 16)) ?></div></td>
              <td class="text-end pe-3 fw-semibold <?= (int) $h['amount'] < 0 ? 'text-danger' : 'text-success' ?>"><?= (int) $h['amount'] > 0 ? '+' : '' ?><?= number_format((int) $h['amount'], 0, ',', '.') ?></td></tr>
          <?php endforeach; ?>
        </tbody>
      </table></div>
    </div>
  </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('page_scripts') ?>
<script>
const PLANS = <?= json_encode($plans) ?>;
function fmt(n){ return n.toLocaleString('id-ID'); }
function updCost(){
  const t = document.getElementById('tier').value, m = document.getElementById('months').value;
  const c = (PLANS[t]||{})[m];
  document.getElementById('costBox').textContent = c ? (fmt(c)+' koin') : '—';
}
document.getElementById('tier').addEventListener('change', updCost);
document.getElementById('months').addEventListener('change', updCost); updCost();

document.querySelectorAll('.js-topup').forEach(b => b.addEventListener('click', async () => {
  const m = document.getElementById('topupMsg');
  const d = await casaPost('<?= esc(site_url('billing/topup')) ?>', { package_id: b.dataset.id });
  if (d.ok && d.link) { m.className='small mt-2 text-success'; m.textContent='Mengalihkan ke pembayaran…'; location.href = d.link; }
  else if (d.ok && d.pending) { m.className='small mt-2 text-warning'; m.textContent='Order dibuat. Gateway Mayar belum dikonfigurasi (hubungi owner untuk kredit manual).'; }
  else { m.className='small mt-2 text-danger'; m.textContent = d.error || 'Gagal.'; }
}));

document.getElementById('subForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const b = document.getElementById('subBtn'), m = document.getElementById('subMsg');
  b.disabled = true; const o = b.innerHTML; b.innerHTML = '<span class="spinner-border spinner-border-sm"></span>';
  const d = await casaPost('<?= esc(site_url('billing/subscribe')) ?>', new FormData(e.target));
  b.disabled = false; b.innerHTML = o;
  if (d.ok) { m.className='small ms-2 text-success'; m.textContent='Berhasil! Key '+d.tier+' s/d '+(d.exp||'∞')+'. Unduh di tabel bawah.'; setTimeout(()=>location.reload(), 1200); }
  else { m.className='small ms-2 text-danger'; m.textContent = d.error || 'Gagal.'; }
});
</script>
<?= $this->endSection() ?>
