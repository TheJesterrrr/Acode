<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<?php
/** @var array $releases */
$fmtSize = static function (int $b): string {
    if ($b >= 1048576) {
        return number_format($b / 1048576, 1, ',', '.') . ' MB';
    }
    if ($b >= 1024) {
        return number_format($b / 1024, 0, ',', '.') . ' KB';
    }

    return $b . ' B';
};
?>
<div class="casa-page-head">
  <div>
    <h1 class="mb-0"><i class="bi bi-download me-1"></i>Download App</h1>
    <div class="small text-muted">Unduh paket installer CASA, pasang di VPS Anda, lalu aktivasi lisensi dari menu <b>Langganan &amp; Koin</b>.</div>
  </div>
</div>

<div class="row g-3">
  <div class="col-lg-8">
    <div class="casa-card p-0">
      <div class="p-3 border-bottom" style="border-color:var(--casa-card-brd)!important"><h2 class="h6 mb-0">Rilis tersedia</h2></div>
      <div class="table-responsive"><table class="table align-middle mb-0">
        <thead><tr><th class="ps-3">Jenis</th><th>Versi</th><th>Ukuran</th><th>SHA-256</th><th class="text-end pe-3">Download</th></tr></thead>
        <tbody>
          <?php if ($releases === []): ?>
            <tr><td colspan="5" class="text-center text-muted py-4">Belum ada rilis. Owner meletakkan paket <code>casa-*</code> (.tar.gz / .zip / .exe) di <code>writable/releases/</code>.</td></tr>
          <?php endif; ?>
          <?php foreach ($releases as $r): ?>
            <tr>
              <td class="ps-3"><i class="bi <?= esc($r['icon']) ?> me-1"></i><span class="fw-semibold"><?= esc($r['label']) ?></span><div class="small text-muted"><?= esc($r['file']) ?></div></td>
              <td class="small">CASA <?= esc($r['version']) ?></td>
              <td class="small"><?= esc($fmtSize((int) $r['size'])) ?></td>
              <td class="small"><code class="text-muted" title="<?= esc($r['sha256']) ?>"><?= esc(substr((string) $r['sha256'], 0, 16)) ?>…</code></td>
              <td class="text-end pe-3"><a class="btn btn-sm btn-amber" href="<?= esc(site_url('download/installer/' . $r['file'])) ?>"><i class="bi bi-download me-1"></i>Download</a></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table></div>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="casa-card p-4">
      <h2 class="h6 mb-3"><i class="bi bi-terminal me-1"></i>Quick start</h2>
      <p class="small mb-1"><i class="bi bi-windows me-1"></i><b>Windows (1-click):</b> download the <code>.exe</code> → run it → follow the wizard (installs Docker + CASA automatically).</p>
      <p class="small mb-1"><i class="bi bi-box-seam me-1"></i><b>Docker (all OS):</b> extract the <code>.zip</code> → <code>docker compose up -d</code> → open <code>casaadmin.localhost:8080</code>.</p>
      <p class="small mb-2"><i class="bi bi-hdd-stack me-1"></i><b>Linux VPS:</b> <code>tar -xzf casa-*.tar.gz</code> → <code>sudo bash install.sh /var/www/casa</code> → <code>/install</code> wizard.</p>
      <div class="small text-muted"><i class="bi bi-shield-check me-1"></i>Verify the SHA-256 after downloading. Full guide: the <b>Guide</b> menu.</div>
    </div>
  </div>
</div>
<?= $this->endSection() ?>
