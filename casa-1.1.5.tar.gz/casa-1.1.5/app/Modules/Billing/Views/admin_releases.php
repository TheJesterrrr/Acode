<?= $this->extend('layouts/admin') ?>
<?= $this->section('content') ?>
<?php
/** @var array $releases */
/** @var string $latestVer */
$fmtSize = static function (int $b): string {
    if ($b >= 1048576) {
        return number_format($b / 1048576, 1, ',', '.') . ' MB';
    }
    if ($b >= 1024) {
        return number_format($b / 1024, 0, ',', '.') . ' KB';
    }

    return $b . ' B';
};
?>
<div class="casa-page-head">
  <div>
    <h1 class="mb-0"><i class="bi bi-box-seam me-1"></i>Rilis Aplikasi</h1>
    <div class="small text-muted">Unggah paket rilis di sini. <b>casamember</b> (Download App) dan instance pelanggan (cek update) membacanya <b>otomatis</b> dari folder yang sama — tak perlu FTP.</div>
  </div>
</div>

<div class="row g-3">
  <div class="col-lg-8">
    <div class="casa-card p-0">
      <div class="p-3 border-bottom" style="border-color:var(--casa-card-brd)!important">
        <h2 class="h6 mb-0">Rilis tersedia<?= $latestVer !== '' ? ' — terbaru <span class="badge bg-success">CASA ' . esc($latestVer) . '</span>' : '' ?></h2>
      </div>
      <div class="table-responsive"><table class="table align-middle mb-0">
        <thead><tr><th class="ps-3">Jenis</th><th>Versi</th><th>Ukuran</th><th>SHA-256</th><th class="text-end pe-3">Aksi</th></tr></thead>
        <tbody>
          <?php if ($releases === []): ?>
            <tr><td colspan="5" class="text-center text-muted py-4">Belum ada rilis. Unggah paket <code>casa-*</code> (.tar.gz / .zip / .exe) lewat form di samping.</td></tr>
          <?php endif; ?>
          <?php foreach ($releases as $r): ?>
            <?php $isLatest = $latestVer !== '' && $r['kind'] === 'vps' && $r['version'] === $latestVer; ?>
            <tr>
              <td class="ps-3">
                <i class="bi <?= esc($r['icon']) ?> me-1"></i><span class="fw-semibold"><?= esc($r['label']) ?></span>
                <?php if ($isLatest): ?><span class="badge bg-success ms-1">terbaru</span><?php endif; ?>
                <div class="small text-muted"><?= esc($r['file']) ?></div>
                <?php if (($r['notes'] ?? '') !== ''): ?><div class="small text-muted mt-1"><i class="bi bi-journal-text me-1"></i><?= esc(mb_substr((string) $r['notes'], 0, 120)) ?></div><?php endif; ?>
              </td>
              <td class="small">CASA <?= esc($r['version']) ?></td>
              <td class="small"><?= esc($fmtSize((int) $r['size'])) ?></td>
              <td class="small"><code class="text-muted" title="<?= esc($r['sha256']) ?>"><?= esc(substr((string) $r['sha256'], 0, 16)) ?>…</code></td>
              <td class="text-end pe-3">
                <form method="post" action="<?= esc(site_url('casaadmin/releases/delete')) ?>" onsubmit="return confirm('Hapus rilis <?= esc($r['file']) ?>? Pelanggan tak bisa lagi mengunduhnya.');" class="d-inline">
                  <?= csrf_field() ?>
                  <input type="hidden" name="file" value="<?= esc($r['file']) ?>">
                  <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table></div>
    </div>
  </div>

  <div class="col-lg-4">
    <div class="casa-card p-4">
      <h2 class="h6 mb-3"><i class="bi bi-cloud-upload me-1"></i>Unggah rilis</h2>
      <form method="post" action="<?= esc(site_url('casaadmin/releases/upload')) ?>" enctype="multipart/form-data">
        <?= csrf_field() ?>
        <div class="mb-3">
          <label class="form-label small">Berkas paket</label>
          <input type="file" name="package" class="form-control" accept=".gz,.tgz,.zip,.exe" required>
          <div class="form-text">Nama harus <code>casa-&lt;versi&gt;.tar.gz</code> / <code>.zip</code> / <code>.exe</code>, mis. <code>casa-1.1.2.tar.gz</code>.</div>
        </div>
        <div class="mb-3">
          <label class="form-label small">Catatan versi (opsional)</label>
          <textarea name="notes" class="form-control" rows="3" placeholder="Ringkasan perubahan rilis ini…"></textarea>
        </div>
        <button class="btn btn-amber w-100"><i class="bi bi-cloud-upload me-1"></i>Unggah &amp; publikasikan</button>
      </form>
      <hr>
      <div class="small text-muted">
        <i class="bi bi-shield-check me-1"></i>SHA-256 dibuat otomatis (dipakai instance memverifikasi saat <code>apply-update</code>).<br>
        <i class="bi bi-info-circle me-1"></i>Versi tertinggi (.tar.gz) ditandai <b>terbaru</b> dan ditawarkan sebagai update ke pelanggan.
      </div>
    </div>
  </div>
</div>
<?= $this->endSection() ?>
