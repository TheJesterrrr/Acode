# Modul Dashboard

Angka ringkas untuk dasbor admin & member. Dasbor "jangan ramai" — hanya angka
yang menuntut tindakan (masukan pemilik #18). Tiap angka satu kueri ringan.

- `adminStats()` — angka ringkas untuk dasbor administrator.
- `adminBadges()` — lencana sidebar. WAJIB ringan: dipanggil tiap permintaan.
- `memberStats()` — angka ringkas untuk dasbor member.

Skeleton hanya menyediakan satu angka contoh. Tambahkan angka milik modul bisnis
di service tersebut, satu kueri ringkas per angka.

View + controller dibangun bersama shell (Fase 6).
