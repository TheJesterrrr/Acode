## Laporan siap-submit

CASA menyusun laporan yang bisa langsung Anda kirim ke program bug bounty. Buka **Reports** (daftar seluruh laporan) atau generate dari sebuah project: **Projects → pilih project → Reports → Generate**.

## Pilih template

| Template | Untuk |
|---|---|
| HackerOne / Bugcrowd / Intigriti / YesWeHack | Submission platform bug bounty |
| Technical | Laporan teknis lengkap |
| Executive | Ringkasan untuk manajemen |

## Struktur tiap temuan

Setiap kerentanan ditulis dalam format standar submission:

- **Summary** — ringkas kerentanan.
- **Steps to Reproduce** — langkah reproduksi bernomor.
- **Impact** — dampak bila dieksploitasi.
- **Proof of Concept** — bukti (request/response).
- **Remediation** — rekomendasi perbaikan.
- **References** — tautan CWE, CVE (NVD), dan MITRE ATT&CK.

## Ekspor

- **Lihat** (HTML), **PDF** (siap lampir), atau **Markdown mentah** (tempel ke platform).
- Ringkasan eksekutif & bagian kepatuhan (OWASP) ditulis dibantu **AI Report Writer**.

> Tips: lengkapi Steps to Reproduce & PoC dengan bukti nyata sebelum submit agar cepat divalidasi triager.
