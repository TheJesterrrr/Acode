**Kode: CASA-E006**

## Gejala

Scan gagal dengan error aneh yang tak jelas (gagal tulis file, tool tak bisa start, dsb), padahal sebelumnya normal. Sering muncul setelah beberapa kali insiden worker crash/OOM (lihat panduan **Mission Nyangkut / Macet**).

## Penyebab

Tiap adapter tool menulis file sementara ke `/tmp` (mis. `/tmp/casa_ffuf_*.json`, `/tmp/casa_nuclei_*.json`) lalu menghapusnya sendiri setelah selesai dibaca. Kalau worker **crash di tengah** (kehabisan memori) sebelum sempat menghapus, file itu **tertinggal selamanya**. Lama-lama, terutama di VM dengan riwayat sering OOM, `/tmp` bisa penuh berisi ribuan file sisa — dan begitu disk penuh, hampir semua operasi (tulis file, database, log) mulai gagal dengan cara yang membingungkan.

## Langkah (SSH ke server CASA)

```bash
# 1. Cek sisa ruang disk
df -h /

# 2. Lihat berapa banyak & seberapa besar sisa file sementara CASA
du -sh /tmp/casa_* 2>/dev/null | tail -1
ls /tmp/casa_* 2>/dev/null | wc -l

# 3. Kalau jumlahnya besar/sudah lama, aman dihapus — CASA cuma butuh file ini
#    SELAMA task scan berjalan, bukan sesudahnya
find /tmp -maxdepth 1 -name "casa_*" -mmin +60 -delete

# 4. Verifikasi ruang disk sudah lega
df -h /
```

## Mencegah berulang (opsional, jangka panjang)

Tambahkan satu baris cron pembersihan rutin agar file sisa tak pernah lebih tua dari 1 jam, berapa pun sering worker crash:

```bash
(crontab -l 2>/dev/null; echo "0 * * * * find /tmp -maxdepth 1 -name 'casa_*' -mmin +60 -delete") | crontab -
```

> Ini aman — tiap task scan biasanya selesai dalam hitungan menit, jadi file berumur lebih dari 1 jam di `/tmp/casa_*` hampir pasti sisa dari proses yang sudah mati.
