**Kode: CASA-E011**

## Gejala

Tiba-tiba tak bisa SSH ke server CASA sama sekali ("connection refused"/"connection timed out"), biasanya setelah aturan firewall diperketat (mis. membatasi akses cuma dari IP tertentu).

## Pencegahan (lakukan SEBELUM mengetatkan firewall)

Jangan langsung terapkan aturan ketat dari sesi SSH yang sama — kalau aturannya salah, Anda langsung terkunci keluar tanpa jalan masuk lagi. Pola aman:

```bash
# 1. Buka jendela/terminal SSH KEDUA dulu (biarkan sesi pertama tetap terbuka)
#    sebagai jaring pengaman selama menguji aturan baru.

# 2. Terapkan aturan baru di sesi pertama
sudo firewall-cmd --permanent --add-rich-rule='rule family="ipv4" source address="IP-ANDA/32" port port="22" protocol="tcp" accept'
sudo firewall-cmd --permanent --remove-service=ssh   # kalau mau tutup akses umum
sudo firewall-cmd --reload

# 3. SEBELUM menutup sesi pertama, tes dari jendela KEDUA: buka SSH baru
#    dari device lain / jaringan lain untuk pastikan aturan tidak keliru
```

## Kalau sudah terlanjur terkunci

Butuh akses di luar jalur SSH — pilih salah satu:

- **Console/VNC** penyedia VPS (DigitalOcean/AWS/Proxmox/dsb biasanya punya "Console" lewat web dashboard, tanpa lewat SSH) — masuk lewat situ, lalu perbaiki aturan firewall.
- **Hubungi penyedia hosting** untuk reset firewall dari sisi mereka kalau tak ada akses console.

Setelah masuk lewat console:

```bash
# Lihat aturan firewall yang aktif
sudo firewall-cmd --list-all

# Buka kembali akses SSH umum sementara untuk pulih dulu
sudo firewall-cmd --permanent --add-service=ssh
sudo firewall-cmd --reload
```

> Baru setelah bisa SSH normal lagi, terapkan pembatasan IP dengan pola dua-sesi di atas.
