**Kode: CASA-E004**

## Gejala

Klik **Unduh PDF** di halaman laporan menampilkan halaman error generik ("Whoops!") alih-alih mengunduh file. Biasanya terjadi pada laporan besar (ratusan temuan) — server kehabisan memori saat merender PDF-nya.

## Solusi tercepat — pakai Print

1. Buka laporannya di menu **Reports**.
2. Klik tombol **Print** (bukan "Unduh PDF").
3. PDF di-render langsung dari browser Anda sendiri, bukan dari server — jadi tak pernah gagal karena RAM server. Pada dialog print, pilih **Save as PDF** sebagai tujuan cetak.

## Alternatif — perkecil laporan dulu

Filter severity yang relevan saja (tombol **Severity: ...** di atas laporan) sebelum klik **Unduh PDF** — laporan yang lebih kecil jauh lebih kecil kemungkinan gagal direndernya oleh server.
