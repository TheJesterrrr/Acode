## Symptom

After **Update Application** to a new version, the app suddenly treats you as the **Community** tier — Pro/Enterprise features are locked, quotas shrink — even though your subscription is still active.

> **Good news:** your license is **not actually lost**. The license token is stored in your instance's database and is **not** touched by the update. The token merely failed verification momentarily. Follow the steps below to restore it.

## Why this happens

The app re-verifies your license token on every check using a **public key** embedded in the code. If verification fails, the tier drops to Community to be safe. Most common causes:

1. **Stale code cache (opcache)** still serving the previous version after files were overwritten.
2. **Token expired** right around the update (coincidental timing) — not caused by the update.
3. **A faulty update package** carrying the wrong public key (should not happen: official releases are checksum-verified and built from the production source).

## Recovery (lightest first)

**1. Clear the code cache & reload.** On your instance server:

```bash
sudo systemctl restart php-fpm   # clears opcache (recommended after EVERY update)
```

Reopen the **License & Activation** page. The tier often returns to normal immediately.

**2. Re-sync the license from the Hub.** On **License & Activation**, click **Sync Now** (or re-paste the **Sync Code** from *Subscription & Coins* in the `casamember` hub). This pulls the latest token for your subscription.

**3. Check expiry.** On the license page, look at the **Expires** date. If it has passed, this is not an update issue — renew in the hub.

**4. Still Community?** Then the token failed verification under the new code (likely a faulty package). **Restore from the backup** the updater is REQUIRED to make before overwriting code:

```bash
cd /var/www/casa
ls -t writable/backups/pre-update-*-app.tar.gz | head -1   # find the latest backup
# restore the previous code version:
tar -xzf writable/backups/pre-update-<old-version>-<stamp>-app.tar.gz
sudo systemctl restart php-fpm
```

Once the old code is back, the license recovers. Then report to support so the package is fixed before you update again.

## Prevention

- **Always** run `sudo systemctl restart php-fpm` right after an update (clears opcache).
- Do not delete the `writable/backups/` folder — that is where the update safety net lives.
- Download update packages **only** from the official **Download App** / **Update Application** menu (its checksum is verified automatically).

## Need help?

Contact support with: the app version (footer), the tier shown, and the contents of the **Engine Health** page. See the **Support & How to Get Help** guide.
