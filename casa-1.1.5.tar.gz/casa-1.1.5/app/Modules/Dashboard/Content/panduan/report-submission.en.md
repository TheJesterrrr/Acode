## Draft Report

Menu **Reports** → pick a finding → **Draft Report**. Choose a platform: **HackerOne** (CVSS + CWE) or **Bugcrowd** (VRT / P1–P5). CASA fills in the skeleton:

`Title · Severity · Summary · Affected Asset · Steps to Reproduce · Proof of Concept · Impact · Remediation · References`

Then **Copy Markdown** / **Download .md** to paste into the platform, and **Save as Submission** to track it.

## Don't look "AI/scanner-written"

Triagers often reject reports that look like raw automated-scanner output. An accepted report = **evidence of manual verification**:

1. **Steps to Reproduce** & **Proof of Concept** in the draft are marked **FILL IN MANUALLY** — write the steps **you** actually took (e.g. in Burp Repeater), not raw tool output.
2. Paste **raw HTTP request/response** from Burp + a **screenshot**.
3. Describe **concrete** impact (what data/access/money an attacker actually gets).
4. CASA provides a **per-type verification checklist** (IDOR, XSS, SQLi, SSRF, Auth, …) as a step-by-step guide.

> CASA **never auto-submits**. It only prepares a draft; you verify it, complete the evidence, and submit it yourself.

## Submissions tracker

Menu **Submissions**: track each report — status (`draft → submitted → triaged → accepted | duplicate | na | resolved`), **bounty ($)**, and **External ID** (the report number on the platform). An Accepted/Duplicate/total-payout summary shows at the top.
