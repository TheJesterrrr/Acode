**Code: CASA-E002**

## Symptoms

No task shows an Error status, cron is already installed (see the **Worker Never Runs** guide), but the mission still sits idle for hours.

## Cause

Usually one scan tool (most often `amass`, `katana`, or `nmap` during a Deep scan on a large target) leaves behind a process that stays alive far longer than reasonable and holds the queue lock (`/var/www/casa/writable/locks/casa-work.lock`), so every subsequent worker tick silently backs off without anything ever being recorded as an error.

## Steps (SSH into the CASA server)

```bash
# 1. Check whether the queue lock file exists & how old it is
ls -la /var/www/casa/writable/locks/casa-work.lock

# 2. Look for a scan tool process that's been running for a very long time
#    (high ELAPSED column, e.g. hours) — that's the likely culprit
ps -eo pid,etime,cmd | grep -E "amass|katana|nmap|naabu|nuclei|httpx|testssl|ffuf" | grep -v grep

# 3. If you find a process with an unreasonable age (compare ELAPSED against a
#    normal scan duration in Engine Health), force-kill it — replace <PID> with
#    the PID from the first column of step 2's output
sudo kill -9 <PID>

# 4. Run the worker manually to confirm the queue is released & moving again
cd /var/www/casa && php spark casa:work
```

If step 4 succeeds in processing a task (output like `casa:work — N task(s) processed`), the mission will continue automatically via cron as usual.
