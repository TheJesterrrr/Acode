## Vulnerability Management board

The **Vulnerabilities** menu collects **every finding across all projects** into one triage board — similar to a PlexTrac-style vulnerability management flow. This is where you track remediation from start to finish.

## Remediation status

| Status | Meaning |
|---|---|
| Open | Not yet addressed |
| In Progress | Being fixed |
| Fixed | Already fixed |
| Risk Accepted | Risk accepted (won't fix) |
| False Positive | Not a real vulnerability |

## How to triage

1. Open the **Vulnerabilities** menu. The tabs at the top filter by status; there's also a **severity** filter and search.
2. Click the **pencil** icon on a finding to open the triage panel.
3. Change the **remediation status**, assign an **owner**, and add **notes**.
4. Save — progress is reflected immediately on the Dashboard (Remediation Progress).

> This status is separate from AI validation (which judges false positives automatically during a mission). You always have the final say.
