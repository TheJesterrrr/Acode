## Bug Bounty mode

Bug Bounty is one of CASA's **two modes** (switch via the **Pentest / Bounty** toggle above the sidebar). The scan engine is the same as Pentesting; what differs is **how it works**:

| | Pentesting | Bug Bounty |
|---|---|---|
| Unit of work | Project (authorized client) | **Program** (HackerOne/Bugcrowd) |
| Scope | Client ROE | **Strict** in/out scope — must be followed |
| Focus | Depth per target | **Broad recon** + new findings |
| Output | Formal report (PDF) | Platform-format **Submission** + status tracking |

## Why it's separate

Bug bounty programs have their own rules: scope that must never be violated, often **banning automated scanners**, and valuing **manual proof** (Burp). Bounty mode configures CASA to follow those rules: scope is enforced, scanning can be forced lighter, and reports are designed to look human-verified.

## Where CASA fits in bug bounty

CASA is a **recon + triage + report-assist** engine. Top-tier bugs (IDOR, auth, business logic) are still found by **you, manually, in Burp** — the results are then **Imported** into CASA. CASA doesn't replace manual hunting; it speeds up recon and cleans up reporting.

> Start at **Programs** → set scope → **Bounty Scan** (recon) → manual hunting → **Import** → **Report** → **Submissions**.
