## Apa itu CASA

CASA (CoreNet Autonomous Security Agent) adalah platform **Pentest**. Satu portal menjalankan siklus penuh: Recon, scan Vulnerability, validasi temuan, sampai penulisan Report. AI dipakai untuk membantu menyusun rencana Mission, menyaring false-positive, dan merapikan Report; eksekusi scan tetap dijalankan Tool nyata (nmap, nuclei, httpx, dll).

Beda dari scanner biasa: ada **Policy Engine** (gerbang scope & etika) dan validasi untuk kelas kerentanan yang butuh konteks — IDOR/BOLA dan Business Logic — yang umumnya lolos dari scanner berbasis pola.

## Alur inti

```
Mission -> Planning -> Execution -> Validation -> Reporting
```

- **Mission** — Anda beri target dan aturan.
- **Planning** — CASA memilih tool yang tepat dan diizinkan.
- **Execution** — pemindaian dijalankan (recon sampai vuln scan).
- **Validation** — AI menyaring false-positive.
- **Reporting** — laporan siap kirim disusun otomatis.

## Dua mode, satu aplikasi

CASA memakai **satu basis kode** yang berjalan dalam **dua mode**, dibedakan otomatis oleh ada/tidaknya lisensi owner:

| Mode | Di mana | Untuk |
|---|---|---|
| **Hub (casamember)** | Server pemilik CASA | Langganan & koin, download/update app, panduan, akun. **Tanpa modul pentest.** |
| **Instance produk** | VPS/server **milik Anda** | Portal pentest penuh: Projects, Missions, Attack Surface, Findings, Reports, Lab — plus pengaturan Lisensi/Tool/AI. **Tanpa billing.** |

Kenapa dipisah: pemindaian berat dan butuh akses root, jadi **beban scan ditaruh di server pelanggan**, bukan di server pemilik. Anda beli di hub, lalu memindai dari instance sendiri.

> Di instance, satu akun pemilik tetap melihat dua alamat — `casaadmin.…` (Lisensi, Tool Manager, AI, Tim, Audit) dan `casamember.…` (kerja pentest). Alamat menentukan tampilan; akunnya satu.

## Sebelum mulai: legalitas

Hanya pindai aset yang Anda miliki atau yang diizinkan secara tertulis. Policy Engine menegakkan etika secara teknis, tetapi tanggung jawab hukum tetap ada pada Anda.
