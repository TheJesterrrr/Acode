## Subscriptions, upgrades & proration

In the **Subscription & Coins** menu you can **top up coins** then **subscribe** to Pro/Enterprise. Coins are deducted, then a **license key** is issued to activate on your CASA instance (see the **License & Activation** guide).

## Fair upgrade pricing (proration)

If you **upgrade** while a subscription is still active, you **don't** pay the full price — only the **difference**. The remaining value of your current plan is credited automatically:

```
remaining credit = coins paid × (days left ÷ total days)
charge           = new plan price − remaining credit   (minimum 0)
```

**Example:** You buy **Pro** (150,000 coins, 1 month), then upgrade to **Enterprise** (500,000 coins) the same day. Since Pro was barely used, its credit is ≈150,000 → you're only charged **≈350,000 coins**, not 500,000.

## Good to know

- After an upgrade, the old subscription is **replaced** — there's never two active subscriptions stacked. The **newest** plan applies.
- Your **plan badge** (Community/Pro/Enterprise) follows your active subscription.
- **Downgrading**: if the remaining credit is larger than the new plan's price, the charge becomes **0**.
- Every charge/credit is logged in **Coin History** for transparency.

> Think a charge looks wrong? Contact the owner — an incorrect full charge can be corrected via a coin grant.
