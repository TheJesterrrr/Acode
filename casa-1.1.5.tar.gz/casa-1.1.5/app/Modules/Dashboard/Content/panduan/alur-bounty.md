## Alur kerja bug bounty di CASA

```
Program (scope) → Bounty Scan (recon) → Hunting manual (Burp) → Import → Report → Submission
```

### 1. Program & scope
Buat program, tetapkan scope in/out (lihat **Program & Scope**).

### 2. Bounty Scan (recon)
Dari halaman program → **Mulai Bounty Scan**. CASA menjalankan recon in-scope: subdomain, DNS, HTTP probing, port/service, TLS, fingerprint, crawl, screenshot. Bila program **mengizinkan automated scanner**, Vulnerability Assessment (Nuclei) ikut; bila tidak, scan dipaksa **Light** tanpa mass-scan. Aset muncul di **Recon Monitor**.

### 3. Hunting manual (Burp)
Nilai bug bounty ada di sini. Pakai **Burp Suite** (Proxy/Repeater/Intruder) untuk uji IDOR, auth, business logic, dsb pada aset in-scope. CASA tidak menjalankan Burp — ini kerja Anda.

### 4. Import
Menu **Import**: unggah **XML Burp** (Target → kanan-klik → *Report issues* → XML) atau tambah **finding manual**. Finding masuk ke program terpilih.

### 5. Report
Menu **Reports** atau **Findings** → pilih finding → **Draft Report**. CASA menyusun kerangka H1/Bugcrowd; bagian **Steps** & **PoC** Anda isi manual (bukti Burp).

### 6. Submission
Dari report → **Simpan sebagai Submission**. Lacak statusnya (submitted → triaged → accepted/duplicate/resolved) + payout di menu **Submissions**.

> Findings dari scan otomatis = bahan **triase**, bukan bukti akhir. Selalu verifikasi manual sebelum submit.
