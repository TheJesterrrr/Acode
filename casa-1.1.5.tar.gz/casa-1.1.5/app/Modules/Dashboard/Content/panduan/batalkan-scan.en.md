## When to use this

A **Deep**-depth scan on a large target can run for a long time (tens of minutes to hours). Once it's enough, or you picked the wrong target, stop it with the Cancel button — don't just close the tab, the mission keeps running on the server if you don't cancel it.

## Steps

1. Open the running mission.
2. Click **Cancel**.
3. Tasks that haven't started yet are skipped automatically; the task currently running is stopped at the end of its current step (not force-killed mid-step).

## Tips to avoid this

Pick **Standard** depth (not Deep) for large targets/enterprise sites unless you genuinely need full coverage — Deep is much heavier on RAM & time. See the **Scan Templates** guide for what each depth means.
