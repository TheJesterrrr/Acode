## Apa itu Attack Surface

Menu **Attack Surface** menampilkan **inventaris aset** yang ditemukan CASA lintas seluruh project Anda — hasil recon mission (httpx, subfinder, naabu, katana, dll.). Ini "peta permukaan serangan" target Anda.

## Jenis aset

| Jenis | Contoh |
|---|---|
| Host / IP | server, alamat IP |
| Subdomain / Domain | api.contoh.com |
| URL / Endpoint | https://contoh.com/login |
| Service / Port | 443/https, 22/ssh |
| Teknologi | nginx, WordPress, PHP |

## Cara pakai

1. Buka menu **Attack Surface**.
2. Kartu statistik di atas menampilkan jumlah per jenis — **klik** untuk memfilter.
3. Gunakan kotak **cari** untuk menemukan aset tertentu (host, url, teknologi).
4. Tiap baris menunjukkan nilai aset, sumber (tool penemu), dan project asalnya.

> Aset terisi setelah Anda menjalankan **Mission** (recon) pada sebuah project. Belum ada aset? Luncurkan mission dulu.
