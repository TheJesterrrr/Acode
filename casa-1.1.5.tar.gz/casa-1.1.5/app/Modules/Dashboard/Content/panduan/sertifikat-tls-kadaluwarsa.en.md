**Code: CASA-E012**

## Symptoms

The browser shows a "Not Secure" / "Your connection is not private" warning when opening the CASA portal over HTTPS, even though it worked fine before.

## Cause

A TLS certificate (e.g. from Let's Encrypt) has a limited lifetime (90 days for Let's Encrypt) and is usually renewed automatically via a cron job — if that renewal cron stops running (server moved, forgot to reinstall it after a migration, etc), the certificate expires with no warning.

## Steps (SSH into the CASA server)

```bash
# 1. Check the expiry date of the certificate currently in use
echo | openssl s_client -connect localhost:443 -servername YOUR-DOMAIN 2>/dev/null | openssl x509 -noout -dates

# 2. If using Certbot (Let's Encrypt), check the status of all installed certificates
sudo certbot certificates

# 3. Check whether the auto-renewal cron is still installed
sudo systemctl status certbot-renew.timer 2>/dev/null || crontab -l | grep certbot

# 4. If it's missing/stopped, renew manually first
sudo certbot renew --force-renewal

# 5. Reinstall the renewal cron if it went missing
sudo systemctl enable --now certbot-renew.timer
```

> After a successful manual renewal, restart the web server (`sudo systemctl restart httpd`) so the new certificate takes effect immediately.
