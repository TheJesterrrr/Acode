## Lab lanjutan (Pro/Enterprise)

Kelas kerentanan yang butuh konteks — bukan sekadar pola pemindai. Diakses per-project.

## IDOR / BOLA — CWE-639

Uji akses objek antar-pengguna secara terautentikasi.

1. Isi dua **Test Account** (A & B) pada project.
2. Buka **projects → (project) → IDOR**.
3. CASA login sebagai A, lalu mencoba mengakses objek milik B — *login A → tukar token B → replay → bandingkan* — dan memberi verdict.

## AuthZ Matrix — CWE-863

Matriks **endpoint × peran** (termasuk Anonymous). CASA menguji tiap kombinasi dan menandai akses yang lolos padahal seharusnya ditolak (Broken Access Control).

## Business Logic — CWE-840

Uji manipulasi logika bisnis: kuantitas negatif/nol/berlebih, ubah harga, replay transaksi — kelemahan yang tak terdeteksi pemindai biasa.

## Automation

Jadwalkan **Mission** berulang (mingguan, dll.) untuk pemantauan berkelanjutan. Diakses dari halaman project.

> Fitur bertanda Pro/Enterprise memerlukan lisensi aktif — lihat panduan **Lisensi & Aktivasi**.
