**Code: CASA-E005**

## Symptoms

A mission suddenly skips a step with *"Tool not installed"*, even though that tool worked fine before. This usually shows up after the server runs `dnf update`/`apt upgrade`, or after a VM restore/clone.

## Cause

Some tools (especially ones with `install_method` = `system`, e.g. nmap, nikto) are installed via the OS package manager rather than downloaded by CASA itself. An OS update can sometimes relocate a binary, remove a package it considers unused, or change the version enough that the old path stored in CASA's database (`bin_path`) is no longer valid.

## Steps

**1. Confirm via the GUI first** — the **Tools** menu (Tool Manager), find the tool named in the error message. If its status isn't "Installed," that confirms the diagnosis.

**2. Check via CLI (SSH into the server) — find the path that tool actually uses now:**

```bash
# Replace <binary-name> with the tool, e.g. nmap, nikto.pl
which <binary-name>
```

**3a. If `which` finds a new path** — the tool is still there, just moved. Update CASA's `bin_path` to the new path from the **Tools** menu (there's usually a re-verify button), or see the **Check Tool Status via CLI** guide for how to update it manually via the database.

**3b. If `which` finds nothing** — the tool is genuinely gone, reinstall it:

```bash
# Example for a system package (AlmaLinux/RHEL) — adjust the package name
sudo dnf install -y nmap nikto
```

For tools CASA installs itself (github_release/python/go), reinstall them via the **Install** button in the Tools menu — don't do it manually, so `bin_path` in the database gets recorded correctly.

> See the **Check Tool Status via CLI** guide to check the health of all 24 tools at once, instead of one at a time.
