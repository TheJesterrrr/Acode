## Peta Menu & Fungsi

Rujukan lengkap seluruh menu aplikasi CASA (portal terpadu). Baca sekali sebelum mulai agar tahu harus ke mana. Menu grup **PENGATURAN** hanya muncul untuk peran **owner** akun.

## NAVIGASI

| Menu | Fungsi |
|---|---|
| **Assessment Baru** | Pemindaian **satu-klik**. Cukup masukkan satu target (URL/domain/repo git/image) → CASA otomatis: buat Project → tambah Target → pasang Policy aman → jalankan Mission (recon → pindai → validasi AI → laporan). Cocok untuk pemula; tak perlu paham tool. |
| **Scan Templates** | Pilih **profil pemindaian** bila ingin mengatur sendiri (tidak otomatis penuh seperti Assessment Baru). Menentukan kapabilitas/tool mana yang dipakai pada sebuah assessment. |
| **Dashboard** | Ringkasan: **Risk Score**, jumlah Missions/Projects/Findings/Reports, progres remediasi, tren temuan 8 minggu, aset paling berisiko, dan postur OWASP. "Jangan ramai" — hanya angka yang menuntut tindakan. |
| **Missions** | Daftar & **progres misi** pemindaian. Buka satu misi untuk melihat tiap langkah (DNS → Subdomain → Port Scan → … ), status tiap task (pending/running/done), dan jumlah temuan. Mission dijalankan **worker** (cron), bukan dari klik — halaman menyegar otomatis. |
| **Projects** | **Wadah** sebuah penilaian: kumpulan Target + Policy + seluruh hasil (Findings, Reports). Satu target besar = satu Project. Di dalam Project ada sub-fitur (lihat bagian *Di dalam Project*). |
| **Attack Surface** | **Inventaris aset** hasil recon lintas Project: subdomain, host, URL, port/service yang ditemukan. Peta "permukaan serang" target. |
| **Vulnerabilities** | **Triase temuan**: seluruh kerentanan dari semua Project dalam satu tabel. Ubah status remediasi (Open → In Progress → Fixed → Risk Accepted → False Positive), filter per severity. |
| **Compliance** | Postur temuan terhadap **OWASP Top-10** — memetakan temuan ke kategori standar untuk laporan kepatuhan. |
| **Reports** | **Laporan** per Project, siap kirim. Ekspor PDF tersedia pada paket Pro. |
| **Panduan Penggunaan** | Dokumentasi ini. |

## PENGATURAN (hanya owner)

| Menu | Fungsi |
|---|---|
| **Lisensi & Aktivasi** | Lihat paket aktif (Community/Pro/Enterprise) dan **aktifkan** Pro/Enterprise dengan menempel *license key* / Kode Sinkron yang diperoleh dari hub (Langganan & Koin). |
| **Tools** (Tool Manager) | Daftar **kapabilitas & tool** yang terpasang di server. Pasang/verifikasi tool, perbarui konten deteksi (template Nuclei). "Aktif" = tool ada di server; pemakaian tool ofensif tetap tunduk pada paket. |
| **AI Settings** | Atur **penyedia AI & model** (mis. Ollama lokal) yang dipakai untuk perencanaan misi, validasi false-positive, dan penulisan laporan. |
| **Engine Health** | Status **engine & worker** (casad): antrean task, job terjadwal, phone-home. Untuk memastikan scan benar-benar berjalan. |
| **Integrasi** | **Webhook/integrasi** keluar (mis. notifikasi ke layanan lain). |
| **Pengaturan** | Setelan platform umum (identitas, preferensi, dsb.). |
| **Audit Log** | **Jejak aksi** di aplikasi (siapa melakukan apa, kapan) — untuk akuntabilitas & forensik. |

## AKUN

| Menu | Fungsi |
|---|---|
| **Tim** | Kelola **anggota tim & peran**: `owner` (akses penuh), `analyst` (jalankan scan, kelola temuan), `viewer` (hanya lihat). Tambah/hapus anggota. |
| **Akun Saya** | Profil, **ganti kata sandi**, dan **Kode Sinkron** (secret) akun. |

## Di dalam sebuah Project

Buka sebuah Project untuk mengakses sub-fitur lanjutan (sebagian hanya Pro):

| Sub-fitur | Fungsi |
|---|---|
| **Policy** | **Gerbang etika wajib** sebelum Mission. Menentukan tool **Allowed/Blocked** + batasan (no brute-force / no DoS / no injeksi agresif). Assessment Baru memasang Policy default aman otomatis. |
| **Targets** | Daftar target dalam Project (domain, URL, repo, image). Tunduk kuota paket. |
| **IDOR / BOLA** *(Pro)* | Workbench uji **Broken Object Level Authorization** — kerentanan logika akses yang tak terdeteksi pemindai pola. |
| **AuthZ Matrix** *(Pro)* | Uji **Broken Access Control** antar peran/akun secara sistematis. |
| **Business Logic** *(Pro)* | Lab uji **kerentanan logika bisnis** (alur yang bisa disalahgunakan). |
| **Automation** *(Pro)* | **Pemindaian terjadwal** (berkala otomatis). |

## Legenda status

**Mission:** `planning` → `executing` → `validating` → `reporting` → `done` (atau `error`).
**Task (per tool):** `pending` (antre) → `running` (jalan) → `done`.
**Temuan (remediasi):** Open · In Progress · Fixed · Risk Accepted · False Positive.

> Catatan paket: menu tampil sama untuk semua paket, tetapi **pemakaian** fitur ofensif (Vulnerability/SQLi/XSS/IDOR/AuthZ/Business Logic), scan terjadwal, ekspor PDF, serta kuota Project/Target mengikuti paket Anda (Community/Pro/Enterprise). Lihat **Lisensi & Aktivasi**.
