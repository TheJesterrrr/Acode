## Symptoms

The CASA page won't load at all (not just a stuck mission), usually after a heavy scan ran overnight.

## Steps (SSH into the CASA server)

```bash
# 1. Make sure the VM itself is still up
ping -c 3 <CASA_VM_IP>
```

If the ping replies but the web page still won't load — the VM is alive, only the web process died. SSH in, then:

```bash
# 2. Check the web service status
sudo systemctl status httpd

# 3. If the status is "inactive"/"failed", restart it
sudo systemctl restart httpd

# 4. Check remaining RAM — if it's consistently tight, this is the most common root cause
free -h
```

> If RAM turns out to be a recurring cause, the long-term fix is increasing the VM's RAM — not just restarting the service every time.
