## Gejala

Halaman CASA sama sekali tidak bisa dibuka (bukan cuma mission yang macet), biasanya setelah scan berat semalaman.

## Langkah (SSH ke server CASA)

```bash
# 1. Pastikan VM-nya sendiri masih hidup
ping -c 3 <IP_VM_CASA>
```

Kalau ping balas tapi halaman web tetap tak bisa dibuka — VM hidup, cuma proses web-nya yang mati. SSH masuk lalu:

```bash
# 2. Cek status layanan web
sudo systemctl status httpd

# 3. Kalau statusnya "inactive"/"failed", nyalakan ulang
sudo systemctl restart httpd

# 4. Cek sisa RAM — kalau mepet terus-menerus, ini akar penyebab paling umum
free -h
```

> Kalau RAM memang jadi penyebab berulang, solusi jangka panjang adalah menambah RAM VM — bukan sekadar restart layanan tiap kali.
