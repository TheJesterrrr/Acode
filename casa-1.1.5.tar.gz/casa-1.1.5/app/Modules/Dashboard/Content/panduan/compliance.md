## Postur kepatuhan

Menu **Compliance** menunjukkan sebaran temuan Anda terhadap **OWASP Top-10 (2021)** dan **CWE** teratas. Berguna untuk melihat kategori risiko mana yang paling terdampak dan mana yang masih "bersih".

## OWASP Top-10 (2021)

| Kode | Kategori |
|---|---|
| A01 | Broken Access Control |
| A02 | Cryptographic Failures |
| A03 | Injection |
| A04 | Insecure Design |
| A05 | Security Misconfiguration |
| A06 | Vulnerable & Outdated Components |
| A07 | Identification & Authentication Failures |
| A08 | Software & Data Integrity Failures |
| A09 | Security Logging & Monitoring Failures |
| A10 | Server-Side Request Forgery (SSRF) |

## Cara baca

- Tiap kategori menunjukkan jumlah temuan + rincian severity, atau tanda **bersih** bila nihil.
- Klik jumlah temuan untuk melompat ke daftar **Vulnerabilities** kategori itu.
- Panel **CWE teratas** merangkum kelemahan paling sering muncul.

Pemetaan CWE→OWASP mengikuti standar (Kitab BAB V 5.2) dan otomatis dari temuan.
