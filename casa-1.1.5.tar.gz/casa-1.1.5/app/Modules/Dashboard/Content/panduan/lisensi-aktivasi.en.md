## Editions

| Edition | Includes |
|---|---|
| Community | Basic recon & scanning, single user — free. |
| Pro | IDOR Workbench, AuthZ Matrix, Business Logic, Automation, PDF, team. |
| Enterprise | Larger quotas + advanced capabilities. |

Without a license, CASA runs fully on **Community**.

## Activation (Online Sync)

Done once; after that it's automatic.

1. In your online member account (casamember portal) → **My Account** → copy the **Instance Sync Code**.
2. On your CASA instance: **admin portal → License & Activation → Online Sync**.
3. Paste the Sync Code → **Sync now**. Features unlock according to your subscription.

## Renewing / upgrading tier

Buy/renew your subscription on the online member portal. Your instance pulls the latest license **automatically** on its next sync (daily) — no need to re-enter a code.

> License verification runs **offline** (via an embedded public key). Only activation & updates need an internet connection.
