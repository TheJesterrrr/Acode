## Gejala

Setelah **Update Aplikasi** ke versi baru, aplikasi tiba-tiba memperlakukan Anda sebagai tier **Community** — fitur Pro/Enterprise terkunci, kuota mengecil — padahal langganan Anda masih aktif.

> **Kabar baik:** lisensi Anda **tidak benar-benar hilang**. Token lisensi tersimpan di database instance Anda dan **tidak** disentuh oleh proses update. Yang terjadi hanyalah token itu gagal diverifikasi sesaat. Ikuti langkah di bawah untuk memulihkannya.

## Kenapa ini bisa terjadi

Aplikasi memverifikasi ulang token lisensi Anda setiap kali dengan **kunci publik** yang tertanam di kode. Jika verifikasi gagal, tier otomatis turun ke Community demi aman. Penyebab tersering:

1. **Cache kode lama (opcache)** masih memuat kode versi sebelumnya setelah file ditimpa.
2. **Token kedaluwarsa** persis saat update (kebetulan waktu) — bukan efek update.
3. **Paket update cacat** yang membawa kunci publik keliru (seharusnya tak terjadi: paket rilis resmi diverifikasi checksum dan dibangun dari sumber produksi).

## Pemulihan (urut dari yang paling ringan)

**1. Bersihkan cache kode & muat ulang.** Di server instance Anda:

```bash
sudo systemctl restart php-fpm   # bersihkan opcache (disarankan setelah SETIAP update)
```

Buka ulang halaman **Lisensi & Aktivasi**. Sering kali tier langsung kembali normal.

**2. Sinkron ulang lisensi dari Hub.** Di menu **Lisensi & Aktivasi**, klik **Sinkron Sekarang** (atau tempel ulang **Kode Sinkron** dari menu *Langganan & Koin* di hub `casamember`). Ini menarik ulang token terbaru sesuai langganan Anda.

**3. Cek masa berlaku.** Di halaman lisensi, lihat tanggal **Kedaluwarsa**. Bila sudah lewat, ini bukan soal update — perpanjang langganan di hub.

**4. Masih Community?** Berarti token gagal diverifikasi oleh kode versi baru (kemungkinan paket cacat). **Pulihkan dari backup** yang WAJIB dibuat updater sebelum menimpa kode:

```bash
cd /var/www/casa
ls -t writable/backups/pre-update-*-app.tar.gz | head -1   # cari backup terbaru
# kembalikan kode versi sebelumnya:
tar -xzf writable/backups/pre-update-<versi-lama>-<stamp>-app.tar.gz
sudo systemctl restart php-fpm
```

Setelah kode lama kembali, lisensi pulih. Lalu laporkan ke support agar paket diperbaiki sebelum Anda update lagi.

## Mencegahnya

- **Selalu** jalankan `sudo systemctl restart php-fpm` sesaat setelah update (membersihkan opcache).
- Jangan hapus folder `writable/backups/` — di situlah jaring pengaman update berada.
- Unduh paket update **hanya** dari menu resmi **Download App** / **Update Aplikasi** (checksum-nya diverifikasi otomatis).

## Butuh bantuan?

Hubungi support dengan menyertakan: versi aplikasi (footer), tier yang tampil, dan isi halaman **Engine Health**. Lihat panduan **Dukungan & Cara Minta Bantuan**.
