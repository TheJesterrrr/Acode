## Why you install the app yourself

This portal (**casamember**) is a **transaction hub**: where you top up coins, subscribe, and grab your license key. The pentest engine itself does **not** run here — scanning (nmap, recon, vuln scan) needs full server access and isn't possible on shared hosting.

That's why CASA is installed as a **standalone app on your own VPS/server**. The owner's server stays light, and you scan from your own legitimate IP.

## Download & install steps

1. Open the **Download App** menu. Pick the package for your target:
   - **VPS / Linux (native)** — `.tar.gz`, for AlmaLinux/Ubuntu servers.
   - **Docker (Win/Mac/Linux)** — `.zip`, runs anywhere Docker runs.
   - **Windows (1-click)** — `.exe`, an automatic installer.
2. Download it, then run `install.sh` (or the installer) on your server. Follow the instructions in the package's README.
3. Once the instance portal is live, open the **License & Activation** menu on that instance and paste the **license key** from your subscription (see the **License & Activation** guide).

> The license key is downloaded from the **Subscription & Coins** menu on this hub — not on the instance.

## Updating to the latest version

The hub dashboard shows the **latest available version**. If it's newer than what you have installed:

1. Download the new version's package from **Download App**.
2. On your server, run the package's built-in update script (it replaces the app's code and runs database migrations, without deleting your data).
3. Your license and pentest data stay intact — the update only touches the app's code.

> Always **back up** your instance's database before updating. An active subscription doesn't need to be reactivated after an update.

## Common issues

- **Package not showing in Download App** — the owner hasn't uploaded a release yet. Contact the admin.
- **Dashboard version looks older than my instance** — you're already on the latest; ignore it.
- **License "invalid" after moving servers** — activation is bound to an instance; ask the owner for an activation reset.
