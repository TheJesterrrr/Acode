## Bug bounty workflow in CASA

```
Program (scope) → Bounty Scan (recon) → Manual hunting (Burp) → Import → Report → Submission
```

### 1. Program & scope
Create a program, set in/out scope (see **Program & Scope**).

### 2. Bounty Scan (recon)
From the program page → **Start Bounty Scan**. CASA runs in-scope recon: subdomains, DNS, HTTP probing, ports/services, TLS, fingerprinting, crawling, screenshots. If the program **allows automated scanners**, Vulnerability Assessment (Nuclei) runs too; otherwise the scan is forced to **Light** with no mass-scanning. Assets appear in **Recon Monitor**.

### 3. Manual hunting (Burp)
This is where the real bug bounty value is. Use **Burp Suite** (Proxy/Repeater/Intruder) to test IDOR, auth, business logic, etc on in-scope assets. CASA doesn't run Burp for you — this is your work.

### 4. Import
Menu **Import**: upload a **Burp XML** export (Target → right-click → *Report issues* → XML) or add a **manual finding**. Findings land in the selected program.

### 5. Report
Menu **Reports** or **Findings** → pick a finding → **Draft Report**. CASA builds an H1/Bugcrowd skeleton; you fill in **Steps** & **PoC** manually (your Burp evidence).

### 6. Submission
From the report → **Save as Submission**. Track its status (submitted → triaged → accepted/duplicate/resolved) + payout under the **Submissions** menu.

> Findings from automated scanning are **triage material**, not final proof. Always verify manually before submitting.
