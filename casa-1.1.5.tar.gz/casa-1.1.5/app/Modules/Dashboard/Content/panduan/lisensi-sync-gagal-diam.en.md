**Code: CASA-E008**

## Symptoms

A Pro/Enterprise feature that was previously active suddenly locks again, even though the subscription is still running and nobody intentionally changed anything in the app.

## Cause

The CASA instance syncs its license **daily** (at 03:30) via the `casa:sync` cron job to the owner's server, **silently** — its output is discarded (`>/dev/null`), so if it fails, **there's no notification at all** in the app. The most common cause: the server's firewall/outbound HTTPS changed (e.g. got tightened), so the instance can no longer reach the owner's server to pull the latest subscription status.

## Steps (SSH into the CASA server)

```bash
# 1. Run the sync manually to see its message directly (normally discarded
#    by cron, here we see it as-is)
cd /var/www/casa && php spark casa:sync
```

- If it shows **"Sync OK — ..."** → the earlier cron run just happened to fail once (a brief network blip, etc), it has now recovered.
- If it shows **"Sync skipped/failed — ..."** → read the error message, continue to step 2.

```bash
# 2. Test outbound connectivity to the owner's server (replace the domain
#    with whichever one your program uses)
curl -I https://casamember.corenet.web.id --max-time 10

# 3. If curl times out/fails, check the outbound firewall rules
sudo firewall-cmd --list-all   # or: sudo iptables -L -n
```

If the firewall is indeed blocking it, add an exception for outbound HTTPS traffic (port 443) to the owner server's domain, then repeat step 1.

> License verification itself still works **offline** (see the **License & Activation** guide) — what's broken here is just the process of pulling the LATEST subscription status. If it hasn't synced in a long time, the instance's status can lag behind what's actually on the owner's server.
