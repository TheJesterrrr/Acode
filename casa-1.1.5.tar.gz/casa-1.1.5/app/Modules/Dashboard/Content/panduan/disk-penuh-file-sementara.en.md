**Code: CASA-E006**

## Symptoms

Scans fail with unclear, odd errors (can't write a file, tool won't start, etc), even though everything was fine before. This often shows up after several worker crash/OOM incidents (see the **Mission Stuck / Frozen** guide).

## Cause

Each tool adapter writes a temporary file to `/tmp` (e.g. `/tmp/casa_ffuf_*.json`, `/tmp/casa_nuclei_*.json`) and deletes it itself once it's done reading the result. If the worker **crashes mid-task** (out of memory) before it gets to delete it, that file is **left behind forever**. Over time — especially on a VM with a history of frequent OOM — `/tmp` can fill up with thousands of leftover files, and once the disk is full, almost everything (writing files, the database, logs) starts failing in confusing ways.

## Steps (SSH into the CASA server)

```bash
# 1. Check remaining disk space
df -h /

# 2. See how many/how large CASA's leftover temp files are
du -sh /tmp/casa_* 2>/dev/null | tail -1
ls /tmp/casa_* 2>/dev/null | wc -l

# 3. If the count is large/old, it's safe to delete — CASA only needs these
#    files WHILE a scan task is running, not afterward
find /tmp -maxdepth 1 -name "casa_*" -mmin +60 -delete

# 4. Confirm disk space is freed up
df -h /
```

## Preventing recurrence (optional, long-term)

Add a routine cleanup cron line so leftover files are never older than 1 hour, no matter how often the worker crashes:

```bash
(crontab -l 2>/dev/null; echo "0 * * * * find /tmp -maxdepth 1 -name 'casa_*' -mmin +60 -delete") | crontab -
```

> This is safe — a scan task normally finishes within minutes, so any `/tmp/casa_*` file older than 1 hour is almost certainly left over from a process that already died.
