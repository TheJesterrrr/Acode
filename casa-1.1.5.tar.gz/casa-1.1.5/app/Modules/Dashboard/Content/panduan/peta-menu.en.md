## Menu Map & Functions

A full reference to every menu in the CASA app (unified portal). Read this once before you start so you know where to go. The **SETTINGS** menu group only appears for the **owner** role.

## NAVIGATION

| Menu | Function |
|---|---|
| **New Assessment** | **One-click** scanning. Just enter a single target (URL/domain/git repo/image) → CASA automatically: creates a Project → adds a Target → applies a safe Policy → runs a Mission (recon → scan → AI validation → report). Great for beginners; no tool knowledge needed. |
| **Scan Templates** | Pick a **scan profile** if you want manual control (not fully automatic like New Assessment). Decides which capabilities/tools are used on an assessment. |
| **Dashboard** | Summary: **Risk Score**, counts of Missions/Projects/Findings/Reports, remediation progress, an 8-week finding trend, the riskiest assets, and OWASP posture. "No noise" — only numbers that demand action. |
| **Missions** | List & **mission progress**. Open a mission to see each step (DNS → Subdomain → Port Scan → …), each task's status (pending/running/done), and the finding count. Missions are run by a **worker** (cron), not by clicking — the page auto-refreshes. |
| **Projects** | A **container** for an assessment: a set of Targets + Policy + all results (Findings, Reports). One large target = one Project. Projects contain sub-features (see *Inside a Project*). |
| **Attack Surface** | **Asset inventory** from recon across all Projects: subdomains, hosts, URLs, ports/services found. A map of the target's "attack surface." |
| **Vulnerabilities** | **Finding triage**: every vulnerability from every Project in one table. Change remediation status (Open → In Progress → Fixed → Risk Accepted → False Positive), filter by severity. |
| **Compliance** | Finding posture against the **OWASP Top 10** — maps findings to standard categories for compliance reporting. |
| **Reports** | Per-Project **reports**, submit-ready. PDF export is available on the Pro plan. |
| **User Guide** | This documentation. |

## SETTINGS (owner only)

| Menu | Function |
|---|---|
| **License & Activation** | View the active plan (Community/Pro/Enterprise) and **activate** Pro/Enterprise by pasting the *license key* / Sync Code obtained from the hub (Subscription & Coins). |
| **Tools** (Tool Manager) | List of **capabilities & tools** installed on the server. Install/verify tools, update detection content (Nuclei templates). "Active" = the tool exists on the server; using offensive tools is still gated by your plan. |
| **AI Settings** | Configure the **AI provider & model** (e.g. local Ollama) used for mission planning, false-positive validation, and report writing. |
| **Engine Health** | Status of the **engine & worker** (casad): task queue, scheduled jobs, phone-home. Confirms scans are actually running. |
| **Integrations** | Outbound **webhooks/integrations** (e.g. notifications to other services). |
| **Settings** | General platform settings (identity, preferences, etc). |
| **Audit Log** | **Action trail** across the app (who did what, when) — for accountability & forensics. |

## ACCOUNT

| Menu | Function |
|---|---|
| **Team** | Manage **team members & roles**: `owner` (full access), `analyst` (run scans, manage findings), `viewer` (read-only). Add/remove members. |
| **My Account** | Profile, **change password**, and the account's **Sync Code** (secret). |

## Inside a Project

Open a Project to access advanced sub-features (some Pro-only):

| Sub-feature | Function |
|---|---|
| **Policy** | A **mandatory ethics gate** before a Mission. Defines **Allowed/Blocked** tools + limits (no brute-force / no DoS / no aggressive injection). New Assessment applies a safe default Policy automatically. |
| **Targets** | List of targets in the Project (domain, URL, repo, image). Subject to plan quota. |
| **IDOR / BOLA** *(Pro)* | A workbench for testing **Broken Object Level Authorization** — access-logic vulnerabilities pattern-based scanners can't detect. |
| **AuthZ Matrix** *(Pro)* | Systematically test **Broken Access Control** across roles/accounts. |
| **Business Logic** *(Pro)* | A lab for testing **business logic vulnerabilities** (flows that can be abused). |
| **Automation** *(Pro)* | **Scheduled scanning** (automatic, recurring). |

## Status legend

**Mission:** `planning` → `executing` → `validating` → `reporting` → `done` (or `error`).
**Task (per tool):** `pending` (queued) → `running` → `done`.
**Finding (remediation):** Open · In Progress · Fixed · Risk Accepted · False Positive.

> Plan note: menus look the same across all plans, but **using** offensive features (Vulnerability/SQLi/XSS/IDOR/AuthZ/Business Logic), scheduled scans, PDF export, and Project/Target quotas follow your plan (Community/Pro/Enterprise). See **License & Activation**.
