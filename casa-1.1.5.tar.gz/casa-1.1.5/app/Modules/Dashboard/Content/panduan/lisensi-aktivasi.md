## Edisi

| Edisi | Isi |
|---|---|
| Community | Recon & pemindaian dasar, satu pengguna — gratis. |
| Pro | IDOR Workbench, AuthZ Matrix, Business Logic, Automation, PDF, tim. |
| Enterprise | Kuota lebih besar + kapabilitas lanjutan. |

Tanpa lisensi, CASA berjalan penuh di **Community**.

## Aktivasi (Sinkron Online)

Cukup sekali; berikutnya otomatis.

1. Di akun member online Anda (portal casamember) → **Akun Saya** → salin **Kode Sinkron Instance**.
2. Di CASA Anda: **portal admin → Lisensi & Aktivasi → Sinkron Online**.
3. Tempel Kode Sinkron → **Sinkron sekarang**. Fitur terbuka sesuai langganan.

## Perpanjang / naik tier

Beli/perpanjang langganan di portal member online. Instance menarik lisensi terbaru **otomatis** pada sinkron berikutnya (harian) — tak perlu memasukkan kode lagi.

> Verifikasi lisensi berjalan **offline** (kunci publik tertanam). Hanya aktivasi & pembaruan yang butuh online.
