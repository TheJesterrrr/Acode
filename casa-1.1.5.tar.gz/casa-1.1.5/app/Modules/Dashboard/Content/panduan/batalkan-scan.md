## Kapan dipakai

Scan depth **Deep** ke target besar bisa berjalan lama (puluhan menit sampai berjam-jam). Kalau sudah cukup atau salah pilih target, hentikan lewat tombol Batalkan — jangan tutup tab begitu saja, mission tetap jalan di server kalau tidak dibatalkan.

## Langkah

1. Buka mission yang sedang berjalan.
2. Klik **Batalkan**.
3. Task yang belum jalan otomatis dilewati; task yang sedang jalan dihentikan di akhir langkah saat ini (bukan dipotong paksa di tengah).

## Tips mencegah

Pilih depth **Standard** (bukan Deep) untuk target besar/situs enterprise kecuali memang perlu cakupan penuh — Deep jauh lebih berat ke RAM & waktu. Lihat panduan **Scan Templates** untuk arti tiap depth.
