**Kode: CASA-E010**

## Gejala

Error database muncul acak di berbagai halaman berbeda ("database error", "connection failed", dll) tanpa pola jelas, biasanya pas banyak scan + laporan jalan bersamaan.

## Penyebab

MySQL/MariaDB punya batas jumlah koneksi bersamaan (`max_connections`, default-nya kadang cuma 100-150). Worker scan (`casad`), tiap halaman yang dibuka pengguna, dan proses generate laporan semuanya butuh koneksi database sendiri-sendiri. Kalau banyak terjadi bersamaan, batas itu bisa tercapai dan koneksi baru ditolak.

## Langkah (SSH ke server CASA)

```bash
# 1. Lihat batas koneksi saat ini & berapa yang sedang dipakai
mysql -u root -p -e "SHOW VARIABLES LIKE 'max_connections'; SHOW STATUS LIKE 'Threads_connected';"

# 2. Lihat query/koneksi apa saja yang sedang aktif (cari yang menumpuk/lama)
mysql -u root -p -e "SHOW PROCESSLIST;"
```

Kalau `Threads_connected` mendekati `max_connections`, itu konfirmasi penyebabnya.

```bash
# 3. Naikkan batas koneksi (sesuaikan angka dengan RAM server — tiap koneksi
#    makan sedikit memori, jangan asal besar)
sudo mysql -u root -p -e "SET GLOBAL max_connections = 300;"

# 4. Simpan permanen supaya tak kembali ke default saat MySQL/MariaDB restart
echo -e "[mysqld]\nmax_connections = 300" | sudo tee /etc/my.cnf.d/casa-connections.cnf
sudo systemctl restart mysqld   # atau: mariadb
```

> Kalau sering kejadian meski sudah dinaikkan, kemungkinan RAM server sendiri yang mepet (lihat panduan **VM / Aplikasi CASA Mati Total**) — menaikkan `max_connections` tanpa RAM cukup bisa memicu OOM baru.
