## What Attack Surface is

The **Attack Surface** menu shows an **asset inventory** CASA found across all your projects — gathered by mission recon (httpx, subfinder, naabu, katana, etc). It's a "map" of your target's attack surface.

## Asset types

| Type | Example |
|---|---|
| Host / IP | server, IP address |
| Subdomain / Domain | api.example.com |
| URL / Endpoint | https://example.com/login |
| Service / Port | 443/https, 22/ssh |
| Technology | nginx, WordPress, PHP |

## How to use it

1. Open the **Attack Surface** menu.
2. The stat cards at the top show counts per type — **click** one to filter.
3. Use the **search** box to find a specific asset (host, url, technology).
4. Each row shows the asset's value, its source (the tool that found it), and its originating project.

> Assets populate after you run a **Mission** (recon) on a project. No assets yet? Launch a mission first.
