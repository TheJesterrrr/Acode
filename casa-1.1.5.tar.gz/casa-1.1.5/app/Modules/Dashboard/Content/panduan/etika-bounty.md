## Patuhi aturan program

Setiap program bug bounty punya aturan (Rules of Engagement). Melanggarnya bisa membuat laporan ditolak, reward hilang, hingga diban. CASA membantu mematuhi, tetapi **tanggung jawab tetap pada Anda**.

## Scope

- Hanya uji aset **in-scope**. Out-of-scope = pelanggaran serius.
- CASA menegakkan scope saat scan, tetapi saat hunting manual (Burp) **Anda** yang menjaga agar tak keluar scope.

## Larangan automated scanner

Banyak program **melarang automated vulnerability scanner** (Nuclei, dsb) dan menerapkan **lockout bila melebihi rate normal**. Di program seperti itu:

- **Jangan centang** "Mengizinkan automated scanner" saat membuat program.
- CASA memaksa scan **Light** + recon saja (tanpa mass-scan) agar aman.
- Lakukan pengujian vuln **manual** lalu Import.

## Rate & beban

Hormati batas laju program. Jangan membebani infrastruktur target. Recon secukupnya; jangan brute-force agresif kecuali diizinkan.

## Hal yang umum dilarang / di-exclude

SPF/DMARC, cookie flags, clickjacking tanpa dampak, self-XSS, missing security headers, banner disclosure, CSRF pada form non-sensitif, rate-limiting, OPTIONS/TRACE — biasanya **tidak eligible**. Daftarkan di **Excluded finding types** program agar CASA menandainya.

## Safe harbor & disclosure

Ikuti ketentuan **safe harbor** program. Jangan mengakses/menyimpan data pengguna lebih dari yang diperlukan untuk PoC. **Jangan publikasikan** temuan sebelum diizinkan (hormati non-disclosure).

> Prinsip: uji hanya yang diizinkan, buktikan seminimal mungkin, laporkan dengan jujur.
