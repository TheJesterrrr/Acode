## Menambah Program

Menu **Programs → Program Baru**. Isi:

- **Nama** & **Platform** (HackerOne / Bugcrowd).
- **URL program** & **URL policy** (opsional).
- **Scope IN** — target yang BOLEH diuji (satu per baris): domain, `*.wildcard`, URL, atau IP.
- **Scope OUT** — yang DIKECUALIKAN (tak akan discan walau cocok wildcard IN).
- **Excluded finding types** — "known issues" program (mis. *Missing security headers, Clickjacking, SPF/DMARC, Self-XSS*) → finding yang cocok ditandai `excluded` agar tak Anda submit sia-sia.
- **Mengizinkan automated scanner** — centang **hanya** bila program mengizinkannya.

## Isi scope otomatis

Panel kanan **"Isi scope otomatis"**: tempel teks policy program (bagian Scope / In Scope / Out of Scope), atau isi URL, lalu **Parse**. CASA menarik host in/out ke kolom kiri — **selalu tinjau & koreksi** sebelum simpan.

> Halaman HackerOne/Bugcrowd sering di balik login/anti-bot, jadi parser dari URL bisa gagal → **salin-tempel teksnya** (paling andal).

## Scope ditegakkan

Saat **Bounty Scan**, CASA hanya menyentuh target **in-scope** (yang juga tak cocok scope OUT). Ini mencegah Anda melanggar aturan program (out-of-scope = pelanggaran, bisa kehilangan reward atau diban).

> Kuota Community: **1 program aktif**. Hapus program untuk membuat yang baru, atau upgrade paket.
