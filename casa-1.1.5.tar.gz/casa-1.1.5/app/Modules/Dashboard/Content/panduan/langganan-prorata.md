## Langganan, upgrade & prorata

Di menu **Langganan & Koin** Anda bisa **topup koin** lalu **berlangganan** Pro/Enterprise. Koin dipotong, lalu **license key** terbit untuk diaktivasi di instance CASA Anda (lihat panduan **Lisensi & Aktivasi**).

## Upgrade dibayar adil (prorata)

Jika Anda **upgrade** saat langganan masih aktif, Anda **tidak** membayar harga penuh — hanya **selisihnya**. Sisa nilai paket berjalan dikreditkan otomatis:

```
kredit sisa = koin dibayar × (hari tersisa ÷ total hari)
potongan    = harga paket baru − kredit sisa   (minimal 0)
```

**Contoh:** Anda beli **Pro** (150.000 koin, 1 bulan), lalu di hari yang sama upgrade ke **Enterprise** (500.000 koin). Karena Pro hampir belum terpakai, kreditnya ≈ 150.000 → yang dipotong hanya **≈ 350.000 koin**, bukan 500.000.

## Yang perlu diketahui

- Setelah upgrade, langganan lama **digantikan** — tak ada dua langganan aktif bertumpuk. Yang berlaku adalah paket **terbaru**.
- **Badge paket** Anda (Community/Pro/Enterprise) mengikuti langganan aktif.
- **Downgrade**: bila kredit sisa lebih besar dari harga paket baru, potongan menjadi **0**.
- Setiap potongan/kredit tercatat di **Riwayat koin** agar transparan.

> Merasa potongan tidak sesuai? Hubungi owner — potongan penuh yang keliru dapat dikoreksi lewat hibah koin.
