**Code: CASA-E010**

## Symptoms

Database errors pop up randomly across different pages ("database error", "connection failed", etc) with no clear pattern, usually when many scans + reports run at the same time.

## Cause

MySQL/MariaDB has a cap on concurrent connections (`max_connections`, sometimes defaulting to as low as 100-150). The scan worker (`casad`), every page a user opens, and report-generation all need their own database connection. If enough of these happen at once, that cap can be hit and new connections get rejected.

## Steps (SSH into the CASA server)

```bash
# 1. Check the current connection limit & how many are in use
mysql -u root -p -e "SHOW VARIABLES LIKE 'max_connections'; SHOW STATUS LIKE 'Threads_connected';"

# 2. See which queries/connections are currently active (look for ones piling up/long-running)
mysql -u root -p -e "SHOW PROCESSLIST;"
```

If `Threads_connected` is close to `max_connections`, that confirms the cause.

```bash
# 3. Raise the connection limit (match the number to the server's RAM — each
#    connection uses a bit of memory, don't set it arbitrarily high)
sudo mysql -u root -p -e "SET GLOBAL max_connections = 300;"

# 4. Save it permanently so it doesn't revert to default on MySQL/MariaDB restart
echo -e "[mysqld]\nmax_connections = 300" | sudo tee /etc/my.cnf.d/casa-connections.cnf
sudo systemctl restart mysqld   # or: mariadb
```

> If this keeps happening even after raising the limit, the server's RAM itself is likely tight (see the **CASA VM / App Completely Down** guide) — raising `max_connections` without enough RAM can trigger a new round of OOM.
