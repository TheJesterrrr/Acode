**Kode: CASA-E008**

## Gejala

Fitur Pro/Enterprise yang sebelumnya aktif tiba-tiba terkunci lagi, padahal langganan masih berjalan dan tak ada yang sengaja mengubah apa pun di aplikasi.

## Penyebab

Instance CASA menyinkronkan lisensi **harian** (jam 03:30) lewat cron `casa:sync` ke server pemilik, secara **diam-diam** — outputnya dibuang (`>/dev/null`), jadi kalau gagal, **tak ada notifikasi sama sekali** di aplikasi. Penyebab paling umum: firewall/outbound HTTPS server berubah (mis. diperketat) sehingga instance tak bisa lagi menghubungi server pemilik untuk menarik status langganan terbaru.

## Langkah (SSH ke server CASA)

```bash
# 1. Jalankan sinkron secara manual untuk melihat pesannya langsung (biasanya
#    dibuang oleh cron, di sini kita lihat apa adanya)
cd /var/www/casa && php spark casa:sync
```

- Kalau muncul **"Sinkron OK — ..."** → cron sebelumnya cuma kebetulan gagal sekali (jaringan sempat putus dsb), sekarang sudah pulih.
- Kalau muncul **"Sinkron dilewati/gagal — ..."** → baca pesan errornya, lanjut ke langkah 2.

```bash
# 2. Tes koneksi keluar ke server pemilik (ganti domain sesuai yang dipakai program)
curl -I https://casamember.corenet.web.id --max-time 10

# 3. Kalau curl timeout/gagal, cek aturan firewall outbound
sudo firewall-cmd --list-all   # atau: sudo iptables -L -n
```

Kalau firewall memang memblokir, tambahkan pengecualian untuk traffic HTTPS keluar (port 443) ke domain server pemilik, lalu ulangi langkah 1.

> Verifikasi lisensi sendiri tetap jalan **offline** (lihat panduan **Lisensi & Aktivasi**) — yang terganggu di sini cuma proses tarik status langganan TERBARU. Kalau sudah lama tak sinkron, status di instance bisa ketinggalan dari yang sebenarnya di server pemilik.
