**Code: CASA-E011**

## Symptoms

Suddenly unable to SSH into the CASA server at all ("connection refused"/"connection timed out"), usually right after firewall rules were tightened (e.g. restricting access to a specific IP only).

## Prevention (do this BEFORE tightening the firewall)

Don't apply a strict rule from the same SSH session you're currently in — if the rule is wrong, you lock yourself out instantly with no way back in. Safe pattern:

```bash
# 1. Open a SECOND SSH window/terminal first (leave the first session open)
#    as a safety net while you test the new rule.

# 2. Apply the new rule in the first session
sudo firewall-cmd --permanent --add-rich-rule='rule family="ipv4" source address="YOUR-IP/32" port port="22" protocol="tcp" accept'
sudo firewall-cmd --permanent --remove-service=ssh   # if you want to close general access
sudo firewall-cmd --reload

# 3. BEFORE closing the first session, test from the SECOND window: open a
#    fresh SSH connection from another device/network to confirm the rule isn't wrong
```

## If you're already locked out

You need access outside the SSH path — pick one:

- Your VPS provider's **Console/VNC** (DigitalOcean/AWS/Proxmox/etc usually have a web-based "Console" that doesn't go through SSH) — get in through that, then fix the firewall rule.
- **Contact your hosting provider** to reset the firewall from their side if there's no console access.

Once you're in via the console:

```bash
# See the currently active firewall rules
sudo firewall-cmd --list-all

# Reopen general SSH access temporarily to recover
sudo firewall-cmd --permanent --add-service=ssh
sudo firewall-cmd --reload
```

> Only apply IP restrictions again once normal SSH access is confirmed working, using the two-session pattern above.
