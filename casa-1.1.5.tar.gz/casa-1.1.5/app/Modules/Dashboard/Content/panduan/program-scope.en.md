## Adding a Program

Menu **Programs → New Program**. Fill in:

- **Name** & **Platform** (HackerOne / Bugcrowd).
- **Program URL** & **Policy URL** (optional).
- **Scope IN** — targets you're ALLOWED to test (one per line): domain, `*.wildcard`, URL, or IP.
- **Scope OUT** — EXCLUDED targets (never scanned even if they match an IN wildcard).
- **Excluded finding types** — the program's "known issues" (e.g. *Missing security headers, Clickjacking, SPF/DMARC, Self-XSS*) → matching findings get tagged `excluded` so you don't waste time submitting them.
- **Allow automated scanners** — tick this **only** if the program explicitly allows it.

## Auto-fill scope

The **"Auto-fill scope"** panel on the right: paste the program's policy text (the Scope / In Scope / Out of Scope section), or fill in the URL, then click **Parse**. CASA pulls in/out hosts into the left-hand fields — **always review & correct** before saving.

> HackerOne/Bugcrowd pages are often behind login or anti-bot protection, so parsing from a URL can fail → **copy-paste the text instead** (most reliable).

## Scope is enforced

During a **Bounty Scan**, CASA only touches **in-scope** targets (that also don't match scope OUT). This keeps you from violating program rules (out-of-scope testing is a serious violation that can cost you the reward or get you banned).

> Community quota: **1 active program**. Delete a program to create a new one, or upgrade your plan.
