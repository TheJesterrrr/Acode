**Kode: CASA-E014**

## Gejala

Upload XML dari Burp di menu **Import** gagal, atau berhasil tapi jumlah finding yang masuk lebih sedikit dari yang diharapkan.

## Penyebab paling umum

**1. Format file salah.** CASA hanya membaca XML dari fitur **"Report issues"** Burp (klik kanan target di Site map → *Report issues* → pilih format **XML**). Ini **beda** dari:
   - File project Burp (`.burp`) — tak bisa dibaca.
   - Export JSON — tak didukung, harus XML.
   - XML dari fitur lain (mis. Scanner results biasa tanpa lewat "Report issues") — strukturnya beda, tak kebaca.

**2. File lebih dari 8 MB.** Batas ukuran upload. Kalau scan Burp mencakup banyak sekali issue, generate report-nya per-target/per-sesi, jangan sekaligus semua.

**3. XML valid tapi 0 issue terbaca** — pesan errornya persis bilang ini. Biasanya karena file XML kosong (tak ada issue di Site map yang dipilih saat generate report) atau XML-nya corrupt/terpotong saat di-download.

## Langkah memastikan

1. Di Burp: Target → Site map → pilih host yang relevan → klik kanan → **Report issues**.
2. Pastikan format output **XML** (bukan HTML), dan **centang issue yang mau diekspor** (kalau tak ada yang dicentang, hasilnya kosong).
3. Simpan, cek ukuran filenya (`ls -la` di komputer Anda) — kalau > 8MB, pecah jadi beberapa export per grup target.
4. Upload lagi di menu **Import**, pilih program yang benar di dropdown sebelum upload.

## Kalau sudah coba semua itu masih gagal

Buka file XML-nya di text editor, cek baris pertama harus diawali `<?xml version="1.0"?>` lalu ada tag `<issues>` — kalau rusak/kepotong (mis. tak ada tag penutup `</issues>` di akhir file), file-nya korup saat di-download dari Burp. Generate ulang report-nya dari Burp.
