**Code: CASA-E001**

## Symptoms

The mission stays **Executing** for a long time with no progress moving (the `x/y` counter on the mission page stays still), or a task shows **Error** with *"Process stopped unexpectedly (timeout/crash, e.g. out of memory) — swept automatically"*.

This is usually caused by a scan task that crashed (out of memory) before its status could be updated to "Error" — the worker process died first, not the tool itself being at fault.

## Fix

1. Open **Missions**, click the stuck mission.
2. Click the **Repair** button (wrench icon, next to the Cancel button).
3. CASA automatically sweeps the stuck task and tries to advance the mission.
4. Wait 1-2 minutes, refresh the page. If progress moves → done.

> Same applies to missions in Bug Bounty mode (Bounty Scan) — the button and behavior are identical.

If after clicking Repair **several times** progress still doesn't move at all (not just one errored task, but the mission is completely frozen), the worker on the server may have stopped entirely — see the **Worker Never Runs** guide.
