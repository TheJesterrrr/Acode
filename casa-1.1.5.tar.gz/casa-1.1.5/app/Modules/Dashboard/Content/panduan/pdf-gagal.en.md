**Code: CASA-E004**

## Symptoms

Clicking **Download PDF** on a report page shows a generic error page ("Whoops!") instead of downloading the file. This usually happens with large reports (hundreds of findings) — the server runs out of memory while rendering the PDF.

## Fastest fix — use Print

1. Open the report under the **Reports** menu.
2. Click the **Print** button (not "Download PDF").
3. The PDF is rendered directly in your own browser, not on the server — so it never fails due to server RAM. In the print dialog, choose **Save as PDF** as the destination.

## Alternative — shrink the report first

Filter to only the relevant severities (the **Severity: ...** button above the report) before clicking **Download PDF** — a smaller report is much less likely to fail server-side rendering.
