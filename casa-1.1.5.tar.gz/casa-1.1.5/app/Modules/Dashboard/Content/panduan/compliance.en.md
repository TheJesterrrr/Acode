## Compliance posture

The **Compliance** menu shows how your findings map against the **OWASP Top 10 (2021)** and the top **CWE**s. Useful for seeing which risk categories are most affected and which ones are still "clean."

## OWASP Top 10 (2021)

| Code | Category |
|---|---|
| A01 | Broken Access Control |
| A02 | Cryptographic Failures |
| A03 | Injection |
| A04 | Insecure Design |
| A05 | Security Misconfiguration |
| A06 | Vulnerable & Outdated Components |
| A07 | Identification & Authentication Failures |
| A08 | Software & Data Integrity Failures |
| A09 | Security Logging & Monitoring Failures |
| A10 | Server-Side Request Forgery (SSRF) |

## How to read it

- Each category shows a finding count + severity breakdown, or a **clean** mark if there are none.
- Click a finding count to jump to the **Vulnerabilities** list for that category.
- The **Top CWEs** panel summarizes the most frequently occurring weaknesses.

CWE→OWASP mapping follows the standard (Kitab BAB V 5.2) and is derived automatically from findings.
