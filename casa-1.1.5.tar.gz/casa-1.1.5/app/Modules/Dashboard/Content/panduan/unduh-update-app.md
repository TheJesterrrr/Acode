## Kenapa aplikasi dipasang sendiri

Portal ini (**casamember**) adalah **hub transaksi**: tempat Anda topup koin, berlangganan, dan mengambil license key. Mesin pentest-nya **tidak** berjalan di sini — pemindaian (nmap, recon, vuln scan) butuh akses penuh ke server dan tak mungkin di shared hosting.

Karena itu CASA dipasang sebagai **aplikasi mandiri di VPS/server milik Anda**. Server pemilik tetap ringan, dan Anda memindai dari IP sendiri yang sah.

## Langkah unduh & pasang

1. Buka menu **Download App**. Pilih paket sesuai target:
   - **VPS / Linux (native)** — `.tar.gz`, untuk server AlmaLinux/Ubuntu.
   - **Docker (Win/Mac/Linux)** — `.zip`, jalan di mana saja ada Docker.
   - **Windows (1-klik)** — `.exe`, pemasang otomatis.
2. Unduh, lalu jalankan `install.sh` (atau installer) di server Anda. Ikuti petunjuk di README paket.
3. Setelah portal instance hidup, buka menu **Lisensi & Aktivasi** di instance itu dan tempel **license key** dari langganan Anda (lihat panduan **Lisensi & Aktivasi**).

> License key diunduh dari menu **Langganan & Koin** di hub ini — bukan di instance.

## Update ke versi terbaru

Dashboard hub menampilkan **versi terbaru** yang tersedia. Bila lebih baru dari yang terpasang:

1. Unduh paket versi baru dari **Download App**.
2. Di server Anda, jalankan skrip update bawaan paket (mengganti kode aplikasi, menjalankan migrasi database, tanpa menghapus data Anda).
3. Lisensi dan data pentest tetap utuh — update hanya menyentuh kode aplikasi.

> Selalu **backup** database instance sebelum update. Langganan aktif tidak perlu diaktivasi ulang setelah update.

## Masalah umum

- **Paket tak muncul di Download App** — owner belum mengunggah rilis. Hubungi admin.
- **Versi di dashboard lebih lama dari instance** — Anda sudah paling baru; abaikan.
- **Lisensi "tidak valid" setelah pindah server** — aktivasi terikat instance; minta reset aktivasi ke owner.
