**Kode: CASA-E002**

## Gejala

Tak ada task berstatus Error, cron sudah terpasang (lihat panduan **Worker Tidak Pernah Berjalan**), tapi mission tetap diam berjam-jam.

## Penyebab

Biasanya satu tool scan (paling sering `amass`, `katana`, atau `nmap` saat Deep scan ke target besar) menyisakan proses yang masih hidup jauh melebihi waktu wajar dan menahan kunci antrean (`/var/www/casa/writable/locks/casa-work.lock`), sehingga worker berikutnya selalu mundur diam-diam tanpa ada yang tercatat sebagai error.

## Langkah (SSH ke server CASA)

```bash
# 1. Cek apakah file kunci antrean ada & sudah berapa lama
ls -la /var/www/casa/writable/locks/casa-work.lock

# 2. Cari proses tool scan yang jalan sangat lama (kolom ELAPSED tinggi,
#    mis. berjam-jam) — itu kandidat biang keladi
ps -eo pid,etime,cmd | grep -E "amass|katana|nmap|naabu|nuclei|httpx|testssl|ffuf" | grep -v grep

# 3. Kalau ketemu proses yang usianya tak wajar (bandingkan kolom ELAPSED dengan
#    durasi scan normal di Engine Health), hentikan paksa — ganti <PID> dengan
#    PID dari kolom pertama hasil langkah 2
sudo kill -9 <PID>

# 4. Jalankan worker manual untuk pastikan antrean sudah lepas & mulai maju lagi
cd /var/www/casa && php spark casa:work
```

Kalau langkah 4 sukses memproses task (ada output `casa:work — N task diproses`), mission akan lanjut otomatis lewat cron seperti biasa.
