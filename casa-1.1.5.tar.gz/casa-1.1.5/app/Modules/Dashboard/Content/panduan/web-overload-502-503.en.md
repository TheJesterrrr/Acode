**Code: CASA-E007**

## Symptoms

The browser shows **502 Bad Gateway** or **503 Service Unavailable** while several scans/reports are running at the same time. Unlike the **CASA VM / App Completely Down** guide — here the web server is **still alive**, it's just run out of "slots" to serve new requests.

## Cause

The web server (Apache `httpd` + PHP-FPM) has a cap on how many processes can run at once (`MaxRequestWorkers` in Apache, `pm.max_children` in PHP-FPM). If several heavy pages open at the same time — e.g. several large reports try to generate a PDF at once, or many mission tabs auto-refresh together — every process slot can fill up, and new requests get rejected with 502/503 until a slot frees up again.

## Steps (SSH into the CASA server)

```bash
# 1. See how many httpd/php-fpm processes are currently running
ps aux | grep -E "httpd|php-fpm" | grep -v grep | wc -l

# 2. Check the current process limit configuration
httpd -V | grep -i "server mpm"
grep -r "MaxRequestWorkers\|pm.max_children" /etc/httpd/ /etc/php-fpm.d/ 2>/dev/null

# 3. Check the error log to confirm (a line like "server reached
#    MaxRequestWorkers" or "server is busy" confirms it's really out of slots)
sudo tail -50 /var/log/httpd/error_log 2>/dev/null

# 4. Restart the services to release stuck processes (a temporary fix)
sudo systemctl restart httpd php-fpm
```

## Long-term fix

If this keeps happening, raise the process limit reasonably (match it to the VM's RAM — each PHP-FPM process can use tens to hundreds of MB, don't raise it blindly without checking RAM first via `free -h`):

```bash
# Edit pm.max_children in the PHP-FPM config (adjust the path & number)
sudo nano /etc/php-fpm.d/www.conf
# find the "pm.max_children = ..." line and raise it a bit, then save

sudo systemctl restart php-fpm
```

> Raising the process limit WITHOUT adding VM RAM just moves the problem to OOM instead (see the **CASA VM / App Completely Down** guide) — make sure there's actually enough RAM before raising this number.
