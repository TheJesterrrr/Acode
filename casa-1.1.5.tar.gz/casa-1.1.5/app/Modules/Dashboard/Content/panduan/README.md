Letakkan berkas panduan pengguna (Markdown) di folder ini.
Dirender oleh GuideController. Isi panduan CASA sengaja tidak dibawa ke skeleton.
