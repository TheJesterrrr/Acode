## Dukungan & cara minta bantuan

Sebelum menghubungi support, sebagian besar masalah bisa Anda kenali sendiri lewat tiga tempat ini. Menyertakan datanya saat melapor membuat penyelesaian jauh lebih cepat.

## 1. Kumpulkan dulu info ini

Saat melapor, lampirkan:

- **Versi aplikasi** — ada di footer tiap halaman (mis. `v1.1.2`).
- **Kode error** bila ada — berformat `CASA-Exxx` (mis. `CASA-E005`). Tiap kode punya artikel panduannya sendiri; cari kodenya di kotak pencarian Panduan.
- **Halaman Engine Health** (`/casaadmin/engine`) — status worker, error terbaru, hasil audit infrastruktur. Salin/screenshot bagian "Error terbaru".
- **Apa yang Anda lakukan** sebelum masalah muncul (mis. "setelah update", "saat scan target besar", "setelah ganti IP server").

## 2. Diagnosa mandiri cepat

| Gejala | Mulai dari panduan |
|---|---|
| Scan diam / progress tak maju | **Mission Nyangkut / Macet** → tombol **Perbaiki** |
| Mission diam total, worker tak jalan | **Mission Diam Total — Proses Macet Menyandera Worker** |
| "Tool belum terpasang" (CASA-E005) | **Tool Hilang Setelah Update OS**, **Cek Status Tool via CLI** |
| Fitur Pro/Enterprise terkunci lagi | **Sinkronisasi Lisensi Gagal Diam-Diam** |
| Tier turun ke Community setelah update | **Tier Turun ke Community Setelah Update** |
| Halaman CASA tak bisa dibuka sama sekali | **VM / Aplikasi CASA Mati Total** |
| Error 502/503 saat banyak scan | **Web Server Kelebihan Beban (502/503)** |
| Unduh PDF laporan gagal | **Unduh PDF Laporan Gagal** |

Gunakan **kotak pencarian** di halaman Panduan — ia menembus isi artikel, bukan cuma judul.

## 3. Cek kesehatan sistem

Halaman **Engine Health** adalah pemeriksaan pertama untuk hampir semua masalah scan:

- **Worker** — harus "berjalan" (cron `casa:work` tiap menit). Bila "belum jalan", lihat **Worker Tidak Pernah Berjalan (Cron)**.
- **Error terbaru** — daftar kejadian berkode terakhir, langsung menunjuk artikel panduannya.
- **Audit infrastruktur** — disk, memori, koneksi database; mendeteksi masalah sebelum mengganggu scan.

## 4. Hubungi kami

Bila sudah mencoba panduan di atas dan masalah bertahan:

- **Email:** support@corenet.web.id
- **WhatsApp:** +62 851-5603-0238

Sertakan info dari bagian 1. Untuk urusan langganan, koin, atau reset aktivasi lisensi (mis. pindah server), sebutkan **email akun** dan **License ID** Anda (tampil di halaman Lisensi & Aktivasi).

> **Catatan privasi:** jangan kirimkan isi temuan sensitif atau kredensial target lewat email/WA. Cukup kirim versi, kode error, dan Engine Health.
