## Support & how to get help

Before contacting support, most issues can be identified from the three places below. Including this data in your report makes resolution much faster.

## 1. Collect this info first

When reporting, attach:

- **App version** — in the footer of every page (e.g. `v1.1.2`).
- **Error code**, if any — formatted `CASA-Exxx` (e.g. `CASA-E005`). Each code has its own guide article; search the code in the Guide search box.
- **Engine Health page** (`/casaadmin/engine`) — worker status, recent errors, infrastructure-audit results. Copy/screenshot the "Recent errors" section.
- **What you were doing** before the problem appeared (e.g. "after an update", "scanning a large target", "after the server IP changed").

## 2. Quick self-diagnosis

| Symptom | Start with this guide |
|---|---|
| Scan frozen / progress not advancing | **Mission Stuck / Frozen** → **Repair** button |
| Mission fully frozen, worker not running | **Mission Fully Frozen — a Stuck Process Is Blocking the Worker** |
| "Tool not installed" (CASA-E005) | **Tool Missing After OS Update**, **Check All Scan Tools via CLI** |
| Pro/Enterprise features locked again | **License Sync Fails Silently** |
| Tier dropped to Community after an update | **Tier Dropped to Community After an Update** |
| CASA page will not load at all | **CASA VM / App Completely Down** |
| 502/503 errors under many scans | **Web Server Overloaded (502/503)** |
| PDF report download fails | **PDF Report Download Fails** |

Use the **search box** on the Guide page — it searches article contents, not just titles.

## 3. Check system health

The **Engine Health** page is the first check for almost any scan problem:

- **Worker** — must be "running" (the `casa:work` cron every minute). If "not running", see **Worker Never Runs (Cron)**.
- **Recent errors** — the latest coded events, each linking straight to its guide article.
- **Infrastructure audit** — disk, memory, database connections; catches problems before they disrupt scans.

## 4. Contact us

If you have tried the guides above and the problem persists:

- **Email:** support@corenet.web.id
- **WhatsApp:** +62 851-5603-0238

Include the info from section 1. For subscription, coins, or license activation resets (e.g. moving servers), mention your **account email** and **License ID** (shown on the License & Activation page).

> **Privacy note:** do not send sensitive finding contents or target credentials over email/WhatsApp. Just send the version, error code, and Engine Health.
