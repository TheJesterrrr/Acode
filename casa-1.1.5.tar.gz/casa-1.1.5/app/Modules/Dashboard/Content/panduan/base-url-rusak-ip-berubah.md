**Kode: CASA-E009**

## Gejala

Portal CASA kelihatan "rusak" setelah pindah jaringan/IP server berubah — link di dalam aplikasi mengarah ke alamat lama, redirect salah, atau aset (CSS/JS/gambar) gagal dimuat, padahal server-nya sendiri hidup normal.

## Penyebab

Alamat portal (`app.baseURL`) ditulis **sekali** ke file `.env` saat instalasi (mis. `http://10.101.20.200.nip.io:8008/` atau domain tetap). CASA memakai nilai ini untuk membangun semua link internal. Kalau IP/domain server berubah setelahnya, nilai di `.env` jadi basi dan tak otomatis menyesuaikan.

## Langkah (SSH ke server CASA)

```bash
cd /var/www/casa

# 1. Lihat nilai baseURL yang tersimpan sekarang
grep "^app.baseURL" .env

# 2. Ganti ke alamat yang benar (ganti URL sesuai IP/domain baru)
sudo sed -i "s|^app.baseURL.*|app.baseURL = 'http://ALAMAT-BARU:8008/'|" .env

# 3. Verifikasi sudah berubah
grep "^app.baseURL" .env

# 4. Bersihkan cache supaya perubahan langsung kepakai
php spark cache:clear
```

Buka ulang portal di browser dan cek apakah link & aset sudah normal.

> Kalau pakai domain nip.io (mis. `10.101.20.200.nip.io`) dan IP server berubah, ganti juga bagian IP di domain nip.io-nya — itu trik DNS yang memetakan nama domain langsung ke IP yang tertulis di dalamnya, bukan DNS beneran yang bisa diupdate terpisah.
