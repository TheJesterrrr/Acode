## Draft Report

Menu **Reports** → pilih finding → **Draft Report**. Pilih platform **HackerOne** (CVSS + CWE) atau **Bugcrowd** (VRT / P1–P5). CASA mengisi kerangka:

`Title · Severity · Summary · Affected Asset · Steps to Reproduce · Proof of Concept · Impact · Remediation · References`

Lalu **Copy Markdown** / **Download .md** untuk ditempel ke platform, dan **Simpan sebagai Submission** untuk dilacak.

## Jangan terlihat "dikerjakan AI/scanner"

Triager sering menolak report yang tampak hasil automated scanner. Report yang diterima = **bukti verifikasi manual**:

1. **Steps to Reproduce** & **Proof of Concept** di draft ditandai **ISI MANUAL** — tulis langkah yang **Anda** lakukan (mis. di Burp Repeater), bukan output tool.
2. Tempel **HTTP request/response mentah** dari Burp + **screenshot**.
3. Tulis dampak **konkret** (data/akses/dana yang didapat attacker).
4. CASA menyediakan **checklist verifikasi per tipe** (IDOR, XSS, SQLi, SSRF, Auth, …) sebagai panduan langkah.

> CASA **tidak pernah auto-submit**. Ia hanya menyiapkan draft; Anda yang verifikasi, lengkapi bukti, dan submit.

## Submissions tracker

Menu **Submissions**: lacak tiap laporan — status (`draft → submitted → triaged → accepted | duplicate | na | resolved`), **bounty ($)**, dan **External ID** (nomor report di platform). Ringkasan Accepted/Duplicate/total payout tampil di atas.
