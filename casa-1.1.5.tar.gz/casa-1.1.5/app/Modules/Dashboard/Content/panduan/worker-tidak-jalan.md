**Kode: CASA-E003**

## Gejala

Menu **Engine Health** (Pengaturan → Engine Health) menunjukkan *"Worker (casa:work): Belum jalan — belum ada catatan cron"*, dan mission manapun tak maju walau sudah klik **Perbaiki** berkali-kali.

## Penyebab

Cron yang menjalankan worker scan tiap menit belum terpasang di server (atau sempat terhapus). Ini masalah server, bukan sesuatu yang bisa dibetulkan dari aplikasi — butuh akses SSH.

## Langkah (SSH ke server CASA)

```bash
# 1. Cek dulu apakah cron casa:work sudah terdaftar
crontab -l

# 2. Kalau TIDAK ada baris "casa:work" di hasil di atas, tambahkan:
(crontab -l 2>/dev/null; echo "* * * * * cd /var/www/casa && php spark casa:work >> /dev/null 2>&1") | crontab -

# 3. Verifikasi sudah masuk
crontab -l

# 4. Test jalankan manual sekali (harus langsung memproses task tanpa error)
cd /var/www/casa && php spark casa:work
```

Setelah ini, tunggu 1-2 menit lalu refresh mission yang tadi macet — harusnya mulai bergerak sendiri (cron jalan tiap menit).
