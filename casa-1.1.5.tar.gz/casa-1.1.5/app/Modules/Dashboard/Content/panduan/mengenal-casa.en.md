## What is CASA

CASA (CoreNet Autonomous Security Agent) is a **Pentest** platform. One portal runs the full cycle: Recon, Vulnerability scanning, finding validation, through to Report writing. AI is used to help plan Missions, filter false positives, and polish Reports; the actual scanning is still carried out by real tools (nmap, nuclei, httpx, etc).

Unlike a plain scanner: there's a **Policy Engine** (scope & ethics gate) and validation for vulnerability classes that need context — IDOR/BOLA and Business Logic — which usually slip past pattern-based scanners.

## Core flow

```
Mission -> Planning -> Execution -> Validation -> Reporting
```

- **Mission** — you provide the target and rules.
- **Planning** — CASA picks the right, allowed tools.
- **Execution** — the scan runs (recon through vuln scan).
- **Validation** — AI filters out false positives.
- **Reporting** — a submit-ready report is assembled automatically.

## Two modes, one app

CASA runs on **one codebase** that operates in **two modes**, switched automatically based on whether an owner license is present:

| Mode | Where | For |
|---|---|---|
| **Hub (casamember)** | The CASA owner's server | Subscriptions & coins, app download/update, guide, account. **No pentest module.** |
| **Product instance** | **Your own** VPS/server | Full pentest portal: Projects, Missions, Attack Surface, Findings, Reports, Lab — plus License/Tool/AI settings. **No billing.** |

Why they're separate: scanning is heavy and needs root access, so the **scan load sits on your own server**, not the owner's. You buy on the hub, then scan from your own instance.

> On the instance, one owner account still sees two addresses — `casaadmin.…` (License, Tool Manager, AI, Team, Audit) and `casamember.…` (pentest work). The address decides the view; the account is the same one.

## Before you start: legality

Only scan assets you own or have written permission to test. The Policy Engine enforces ethics technically, but legal responsibility is always yours.
