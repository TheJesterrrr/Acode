**Kode: CASA-E013**

## Gejala

Bounty Scan kelihatan "kurang lengkap" dibanding Pentest biasa — Vulnerability Assessment tak jalan, hasil cuma recon dasar, atau terasa jauh lebih lambat dari scan Pentest ke target serupa.

## Ini biasanya BUKAN bug

Kalau program bug bounty Anda **tidak mencentang** "Mengizinkan automated scanner" saat dibuat (lihat panduan **Program & Scope**), CASA **sengaja** memaksa scan jadi **Light** + recon saja, tanpa Vulnerability Assessment massal. Ini bukan error — itu cara CASA mematuhi aturan program yang melarang scanner otomatis (lihat panduan **Etika & Aturan Program**). Banyak program bug bounty benar-benar melarang ini dan bisa memblokir/mem-ban akun yang ketahuan menjalankan scanner penuh.

## Cara memastikan ini memang dari pengaturan, bukan error

1. Buka **Programs**, pilih program yang scan-nya terasa terbatas.
2. Cek apakah **"Mengizinkan automated scanner"** dicentang atau tidak.
3. Kalau TIDAK dicentang — perilaku Light + recon-saja memang disengaja, sesuai aturan program.
4. Kalau program itu SEBENARNYA mengizinkan automated scanner (sudah dicek ulang ke halaman policy program) tapi centangnya lupa diaktifkan — edit program, centang opsi itu, jalankan ulang Bounty Scan.

## Kalau memang dibatasi, langkah vulnerability tetap dari Anda

Dengan scan Light, kelas kerentanan yang butuh scanning aktif (SQLi otomatis, XSS otomatis, dll) **tidak** CASA jalankan. Itu memang area kerja **manual** (Burp) sesuai alur bug bounty — lihat panduan **Alur Bug Bounty**. CASA di sini cuma mempercepat recon; hunting sesungguhnya tetap tangan Anda.
