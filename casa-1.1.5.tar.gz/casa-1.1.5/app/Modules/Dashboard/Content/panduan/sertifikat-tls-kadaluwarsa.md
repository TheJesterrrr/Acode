**Kode: CASA-E012**

## Gejala

Browser menampilkan peringatan "Not Secure" / "Your connection is not private" saat membuka portal CASA lewat HTTPS, padahal sebelumnya normal.

## Penyebab

Sertifikat TLS (mis. dari Let's Encrypt) punya masa berlaku terbatas (90 hari untuk Let's Encrypt) dan biasanya diperpanjang otomatis lewat cron — kalau cron perpanjangannya berhenti jalan (server pindah, lupa pasang ulang setelah migrasi, dll), sertifikat kedaluwarsa tanpa peringatan.

## Langkah (SSH ke server CASA)

```bash
# 1. Cek tanggal kedaluwarsa sertifikat yang sedang dipakai
echo | openssl s_client -connect localhost:443 -servername DOMAIN-ANDA 2>/dev/null | openssl x509 -noout -dates

# 2. Kalau pakai Certbot (Let's Encrypt), cek status semua sertifikat terpasang
sudo certbot certificates

# 3. Cek apakah cron perpanjangan otomatis masih terpasang
sudo systemctl status certbot-renew.timer 2>/dev/null || crontab -l | grep certbot

# 4. Kalau tidak ada / berhenti, perpanjang manual dulu
sudo certbot renew --force-renewal

# 5. Pasang ulang cron perpanjangan kalau sempat hilang
sudo systemctl enable --now certbot-renew.timer
```

> Setelah perpanjangan manual sukses, restart web server (`sudo systemctl restart httpd`) supaya sertifikat baru langsung dipakai.
