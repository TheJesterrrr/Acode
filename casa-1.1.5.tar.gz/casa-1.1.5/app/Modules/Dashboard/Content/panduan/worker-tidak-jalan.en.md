**Code: CASA-E003**

## Symptoms

The **Engine Health** menu (Settings → Engine Health) shows *"Worker (casa:work): Not running — no cron record"*, and no mission advances even after clicking **Repair** repeatedly.

## Cause

The cron job that runs the scan worker every minute was never installed on the server (or got removed at some point). This is a server-side problem, not something you can fix from the app — it needs SSH access.

## Steps (SSH into the CASA server)

```bash
# 1. First check whether the casa:work cron is already registered
crontab -l

# 2. If there is NO "casa:work" line in the output above, add it:
(crontab -l 2>/dev/null; echo "* * * * * cd /var/www/casa && php spark casa:work >> /dev/null 2>&1") | crontab -

# 3. Verify it was added
crontab -l

# 4. Test-run it manually once (it should process tasks immediately with no error)
cd /var/www/casa && php spark casa:work
```

After this, wait 1-2 minutes then refresh the mission that was stuck — it should start moving on its own (the cron runs every minute).
