## Mode Bug Bounty

Bug Bounty adalah salah satu dari **dua mode** CASA (ganti lewat toggle **Pentest / Bounty** di atas sidebar). Engine scan-nya sama dengan Pentesting; yang beda adalah **cara kerjanya**:

| | Pentesting | Bug Bounty |
|---|---|---|
| Unit kerja | Project (klien berizin) | **Program** (HackerOne/Bugcrowd) |
| Scope | ROE klien | **Scope ketat** in/out — wajib dipatuhi |
| Fokus | Kedalaman per target | **Recon luas** + temuan baru |
| Output | Report formal (PDF) | **Submission** format platform + lacak status |

## Kenapa dipisah

Program bug bounty punya aturan sendiri: scope yang tak boleh dilanggar, sering **melarang automated scanner**, dan menghargai **bukti manual** (Burp). Mode Bounty menata CASA agar patuh aturan itu: scope di-enforce, scan bisa dipaksa hemat, dan report dirancang agar terlihat diverifikasi manusia.

## Posisi CASA di bug bounty

CASA = mesin **recon + triase + bantu report**. Bug kelas atas (IDOR, auth, business logic) tetap Anda temukan **manual di Burp** — hasilnya di-**Import** ke CASA. CASA tidak menggantikan hunting manual; ia mempercepat recon dan merapikan report.

> Mulai dari **Programs** → tetapkan scope → **Bounty Scan** (recon) → hunting manual → **Import** → **Report** → **Submissions**.
