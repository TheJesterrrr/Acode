## Berapa banyak tool yang dipakai CASA

CASA aktif memakai **24 tool eksternal** lewat CLI (ditambah 1 fitur IDOR Workbench yang dibangun sendiri oleh CASA, tanpa binary eksternal — jadi total 25 kapabilitas scan). Katalog Tool Manager menampilkan lebih banyak nama (~30 kategori arsenal pentest) karena sebagian **belum** punya adapter yang menjalankannya — itu daftar roadmap, bukan yang aktif dipakai.

Cara tercepat lihat status 24 tool ini: menu **Tools** (Tool Manager). Tapi status di situ cuma mencerminkan apa yang **tercatat di database** — kalau binary-nya ternyata rusak/hilang di disk tanpa CASA tahu, GUI tetap bilang "Terpasang". Panduan ini untuk verifikasi **sebenarnya** lewat server.

## Cek cepat — semua tool sekaligus (SSH ke server CASA)

Script ini membaca kredensial database otomatis dari `.env`, lalu mengecek SETIAP tool yang tercatat "Terpasang": apakah file binary-nya **benar-benar ada** dan **bisa dieksekusi**. Ini satu-satunya cek yang berlaku sama untuk semua 24 tool (tak semua tool punya cara cek versi yang seragam).

```bash
cd /var/www/casa

# Baca kredensial DB dari .env
DB_HOST=$(grep -E "^database.default.hostname" .env | cut -d= -f2 | tr -d ' ')
DB_NAME=$(grep -E "^database.default.database" .env | cut -d= -f2 | tr -d ' ')
DB_USER=$(grep -E "^database.default.username" .env | cut -d= -f2 | tr -d ' ')
DB_PASS=$(grep -E "^database.default.password" .env | cut -d= -f2-)

echo "=== Status tercatat di database ==="
mysql -h"$DB_HOST" -u"$DB_USER" -p"$DB_PASS" "$DB_NAME" -e \
  "SELECT tool_code, status, bin_path, installed_version FROM tool_install ORDER BY tool_code;"

echo ""
echo "=== Verifikasi nyata: file ada & bisa dieksekusi? ==="
mysql -h"$DB_HOST" -u"$DB_USER" -p"$DB_PASS" -N "$DB_NAME" -e \
  "SELECT tool_code, bin_path FROM tool_install WHERE status='installed';" | \
while IFS=$'\t' read -r code path; do
  if [ -z "$path" ] || [ "$path" = "NULL" ]; then
    echo "[KOSONG]    $code — bin_path kosong di database"
  elif [ ! -f "$path" ]; then
    echo "[HILANG]    $code — $path tidak ada di disk"
  elif [ ! -x "$path" ]; then
    echo "[NO-EXEC]   $code — $path ada tapi tak punya izin eksekusi"
  else
    echo "[OK]        $code — $path"
  fi
done
```

Baca hasilnya: baris `[OK]` aman. Baris lain langsung menunjukkan masalahnya — lanjut ke bagian **Cara memperbaiki** di bawah sesuai labelnya.

## Cek lebih dalam — jalankan tiap tool, lihat versinya

Kalau mau pastikan tool bukan cuma "ada filenya" tapi **beneran bisa jalan** (kadang file ada tapi dependency-nya rusak, mis. library Python hilang), jalankan perintah versi masing-masing. Tabel ini referensi lengkap 24 tool + cara cek standarnya:

| Tool | Binary | Perintah cek | Catatan |
|---|---|---|---|
| httpx | `httpx` | `httpx -version` | |
| nuclei | `nuclei` | `nuclei -version` | |
| dalfox | `dalfox` | `dalfox version` | |
| sqlmap | `sqlmap.py` | `python3 sqlmap.py --version` | Python; cek juga `python3 --version` |
| katana | `katana` | `katana -version` | |
| naabu | `naabu` | `naabu -version` | |
| subfinder | `subfinder` | `subfinder -version` | |
| gau | `gau` | `gau --version` | |
| dnsx | `dnsx` | `dnsx -version` | |
| testssl | `testssl.sh` | `testssl.sh --version` | |
| ffuf | `ffuf` | `ffuf -V` | |
| gowitness | `gowitness` | `gowitness version` | Perlu Chromium headless terpasang |
| whatweb | `whatweb` | `whatweb --version` | Ruby |
| nikto | `nikto.pl` | `nikto.pl -h` lalu lihat baris pertama | Tak ada flag versi baku; `-h` cukup konfirmasi ia jalan |
| arjun | `arjun` | `arjun -h` | Python; tak ada flag versi, `-h` cukup |
| wafw00f | `wafw00f` | `wafw00f -h` | Python; tak ada flag versi, `-h` cukup |
| trufflehog | `trufflehog` | `trufflehog --version` | |
| gitleaks | `gitleaks` | `gitleaks version` | |
| trivy | `trivy` | `trivy --version` | |
| waybackurls | `waybackurls` | `echo example.com \| waybackurls` | Go; tak ada flag versi, tes jalankan langsung |
| hakrawler | `hakrawler` | `echo https://example.com \| hakrawler` | Go; tak ada flag versi, tes jalankan langsung |
| feroxbuster | `feroxbuster` | `feroxbuster --version` | |
| nmap | `nmap` | `nmap --version` | |
| wpscan | `wpscan` | `wpscan --version` | Ruby gem |
| idor | *(builtin)* | — | Bagian dari kode CASA sendiri, tak perlu dicek terpisah |

Contoh pakai tabel ini — cek satu tool spesifik pakai path dari hasil script di atas:

```bash
# Ganti <path-dari-database> dengan hasil kolom bin_path tool yang dicurigai
<path-dari-database> -version
```

## Cara memperbaiki per label masalah

**`[KOSONG]`** — `bin_path` di database kosong (belum pernah dipasang lewat CASA). Pasang lewat menu **Tools**, tombol **Pasang**.

**`[HILANG]`** — file pernah ada tapi sekarang tidak. Biasanya karena update OS menghapusnya tanpa sengaja (lihat panduan **Tool Hilang Setelah Update OS**), atau VM pernah di-restore dari snapshot lama. Pasang ulang lewat menu **Tools**.

**`[NO-EXEC]`** — file ada tapi izin eksekusinya hilang (sering terjadi setelah transfer file lewat FTP/SFTP yang tak menjaga permission). Perbaiki langsung:

```bash
chmod +x <path-yang-bermasalah>
```

**Binary jalan tapi error saat dieksekusi** (mis. `ModuleNotFoundError` untuk tool Python, atau `cannot load library` untuk tool Go/Rust) — dependency-nya rusak/hilang, bukan binary-nya. Solusi paling aman: pasang ulang lewat menu **Tools** (bukan perbaiki manual satu-satu dependency) supaya lingkungan terpasang bersih kembali.

> Tool `amass` sudah **dipensiunkan** dari CASA (digantikan `subfinder`) — kalau Anda lihat `amass` berstatus error/tak terpasang, itu memang disengaja, bukan masalah.
