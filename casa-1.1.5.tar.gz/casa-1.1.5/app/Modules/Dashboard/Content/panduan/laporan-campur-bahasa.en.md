## Symptoms

A report you selected as English still shows some finding titles/descriptions in Indonesian (or vice versa).

## Cause

Older findings that were saved before you ever opened a report in a given language still carry their original text. Reopening the report in your chosen language rebuilds its content fresh.

## Steps

1. Open the report under the **Reports** menu.
2. Click the **Indonesia** / **English** toggle at the top-right of the report page.
3. The report is rebuilt fresh in the chosen language, including older findings that were previously stored in a mixed language.
