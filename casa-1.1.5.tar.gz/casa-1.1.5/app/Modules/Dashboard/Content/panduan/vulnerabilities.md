## Vulnerability Management board

Menu **Vulnerabilities** mengumpulkan **seluruh temuan lintas project** dalam satu papan triase — mirip alur manajemen kerentanan PlexTrac. Di sini Anda melacak perbaikan dari awal sampai selesai.

## Status remediasi

| Status | Arti |
|---|---|
| Open | Belum ditangani |
| In Progress | Sedang diperbaiki |
| Fixed | Sudah diperbaiki |
| Risk Accepted | Risiko diterima (tak diperbaiki) |
| False Positive | Bukan kerentanan nyata |

## Cara triase

1. Buka menu **Vulnerabilities**. Tab di atas memfilter per status; ada juga filter **severity** dan pencarian.
2. Klik tombol **pensil** pada sebuah temuan untuk membuka jendela triase.
3. Ubah **status remediasi**, tetapkan **penanggung jawab**, dan tambah **catatan**.
4. Simpan — progres langsung tercermin di Dashboard (Progres Remediasi).

> Status ini terpisah dari validasi AI (yang menilai false-positive otomatis saat mission). Anda tetap pemegang keputusan akhir.
