**Kode: CASA-E001**

## Gejala

Mission tetap berstatus **Executing** lama tanpa progress bergerak (angka `x/y` di halaman mission diam), atau ada task berstatus **Error** dengan pesan *"Proses terhenti tak terduga (timeout/crash, mis. kehabisan memori) — disapu otomatis"*.

Paling sering disebabkan task scan yang crash (kehabisan memori) tapi statusnya tak sempat terbarui jadi "Error" — proses workernya mati duluan, bukan tool-nya yang salah.

## Langkah perbaikan

1. Buka **Missions**, klik mission yang macet.
2. Klik tombol **Perbaiki** (ikon kunci-inggris, di sebelah tombol Batalkan).
3. CASA otomatis menyapu task yang nyangkut lalu mencoba memajukan mission.
4. Tunggu 1-2 menit, refresh halaman. Kalau progress bergerak → selesai.

> Berlaku sama untuk mission di mode Bug Bounty (Bounty Scan) — tombol & perilakunya identik.

Kalau setelah **beberapa kali** klik Perbaiki progress tetap diam sama sekali (bukan satu task yang error, tapi mission benar-benar tak bergerak), kemungkinan worker di server berhenti total — lihat panduan **Worker Tidak Pernah Berjalan**.
