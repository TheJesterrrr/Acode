## Team & roles (Pro/Enterprise)

Multiple pentesters under one account. Added from **admin portal → Team**.

| Role | Can do |
|---|---|
| Owner | Everything — projects, credentials, team, settings, license. |
| Analyst | Run pentests; can't change team/license. |
| Viewer | Read-only access to findings & reports. |

Members log in on the member portal with credentials you create for them. On **Community**, there's just the one owner account.

## My Account

The **My Account** menu is for:

- Updating your profile (name, company, phone).
- Changing your password (requires your old password).

Email can't be changed yourself since it's your login identity.

> On the online member portal (where you subscribe), this is also where the **Instance Sync Code** is shown for license activation.
