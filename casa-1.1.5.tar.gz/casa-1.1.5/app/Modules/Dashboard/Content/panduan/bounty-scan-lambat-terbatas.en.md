**Code: CASA-E013**

## Symptoms

A Bounty Scan looks "incomplete" compared to a normal Pentest scan — Vulnerability Assessment doesn't run, results are just basic recon, or it feels much slower than a Pentest scan on a similar target.

## This is usually NOT a bug

If your bug bounty program was created **without ticking** "Allow automated scanners" (see the **Program & Scope** guide), CASA **intentionally** forces the scan to **Light** + recon only, with no mass Vulnerability Assessment. This isn't an error — it's how CASA complies with programs that ban automated scanners (see the **Ethics & Program Rules** guide). Many bug bounty programs genuinely forbid this and can block/ban accounts caught running a full scanner.

## How to confirm this is a setting, not an error

1. Open **Programs**, pick the program whose scan feels limited.
2. Check whether **"Allow automated scanners"** is ticked or not.
3. If it's NOT ticked — the Light/recon-only behavior is intentional, matching the program's rules.
4. If the program actually DOES allow automated scanners (double-check its policy page) but the checkbox was simply forgotten — edit the program, tick that option, and re-run the Bounty Scan.

## If it's intentionally limited, vulnerability testing is still on you

With a Light scan, vulnerability classes that need active scanning (automated SQLi, automated XSS, etc) are **not** run by CASA. That's genuinely **manual** work (Burp) as part of the bug bounty flow — see the **Bug Bounty Workflow** guide. CASA here only speeds up recon; the real hunting is still in your hands.
