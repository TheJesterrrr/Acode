## How many tools CASA actually uses

CASA actively uses **24 external tools** via CLI (plus 1 self-built capability, IDOR Workbench, which has no external binary — so 25 scan capabilities in total). The Tool Manager catalog shows more names (~30 pentest-arsenal categories) because some of them **don't yet** have an adapter wired up to run them — that list is a roadmap, not what's actively used.

The fastest way to see these 24 tools' status: the **Tools** menu (Tool Manager). But that status only reflects what's **recorded in the database** — if a binary is actually broken/missing on disk without CASA knowing, the GUI will still say "Installed." This guide is for verifying the **real** state via the server.

## Quick check — all tools at once (SSH into the CASA server)

This script reads the database credentials automatically from `.env`, then checks EVERY tool marked "Installed": whether its binary file **actually exists** and **is executable**. This is the one check that applies uniformly to all 24 tools (not every tool has a consistent version-check method).

```bash
cd /var/www/casa

# Read DB credentials from .env
DB_HOST=$(grep -E "^database.default.hostname" .env | cut -d= -f2 | tr -d ' ')
DB_NAME=$(grep -E "^database.default.database" .env | cut -d= -f2 | tr -d ' ')
DB_USER=$(grep -E "^database.default.username" .env | cut -d= -f2 | tr -d ' ')
DB_PASS=$(grep -E "^database.default.password" .env | cut -d= -f2-)

echo "=== Status recorded in the database ==="
mysql -h"$DB_HOST" -u"$DB_USER" -p"$DB_PASS" "$DB_NAME" -e \
  "SELECT tool_code, status, bin_path, installed_version FROM tool_install ORDER BY tool_code;"

echo ""
echo "=== Real verification: does the file exist & is it executable? ==="
mysql -h"$DB_HOST" -u"$DB_USER" -p"$DB_PASS" -N "$DB_NAME" -e \
  "SELECT tool_code, bin_path FROM tool_install WHERE status='installed';" | \
while IFS=$'\t' read -r code path; do
  if [ -z "$path" ] || [ "$path" = "NULL" ]; then
    echo "[EMPTY]     $code — bin_path is empty in the database"
  elif [ ! -f "$path" ]; then
    echo "[MISSING]   $code — $path does not exist on disk"
  elif [ ! -x "$path" ]; then
    echo "[NO-EXEC]   $code — $path exists but isn't executable"
  else
    echo "[OK]        $code — $path"
  fi
done
```

Reading the results: `[OK]` lines are fine. Any other label points straight at the problem — jump to the **How to fix it** section below based on its label.

## Going deeper — run each tool, check its version

If you want to confirm a tool isn't just "the file exists" but **actually runs** (sometimes the file is there but a dependency is broken, e.g. a missing Python library), run each one's version command. This table is the full reference for all 24 tools + their standard check:

| Tool | Binary | Check command | Note |
|---|---|---|---|
| httpx | `httpx` | `httpx -version` | |
| nuclei | `nuclei` | `nuclei -version` | |
| dalfox | `dalfox` | `dalfox version` | |
| sqlmap | `sqlmap.py` | `python3 sqlmap.py --version` | Python; also check `python3 --version` |
| katana | `katana` | `katana -version` | |
| naabu | `naabu` | `naabu -version` | |
| subfinder | `subfinder` | `subfinder -version` | |
| gau | `gau` | `gau --version` | |
| dnsx | `dnsx` | `dnsx -version` | |
| testssl | `testssl.sh` | `testssl.sh --version` | |
| ffuf | `ffuf` | `ffuf -V` | |
| gowitness | `gowitness` | `gowitness version` | Needs headless Chromium installed |
| whatweb | `whatweb` | `whatweb --version` | Ruby |
| nikto | `nikto.pl` | `nikto.pl -h` then check the first line | No standard version flag; `-h` is enough to confirm it runs |
| arjun | `arjun` | `arjun -h` | Python; no version flag, `-h` is enough |
| wafw00f | `wafw00f` | `wafw00f -h` | Python; no version flag, `-h` is enough |
| trufflehog | `trufflehog` | `trufflehog --version` | |
| gitleaks | `gitleaks` | `gitleaks version` | |
| trivy | `trivy` | `trivy --version` | |
| waybackurls | `waybackurls` | `echo example.com \| waybackurls` | Go; no version flag, test-run it directly |
| hakrawler | `hakrawler` | `echo https://example.com \| hakrawler` | Go; no version flag, test-run it directly |
| feroxbuster | `feroxbuster` | `feroxbuster --version` | |
| nmap | `nmap` | `nmap --version` | |
| wpscan | `wpscan` | `wpscan --version` | Ruby gem |
| idor | *(builtin)* | — | Part of CASA's own code, no separate check needed |

Example usage of this table — check one specific tool using the path from the script's output above:

```bash
# Replace <path-from-database> with that tool's bin_path column result
<path-from-database> -version
```

## How to fix it, by label

**`[EMPTY]`** — `bin_path` is empty in the database (never installed via CASA). Install it from the **Tools** menu, **Install** button.

**`[MISSING]`** — the file existed before but is gone now. Usually caused by an OS update accidentally removing it (see the **Tool Missing After OS Update** guide), or the VM being restored from an old snapshot. Reinstall it from the **Tools** menu.

**`[NO-EXEC]`** — the file exists but lost its execute permission (often happens after transferring files via FTP/SFTP that doesn't preserve permissions). Fix it directly:

```bash
chmod +x <the-broken-path>
```

**The binary runs but errors out** (e.g. `ModuleNotFoundError` for a Python tool, or `cannot load library` for a Go/Rust tool) — its dependencies are broken/missing, not the binary itself. The safest fix: reinstall via the **Tools** menu (rather than manually patching dependencies one by one) so the installed environment comes back clean.

> The `amass` tool has been **retired** from CASA (replaced by `subfinder`) — if you see `amass` showing error/not-installed, that's intentional, not a problem.
