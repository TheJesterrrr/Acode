**Kode: CASA-E005**

## Gejala

Mission tiba-tiba men-skip langkah tertentu dengan alasan *"Tool belum terpasang"*, padahal sebelumnya tool itu normal dipakai. Biasanya muncul setelah server di-`dnf update`/`apt upgrade`, atau setelah restore/clone VM.

## Penyebab

Beberapa tool (terutama yang `install_method`-nya `system`, mis. nmap, nikto) dipasang lewat package manager OS, bukan diunduh CASA sendiri. Update OS kadang memindahkan lokasi binary, menghapus paket yang dianggap tak terpakai, atau mengubah versi sedemikian rupa sehingga path lama di database CASA (`bin_path`) tak lagi valid.

## Langkah

**1. Konfirmasi dulu lewat GUI** — menu **Tools** (Tool Manager), cari tool yang disebut di pesan error. Kalau statusnya bukan "Terpasang", itu konfirmasi diagnosisnya.

**2. Cek lewat CLI (SSH ke server) — path mana yang sebenarnya dipakai tool itu sekarang:**

```bash
# Ganti <nama-binary> sesuai tool, mis. nmap, nikto.pl
which <nama-binary>
```

**3a. Kalau `which` menemukan path baru** — tool masih ada, cuma pindah lokasi. Update `bin_path` di database CASA ke path baru lewat menu **Tools** (biasanya ada tombol verifikasi ulang), atau lihat panduan **Cek Status Tool via CLI** untuk cara update manual lewat database.

**3b. Kalau `which` tidak menemukan apa pun** — tool benar-benar hilang, pasang ulang:

```bash
# Contoh untuk paket sistem (AlmaLinux/RHEL) — sesuaikan nama paket
sudo dnf install -y nmap nikto
```

Untuk tool yang dipasang CASA sendiri (github_release/python/go), pasang ulang lewat tombol **Pasang** di menu Tools — jangan manual, supaya `bin_path` di database ikut tercatat benar.

> Lihat panduan **Cek Status Tool via CLI** untuk cek kesehatan SEMUA 24 tool sekaligus, bukan satu-satu.
