## Tim & peran (Pro/Enterprise)

Beberapa pentester di bawah satu akun. Ditambahkan dari **portal admin → Tim**.

| Peran | Bisa |
|---|---|
| Owner | Semua — project, kredensial, tim, setelan, lisensi. |
| Analyst | Menjalankan pentest; tak mengubah tim/lisensi. |
| Viewer | Hanya baca temuan & laporan. |

Anggota login di portal member dengan kredensial yang Anda buatkan. Di **Community**, cukup satu akun pemilik.

## Akun Saya

Menu **Akun Saya** untuk:

- Memperbarui profil (nama, perusahaan, telepon).
- Mengganti kata sandi (butuh sandi lama).

Email tak dapat diubah sendiri karena menjadi identitas login.

> Di portal member online (tempat berlangganan), di sini pula **Kode Sinkron Instance** ditampilkan untuk aktivasi lisensi.
