**Code: CASA-E014**

## Symptoms

Uploading an XML file from Burp under the **Import** menu fails, or succeeds but fewer findings come in than expected.

## Most common causes

**1. Wrong file format.** CASA only reads XML from Burp's **"Report issues"** feature (right-click a target in Site map → *Report issues* → pick the **XML** format). This is **different** from:
   - A Burp project file (`.burp`) — can't be read.
   - A JSON export — not supported, it must be XML.
   - XML from another feature (e.g. plain Scanner results not exported via "Report issues") — its structure is different and won't parse.

**2. File larger than 8 MB.** That's the upload size limit. If your Burp scan covers a huge number of issues, generate the report per-target/per-session instead of all at once.

**3. Valid XML but 0 issues parsed** — the error message says exactly this. Usually because the XML is empty (no issues were selected in Site map when generating the report) or the XML got corrupted/truncated during download.

## Steps to verify

1. In Burp: Target → Site map → select the relevant host → right-click → **Report issues**.
2. Make sure the output format is **XML** (not HTML), and **tick the issues you want to export** (if none are ticked, the result is empty).
3. Save it, check the file size (`ls -la` on your computer) — if it's over 8MB, split it into multiple exports by target group.
4. Upload again under the **Import** menu, making sure to pick the correct program from the dropdown before uploading.

## If you've tried all that and it still fails

Open the XML file in a text editor; the first line should start with `<?xml version="1.0"?>` followed by an `<issues>` tag — if it's broken/truncated (e.g. missing the closing `</issues>` tag at the end of the file), the file got corrupted during download from Burp. Regenerate the report from Burp.
