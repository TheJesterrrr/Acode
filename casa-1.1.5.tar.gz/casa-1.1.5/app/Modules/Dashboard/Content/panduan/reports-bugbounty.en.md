## Submit-ready reports

CASA assembles reports you can send straight to a bug bounty program. Open **Reports** (list of all reports) or generate one from a project: **Projects → pick a project → Reports → Generate**.

## Pick a template

| Template | For |
|---|---|
| HackerOne / Bugcrowd / Intigriti / YesWeHack | Bug bounty platform submission |
| Technical | A full technical report |
| Executive | A summary for management |

## Structure of each finding

Every vulnerability is written in the standard submission format:

- **Summary** — a brief description of the vulnerability.
- **Steps to Reproduce** — numbered reproduction steps.
- **Impact** — what happens if it's exploited.
- **Proof of Concept** — evidence (request/response).
- **Remediation** — fix recommendations.
- **References** — links to CWE, CVE (NVD), and MITRE ATT&CK.

## Export

- **View** (HTML), **PDF** (ready to attach), or **raw Markdown** (paste into the platform).
- The executive summary & compliance (OWASP) section are drafted with help from the **AI Report Writer**.

> Tip: fill in Steps to Reproduce & PoC with real evidence before submitting so triagers can validate it quickly.
