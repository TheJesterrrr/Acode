**Code: CASA-E009**

## Symptoms

The CASA portal looks "broken" after the server's network/IP changes — links inside the app point to the old address, redirects go wrong, or assets (CSS/JS/images) fail to load, even though the server itself is running fine.

## Cause

The portal address (`app.baseURL`) is written **once** into the `.env` file during installation (e.g. `http://10.101.20.200.nip.io:8008/` or a fixed domain). CASA uses this value to build every internal link. If the server's IP/domain changes afterward, the value in `.env` goes stale and doesn't adjust automatically.

## Steps (SSH into the CASA server)

```bash
cd /var/www/casa

# 1. See the currently stored baseURL value
grep "^app.baseURL" .env

# 2. Change it to the correct address (adjust the URL to the new IP/domain)
sudo sed -i "s|^app.baseURL.*|app.baseURL = 'http://NEW-ADDRESS:8008/'|" .env

# 3. Verify it changed
grep "^app.baseURL" .env

# 4. Clear the cache so the change takes effect immediately
php spark cache:clear
```

Reopen the portal in your browser and check whether links & assets look normal now.

> If you're using a nip.io domain (e.g. `10.101.20.200.nip.io`) and the server's IP changed, also update the IP portion inside that nip.io domain — it's a DNS trick that maps a domain name straight to the IP written inside it, not real DNS you can update separately.
