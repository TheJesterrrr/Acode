## Advanced Lab (Pro/Enterprise)

Vulnerability classes that need context — not just scanner patterns. Accessed per-project.

## IDOR / BOLA — CWE-639

Test cross-user object access while authenticated.

1. Fill in two **Test Accounts** (A & B) on the project.
2. Open **projects → (project) → IDOR**.
3. CASA logs in as A, then tries accessing an object belonging to B — *log in as A → swap in B's token → replay → compare* — and gives a verdict.

## AuthZ Matrix — CWE-863

An **endpoint × role** matrix (including Anonymous). CASA tests every combination and flags access that succeeded when it should have been denied (Broken Access Control).

## Business Logic — CWE-840

Test business-logic manipulation: negative/zero/excessive quantities, changed prices, replayed transactions — weaknesses a normal scanner won't catch.

## Automation

Schedule a recurring **Mission** (weekly, etc) for continuous monitoring. Accessed from the project page.

> Features marked Pro/Enterprise require an active license — see the **License & Activation** guide.
