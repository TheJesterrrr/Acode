## Follow the program's rules

Every bug bounty program has Rules of Engagement. Breaking them can get your report rejected, the reward withheld, or get you banned. CASA helps you comply, but **responsibility is always yours**.

## Scope

- Only test **in-scope** assets. Out-of-scope testing is a serious violation.
- CASA enforces scope during scanning, but during manual hunting (Burp) **you** are the one who has to stay in scope.

## Automated scanner restrictions

Many programs **ban automated vulnerability scanners** (Nuclei, etc) and apply a **lockout if you exceed the normal rate**. On programs like that:

- **Don't tick** "Allow automated scanners" when creating the program.
- CASA forces **Light** scanning + recon only (no mass-scanning) to stay safe.
- Do vulnerability testing **manually**, then Import the results.

## Rate & load

Respect the program's rate limits. Don't overload the target's infrastructure. Recon just enough; don't brute-force aggressively unless explicitly allowed.

## Commonly disallowed / excluded issues

SPF/DMARC, cookie flags, clickjacking with no impact, self-XSS, missing security headers, banner disclosure, CSRF on non-sensitive forms, rate-limiting, OPTIONS/TRACE — these are usually **not eligible**. List them under the program's **Excluded finding types** so CASA flags them.

## Safe harbor & disclosure

Follow the program's **safe harbor** terms. Don't access or retain more user data than needed for a PoC. **Don't publish** findings before you're allowed to (respect non-disclosure).

> Principle: test only what's allowed, prove it with the least access necessary, report it honestly.
