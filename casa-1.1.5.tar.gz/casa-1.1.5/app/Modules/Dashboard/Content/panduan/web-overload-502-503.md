**Kode: CASA-E007**

## Gejala

Browser menampilkan **502 Bad Gateway** atau **503 Service Unavailable** saat beberapa scan/laporan berjalan bersamaan. Beda dari panduan **VM / Aplikasi CASA Mati Total** — di sini web server-nya **masih hidup**, cuma kehabisan "slot" untuk melayani request baru.

## Penyebab

Web server (Apache `httpd` + PHP-FPM) punya batas jumlah proses yang boleh jalan bersamaan (`MaxRequestWorkers` di Apache, `pm.max_children` di PHP-FPM). Kalau beberapa halaman berat dibuka bersamaan — mis. beberapa laporan besar coba di-generate PDF sekaligus, atau banyak tab mission ter-refresh otomatis — semua slot proses bisa penuh, dan request baru ditolak dengan 502/503 sampai ada slot yang kosong lagi.

## Langkah (SSH ke server CASA)

```bash
# 1. Lihat berapa banyak proses httpd/php-fpm yang sedang jalan
ps aux | grep -E "httpd|php-fpm" | grep -v grep | wc -l

# 2. Cek konfigurasi batas proses saat ini
httpd -V | grep -i "server mpm"
grep -r "MaxRequestWorkers\|pm.max_children" /etc/httpd/ /etc/php-fpm.d/ 2>/dev/null

# 3. Cek log error untuk konfirmasi (baris "server reached MaxRequestWorkers"
#    atau "server is busy" memastikan ini memang kehabisan slot)
sudo tail -50 /var/log/httpd/error_log 2>/dev/null

# 4. Restart layanan untuk melepas proses yang nyangkut (langkah sementara)
sudo systemctl restart httpd php-fpm
```

## Solusi jangka panjang

Kalau ini sering terjadi, naikkan batas proses secara wajar (sesuaikan dengan RAM VM — tiap proses PHP-FPM bisa makan puluhan-ratusan MB, jangan dinaikkan sembarangan tanpa cek RAM dulu lewat `free -h`):

```bash
# Edit nilai pm.max_children di konfigurasi PHP-FPM (sesuaikan path & angka)
sudo nano /etc/php-fpm.d/www.conf
# cari baris "pm.max_children = ..." lalu naikkan sedikit, simpan

sudo systemctl restart php-fpm
```

> Menaikkan batas proses TANPA menambah RAM VM hanya memindahkan masalah ke OOM (lihat panduan **VM / Aplikasi CASA Mati Total**) — pastikan RAM memang cukup sebelum menaikkan angka ini.
