## Gejala

Laporan yang dipilih berbahasa Inggris, tapi sebagian judul/deskripsi temuan masih muncul dalam Bahasa Indonesia (atau sebaliknya).

## Penyebab

Temuan lama yang tersimpan sebelum sebuah laporan pernah dibuka dalam bahasa tertentu masih memakai teks asli saat disimpan. Membuka ulang laporannya dalam bahasa pilihan akan menyusun ulang kontennya secara segar.

## Langkah

1. Buka laporannya di menu **Reports**.
2. Klik toggle **Indonesia** / **English** di pojok kanan atas halaman laporan.
3. Laporan disusun ulang segar dalam bahasa yang dipilih, termasuk temuan lama yang sebelumnya tersimpan campur bahasa.
