## Ringkas

Halaman ini menjelaskan dua hal operasional owner:

1. **Update paket** — merilis versi aplikasi baru agar muncul di **Download App** pelanggan.
2. **Kebijakan prorata** — bagaimana koin dipotong saat pelanggan **upgrade/ganti** langganan.

---

## Bagian 1 — Update paket (rilis versi baru)

Pelanggan mengunduh installer dari menu **Download App** (portal member). Daftar rilis dibaca **langsung** dari folder `writable/releases/` di server owner — jadi update paket = **taruh berkas baru** di folder itu, tanpa ubah basis data.

### Cara membuat paket

Di sisi dev/owner, dari root repo:

```
bash build/package.sh
```

Script menghasilkan `casa-<versi>.tar.gz` yang berisi produk **lengkap** (termasuk `vendor/`) + `install.sh` auto-provisioner + `.env.example`, dan **tanpa** rahasia (`.env` owner, `writable/casa.key`, dan **private key** lisensi). Public key produksi sudah ditanam di `Config\Edition`.

> **Wajib diperiksa:** paket tidak boleh memuat `.env` owner atau `license.privateKey`. Private key hanya milik console owner — bila bocor, siapa pun bisa menerbitkan lisensi palsu.

### Cara mengunggah (cPanel)

1. **File Manager** → `/casa_app/writable/releases/` (buat folder `releases` bila belum ada).
2. **Upload** `casa-<versi>.tar.gz`. **Jangan di-extract** — berkas di-stream apa adanya lewat controller ber-auth (bukan tautan publik).
3. Selesai — langsung muncul di **Download App** (terbaru di atas, lengkap ukuran + SHA256).

Format nama yang dikenali: `casa-<versi>.tar.gz` (VPS/Linux), `casa-...-docker.zip` (Docker), `casa-....exe` (Windows). Nama di luar pola itu diabaikan (anti path-traversal).

### Apakah pelanggan harus install ulang?

Tidak untuk update **konten deteksi**. Ada dua jalur berbeda:

| Yang berubah | Cara sampai ke pelanggan |
|---|---|
| **Template/aturan/CVE** (deteksi) | Otomatis via **Detection Feed** → `casa:feed-sync` (cron). Tanpa unduh ulang. |
| **Tool aktif** untuk member | Otomatis — centang di Detection Feed, versi feed naik, tersinkron. |
| **Kode aplikasi** (fitur/menu/perbaikan) | Pelanggan unduh paket baru & jalankan `install.sh` (idempoten) atau prosedur update. |

Jadi untuk perbaikan besar → rilis paket baru. Untuk deteksi terbaru → cukup **publikasikan feed** (lihat panduan **Detection Feed (CVE)**).

---

## Bagian 2 — Kebijakan prorata (upgrade langganan)

Saat pelanggan **berlangganan** sementara masih punya langganan **aktif**, CASA **tidak** memotong harga penuh. Ia menghitung **selisih** secara adil:

### Rumus

```
kredit sisa = koin_dibayar × (hari_tersisa ÷ total_hari)
potongan    = harga_paket_baru − kredit_sisa   (minimal 0)
```

- **`koin_dibayar`** — koin yang dibayar untuk langganan berjalan (hibah manual = 0 → tak ada kredit).
- **`hari_tersisa`** — dari hari ini sampai `expires_at` langganan lama.
- **`total_hari`** — durasi penuh langganan lama.

Langganan lama otomatis ditandai **`replaced`** agar **tidak ada dua langganan aktif** bertumpuk. License key aktif yang diserahkan ke instance selalu langganan **aktif terbaru**.

### Contoh

Pelanggan beli **Pro** (150.000 koin, 1 bulan). **Di hari yang sama** upgrade ke **Enterprise** (500.000 koin):

```
kredit sisa = 150.000 × (≈30 ÷ 30) ≈ 150.000
potongan    = 500.000 − 150.000    = 350.000 koin
```

Dipotong **350.000**, bukan 500.000. Pro ditandai `replaced`, Enterprise menjadi langganan aktif.

### Catatan

- **Downgrade**: bila kredit sisa lebih besar dari harga paket baru, potongan = **0** (tidak ada koin balik otomatis; owner bisa hibah bila perlu).
- **Badge paket** pelanggan (Community/Pro/Enterprise) mengikuti **langganan aktif** mereka di portal ini — bukan lisensi instance.
- **Hibah/manual** oleh owner tidak memotong koin dan tidak menghasilkan kredit prorata.

> Ingin perbaiki potongan penuh yang **terlanjur** terjadi sebelum kebijakan ini aktif? Cukup **Hibah koin** selisihnya ke pelanggan dari detail pelanggan.
