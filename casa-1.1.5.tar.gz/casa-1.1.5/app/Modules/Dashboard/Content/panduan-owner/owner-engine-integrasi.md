## Engine Health

Menu **Engine Health** memantau mesin scan:

- **Worker (casa:work)** — denyut cron; hijau bila jalan <5 menit lalu.
- **Antrean task** — pending/running/done/error/skipped.
- **Status mission** — planning→…→done.
- **Tools terpasang** & **AI aktif**.
- **Error terbaru** & **riwayat cron**.

Jika worker "Terlambat" atau banyak task error, periksa cron `casa:work` dan tool yang terpasang.

## Integrasi & Notifikasi

Menu **Integrasi** mengatur:

- **Email (SMTP)** — host, port, user, sandi, from.
- **Slack** — webhook URL.
- **Webhook keluar** — kirim temuan baru ke sistem lain.
- **Jira** — base URL, user, API token.

Nilai rahasia (sandi/token) disimpan **terenkripsi**.

## Cron yang perlu dipasang

Di server (owner & pelanggan sesuai peran):

```
* * * * * casa:work        # proses task & majukan mission
* * * * * casa:schedule    # pemindaian terjadwal
0 3 * * * casa:phonehome   # telemetri (pelanggan)
30 3 * * * casa:sync       # sinkron lisensi (pelanggan)
0 4 * * * casa:feed-sync   # sinkron feed deteksi (pelanggan)
```
