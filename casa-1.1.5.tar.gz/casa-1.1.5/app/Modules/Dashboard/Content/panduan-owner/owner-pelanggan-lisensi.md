## Pelanggan

Menu **Pelanggan** menampilkan seluruh member: status, saldo koin, langganan, dan **ikatan instance**.

Pada detail pelanggan Anda bisa:

- **Hibah koin** (manual, mis. kompensasi).
- **Terbitkan langganan manual** (tanpa koin).
- **Lepas ikatan instance** — memungkinkan pelanggan pindah/ganti VPS.
- Ubah status akun (aktif/suspend/banned).

## Menerbitkan license key

Lisensi = token RSA yang ditandatangani private key Anda; produk memverifikasinya offline.

1. **Lisensi & Aktivasi → Generator** (hanya muncul di konsol owner).
2. Pilih tier + masa + nama customer → **Terbitkan** → salin key.
3. Atau lewat langganan koin: pelanggan berlangganan → key otomatis terbit di akunnya.

## Model aktivasi pelanggan

Pelanggan mengaktifkan lewat **Kode Sinkron** (Sinkron Online), bukan salin-tempel manual. Instance menarik token dari server Anda, lalu verifikasi offline. Perpanjangan/naik tier berlaku otomatis pada sinkron berikutnya.

## Node-lock

Satu lisensi terikat ke satu instance (install_id). Bila pelanggan ganti VPS, gunakan **Lepas ikatan** di detail pelanggan.
