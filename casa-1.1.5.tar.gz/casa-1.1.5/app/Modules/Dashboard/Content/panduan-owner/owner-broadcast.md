## Broadcast

Menu **Broadcast** mengirim pengumuman ke seluruh instance pelanggan (mis. rilis fitur, jadwal maintenance, peringatan keamanan).

## Membuat pengumuman

1. Isi **Judul**, **Isi**, dan **Level** (Info / Warning / Critical).
2. **Terbitkan** — pengumuman aktif langsung tersedia.

## Mengelola

- **Aktifkan/Nonaktif** — sembunyikan tanpa menghapus.
- **Hapus** — buang permanen.

## Bagaimana instance membacanya

Instance pelanggan membaca pengumuman aktif via endpoint publik `api/announcements`. Hanya yang berstatus aktif yang dikirim.

> Gunakan level **Critical** hemat — hanya untuk hal mendesak (mis. kerentanan yang perlu update segera).
