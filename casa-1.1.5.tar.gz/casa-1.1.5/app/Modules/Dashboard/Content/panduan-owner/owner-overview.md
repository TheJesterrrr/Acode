## Konsol Owner

Sebagai owner, konsol Anda (casaadmin) adalah pusat kendali bisnis CASA: kelola pelanggan, terbitkan lisensi, atur harga, publikasikan feed deteksi, dan pantau seluruh instance.

## Dua mode, satu kode

CASA berjalan dalam dua mode dari satu basis kode:

| Mode | Aktif bila | Fitur |
|---|---|---|
| **Owner** | punya private key lisensi (`.env`) | generator lisensi, Pelanggan, Analytics, Detection Feed, Plans, Broadcast |
| **Produk** | instance pelanggan (tanpa private key) | portal pentest + admin lokal, lisensi terkunci |

Menu bertanda **owner** hanya muncul di konsol Anda.

## Peta menu owner

- **Analytics** — angka bisnis (pelanggan, instance, tier, koin).
- **Pelanggan** — kelola akun + billing manual + lepas ikatan instance.
- **Plans & Pricing** — paket koin topup.
- **Lisensi & Aktivasi** — generator license key.
- **Detection Feed** — publikasikan konten deteksi ke pelanggan.
- **Broadcast** — pengumuman ke instance.
- **Engine Health / Integrasi / Monitoring** — operasional.

> Jaga **private key lisensi** hanya di server owner — tak pernah dikirim ke pelanggan.
