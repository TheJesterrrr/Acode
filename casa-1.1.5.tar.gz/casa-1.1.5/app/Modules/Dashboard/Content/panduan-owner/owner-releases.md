# Kelola Rilis Aplikasi

Menu **Rilis Aplikasi** (`casaadmin/releases`) adalah tempat Anda, sebagai pemilik CASA, menerbitkan versi baru aplikasi untuk pelanggan — tanpa perlu FTP atau File Manager lagi.

## Satu folder, dua arah otomatis

Berkas yang Anda unggah di sini masuk ke `writable/releases/`. Folder itu dibaca **otomatis** oleh dua pihak:

1. **casamember → Download App** — pelanggan yang login melihat paket terbaru untuk diunduh & dipasang.
2. **Instance pelanggan** — saat sinkron lisensi harian, instance membandingkan versinya dengan rilis tertinggi di sini; bila lebih baru, muncul tawaran **Update Aplikasi** di instance mereka.

Jadi cukup unggah sekali di konsol ini — casamember dan seluruh instance langsung ikut.

## Mengunggah rilis

1. Klik **Unggah rilis**.
2. Pilih berkas paket. Namanya **wajib** berpola `casa-<versi>.tar.gz` (VPS/Linux), `.zip` (Docker), atau `.exe` (Windows) — contoh: `casa-1.1.2.tar.gz`.
3. (Opsional) isi **Catatan versi** — ringkasan perubahan, tampil di daftar.
4. Klik **Unggah & publikasikan**.

Sistem otomatis menghitung **SHA-256** dan menyimpannya sebagai sidecar `.sha256`. Nilai itulah yang dipakai instance memverifikasi paket saat `casa:apply-update` — jadi pelanggan tak akan memasang berkas yang rusak/terpotong.

## Versi "terbaru"

Di antara paket `.tar.gz`, yang bernomor **versi tertinggi** otomatis ditandai **terbaru** dan itulah yang ditawarkan sebagai update ke pelanggan. Anda boleh menyimpan beberapa versi lama sekaligus (untuk rollback); yang tertinggi tetap jadi acuan update.

## Menghapus rilis

Tombol hapus membuang paket beserta sidecar `.sha256` dan catatannya. Pelanggan tak lagi bisa mengunduh versi itu. Hati-hati menghapus versi yang masih dipakai pelanggan untuk pemasangan baru.

## Catatan penting

- **Bangun paket dari sumber produksi.** Paket harus memuat kunci publik lisensi **produksi**; `build/package.sh` punya gerbang yang menolak build dari sumber berkunci non-produksi. Paket salah-kunci akan membuat lisensi pelanggan "hilang" saat update.
- **Ukuran unggah.** Paket VPS penuh ±6 MB. Bila unggahan gagal, cek batas `upload_max_filesize`/`post_max_size` PHP di hosting.
- **Backup instance.** Proses update di instance selalu membuat backup app+DB otomatis sebelum menimpa kode — tetapi ingatkan pelanggan untuk tidak menghapus folder `writable/backups/`.
