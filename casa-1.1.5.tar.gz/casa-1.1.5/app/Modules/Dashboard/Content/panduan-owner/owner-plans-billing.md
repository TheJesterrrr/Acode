## Plans & Pricing

Menu **Plans & Pricing** mengelola **paket koin** yang muncul di topup portal member.

- **Tambah/Edit** paket: label, harga (Rp), jumlah koin, bonus, urutan.
- **Aktif/Nonaktif** atau **hapus** paket.
- **Pulihkan paket default** — mengisi 5 paket standar bila kosong.

> Jika pelanggan melihat topup **kosong**, buka Plans & Pricing → **Pulihkan paket default**.

## Koin & langganan

- **1 koin = Rp 1.**
- Pelanggan **topup koin** (via Mayar), lalu **berlangganan** (koin dipotong → license key terbit).
- Owner juga bisa **hibah koin** / **langganan manual** dari detail pelanggan.

## Mayar (gateway pembayaran)

Modul topup memakai **Mayar**: invoice dibuat via API, koin dikreditkan **hanya setelah pembayaran terverifikasi server** (anti-manipulasi; webhook hanya pemicu).

Untuk mengaktifkan pembayaran nyata, isi kredensial di `.env`:

```
mayar.apiKey = ...
mayar.webhookSecret = ...
mayar.baseUrl = ...
```

Tanpa kunci ini, topup berstatus pending (owner bisa kredit manual).
