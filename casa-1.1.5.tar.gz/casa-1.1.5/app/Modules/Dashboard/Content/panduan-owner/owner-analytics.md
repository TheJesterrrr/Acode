## Analytics

Menu **Analytics** merangkum kesehatan bisnis Anda:

- **Pelanggan aktif** + pelanggan baru 30 hari.
- **Instance aktif** (melapor 3 hari terakhir) / total.
- **Langganan aktif** vs kedaluwarsa.
- **Koin terpakai** (indikator pendapatan).
- Sebaran **tier** (instance & langganan) dan **versi** terpasang.
- Tabel langganan terbaru & instance pelanggan.

## Monitoring instance

Menu **Monitoring** menampilkan laporan **phone-home** tiap instance: install_id, tier, versi, jumlah project/mission/finding, dan kapan terakhir melapor. Tanpa data pentest sensitif — hanya hitungan & status.

## Sumber data

Angka berasal dari telemetri ringan yang dikirim instance pelanggan (1 permintaan kecil/hari). Instance yang tak melapor >3 hari dianggap tidak aktif.

> Gunakan Analytics untuk memutuskan perpanjangan, deteksi churn, dan melihat adopsi versi.
