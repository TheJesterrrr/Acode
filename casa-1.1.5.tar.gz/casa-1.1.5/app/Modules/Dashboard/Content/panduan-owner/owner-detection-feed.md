## Detection Feed

Menu **Detection Feed** memungkinkan Anda memperbarui konten deteksi (template/aturan nuclei) secara terpusat, lalu **seluruh instance pelanggan menariknya otomatis** — analog dengan plugin-feed Nessus.

## Cara kerja

```
Owner publish versi feed  ->  api/feed/latest  ->  casa:feed-sync (cron pelanggan)
                                                    -> update nuclei-templates
```

## Mempublikasikan versi baru

1. Buka **Detection Feed**.
2. Isi **Nuclei templates ref/tag** (mis. `latest` atau `v10.2.6`) dan **catatan rilis**.
3. Klik **Publikasikan** — versi feed naik.
4. Instance pelanggan yang menjalankan `casa:feed-sync` (cron harian) akan memperbarui konten deteksinya ke versi itu.

## Endpoint manifest

`api/feed/latest` mengembalikan versi feed terbaru (dibaca instance). Bersifat publik (hanya metadata, bukan konten rahasia).

> Menaikkan versi = memberi sinyal "ada update" ke semua pelanggan. Naikkan setiap kali ada CVE/aturan penting baru.
