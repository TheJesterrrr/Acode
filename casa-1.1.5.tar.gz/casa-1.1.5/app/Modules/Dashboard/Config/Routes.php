<?php

declare(strict_types=1);

use CodeIgniter\Router\RouteCollection;

/** Rute dasbor (CES 13.10). */

/** @var RouteCollection $routes */
$ns = 'App\Modules\Dashboard\Controllers';

$routes->get('member', 'MemberDashboardController::index', ['namespace' => $ns, 'filter' => 'member']);
$routes->get('casaadmin', 'AdminDashboardController::index', ['namespace' => $ns, 'filter' => 'admin']);
$routes->get('panduan', 'GuideController::index', ['namespace' => $ns, 'filter' => 'member']);
$routes->get('panduan/gambar/(:segment)', 'GuideController::gambar/$1', ['namespace' => $ns, 'filter' => 'member']);
$routes->get('panduan/(:segment)', 'GuideController::show/$1', ['namespace' => $ns, 'filter' => 'member']);

// Panduan OWNER (admin console).
$routes->get('casaadmin/panduan', 'OwnerGuideController::index', ['namespace' => $ns, 'filter' => 'admin']);
$routes->get('casaadmin/panduan/(:segment)', 'OwnerGuideController::show/$1', ['namespace' => $ns, 'filter' => 'admin']);
