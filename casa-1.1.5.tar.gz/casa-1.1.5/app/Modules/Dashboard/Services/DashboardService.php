<?php

declare(strict_types=1);

namespace App\Modules\Dashboard\Services;

use CodeIgniter\Database\BaseConnection;
use Config\Database;

/**
 * DashboardService — angka ringkas untuk dasbor (CES 13.4).
 *
 * Dasbor CoreNet "jangan ramai": hanya angka yang menuntut tindakan. Tiap angka
 * satu kueri ringkas; tak ada agregasi berat yang memberati shared hosting.
 *
 * Skeleton hanya menyediakan kerangka dan satu contoh angka. Tambahkan angka
 * milik modul bisnis di sini setelah modulnya dibuat — gunakan helper count()
 * agar polanya seragam, dan hindari kueri yang memindai tabel besar.
 */
final class DashboardService
{
    private BaseConnection $db;

    public function __construct(?BaseConnection $db = null)
    {
        $this->db = $db ?? Database::connect();
    }

    /**
     * Angka untuk dasbor administrator.
     *
     * Contoh penambahan setelah modul bisnis ada:
     *     'hadir_hari_ini' => $this->count('absensi', 'DATE(waktu)=CURDATE()'),
     */
    public function adminStats(): array
    {
        return [
            'customers'       => $this->count('customers', 'deleted_at IS NULL'),
            'tools_installed' => $this->count('tool_install', "status='installed'"),
            'tools_total'     => $this->count('tool', '1=1'),
            'ai_enabled'      => $this->count('ai_provider', 'enabled=1'),
            'missions'        => $this->count('mission', '1=1'),
            'findings'        => $this->count('finding', '1=1'),
            'audit'           => $this->count('audit_logs', '1=1'),
        ];
    }

    /**
     * Angka untuk lencana sidebar admin. WAJIB ringan — dipanggil pada
     * setiap permintaan halaman admin.
     */
    public function adminBadges(): array
    {
        return [];
    }

    /** Angka + aktivitas untuk dasbor member (di-scope per pemilik). */
    public function memberStats(int $customerId): array
    {
        $c = (int) $customerId;
        $sev = ['crit' => 0, 'high' => 0, 'med' => 0, 'low' => 0, 'info' => 0];
        foreach ($this->db->query(
            "SELECT f.severity s, COUNT(*) n FROM finding f JOIN project p ON f.project_id=p.id WHERE p.customer_id={$c} GROUP BY f.severity"
        )->getResultArray() as $r) {
            $sev[$r['s']] = (int) $r['n'];
        }

        // Risk score 0-100 (jenuh di 100): critical paling berbobot.
        $riskScore = min(100, $sev['crit'] * 25 + $sev['high'] * 10 + $sev['med'] * 3 + $sev['low']);

        // Progres remediasi (kolom remediation_status; kompatibel bila kolom baru).
        $rem = ['open' => 0, 'in_progress' => 0, 'fixed' => 0, 'risk_accepted' => 0, 'false_positive' => 0];
        try {
            foreach ($this->db->query("SELECT f.remediation_status s, COUNT(*) n FROM finding f JOIN project p ON f.project_id=p.id WHERE p.customer_id={$c} GROUP BY f.remediation_status")->getResultArray() as $r) {
                $rem[$r['s'] ?: 'open'] = (int) $r['n'];
            }
        } catch (\Throwable $e) {
            $rem['open'] = array_sum($sev);
        }

        // Tren temuan 8 minggu terakhir (isi celah dengan 0).
        $byWeek = [];
        foreach ($this->db->query("SELECT YEARWEEK(f.created_at,3) yw, COUNT(*) n FROM finding f JOIN project p ON f.project_id=p.id WHERE p.customer_id={$c} AND f.created_at>=DATE_SUB(CURDATE(),INTERVAL 8 WEEK) GROUP BY yw")->getResultArray() as $r) {
            $byWeek[(int) $r['yw']] = (int) $r['n'];
        }
        $trend = [];
        for ($i = 7; $i >= 0; $i--) {
            $ts      = strtotime("-{$i} week");
            $trend[] = ['lbl' => date('d/m', $ts), 'n' => $byWeek[(int) date('oW', $ts)] ?? 0];
        }

        $sevOrder  = ['crit', 'high', 'med', 'low', 'info'];
        $topAssets = $this->db->query("SELECT f.asset a, COUNT(*) n, MIN(FIELD(f.severity,'crit','high','med','low','info')) sr FROM finding f JOIN project p ON f.project_id=p.id WHERE p.customer_id={$c} AND f.asset IS NOT NULL AND f.asset<>'' GROUP BY f.asset ORDER BY n DESC LIMIT 6")->getResultArray();
        foreach ($topAssets as &$ta) {
            $ta['sev'] = $sevOrder[((int) $ta['sr']) - 1] ?? 'info';
        }
        unset($ta);

        $owasp = $this->db->query("SELECT f.owasp o, COUNT(*) n FROM finding f JOIN project p ON f.project_id=p.id WHERE p.customer_id={$c} AND f.owasp IS NOT NULL AND f.owasp<>'' GROUP BY f.owasp ORDER BY n DESC LIMIT 6")->getResultArray();

        return [
            'projects'        => $this->count('project', "customer_id={$c} AND deleted_at IS NULL"),
            'missions'        => $this->count('mission', "customer_id={$c}"),
            'findings_total'  => array_sum($sev),
            'severity'        => $sev,
            'reports'         => (int) ($this->db->query("SELECT COUNT(*) n FROM report r JOIN project p ON r.project_id=p.id WHERE p.customer_id={$c}")->getRowArray()['n'] ?? 0),
            'risk_score'      => $riskScore,
            'remediation'     => $rem,
            'trend'           => $trend,
            'top_assets'      => $topAssets,
            'owasp'           => $owasp,
            'assets_total'    => (int) ($this->db->query("SELECT COUNT(*) n FROM asset a JOIN project p ON a.project_id=p.id WHERE p.customer_id={$c}")->getRowArray()['n'] ?? 0),
            'recent_missions' => $this->db->query("SELECT id,brief,state,created_at FROM mission WHERE customer_id={$c} ORDER BY id DESC LIMIT 5")->getResultArray(),
            'recent_findings' => $this->db->query("SELECT f.id,f.ref,f.severity,f.title,f.tool FROM finding f JOIN project p ON f.project_id=p.id WHERE p.customer_id={$c} ORDER BY FIELD(f.severity,'crit','high','med','low','info'), f.id DESC LIMIT 6")->getResultArray(),
        ];
    }

    /* ---------------------------------------------------------------- internal */

    private function count(string $table, string $where): int
    {
        return (int) ($this->db->query("SELECT COUNT(*) n FROM {$table} WHERE {$where}")->getRowArray()['n'] ?? 0);
    }
}
