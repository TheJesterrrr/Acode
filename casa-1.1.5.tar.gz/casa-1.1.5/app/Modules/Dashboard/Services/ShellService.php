<?php

declare(strict_types=1);

namespace App\Modules\Dashboard\Services;

use App\Modules\Auth\Models\CustomerModel;
use App\Modules\Auth\Models\UserModel;
use App\Modules\Licensing\Services\EditionService;
use App\Modules\Notification\Services\NotificationService;

/**
 * ShellService — konteks bersama untuk kerangka halaman (nav, bell, identitas).
 * Dipanggil BaseController agar controller lain tak menyentuh kueri (CES 13.2).
 */
final class ShellService
{
    public function __construct(
        private readonly NotificationService $notify = new NotificationService(),
        private readonly CustomerModel $customers = new CustomerModel(),
        private readonly UserModel $users = new UserModel(),
        private readonly DashboardService $dash = new DashboardService(),
        private readonly EditionService $edition = new EditionService(),
    ) {
    }

    public function member(int $customerId, string $active): array
    {
        $c   = $this->customers->find($customerId);
        $ed  = $this->edition->resolve($customerId);

        return [
            'name'       => $c['name'] ?? lang('Chrome.customer'),
            'role'       => lang('Chrome.member'),
            'team_role'  => (string) (session()->get('team_role') ?: 'owner'),
            'tier'       => $ed['tier'],
            'tier_label' => $ed['label'],
            'active'     => $active,
            'unread'     => $this->notify->unreadCount('customer', $customerId),
            'notif_url'  => site_url('member/notifikasi'),
            'logout_url' => site_url('logout'),
            'user_menu'  => [
                ['label' => lang('Chrome.myAccount'), 'icon' => 'bi-person', 'url' => site_url('member/akun')],
            ],
        ];
    }

    public function admin(int $userId, string $active): array
    {
        $u = $this->users->find($userId);

        return [
            'name'       => $u['name'] ?? 'Admin',
            'role'       => ucfirst((string) ($u['role'] ?? 'admin')),
            'active'     => $active,
            'unread'     => $this->notify->unreadCount('admin'),
            'notif_url'  => site_url('casaadmin/notifikasi'),
            'logout_url' => site_url('logout'),
            'badges'     => $this->dash->adminBadges(),
            'user_menu'  => [
                ['label' => lang('Chrome.settings'), 'icon' => 'bi-gear', 'url' => site_url('casaadmin/settings')],
            ],
        ];
    }
}
