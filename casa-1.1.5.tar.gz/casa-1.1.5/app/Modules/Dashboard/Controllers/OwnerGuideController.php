<?php

declare(strict_types=1);

namespace App\Modules\Dashboard\Controllers;

use App\Controllers\BaseController;
use App\Libraries\Markdown;
use CodeIgniter\Exceptions\PageNotFoundException;

/**
 * OwnerGuideController — panduan untuk OWNER/admin (konsol casaadmin).
 *
 * Owner = pemilik aplikasi CASA, jadi di sini ditampilkan SEMUA panduan:
 *   1) Topik OWNER (Content/panduan-owner/) — billing, lisensi, feed, dll.
 *   2) SELURUH panduan instance (Content/panduan/) — Mulai, Pentest, Bug Bounty,
 *      Troubleshooting, Kelola — supaya owner tahu persis apa yang dialami &
 *      dibaca pelanggan di instance mereka (dukungan jadi mudah).
 *
 * Satu sumber kebenaran: panduan instance dibaca dari registri & berkas milik
 * GuideController (lihat GuideController::catalog()/contentFile()), tidak disalin.
 * Whitelist slug (gabungan owner + instance) menjaga dari path-traversal.
 */
final class OwnerGuideController extends BaseController
{
    /** Topik khusus OWNER. Format: slug => [judul, kategori, ikon, ringkas]. */
    private const ARTIKEL = [
        'owner-overview'          => ['Konsol Owner', 'Owner', 'bi-speedometer2', 'Peta konsol owner, dua mode, dan menu.'],
        'owner-pelanggan-lisensi' => ['Pelanggan & Lisensi', 'Owner', 'bi-people', 'Kelola pelanggan, terbitkan license key, aktivasi.'],
        'owner-plans-billing'     => ['Plans, Koin & Billing', 'Owner', 'bi-tags', 'Paket koin, topup Mayar, langganan.'],
        'owner-update-prorata'    => ['Update Paket & Prorata', 'Owner', 'bi-arrow-repeat', 'Rilis versi baru ke Download App + kebijakan prorata upgrade.'],
        'owner-releases'          => ['Kelola Rilis Aplikasi', 'Owner', 'bi-box-seam', 'Unggah paket rilis dari casaadmin → otomatis ke casamember & instance.'],
        'owner-detection-feed'    => ['Detection Feed (CVE)', 'Owner', 'bi-rss', 'Publikasikan feed deteksi → auto-sync ke pelanggan.'],
        'owner-analytics'         => ['Analytics & Monitoring', 'Owner', 'bi-graph-up', 'Analitik bisnis & pantau instance.'],
        'owner-broadcast'         => ['Broadcast', 'Owner', 'bi-megaphone', 'Kirim pengumuman ke seluruh instance.'],
        'owner-engine-integrasi'  => ['Engine Health & Integrasi', 'Owner', 'bi-hdd-network', 'Kondisi mesin, notifikasi, integrasi.'],
    ];

    public function index(): string
    {
        $kategori = [];

        // 1) Topik owner lebih dulu.
        foreach (self::ARTIKEL as $slug => [$judul, $kat, $ikon, $ringkas]) {
            $kategori[$kat][] = compact('slug', 'judul', 'ikon', 'ringkas');
        }

        // 2) Seluruh panduan instance (ID), dikelompokkan per label kategorinya.
        foreach (GuideController::catalog() as $slug => [$judul, $katKey, $ikon, $ringkas]) {
            $label                = GuideController::categoryLabel($katKey, 'id');
            $kategori[$label][]   = [
                'slug'    => $slug,
                'judul'   => $judul['id'] ?? (is_string($judul) ? $judul : $slug),
                'ikon'    => $ikon,
                'ringkas' => $ringkas['id'] ?? (is_string($ringkas) ? $ringkas : ''),
            ];
        }

        return $this->adminView('App\Modules\Dashboard\Views\panduan_owner\index', [
            'title'    => 'Panduan',
            'kategori' => $kategori,
        ], 'panduan');
    }

    public function show(string $slug): string
    {
        $owner    = self::ARTIKEL;
        $instance = GuideController::catalog();
        $isOwner  = isset($owner[$slug]);
        if (! $isOwner && ! isset($instance[$slug])) {
            throw PageNotFoundException::forPageNotFound('Artikel panduan tidak ditemukan.');
        }

        // Resolusi meta + berkas konten sesuai sumbernya.
        if ($isOwner) {
            [$judul, $kat] = $owner[$slug];
            $judulTeks     = $judul;
            $katTeks       = $kat;
            $berkas        = APPPATH . 'Modules/Dashboard/Content/panduan-owner/' . $slug . '.md';
            $cachePrefix   = 'panduan_owner_';
        } else {
            [$judul, $katKey] = $instance[$slug];
            $judulTeks        = $judul['id'] ?? (is_string($judul) ? $judul : $slug);
            $katTeks          = GuideController::categoryLabel($katKey, 'id');
            $berkas           = GuideController::contentFile($slug, 'id');
            $cachePrefix      = 'panduan_owner_inst_';
        }
        if ($berkas === null || ! is_file($berkas)) {
            throw PageNotFoundException::forPageNotFound('Konten panduan belum tersedia.');
        }

        // Urutan gabungan (owner dulu, lalu instance) untuk navigasi sebelum/berikut.
        $slugs = array_merge(array_keys($owner), array_keys($instance));
        $i     = array_search($slug, $slugs, true);

        $judulOf = static function (string $s) use ($owner, $instance): string {
            if (isset($owner[$s])) {
                return $owner[$s][0];
            }
            $j = $instance[$s][0];

            return $j['id'] ?? (is_string($j) ? $j : $s);
        };

        $kunci = $cachePrefix . $slug . '_' . (int) filemtime($berkas);
        $isi   = cache()->remember($kunci, 86400, static fn (): string => Markdown::render((string) file_get_contents($berkas)));

        return $this->adminView('App\Modules\Dashboard\Views\panduan_owner\artikel', [
            'title'      => $judulTeks,
            'judul'      => $judulTeks,
            'kategori'   => $katTeks,
            'isi'        => $isi,
            'sebelumnya' => $i > 0 ? [$slugs[$i - 1], $judulOf($slugs[$i - 1])] : null,
            'berikutnya' => $i !== false && $i < count($slugs) - 1 ? [$slugs[$i + 1], $judulOf($slugs[$i + 1])] : null,
        ], 'panduan');
    }
}
