<?php

declare(strict_types=1);

namespace App\Modules\Dashboard\Controllers;

use App\Controllers\BaseController;
use App\Libraries\CasaLog;
use App\Libraries\Markdown;
use CodeIgniter\Exceptions\PageNotFoundException;
use CodeIgniter\HTTP\ResponseInterface;

/**
 * GuideController — panduan penggunaan untuk member (CES 13.2 thin).
 *
 * Artikel disimpan sebagai berkas view agar ikut terversi bersama kode dan
 * tidak membebani basis data. DAFTAR di bawah berfungsi sebagai whitelist:
 * hanya slug terdaftar yang dapat dimuat, sehingga tidak ada jalan untuk
 * membaca berkas sembarangan lewat parameter URL (path traversal).
 *
 * Dwibahasa (ID/EN): tiap artikel punya dua berkas — `{slug}.md` (Indonesia,
 * default) dan `{slug}.en.md` (Inggris). Kalau versi Inggris belum ada,
 * otomatis jatuh ke versi Indonesia (bukan 404) supaya artikel baru tetap
 * terbaca sebelum sempat diterjemahkan.
 */
final class GuideController extends BaseController
{
    /** Label kategori per bahasa — dirujuk oleh kunci kategori di ARTIKEL. */
    private const KATEGORI_LABEL = [
        'mulai'           => ['id' => 'Mulai', 'en' => 'Getting Started'],
        'bug-bounty'      => ['id' => 'Bug Bounty', 'en' => 'Bug Bounty'],
        'pentest'         => ['id' => 'Pentest', 'en' => 'Pentest'],
        'troubleshooting' => ['id' => 'Troubleshooting', 'en' => 'Troubleshooting'],
        'kelola'          => ['id' => 'Kelola', 'en' => 'Manage'],
    ];

    /**
     * Daftar artikel panduan: slug => [judul{id,en}, kunci-kategori, ikon, ringkasan{id,en}, scope].
     *
     * Daftar ini sekaligus berfungsi sebagai whitelist — hanya slug terdaftar
     * yang dapat dimuat, sehingga tidak ada jalan membaca berkas sembarangan
     * lewat parameter URL (path traversal). Menambah artikel WAJIB lewat sini,
     * bukan dengan membaca isi folder.
     *
     * Berkas Markdown-nya diletakkan di Modules/Dashboard/Content/panduan/.
     *
     * Elemen ke-5 = SCOPE run-mode:
     *   'all'      → tampil di hub (casamember) DAN instance produk.
     *   'hub'      → hanya hub (billing-only): langganan, koin, unduh app.
     *   'instance' → instance mode PENTEST.
     *   'bounty'   → instance mode BUG BOUNTY.
     * Hub tak boleh menampilkan panduan pentest/bounty (fitur itu tak ada di sana).
     */
    private const ARTIKEL = [
        'mengenal-casa'       => [['id' => 'Mengenal CASA', 'en' => 'Understanding CASA'], 'mulai', 'bi-compass', ['id' => 'Konsep, alur Mission→Reporting, dan dua portal.', 'en' => 'Concepts, the Mission→Reporting flow, and the two portals.'], 'all'],
        'peta-menu'           => [['id' => 'Peta Menu & Fungsi', 'en' => 'Menu Map & Functions'], 'mulai', 'bi-list-check', ['id' => 'Rujukan lengkap: tiap menu pada aplikasi beserta fungsinya.', 'en' => 'Full reference: every menu in the app and what it does.'], 'instance'],
        // --- Bug Bounty ---
        'mengenal-bug-bounty' => [['id' => 'Mengenal Bug Bounty', 'en' => 'Understanding Bug Bounty'], 'mulai', 'bi-bullseye', ['id' => 'Apa itu mode Bug Bounty & bedanya dengan Pentesting.', 'en' => 'What Bug Bounty mode is & how it differs from Pentesting.'], 'bounty'],
        'program-scope'       => [['id' => 'Program & Scope', 'en' => 'Program & Scope'], 'bug-bounty', 'bi-diagram-3', ['id' => 'Tambah program, tetapkan scope in/out, excluded types.', 'en' => 'Add a program, set in/out scope, excluded types.'], 'bounty'],
        'alur-bounty'         => [['id' => 'Alur Bug Bounty', 'en' => 'Bug Bounty Workflow'], 'bug-bounty', 'bi-signpost-split', ['id' => 'Recon → hunting manual (Burp) → Import → Report → Submission.', 'en' => 'Recon → manual hunting (Burp) → Import → Report → Submission.'], 'bounty'],
        'report-submission'   => [['id' => 'Report & Submission', 'en' => 'Report & Submission'], 'bug-bounty', 'bi-send', ['id' => 'Report siap-submit H1/Bugcrowd + lacak status; anti kesan "AI yang kerja".', 'en' => 'Submit-ready H1/Bugcrowd reports + status tracking; avoids looking AI-written.'], 'bounty'],
        'etika-bounty'        => [['id' => 'Etika & Aturan Program', 'en' => 'Ethics & Program Rules'], 'bug-bounty', 'bi-shield-check', ['id' => 'ROE, larangan automated scanner, rate-limit, safe harbor.', 'en' => 'ROE, automated-scanner restrictions, rate limits, safe harbor.'], 'bounty'],
        'bounty-scan-lambat-terbatas' => [['id' => 'Bounty Scan Terasa Lambat/Terbatas', 'en' => 'Bounty Scan Feels Slow/Limited'], 'bug-bounty', 'bi-speedometer', ['id' => 'Biasanya bukan bug — program tak mengizinkan automated scanner.', 'en' => 'Usually not a bug — the program disallows automated scanners.'], 'bounty'],
        'import-burp-xml-gagal'      => [['id' => 'Import XML Burp Gagal', 'en' => 'Burp XML Import Fails'], 'bug-bounty', 'bi-file-earmark-break', ['id' => 'Format file, ukuran, dan cara export yang benar dari Burp.', 'en' => 'File format, size, and the correct way to export from Burp.'], 'bounty'],
        'unduh-update-app'    => [['id' => 'Download & Update App', 'en' => 'Download & Update App'], 'mulai', 'bi-download', ['id' => 'Unduh installer CASA, pasang di VPS, dan cara update ke versi terbaru.', 'en' => 'Download the CASA installer, install it on your VPS, and update to the latest version.'], 'hub'],
        'menjalankan-pentest' => [['id' => 'Menjalankan Pentest', 'en' => 'Running a Pentest'], 'pentest', 'bi-lightning-charge', ['id' => 'Dari QuickScan sampai alur lengkap: Project, Policy, Mission, Findings, Reports.', 'en' => 'From QuickScan to the full flow: Project, Policy, Mission, Findings, Reports.'], 'instance'],
        'attack-surface'      => [['id' => 'Attack Surface', 'en' => 'Attack Surface'], 'pentest', 'bi-diagram-2', ['id' => 'Inventaris aset lintas project hasil recon.', 'en' => 'Cross-project asset inventory from recon.'], 'instance'],
        'vulnerabilities'     => [['id' => 'Vulnerabilities & Triase', 'en' => 'Vulnerabilities & Triage'], 'pentest', 'bi-bug', ['id' => 'Kelola status remediasi seluruh temuan.', 'en' => 'Manage remediation status for every finding.'], 'instance'],
        'compliance'          => [['id' => 'Compliance OWASP', 'en' => 'OWASP Compliance'], 'pentest', 'bi-clipboard2-check', ['id' => 'Postur temuan terhadap OWASP Top-10.', 'en' => 'Findings posture against the OWASP Top 10.'], 'instance'],
        'reports-bugbounty'   => [['id' => 'Reports untuk Bug Bounty', 'en' => 'Reports for Bug Bounty'], 'pentest', 'bi-file-earmark-text', ['id' => 'Laporan siap-submit HackerOne/Bugcrowd.', 'en' => 'Submit-ready HackerOne/Bugcrowd reports.'], 'instance'],
        'lab-lanjutan'        => [['id' => 'Lab Lanjutan', 'en' => 'Advanced Lab'], 'pentest', 'bi-diagram-3', ['id' => 'IDOR/BOLA, AuthZ Matrix, Business Logic.', 'en' => 'IDOR/BOLA, AuthZ Matrix, Business Logic.'], 'instance'],
        // --- Troubleshooting ---
        'mission-nyangkut'            => [['id' => 'Mission Nyangkut / Macet', 'en' => 'Mission Stuck / Frozen'], 'troubleshooting', 'bi-arrow-repeat', ['id' => 'Progress diam, task Error — perbaiki lewat tombol Perbaiki.', 'en' => 'Progress frozen, task Error — fix it with the Repair button.'], 'instance'],
        'batalkan-scan'               => [['id' => 'Membatalkan Scan yang Kelamaan', 'en' => 'Cancelling a Long-Running Scan'], 'troubleshooting', 'bi-x-circle', ['id' => 'Hentikan scan Deep yang sudah cukup atau salah target.', 'en' => 'Stop a Deep scan once it is enough, or on the wrong target.'], 'instance'],
        'pdf-gagal'                   => [['id' => 'Unduh PDF Laporan Gagal', 'en' => 'PDF Report Download Fails'], 'troubleshooting', 'bi-file-earmark-pdf', ['id' => 'Halaman error "Whoops!" saat unduh PDF besar — pakai Print.', 'en' => 'A "Whoops!" error page on large PDF downloads — use Print instead.'], 'instance'],
        'laporan-campur-bahasa'       => [['id' => 'Laporan Tercampur Bahasa', 'en' => 'Report Mixing Languages'], 'troubleshooting', 'bi-translate', ['id' => 'Judul/deskripsi temuan tak sesuai bahasa laporan.', 'en' => 'Finding titles/descriptions not matching the report language.'], 'instance'],
        'worker-tidak-jalan'          => [['id' => 'Worker Tidak Pernah Berjalan (Cron)', 'en' => 'Worker Never Runs (Cron)'], 'troubleshooting', 'bi-hdd-network', ['id' => 'Engine Health: "Belum jalan" — pasang cron casa:work via CLI.', 'en' => 'Engine Health: "Not running" — install the casa:work cron via CLI.'], 'instance'],
        'mission-diam-proses-macet'   => [['id' => 'Mission Diam Total — Proses Macet Menyandera Worker', 'en' => 'Mission Fully Frozen — a Stuck Process Is Blocking the Worker'], 'troubleshooting', 'bi-lock', ['id' => 'Tool scan nyisa proses & menahan lock antrean — lepas via CLI.', 'en' => 'A scan tool left a stray process holding the queue lock — release it via CLI.'], 'instance'],
        'vm-mati-total'               => [['id' => 'VM / Aplikasi CASA Mati Total', 'en' => 'CASA VM / App Completely Down'], 'troubleshooting', 'bi-server', ['id' => 'Halaman CASA tak bisa dibuka sama sekali — cek & nyalakan ulang via CLI.', 'en' => 'The CASA page will not load at all — check & restart it via CLI.'], 'instance'],
        'cek-tool-cli'                => [['id' => 'Cek Status 24 Tool Scan via CLI', 'en' => 'Check All 24 Scan Tools via CLI'], 'troubleshooting', 'bi-terminal', ['id' => 'Verifikasi tiap tool benar-benar terpasang & bisa jalan, plus cara memperbaikinya.', 'en' => 'Verify every tool is actually installed & working, plus how to fix it.'], 'instance'],
        'disk-penuh-file-sementara'   => [['id' => 'Disk Penuh dari File Sementara Scan', 'en' => 'Disk Full From Leftover Scan Temp Files'], 'troubleshooting', 'bi-hdd', ['id' => 'File /tmp sisa worker crash menumpuk sampai disk penuh.', 'en' => 'Leftover /tmp files from worker crashes pile up until the disk is full.'], 'instance'],
        'web-overload-502-503'        => [['id' => 'Web Server Kelebihan Beban (502/503)', 'en' => 'Web Server Overloaded (502/503)'], 'troubleshooting', 'bi-hdd-rack', ['id' => 'Beda dari VM mati — slot proses web server habis saat banyak scan bareng.', 'en' => "Different from the VM being down — web server process slots run out under load."], 'instance'],
        'tool-hilang-setelah-update-os' => [['id' => 'Tool Hilang Setelah Update OS', 'en' => 'Tool Missing After OS Update'], 'troubleshooting', 'bi-box-seam', ['id' => '"Tool belum terpasang" setelah dnf/apt update — cara cek & pasang ulang.', 'en' => '"Tool not installed" after a dnf/apt update — how to check & reinstall.'], 'instance'],
        'lisensi-sync-gagal-diam'     => [['id' => 'Sinkronisasi Lisensi Gagal Diam-Diam', 'en' => 'License Sync Fails Silently'], 'troubleshooting', 'bi-key', ['id' => 'Fitur Pro/Enterprise terkunci lagi — cron sinkron harian gagal tanpa notifikasi.', 'en' => 'Pro/Enterprise features lock again — the daily sync cron fails with no notification.'], 'instance'],
        'lisensi-turun-setelah-update' => [['id' => 'Tier Turun ke Community Setelah Update', 'en' => 'Tier Dropped to Community After an Update'], 'troubleshooting', 'bi-unlock', ['id' => 'Fitur terkunci sehabis update padahal langganan aktif — lisensi tak hilang, begini memulihkannya.', 'en' => 'Features locked after an update though the subscription is active — the license is not lost; how to restore it.'], 'all'],
        'base-url-rusak-ip-berubah'   => [['id' => 'Base URL Rusak Setelah IP Berubah', 'en' => 'Base URL Breaks After an IP Change'], 'troubleshooting', 'bi-link-45deg', ['id' => 'Link & aset rusak setelah server pindah jaringan — perbaiki lewat .env.', 'en' => 'Links & assets break after the server changes networks — fix it via .env.'], 'instance'],
        'database-koneksi-penuh'      => [['id' => 'Database Kehabisan Slot Koneksi', 'en' => 'Database Runs Out of Connection Slots'], 'troubleshooting', 'bi-database-x', ['id' => 'Error database acak saat banyak scan+laporan jalan bersamaan.', 'en' => 'Random database errors when many scans+reports run at once.'], 'instance'],
        'ssh-terkunci-sendiri'        => [['id' => 'SSH Terkunci Sendiri Setelah Ubah Firewall', 'en' => 'Locked Out of SSH After a Firewall Change'], 'troubleshooting', 'bi-shield-x', ['id' => 'Cara aman mengetatkan firewall, dan cara pulih kalau sudah terkunci.', 'en' => 'How to tighten the firewall safely, and how to recover if already locked out.'], 'instance'],
        'sertifikat-tls-kadaluwarsa'  => [['id' => 'Sertifikat TLS Kedaluwarsa', 'en' => 'TLS Certificate Expired'], 'troubleshooting', 'bi-shield-lock', ['id' => 'Peringatan "Not Secure" di browser — perpanjang sertifikat via CLI.', 'en' => 'Browser shows "Not Secure" — renew the certificate via CLI.'], 'instance'],
        'dukungan-minta-bantuan'      => [['id' => 'Dukungan & Cara Minta Bantuan', 'en' => 'Support & How to Get Help'], 'troubleshooting', 'bi-life-preserver', ['id' => 'Info yang perlu dikumpulkan, diagnosa mandiri cepat, dan kontak support.', 'en' => 'Info to collect, quick self-diagnosis, and how to reach support.'], 'all'],
        'lisensi-aktivasi'    => [['id' => 'Lisensi & Aktivasi', 'en' => 'License & Activation'], 'kelola', 'bi-key', ['id' => 'Aktifkan Pro/Enterprise via Kode Sinkron.', 'en' => 'Activate Pro/Enterprise via a Sync Code.'], 'all'],
        'langganan-prorata'   => [['id' => 'Langganan & Prorata', 'en' => 'Subscription & Proration'], 'kelola', 'bi-arrow-repeat', ['id' => 'Upgrade dibayar adil: hanya selisih koin yang dipotong.', 'en' => 'Fair upgrade pricing: only the coin difference is charged.'], 'hub'],
        'tim-akun'            => [['id' => 'Tim & Akun', 'en' => 'Team & Account'], 'kelola', 'bi-people', ['id' => 'Peran tim (owner/analyst/viewer) & pengaturan akun.', 'en' => 'Team roles (owner/analyst/viewer) & account settings.'], 'instance'],
    ];

    /** @return array<string,string> kode => label bahasa (untuk UI toggle ID/EN) */
    public static function languages(): array
    {
        return ['id' => 'Indonesia', 'en' => 'English'];
    }

    /** 'id'|'en' dari ?lang= — default 'id' bila tak ada/tak dikenal. */
    private function lang(): string
    {
        $l = (string) $this->request->getGet('lang');

        return $l === 'en' ? 'en' : 'id';
    }

    /** Artikel relevan dengan run-mode (hub) + mode portal (pentest/bounty). */
    private function visible(): array
    {
        helper('edition');
        $hub = function_exists('is_owner_console') && is_owner_console();
        if ($hub) {
            $want = 'hub';
        } else {
            $mode = function_exists('scan_mode') ? scan_mode() : 'pentest';
            $want = $mode === 'bounty' ? 'bounty' : 'instance';
        }

        return array_filter(
            self::ARTIKEL,
            static fn (array $a): bool => $a[4] === 'all' || $a[4] === $want
        );
    }

    /**
     * Registri artikel instance (whitelist slug) — dibuka agar konsol OWNER
     * (OwnerGuideController) dapat menampilkan SELURUH panduan, bukan cuma topik
     * owner. Tetap satu sumber kebenaran: owner membaca registri & berkas yang sama.
     * @return array<string,array{0:array<string,string>,1:string,2:string,3:array<string,string>,4:string}>
     */
    public static function catalog(): array
    {
        return self::ARTIKEL;
    }

    /** Label kategori (id|en) untuk kunci kategori ARTIKEL. */
    public static function categoryLabel(string $key, string $lang = 'id'): string
    {
        return self::KATEGORI_LABEL[$key][$lang] ?? $key;
    }

    /**
     * Path berkas konten artikel instance ({slug}.{lang}.md → fallback {slug}.md),
     * atau null bila tak ada. Dipakai ulang oleh OwnerGuideController.
     */
    public static function contentFile(string $slug, string $lang = 'id'): ?string
    {
        $base = APPPATH . 'Modules/Dashboard/Content/panduan/' . $slug;
        foreach ([$base . '.' . $lang . '.md', $base . '.md'] as $f) {
            if (is_file($f)) {
                return $f;
            }
        }

        return null;
    }

    public function index(): string
    {
        $lang     = $this->lang();
        $kategori = [];
        foreach ($this->visible() as $slug => [$judul, $katKey, $ikon, $ringkas]) {
            $kat   = self::KATEGORI_LABEL[$katKey][$lang] ?? $katKey;
            $judulTeks  = $judul[$lang] ?? $judul['id'];
            $ringkasTeks = $ringkas[$lang] ?? $ringkas['id'];
            $kode  = self::codeFor($slug);
            // Teks pencarian: judul + ringkasan + kode + isi artikel (di-strip dari HTML
            // hasil render yang sama dengan halaman artikel, jadi "cari" ikut menembus
            // ISI, bukan cuma judul — satu sumber, tak ada render ganda yang bisa beda.
            $cari = mb_strtolower(trim($judulTeks . ' ' . $ringkasTeks . ' ' . ($kode ?? '') . ' ' . $this->plainText($slug, $lang)));
            $kategori[$kat][] = ['slug' => $slug, 'judul' => $judulTeks, 'ikon' => $ikon, 'ringkas' => $ringkasTeks, 'kode' => $kode, 'cari' => $cari];
        }

        return $this->memberView('App\Modules\Dashboard\Views\panduan\index', [
            'title'    => $lang === 'en' ? 'User Guide' : 'Panduan Penggunaan',
            'kategori' => $kategori,
            'lang'     => $lang,
            'langs'    => self::languages(),
        ], 'panduan');
    }

    /** Kode CASA-Exxx yang merujuk ke artikel ini, atau null (kebanyakan artikel tak punya). CASA-E000 dikecualikan — itu placeholder "audit OK", bukan kode milik artikel cek-tool-cli. */
    private static function codeFor(string $slug): ?string
    {
        foreach (CasaLog::CODES as $code => [, $guideSlug]) {
            if ($guideSlug === $slug && $code !== 'CASA-E000') {
                return $code;
            }
        }

        return null;
    }

    /** @return array{0:string,1:string} [path berkas, bahasa yang benar2 dipakai] — fallback ID bila versi EN belum ada. */
    private function resolveFile(string $slug, string $lang): array
    {
        $berkasEn = APPPATH . 'Modules/Dashboard/Content/panduan/' . $slug . '.en.md';
        $berkasId = APPPATH . 'Modules/Dashboard/Content/panduan/' . $slug . '.md';
        $berkas   = ($lang === 'en' && is_file($berkasEn)) ? $berkasEn : $berkasId;

        return [$berkas, $berkas === $berkasEn ? 'en' : 'id'];
    }

    /** HTML artikel ter-render, di-cache per berkas+bahasa+waktu-ubah (dipakai show() & index() — satu sumber render). */
    private function renderedHtml(string $berkas, string $dipakaiLang, string $slug): string
    {
        $kunci = 'panduan_' . $slug . '_' . $dipakaiLang . '_' . (int) filemtime($berkas);

        return cache()->remember($kunci, 86400, static fn (): string => Markdown::render(
            (string) file_get_contents($berkas),
            [
                'imgDir' => APPPATH . 'Modules/Dashboard/Content/panduan/_img',
                'imgUrl' => site_url('panduan/gambar/'),
            ]
        ));
    }

    /** Isi artikel sebagai teks polos (markdown yang sudah di-render lalu di-strip tag) — dipakai utk pencarian konten di index(). */
    private function plainText(string $slug, string $lang): string
    {
        [$berkas, $dipakaiLang] = $this->resolveFile($slug, $lang);
        if (! is_file($berkas)) {
            return '';
        }
        $html = $this->renderedHtml($berkas, $dipakaiLang, $slug);
        $teks = html_entity_decode(strip_tags($html), ENT_QUOTES, 'UTF-8');

        return (string) preg_replace('/\s+/', ' ', $teks);
    }

    /**
     * Sajikan gambar panduan dari folder Content (di luar document root).
     *
     * Nama berkas divalidasi ketat agar parameter URL tidak dapat dipakai
     * membaca berkas lain di server.
     */
    public function gambar(string $nama): ResponseInterface
    {
        if (preg_match('/^[A-Za-z0-9._-]+\.(png|jpe?g|webp|gif)$/i', $nama) !== 1) {
            throw PageNotFoundException::forPageNotFound('Gambar tidak sah.');
        }

        $path = APPPATH . 'Modules/Dashboard/Content/panduan/_img/' . $nama;
        if (! is_file($path)) {
            throw PageNotFoundException::forPageNotFound('Gambar tidak ditemukan.');
        }

        $tipe = match (strtolower((string) pathinfo($nama, PATHINFO_EXTENSION))) {
            'png'   => 'image/png',
            'webp'  => 'image/webp',
            'gif'   => 'image/gif',
            default => 'image/jpeg',
        };

        return $this->response->setHeader('Content-Type', $tipe)
            ->setHeader('Cache-Control', 'private, max-age=86400')
            ->setBody((string) file_get_contents($path));
    }

    public function show(string $slug): string
    {
        $lang    = $this->lang();
        $visible = $this->visible();
        if (! isset($visible[$slug])) {
            throw PageNotFoundException::forPageNotFound('Artikel panduan tidak ditemukan.');
        }
        [$judul, $katKey, $ikon, $ringkas] = self::ARTIKEL[$slug];
        $kat = self::KATEGORI_LABEL[$katKey][$lang] ?? $katKey;

        $slugs = array_keys($visible);
        $i     = array_search($slug, $slugs, true);

        // Versi Inggris opsional per artikel ({slug}.en.md); kalau belum ada,
        // jatuh ke versi Indonesia ({slug}.md) daripada 404 — artikel baru tetap
        // terbaca sebelum sempat diterjemahkan.
        [$berkas, $dipakaiLang] = $this->resolveFile($slug, $lang);
        if (! is_file($berkas)) {
            throw PageNotFoundException::forPageNotFound('Konten panduan belum tersedia.');
        }

        // Hasil render disimpan di cache dan ditandai waktu ubah berkas + bahasa,
        // sehingga penyuntingan artikel langsung tampil tanpa perlu membersihkan cache.
        $isi = $this->renderedHtml($berkas, $dipakaiLang, $slug);

        return $this->memberView('App\Modules\Dashboard\Views\panduan\artikel', [
            'isi'            => $isi,
            'title'          => $judul[$lang] ?? $judul['id'],
            'judul'          => $judul[$lang] ?? $judul['id'],
            'kategori'       => $kat,
            'ringkas'        => $ringkas[$lang] ?? $ringkas['id'],
            'lang'           => $lang,
            'langs'          => self::languages(),
            'fallbackCatatan' => $lang === 'en' && $dipakaiLang === 'id',
            'sebelumnya'     => $i > 0 ? [$slugs[$i - 1], self::ARTIKEL[$slugs[$i - 1]][0][$lang] ?? self::ARTIKEL[$slugs[$i - 1]][0]['id']] : null,
            'berikutnya'     => $i < count($slugs) - 1 ? [$slugs[$i + 1], self::ARTIKEL[$slugs[$i + 1]][0][$lang] ?? self::ARTIKEL[$slugs[$i + 1]][0]['id']] : null,
        ], 'panduan');
    }
}
