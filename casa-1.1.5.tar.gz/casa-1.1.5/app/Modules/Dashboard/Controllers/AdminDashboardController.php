<?php

declare(strict_types=1);

namespace App\Modules\Dashboard\Controllers;

use App\Controllers\BaseController;
use App\Modules\Dashboard\Services\DashboardService;

/** Dasbor admin — "jangan ramai" (CES 13.2 thin). */
final class AdminDashboardController extends BaseController
{
    public function __construct(private readonly DashboardService $dash = new DashboardService())
    {
    }

    public function index(): string
    {
        return $this->adminView('App\Modules\Dashboard\Views\admin', [
            'title' => 'Dashboard',
            'stats' => $this->dash->adminStats(),
        ], 'dashboard');
    }
}
