<?php

declare(strict_types=1);

namespace App\Modules\Dashboard\Controllers;

use App\Controllers\BaseController;
use App\Modules\Billing\Models\SubscriptionModel;
use App\Modules\Billing\Services\SubscriptionService;
use App\Modules\Billing\Services\WalletService;
use App\Modules\Dashboard\Services\DashboardService;

/** Dasbor member (CES 13.2 thin). */
final class MemberDashboardController extends BaseController
{
    public function __construct(private readonly DashboardService $dash = new DashboardService())
    {
    }

    public function index(): string
    {
        $customerId = (int) $this->session->get('member_id');

        // Dua run-mode, satu codebase (lihat sidebar_member.php):
        //  - HUB console owner (punya private key) → dasbor BILLING-ONLY.
        //  - Instance produk di VPS pelanggan        → dasbor pentest penuh.
        if ((string) (env('license.privateKey') ?: '') !== '') {
            return $this->hub($customerId);
        }

        return $this->memberView('App\Modules\Dashboard\Views\member', [
            'title' => 'Dashboard',
            'stats' => $this->dash->memberStats($customerId),
        ], 'dashboard');
    }

    /** Dasbor hub (casamember): langganan, koin, unduh/update app. */
    private function hub(int $customerId): string
    {
        $wallet = new WalletService();
        $subsSv = new SubscriptionService();
        $subMdl = new SubscriptionModel();

        return $this->memberView('App\Modules\Dashboard\Views\hub', [
            'title'     => 'Dashboard',
            'coin'      => $wallet->balance($customerId),
            'sub'       => $subsSv->activeForCustomer($customerId),
            'subsCount' => $subMdl->where('customer_id', $customerId)->countAllResults(),
            'tx'        => array_slice($wallet->history($customerId), 0, 6),
            'latest'    => $this->latestRelease(),
        ], 'dashboard');
    }

    /** Rilis app terbaru dari writable/releases/ ({version,label,size}|null). */
    private function latestRelease(): ?array
    {
        $dir  = rtrim(WRITEPATH, '/\\') . DIRECTORY_SEPARATOR . 'releases';
        $best = null;
        foreach (glob($dir . DIRECTORY_SEPARATOR . 'casa-*') ?: [] as $path) {
            $name = basename($path);
            if (! is_file($path) || preg_match('/^casa-[A-Za-z0-9._-]+\.(tar\.gz|zip|exe)$/', $name) !== 1) {
                continue;
            }
            $mtime = (int) (filemtime($path) ?: 0);
            if ($best !== null && $mtime <= $best['mtime']) {
                continue;
            }
            $label = str_ends_with($name, '.exe') ? 'Windows'
                : (str_contains($name, 'docker') ? 'Docker' : 'VPS / Linux');
            $best = [
                'version' => preg_match('/(\d+\.\d+\.\d+)/', $name, $m) === 1 ? $m[1] : '—',
                'label'   => $label,
                'size'    => (int) (filesize($path) ?: 0),
                'mtime'   => $mtime,
            ];
        }

        return $best;
    }
}
