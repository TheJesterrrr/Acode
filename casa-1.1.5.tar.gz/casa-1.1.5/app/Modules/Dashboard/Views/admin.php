<?php
/** Dasbor administrator. @var array $stats */
?>
<?= $this->extend('layouts/admin') ?>
<?= $this->section('content') ?>
<?php $owner = \App\Libraries\ToolLabel::isOwner(); ?>
<div class="casa-page-head">
  <h1 class="h4 mb-0">Overview</h1>
  <div class="d-flex gap-2">
    <a href="<?= esc(site_url('casaadmin/ai')) ?>" class="btn btn-outline-primary btn-sm"><i class="bi bi-cpu me-1"></i>AI Settings</a>
    <?php if ($owner): ?><a href="<?= esc(site_url('casaadmin/tools')) ?>" class="btn btn-amber btn-sm"><i class="bi bi-tools me-1"></i>Tool Manager</a><?php endif; ?>
  </div>
</div>

<div class="row g-3">
  <?php if ($owner): ?><div class="col-6 col-lg-3"><div class="casa-stat"><div class="casa-stat__n"><?= (int) ($stats['tools_installed'] ?? 0) ?><span class="fs-6 text-muted">/<?= (int) ($stats['tools_total'] ?? 0) ?></span></div><div class="casa-stat__l">Tool terpasang</div><i class="bi bi-tools"></i></div></div><?php endif; ?>
  <div class="col-6 col-lg-3"><div class="casa-stat"><div class="casa-stat__n"><?= (int) ($stats['ai_enabled'] ?? 0) ?></div><div class="casa-stat__l">AI provider aktif</div><i class="bi bi-cpu"></i></div></div>
  <div class="col-6 col-lg-3"><div class="casa-stat casa-stat--amber"><div class="casa-stat__n"><?= (int) ($stats['missions'] ?? 0) ?></div><div class="casa-stat__l">Total mission</div><i class="bi bi-lightning-charge"></i></div></div>
  <div class="col-6 col-lg-3"><div class="casa-stat casa-stat--rose"><div class="casa-stat__n"><?= (int) ($stats['findings'] ?? 0) ?></div><div class="casa-stat__l">Total finding</div><i class="bi bi-bug"></i></div></div>
</div>

<div class="row g-3 mt-0">
  <div class="col-lg-3 col-6"><div class="casa-stat casa-stat--slate"><div class="casa-stat__n"><?= (int) ($stats['customers'] ?? 0) ?></div><div class="casa-stat__l">Member</div><i class="bi bi-people"></i></div></div>
  <div class="col-lg-3 col-6"><a href="<?= esc(site_url('casaadmin/audit')) ?>" class="text-decoration-none"><div class="casa-stat casa-stat--slate"><div class="casa-stat__n"><?= (int) ($stats['audit'] ?? 0) ?></div><div class="casa-stat__l">Peristiwa audit</div><i class="bi bi-shield-lock"></i></div></a></div>
  <div class="col-lg-6">
    <div class="casa-card p-3 p-lg-4 h-100">
      <h2 class="h6">Konfigurasi platform</h2>
      <p class="text-muted small mb-3">Kelola penyedia AI<?= $owner ? ', kemampuan assessment,' : ' dan' ?> setelan platform CASA.</p>
      <div class="d-flex flex-wrap gap-2">
        <a href="<?= esc(site_url('casaadmin/ai')) ?>" class="btn btn-primary btn-sm"><i class="bi bi-cpu me-1"></i>AI Settings</a>
        <?php if ($owner): ?><a href="<?= esc(site_url('casaadmin/tools')) ?>" class="btn btn-outline-primary btn-sm"><i class="bi bi-tools me-1"></i>Tool Manager</a><?php endif; ?>
        <a href="<?= esc(site_url('casaadmin/settings')) ?>" class="btn btn-outline-primary btn-sm"><i class="bi bi-gear me-1"></i>Pengaturan</a>
        <a href="<?= esc(site_url('casaadmin/audit')) ?>" class="btn btn-outline-primary btn-sm"><i class="bi bi-shield-lock me-1"></i>Audit Log</a>
      </div>
    </div>
  </div>
</div>
<?= $this->endSection() ?>
