<?php
/** Dasbor member. @var array $stats */
$sev = $stats['severity'] ?? ['crit' => 0, 'high' => 0, 'med' => 0, 'low' => 0, 'info' => 0];
$sevMeta = ['crit' => ['Critical', 'danger'], 'high' => ['High', 'warning'], 'med' => ['Medium', 'info'], 'low' => ['Low', 'primary'], 'info' => ['Info', 'secondary']];
$stateBadge = ['planning' => 'secondary', 'executing' => 'primary', 'validating' => 'info', 'reporting' => 'warning', 'done' => 'success', 'error' => 'danger'];
?>
<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<div class="casa-page-head">
  <h1 class="h4 mb-0">Dashboard</h1>
  <a href="<?= esc(site_url('scan')) ?>" class="btn btn-amber"><i class="bi bi-stars me-1"></i>Assessment Baru</a>
</div>

<div class="row g-3 mb-1">
  <div class="col-6 col-lg-3"><a href="<?= esc(site_url('missions')) ?>" class="text-decoration-none"><div class="casa-stat"><div class="casa-stat__n"><?= (int) ($stats['missions'] ?? 0) ?></div><div class="casa-stat__l">Missions</div><i class="bi bi-lightning-charge"></i></div></a></div>
  <div class="col-6 col-lg-3"><a href="<?= esc(site_url('projects')) ?>" class="text-decoration-none"><div class="casa-stat"><div class="casa-stat__n"><?= (int) ($stats['projects'] ?? 0) ?></div><div class="casa-stat__l">Projects</div><i class="bi bi-folder2"></i></div></a></div>
  <div class="col-6 col-lg-3"><div class="casa-stat casa-stat--rose"><div class="casa-stat__n"><?= (int) ($stats['findings_total'] ?? 0) ?></div><div class="casa-stat__l">Findings</div><i class="bi bi-bug"></i></div></div>
  <div class="col-6 col-lg-3"><div class="casa-stat casa-stat--amber"><div class="casa-stat__n"><?= (int) ($stats['reports'] ?? 0) ?></div><div class="casa-stat__l">Reports</div><i class="bi bi-file-earmark-text"></i></div></div>
</div>

<?php
$rs     = (int) ($stats['risk_score'] ?? 0);
$rsBand = $rs >= 75 ? ['Kritis', 'danger'] : ($rs >= 50 ? ['Tinggi', 'warning'] : ($rs >= 25 ? ['Sedang', 'info'] : ['Rendah', 'success']));
$rem    = $stats['remediation'] ?? [];
$remTot = array_sum($rem) ?: 1;
$remMeta = ['open' => ['Open', 'warning'], 'in_progress' => ['In Progress', 'info'], 'fixed' => ['Fixed', 'success'], 'risk_accepted' => ['Risk Acc.', 'secondary'], 'false_positive' => ['FP', 'dark']];
$remColor = ['open' => '#f59e0b', 'in_progress' => '#0dcaf0', 'fixed' => '#198754', 'risk_accepted' => '#6c757d', 'false_positive' => '#343a40'];
$trend    = $stats['trend'] ?? [];
$trendMax = 1;
foreach ($trend as $t) { $trendMax = max($trendMax, (int) $t['n']); }
$fixedPct = round((($rem['fixed'] ?? 0) + ($rem['risk_accepted'] ?? 0) + ($rem['false_positive'] ?? 0)) / $remTot * 100);
?>
<div class="row g-3 mt-0 mb-1">
  <!-- Risk score -->
  <div class="col-lg-4">
    <div class="casa-card p-3 p-lg-4 h-100">
      <div class="d-flex align-items-baseline justify-content-between">
        <h2 class="h6 mb-0">Risk Score</h2>
        <span class="badge text-bg-<?= $rsBand[1] ?>"><?= $rsBand[0] ?></span>
      </div>
      <div class="display-5 fw-bold mt-2 mb-1 text-<?= $rsBand[1] ?>"><?= $rs ?><small class="fs-6 text-muted fw-normal">/100</small></div>
      <div class="progress" style="height:8px"><div class="progress-bar bg-<?= $rsBand[1] ?>" style="width:<?= $rs ?>%"></div></div>
      <div class="small text-muted mt-2"><i class="bi bi-diagram-2 me-1"></i><?= (int) ($stats['assets_total'] ?? 0) ?> aset dipantau · <?= (int) ($stats['findings_total'] ?? 0) ?> temuan</div>
    </div>
  </div>
  <!-- Remediasi -->
  <div class="col-lg-4">
    <div class="casa-card p-3 p-lg-4 h-100">
      <div class="d-flex align-items-baseline justify-content-between mb-2">
        <h2 class="h6 mb-0">Progres Remediasi</h2><span class="small text-muted"><?= $fixedPct ?>% selesai</span>
      </div>
      <div class="progress mb-3" style="height:14px">
        <?php foreach ($remMeta as $k => [$lbl, $c]): $n = (int) ($rem[$k] ?? 0); if ($n === 0) { continue; } ?>
          <div class="progress-bar" style="width:<?= round($n / $remTot * 100) ?>%;background:<?= $remColor[$k] ?>" title="<?= $lbl ?>: <?= $n ?>"></div>
        <?php endforeach; ?>
      </div>
      <div class="d-flex flex-wrap gap-2">
        <?php foreach ($remMeta as $k => [$lbl, $c]): ?>
          <a href="<?= esc(site_url('vulnerabilities?rstatus=' . $k)) ?>" class="small text-decoration-none text-body"><span class="d-inline-block rounded" style="width:9px;height:9px;background:<?= $remColor[$k] ?>"></span> <?= $lbl ?> <b><?= (int) ($rem[$k] ?? 0) ?></b></a>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
  <!-- Tren -->
  <div class="col-lg-4">
    <div class="casa-card p-3 p-lg-4 h-100">
      <h2 class="h6 mb-3">Tren temuan (8 minggu)</h2>
      <div class="d-flex align-items-end gap-1" style="height:70px">
        <?php foreach ($trend as $t): $h = max(3, round((int) $t['n'] / $trendMax * 62)); ?>
          <div class="flex-fill d-flex flex-column align-items-center" title="<?= esc($t['lbl']) ?>: <?= (int) $t['n'] ?>">
            <div class="w-100 rounded-top" style="height:<?= $h ?>px;background:var(--casa-teal,#0d9488);opacity:.85"></div>
          </div>
        <?php endforeach; ?>
      </div>
      <div class="d-flex justify-content-between small text-muted mt-1"><span><?= esc($trend[0]['lbl'] ?? '') ?></span><span><?= esc(end($trend)['lbl'] ?? '') ?></span></div>
    </div>
  </div>
</div>

<div class="row g-3 mt-0">
  <!-- Severity + recent findings -->
  <div class="col-lg-7">
    <div class="casa-card p-3 p-lg-4 h-100">
      <h2 class="h6 mb-3">Findings menurut severity</h2>
      <div class="d-flex flex-wrap gap-2 mb-3">
        <?php foreach ($sevMeta as $k => [$lbl, $c]): ?>
          <span class="badge text-bg-<?= $c ?> px-3 py-2"><?= $lbl ?>: <?= (int) ($sev[$k] ?? 0) ?></span>
        <?php endforeach; ?>
      </div>
      <h2 class="h6 mb-2">Temuan terbaru</h2>
      <div class="table-responsive">
        <table class="table table-sm align-middle mb-0">
          <tbody>
            <?php foreach (($stats['recent_findings'] ?? []) as $f): [$lbl, $c] = $sevMeta[$f['severity']] ?? ['Info', 'secondary']; ?>
              <tr style="cursor:pointer" onclick="location='<?= esc(site_url('findings/' . $f['id'])) ?>'">
                <td style="width:90px"><span class="badge text-bg-<?= $c ?>"><?= $lbl ?></span></td>
                <td><?= esc($f['title']) ?><div class="small text-muted font-monospace"><?= esc($f['ref']) ?><?php $tl = \App\Libraries\ToolLabel::show($f['tool'] ?? null); ?><?= $tl !== '' ? ' · ' . esc($tl) : '' ?></div></td>
              </tr>
            <?php endforeach; ?>
            <?php if (($stats['recent_findings'] ?? []) === []): ?><tr><td class="text-muted small py-3">Belum ada temuan. Luncurkan Mission untuk memindai.</td></tr><?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <!-- Recent missions -->
  <div class="col-lg-5">
    <div class="casa-card p-3 p-lg-4 h-100">
      <h2 class="h6 mb-3">Mission terbaru</h2>
      <?php foreach (($stats['recent_missions'] ?? []) as $m): ?>
        <a href="<?= esc(site_url('missions/' . $m['id'])) ?>" class="d-flex align-items-center gap-2 py-2 border-bottom text-decoration-none" style="border-color:var(--casa-card-brd)!important">
          <span class="font-monospace small text-muted">M-<?= (int) $m['id'] ?></span>
          <span class="flex-grow-1 text-truncate small"><?= esc(mb_substr((string) $m['brief'], 0, 46)) ?></span>
          <span class="badge text-bg-<?= $stateBadge[$m['state']] ?? 'secondary' ?>"><?= esc($m['state']) ?></span>
        </a>
      <?php endforeach; ?>
      <?php if (($stats['recent_missions'] ?? []) === []): ?>
        <p class="text-muted small mb-3">Belum ada mission.</p>
      <?php endif; ?>
      <a href="<?= esc(site_url('missions')) ?>" class="btn btn-primary btn-sm mt-3 w-100"><i class="bi bi-lightning-charge me-1"></i>Start New Mission</a>
    </div>
  </div>
</div>

<?php $topA = $stats['top_assets'] ?? []; $ow = $stats['owasp'] ?? []; $owMax = 1; foreach ($ow as $o) { $owMax = max($owMax, (int) $o['n']); } ?>
<div class="row g-3 mt-0">
  <!-- Aset paling berisiko -->
  <div class="col-lg-6">
    <div class="casa-card p-3 p-lg-4 h-100">
      <div class="d-flex align-items-baseline justify-content-between mb-2">
        <h2 class="h6 mb-0">Aset paling berisiko</h2>
        <a href="<?= esc(site_url('attack-surface')) ?>" class="small text-decoration-none">Attack Surface →</a>
      </div>
      <table class="table table-sm align-middle mb-0">
        <tbody>
          <?php foreach ($topA as $a): [$lbl, $c] = $sevMeta[$a['sev']] ?? ['Info', 'secondary']; ?>
            <tr><td class="font-monospace small" style="word-break:break-all"><?= esc($a['a']) ?></td>
              <td style="width:90px"><span class="badge text-bg-<?= $c ?>"><?= $lbl ?></span></td>
              <td class="text-end" style="width:60px"><span class="badge text-bg-dark border"><?= (int) $a['n'] ?></span></td></tr>
          <?php endforeach; ?>
          <?php if ($topA === []): ?><tr><td class="text-muted small py-3">Belum ada aset bertemuan.</td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
  <!-- OWASP -->
  <div class="col-lg-6">
    <div class="casa-card p-3 p-lg-4 h-100">
      <h2 class="h6 mb-3">Kepatuhan OWASP Top-10</h2>
      <?php foreach ($ow as $o): ?>
        <div class="mb-2">
          <div class="d-flex justify-content-between small mb-1"><span><?= esc($o['o']) ?></span><span class="text-muted"><?= (int) $o['n'] ?></span></div>
          <div class="progress" style="height:7px"><div class="progress-bar bg-danger" style="width:<?= round((int) $o['n'] / $owMax * 100) ?>%"></div></div>
        </div>
      <?php endforeach; ?>
      <?php if ($ow === []): ?><p class="text-muted small mb-0">Belum ada temuan terpetakan OWASP.</p><?php endif; ?>
    </div>
  </div>
</div>
<?= $this->endSection() ?>
