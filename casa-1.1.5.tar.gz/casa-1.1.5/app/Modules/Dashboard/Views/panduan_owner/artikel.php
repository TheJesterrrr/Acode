<?= $this->extend('layouts/admin') ?>
<?= $this->section('content') ?>
<?php /** @var string $isi @var string $judul @var ?array $sebelumnya @var ?array $berikutnya */ ?>
<div class="casa-page-head">
  <div>
    <a href="<?= esc(site_url('casaadmin/panduan')) ?>" class="small text-muted text-decoration-none"><i class="bi bi-arrow-left"></i> Panduan</a>
    <h1 class="h4 mb-0"><?= esc($judul) ?></h1>
  </div>
</div>

<div class="casa-card p-3 p-lg-4 casa-artikel"><?= $isi // sudah di-escape Markdown::render ?></div>

<div class="d-flex justify-content-between mt-3">
  <?php if ($sebelumnya): ?><a class="btn btn-outline-secondary btn-sm" href="<?= esc(site_url('casaadmin/panduan/' . $sebelumnya[0])) ?>"><i class="bi bi-arrow-left me-1"></i><?= esc($sebelumnya[1]) ?></a><?php else: ?><span></span><?php endif; ?>
  <?php if ($berikutnya): ?><a class="btn btn-outline-secondary btn-sm" href="<?= esc(site_url('casaadmin/panduan/' . $berikutnya[0])) ?>"><?= esc($berikutnya[1]) ?><i class="bi bi-arrow-right ms-1"></i></a><?php endif; ?>
</div>
<?= $this->endSection() ?>
