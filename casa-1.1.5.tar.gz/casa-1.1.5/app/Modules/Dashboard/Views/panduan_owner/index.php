<?= $this->extend('layouts/admin') ?>
<?= $this->section('content') ?>
<?php /** @var array $kategori */ ?>
<div class="casa-page-head"><h1 class="h4 mb-0"><i class="bi bi-life-preserver me-1"></i>Panduan Owner</h1></div>

<div class="row g-3">
  <?php foreach ($kategori as $nama => $items): ?>
    <div class="col-lg-6">
      <div class="casa-card p-3 p-lg-4 h-100">
        <h2 class="h6 text-primary mb-3"><?= esc($nama) ?></h2>
        <div class="list-group list-group-flush">
          <?php foreach ($items as $a): ?>
            <a class="list-group-item list-group-item-action px-0 d-flex gap-3 align-items-start" href="<?= esc(site_url('casaadmin/panduan/' . $a['slug'])) ?>">
              <i class="bi <?= esc($a['ikon']) ?> fs-5 text-primary"></i>
              <span><span class="fw-semibold d-block"><?= esc($a['judul']) ?></span><span class="small text-muted"><?= esc($a['ringkas']) ?></span></span>
            </a>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
</div>
<?= $this->endSection() ?>
