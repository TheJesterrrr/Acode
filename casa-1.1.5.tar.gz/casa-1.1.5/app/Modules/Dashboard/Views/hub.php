<?php
/**
 * Dasbor HUB (console owner / casamember) — BILLING-ONLY.
 *
 * Portal member di server owner hanyalah hub transaksi: langganan, koin, unduh &
 * update aplikasi, panduan, akun. TANPA widget pentest (Missions/Findings/Reports)
 * — pentest berjalan di instance produk yang dipasang pelanggan di VPS-nya sendiri.
 *
 * @var int        $coin       Saldo koin.
 * @var array|null $sub        Langganan aktif (null = Community).
 * @var int        $subsCount  Total langganan (riwayat).
 * @var array      $tx         Mutasi koin terbaru.
 * @var array      $latest     Rilis app terbaru (null bila belum ada).
 * @var array      $shell
 */
$tierLabel = $shell['tier_label'] ?? 'Community';
$tier      = $shell['tier'] ?? 'community';
$tierColor = ['community' => 'secondary', 'pro' => 'info', 'enterprise' => 'amber'][$tier] ?? 'secondary';

$exp      = $sub['expires_at'] ?? null;
$daysLeft = $exp ? (int) floor((strtotime($exp) - strtotime(date('Y-m-d'))) / 86400) : null;
$expColor = $daysLeft === null ? 'secondary' : ($daysLeft <= 7 ? 'danger' : ($daysLeft <= 30 ? 'warning' : 'success'));

$txMeta = ['topup' => ['Topup', 'success', '+'], 'spend' => ['Subscription', 'warning', '−'], 'grant' => ['Bonus', 'info', '+'], 'refund' => ['Refund', 'secondary', '+']];
?>
<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<div class="casa-page-head">
  <h1 class="h4 mb-0">Dashboard</h1>
  <a href="<?= esc(site_url('billing')) ?>" class="btn btn-amber"><i class="bi bi-coin me-1"></i>Topup &amp; Subscription</a>
</div>

<!-- Ringkasan akun: koin, paket, masa aktif -->
<div class="row g-3 mb-1">
  <div class="col-6 col-lg-3">
    <a href="<?= esc(site_url('billing')) ?>" class="text-decoration-none">
      <div class="casa-stat casa-stat--amber"><div class="casa-stat__n"><?= number_format($coin, 0, ',', '.') ?></div><div class="casa-stat__l">Coin Balance</div><i class="bi bi-coin"></i></div>
    </a>
  </div>
  <div class="col-6 col-lg-3">
    <div class="casa-stat"><div class="casa-stat__n" style="font-size:1.6rem;line-height:2.2rem"><?= esc($tierLabel) ?></div><div class="casa-stat__l">Active Plan</div><i class="bi bi-patch-check"></i></div>
  </div>
  <div class="col-6 col-lg-3">
    <div class="casa-stat"><div class="casa-stat__n"><?= $daysLeft !== null ? (int) max(0, $daysLeft) : '∞' ?><?php if ($daysLeft !== null): ?><small class="fs-6 text-muted fw-normal"> days</small><?php endif; ?></div><div class="casa-stat__l">Active Period</div><i class="bi bi-calendar-check"></i></div>
  </div>
  <div class="col-6 col-lg-3">
    <a href="<?= esc(site_url('billing')) ?>" class="text-decoration-none">
      <div class="casa-stat"><div class="casa-stat__n"><?= (int) $subsCount ?></div><div class="casa-stat__l">Subscriptions</div><i class="bi bi-receipt"></i></div>
    </a>
  </div>
</div>

<div class="row g-3 mt-0 mb-1">
  <!-- Status langganan + lisensi -->
  <div class="col-lg-7">
    <div class="casa-card p-3 p-lg-4 h-100">
      <div class="d-flex align-items-baseline justify-content-between mb-2">
        <h2 class="h6 mb-0">My Subscription</h2>
        <span class="badge text-bg-<?= esc($tierColor) ?>"><i class="bi bi-patch-check-fill me-1"></i><?= esc($tierLabel) ?></span>
      </div>
      <?php if ($sub !== null): ?>
        <p class="mb-2">The <b><?= esc($tierLabel) ?></b> plan is active until
          <b><?= esc(date('d M Y', strtotime((string) $exp))) ?></b>
          <span class="badge text-bg-<?= $expColor ?> ms-1"><?= (int) max(0, (int) $daysLeft) ?> days left</span>
        </p>
        <?php if (! empty($sub['license_id'])): ?>
          <div class="d-flex flex-wrap align-items-center gap-2">
            <span class="small text-muted">License <code><?= esc($sub['license_id']) ?></code></span>
            <a href="<?= esc(site_url('billing/key/' . (int) $sub['id'])) ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-key me-1"></i>Download License Key</a>
          </div>
          <p class="small text-muted mt-2 mb-0"><i class="bi bi-info-circle me-1"></i>Activate this key in the CASA app you installed on your VPS to unlock <?= esc($tierLabel) ?> features.</p>
        <?php endif; ?>
      <?php else: ?>
        <p class="mb-2">You're on the <b>Community</b> plan (free). Upgrade to Pro/Enterprise for a bigger project &amp; target quota plus team features.</p>
        <a href="<?= esc(site_url('billing')) ?>" class="btn btn-sm btn-amber"><i class="bi bi-arrow-up-circle me-1"></i>View Plans</a>
      <?php endif; ?>
    </div>
  </div>

  <!-- Download / update app -->
  <div class="col-lg-5">
    <div class="casa-card p-3 p-lg-4 h-100">
      <h2 class="h6 mb-2">CASA App</h2>
      <?php if (! empty($latest)): ?>
        <p class="mb-2">Latest version <b><?= esc($latest['version']) ?></b>
          <span class="small text-muted">· <?= esc($latest['label']) ?> · <?= number_format($latest['size'] / 1048576, 1) ?> MB</span>
        </p>
        <a href="<?= esc(site_url('download')) ?>" class="btn btn-sm btn-primary"><i class="bi bi-download me-1"></i>Download / Update</a>
      <?php else: ?>
        <p class="text-muted small mb-2">No release installed yet. Contact the admin if the installer package isn't available yet.</p>
        <a href="<?= esc(site_url('download')) ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-download me-1"></i>Open Download Page</a>
      <?php endif; ?>
      <p class="small text-muted mt-2 mb-0"><i class="bi bi-life-preserver me-1"></i>First time here? Read the <a href="<?= esc(site_url('panduan')) ?>">User Guide</a>.</p>
    </div>
  </div>
</div>

<div class="row g-3 mt-0">
  <!-- Mutasi koin terbaru -->
  <div class="col-lg-7">
    <div class="casa-card p-3 p-lg-4 h-100">
      <div class="d-flex align-items-baseline justify-content-between mb-2">
        <h2 class="h6 mb-0">Recent Coin Activity</h2>
        <a href="<?= esc(site_url('billing')) ?>" class="small text-decoration-none">Full history →</a>
      </div>
      <div class="table-responsive">
        <table class="table table-sm align-middle mb-0">
          <tbody>
            <?php foreach ($tx as $t): [$lbl, $c, $sign] = $txMeta[$t['type']] ?? ['Activity', 'secondary', '']; ?>
              <tr>
                <td style="width:96px"><span class="badge text-bg-<?= $c ?>"><?= $lbl ?></span></td>
                <td><?= esc($t['note'] ?: '—') ?><div class="small text-muted"><?= esc(date('d/m/Y H:i', strtotime((string) $t['created_at']))) ?></div></td>
                <td class="text-end font-monospace fw-semibold"><?= $sign ?><?= number_format(abs((int) $t['amount']), 0, ',', '.') ?></td>
              </tr>
            <?php endforeach; ?>
            <?php if ($tx === []): ?><tr><td class="text-muted small py-3">No coin activity yet. Top up to start subscribing.</td></tr><?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Pintasan -->
  <div class="col-lg-5">
    <div class="casa-card p-3 p-lg-4 h-100">
      <h2 class="h6 mb-3">Shortcuts</h2>
      <a href="<?= esc(site_url('billing')) ?>" class="d-flex align-items-center gap-2 py-2 border-bottom text-decoration-none text-body" style="border-color:var(--casa-card-brd)!important"><i class="bi bi-coin fs-5 text-warning"></i><span class="flex-grow-1">Subscription &amp; Coins</span><i class="bi bi-chevron-right small text-muted"></i></a>
      <a href="<?= esc(site_url('download')) ?>" class="d-flex align-items-center gap-2 py-2 border-bottom text-decoration-none text-body" style="border-color:var(--casa-card-brd)!important"><i class="bi bi-download fs-5 text-info"></i><span class="flex-grow-1">Download App</span><i class="bi bi-chevron-right small text-muted"></i></a>
      <a href="<?= esc(site_url('panduan')) ?>" class="d-flex align-items-center gap-2 py-2 border-bottom text-decoration-none text-body" style="border-color:var(--casa-card-brd)!important"><i class="bi bi-life-preserver fs-5 text-success"></i><span class="flex-grow-1">User Guide</span><i class="bi bi-chevron-right small text-muted"></i></a>
      <a href="<?= esc(site_url('member/akun')) ?>" class="d-flex align-items-center gap-2 py-2 text-decoration-none text-body"><i class="bi bi-person fs-5 text-secondary"></i><span class="flex-grow-1">My Account</span><i class="bi bi-chevron-right small text-muted"></i></a>
    </div>
  </div>
</div>
<?= $this->endSection() ?>
