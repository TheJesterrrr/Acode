<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<?php
$wa = (string) (setting_value('whatsapp_number') ?: '');
$waLink = $wa !== '' ? 'https://wa.me/' . preg_replace('/\D+/', '', $wa) : '';
?>
<div class="casa-page-head"><h1>Panduan Penggunaan</h1></div>

<div class="row g-3">
  <div class="col-lg-6">
    <div class="casa-card p-3 p-lg-4 h-100">
      <h2 class="h6 mb-3"><i class="bi bi-coin me-1"></i> CoreNet Koin</h2>
      <ol class="small text-muted ps-3 mb-0">
        <li>Buka menu <strong>Koin Saya</strong>, pilih paket, lalu klik <em>Beli Koin</em>.</li>
        <li>Anda diarahkan ke halaman invoice. Klik <strong>Bayar Sekarang</strong>.</li>
        <li>Transfer sesuai metode yang tampil, lalu <strong>upload bukti</strong>.</li>
        <li>Admin memverifikasi; Koin otomatis masuk ke saldo Anda.</li>
      </ol>
    </div>
  </div>

  <div class="col-lg-6">
    <div class="casa-card p-3 p-lg-4 h-100">
      <h2 class="h6 mb-3"><i class="bi bi-hdd-network me-1"></i> VPN Remote</h2>
      <ol class="small text-muted ps-3 mb-0">
        <li>Menu <strong>Layanan VPN → Tambah VPN</strong>, pilih paket, server, dan username.</li>
        <li>Setelah pesanan berhasil, buka detail layanan.</li>
        <li>Pada tab <strong>Script</strong>, pilih protokol (SSTP/L2TP) dan versi RouterOS.</li>
        <li>Klik <strong>Salin</strong>, lalu tempel ke terminal MikroTik Anda.</li>
        <li>Tambahkan <strong>Port Forwarding</strong> bila perlu akses Winbox/API dari luar.</li>
      </ol>
    </div>
  </div>

  <div class="col-lg-6">
    <div class="casa-card p-3 p-lg-4 h-100">
      <h2 class="h6 mb-3"><i class="bi bi-diagram-3 me-1"></i> VPN Interkoneksi</h2>
      <ul class="small text-muted ps-3 mb-0">
        <li>Menghubungkan 2 router atau lebih menjadi satu jaringan (pusat, cabang, gudang).</li>
        <li>Pilih paket sesuai jumlah akun, lalu tentukan <strong>awalan nama</strong> — mis. <code>kantor</code> menghasilkan <code>kantor-1</code>, <code>kantor-2</code>, dan seterusnya.</li>
        <li>Tiap akun memiliki script sendiri; terapkan di router masing-masing.</li>
        <li>Layanan ini <strong>tanpa port forwarding</strong>. Bila butuh, gunakan VPN Remote.</li>
      </ul>
    </div>
  </div>

  <div class="col-lg-6">
    <div class="casa-card p-3 p-lg-4 h-100">
      <h2 class="h6 mb-3"><i class="bi bi-life-preserver me-1"></i> Bantuan</h2>
      <ul class="small text-muted ps-3">
        <li><strong>Perpanjangan otomatis</strong> memotong Koin saat jatuh tempo. Pastikan saldo cukup.</li>
        <li>Layanan yang lewat masa tenggang akan <strong>ditangguhkan</strong>, bukan langsung dihapus.</li>
        <li>Wajib memakai <strong>netwatch</strong> (sudah termasuk pada script).</li>
      </ul>
      <?php if ($waLink !== ''): ?>
        <a href="<?= esc($waLink) ?>" target="_blank" rel="noopener" class="btn btn-sm btn-success">
          <i class="bi bi-whatsapp me-1"></i> Hubungi Admin
        </a>
      <?php endif; ?>
    </div>
  </div>
</div>
<?= $this->endSection() ?>
