<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<?php
/** @var array<string,array<int,array{slug:string,judul:string,ikon:string,ringkas:string}>> $kategori */
/** @var string $title @var string $lang @var array<string,string> $langs */
$wa = (string) (setting_value('whatsapp_number') ?: '');
$waLink = $wa !== '' ? 'https://wa.me/' . preg_replace('/\D+/', '', $wa) : '';
?>
<div class="casa-page-head d-flex flex-wrap align-items-center gap-2">
  <h1 class="mb-0"><?= esc($title) ?></h1>
  <div class="btn-group btn-group-sm ms-auto" role="group" aria-label="<?= $lang === 'en' ? 'Guide language' : 'Bahasa panduan' ?>">
    <?php foreach (($langs ?? ['id' => 'Indonesia', 'en' => 'English']) as $code => $name): ?>
      <a class="btn btn-sm <?= $lang === $code ? 'btn-secondary' : 'btn-outline-secondary' ?>"
         href="<?= esc(site_url('panduan') . '?lang=' . $code) ?>"><?= esc($name) ?></a>
    <?php endforeach; ?>
  </div>
</div>

<div class="casa-card p-2 p-lg-3 mb-3">
  <div class="input-group">
    <span class="input-group-text bg-transparent border-0 pe-0"><i class="bi bi-search"></i></span>
    <input type="search" id="panduanSearch" class="form-control border-0" autocomplete="off"
           placeholder="<?= $lang === 'en' ? 'Search article, keyword, or CASA-Exxx code…' : 'Cari artikel, kata kunci, atau kode CASA-Exxx…' ?>">
  </div>
</div>
<p id="panduanNoResult" class="text-muted small d-none"><?= $lang === 'en' ? 'No articles match.' : 'Tak ada artikel yang cocok.' ?></p>

<div class="row g-3" id="panduanList">
  <?php foreach ($kategori as $nama => $items): ?>
    <div class="col-lg-6 panduan-kategori">
      <div class="casa-card p-3 p-lg-4 h-100">
        <h2 class="h6 text-primary mb-3"><?= esc($nama) ?></h2>
        <div class="list-group list-group-flush">
          <?php foreach ($items as $a): ?>
            <a class="list-group-item list-group-item-action px-0 d-flex gap-3 align-items-start panduan-item"
               data-cari="<?= esc($a['cari']) ?>"
               href="<?= esc(site_url('panduan/' . $a['slug']) . ($lang === 'en' ? '?lang=en' : '')) ?>">
              <i class="bi <?= esc($a['ikon']) ?> fs-5 text-primary"></i>
              <span>
                <span class="fw-600 d-block">
                  <?= esc($a['judul']) ?>
                  <?php if ($a['kode']): ?><span class="badge text-bg-dark font-monospace ms-1"><?= esc($a['kode']) ?></span><?php endif; ?>
                </span>
                <span class="small text-muted"><?= esc($a['ringkas']) ?></span>
              </span>
            </a>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<?php if ($waLink !== ''): ?>
  <div class="casa-card p-3 p-lg-4 mt-3 text-center">
    <p class="mb-2 small text-muted"><?= $lang === 'en' ? "Can't find the answer here?" : 'Tidak menemukan jawaban di sini?' ?></p>
    <a href="<?= esc($waLink) ?>" target="_blank" rel="noopener" class="btn btn-success btn-sm">
      <i class="bi bi-whatsapp me-1"></i> <?= $lang === 'en' ? 'Contact Admin' : 'Hubungi Admin' ?>
    </a>
  </div>
<?php endif; ?>
<script>
// Pencarian sisi-klien: menyaring judul, ringkasan, kode CASA-Exxx, SAMPAI isi
// penuh artikel (sudah disematkan di atribut data-cari tiap kartu) — tanpa
// perlu permintaan server, langsung respons tiap huruf diketik.
(function () {
  var input = document.getElementById('panduanSearch');
  var items = Array.prototype.slice.call(document.querySelectorAll('.panduan-item'));
  var kategoriCols = Array.prototype.slice.call(document.querySelectorAll('.panduan-kategori'));
  var noResult = document.getElementById('panduanNoResult');
  input.addEventListener('input', function () {
    var q = input.value.trim().toLowerCase();
    var totalTampil = 0;
    kategoriCols.forEach(function (col) {
      var tampilDiKategori = 0;
      col.querySelectorAll('.panduan-item').forEach(function (el) {
        var cocok = q === '' || (el.getAttribute('data-cari') || '').indexOf(q) !== -1;
        el.style.display = cocok ? '' : 'none';
        if (cocok) { tampilDiKategori++; totalTampil++; }
      });
      col.style.display = tampilDiKategori > 0 ? '' : 'none';
    });
    noResult.classList.toggle('d-none', totalTampil > 0);
  });
})();
</script>
<?= $this->endSection() ?>
