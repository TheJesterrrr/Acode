<?php /** @var array|null $sebelumnya @var array|null $berikutnya @var string $lang */ ?>
<div class="d-flex justify-content-between gap-2 mt-4">
  <?php if ($sebelumnya): ?>
    <a class="btn btn-outline-secondary btn-sm" href="<?= esc(site_url('panduan/' . $sebelumnya[0]) . ($lang === 'en' ? '?lang=en' : '')) ?>">
      <i class="bi bi-arrow-left me-1"></i><?= esc($sebelumnya[1]) ?>
    </a>
  <?php else: ?><span></span><?php endif; ?>
  <?php if ($berikutnya): ?>
    <a class="btn btn-outline-primary btn-sm" href="<?= esc(site_url('panduan/' . $berikutnya[0]) . ($lang === 'en' ? '?lang=en' : '')) ?>">
      <?= esc($berikutnya[1]) ?><i class="bi bi-arrow-right ms-1"></i>
    </a>
  <?php endif; ?>
</div>
