<?php /** @var string $judul @var string $kategori @var string $ringkas @var string $lang @var array<string,string> $langs @var bool $fallbackCatatan */ ?>
<div class="casa-page-head d-flex flex-wrap align-items-start gap-2">
  <div>
    <div class="small text-muted mb-1">
      <a href="<?= esc(site_url('panduan') . ($lang === 'en' ? '?lang=en' : '')) ?>" class="text-decoration-none">Guide</a>
      <i class="bi bi-chevron-right mx-1" style="font-size:.7rem"></i><?= esc($kategori) ?>
    </div>
    <h1><?= esc($judul) ?></h1>
  </div>
  <div class="ms-auto d-flex align-items-center gap-2">
    <div class="btn-group btn-group-sm" role="group" aria-label="<?= $lang === 'en' ? 'Guide language' : 'Bahasa panduan' ?>">
      <?php foreach (($langs ?? ['id' => 'Indonesia', 'en' => 'English']) as $code => $name): ?>
        <a class="btn btn-sm <?= $lang === $code ? 'btn-secondary' : 'btn-outline-secondary' ?>"
           href="?lang=<?= esc($code) ?>"><?= esc($name) ?></a>
      <?php endforeach; ?>
    </div>
    <a href="<?= esc(site_url('panduan') . ($lang === 'en' ? '?lang=en' : '')) ?>" class="btn btn-outline-secondary btn-sm">
      <i class="bi bi-arrow-left me-1"></i>All Guides
    </a>
  </div>
</div>
<p class="text-muted"><?= esc($ringkas) ?></p>
<?php if (! empty($fallbackCatatan)): ?>
  <div class="alert alert-secondary small py-2"><i class="bi bi-info-circle me-1"></i>English version of this article isn't available yet — showing the Indonesian content below.</div>
<?php endif; ?>
