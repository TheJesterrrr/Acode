<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<?php /** @var string $isi */ ?>
<?= $this->include('App\Modules\Dashboard\Views\panduan\_head') ?>

<div class="casa-card p-3 p-lg-4 casa-artikel">
  <?= $isi // sudah di-escape oleh Markdown::render() ?>
</div>

<?= $this->include('App\Modules\Dashboard\Views\panduan\_nav') ?>
<?= $this->endSection() ?>
