<?php

declare(strict_types=1);

namespace App\Modules\BugBounty\Database\Migrations;

use CodeIgniter\Database\Migration;

/** Tabel `submission` — tracker laporan bug bounty (lifecycle H1/Bugcrowd). */
final class CreateSubmissionTable extends Migration
{
    public function up(): void
    {
        $this->forge->addField([
            'id'            => ['type' => 'INT', 'constraint' => 10, 'unsigned' => true, 'auto_increment' => true],
            'project_id'    => ['type' => 'INT', 'constraint' => 10, 'unsigned' => true],
            'finding_id'    => ['type' => 'INT', 'constraint' => 10, 'unsigned' => true, 'null' => true],
            'platform'      => ['type' => 'VARCHAR', 'constraint' => 20, 'default' => 'other'],
            'title'         => ['type' => 'VARCHAR', 'constraint' => 200],
            'severity'      => ['type' => 'VARCHAR', 'constraint' => 20, 'null' => true], // CVSS/VRT label
            'status'        => ['type' => 'VARCHAR', 'constraint' => 12, 'default' => 'draft'], // draft|submitted|triaged|accepted|duplicate|na|resolved
            'bounty_amount' => ['type' => 'BIGINT', 'constraint' => 15, 'default' => 0],
            'external_id'   => ['type' => 'VARCHAR', 'constraint' => 60, 'null' => true],
            'note'          => ['type' => 'TEXT', 'null' => true],
            'created_at'    => ['type' => 'DATETIME', 'null' => true],
            'updated_at'    => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey('project_id');
        $this->forge->createTable('submission', true, ['ENGINE' => 'InnoDB', 'DEFAULT CHARSET' => 'utf8mb4', 'COLLATE' => 'utf8mb4_unicode_ci']);
    }

    public function down(): void
    {
        $this->forge->dropTable('submission', true);
    }
}
