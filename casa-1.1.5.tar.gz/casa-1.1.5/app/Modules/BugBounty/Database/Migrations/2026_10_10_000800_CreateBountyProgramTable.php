<?php

declare(strict_types=1);

namespace App\Modules\BugBounty\Database\Migrations;

use CodeIgniter\Database\Migration;

/** Tabel `bounty_program` — metadata program bug bounty (1:1 dengan project mode=bounty). */
final class CreateBountyProgramTable extends Migration
{
    public function up(): void
    {
        $this->forge->addField([
            'id'                => ['type' => 'INT', 'constraint' => 10, 'unsigned' => true, 'auto_increment' => true],
            'project_id'        => ['type' => 'INT', 'constraint' => 10, 'unsigned' => true],
            'platform'          => ['type' => 'VARCHAR', 'constraint' => 20, 'default' => 'other'], // hackerone|bugcrowd|other
            'program_url'       => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => true],
            'policy_url'        => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => true],
            'scope_in'          => ['type' => 'TEXT', 'null' => true],  // JSON array
            'scope_out'         => ['type' => 'TEXT', 'null' => true],  // JSON array
            'excluded_types'    => ['type' => 'TEXT', 'null' => true],  // JSON array
            'focus_areas'       => ['type' => 'TEXT', 'null' => true],
            'allows_automation' => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 1],
            'created_at'        => ['type' => 'DATETIME', 'null' => true],
            'updated_at'        => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addUniqueKey('project_id');
        $this->forge->createTable('bounty_program', true, ['ENGINE' => 'InnoDB', 'DEFAULT CHARSET' => 'utf8mb4', 'COLLATE' => 'utf8mb4_unicode_ci']);
    }

    public function down(): void
    {
        $this->forge->dropTable('bounty_program', true);
    }
}
