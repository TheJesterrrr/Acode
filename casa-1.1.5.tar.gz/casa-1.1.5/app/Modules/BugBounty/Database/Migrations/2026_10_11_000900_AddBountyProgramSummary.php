<?php

declare(strict_types=1);

namespace App\Modules\BugBounty\Database\Migrations;

use CodeIgniter\Database\Migration;

/** Tambah kolom summary: ringkasan program (tujuan/boleh/tidak boleh/tak dibayar/uji Burp) dibangkitkan AI. */
final class AddBountyProgramSummary extends Migration
{
    public function up(): void
    {
        if (! $this->db->fieldExists('summary', 'bounty_program')) {
            $this->forge->addColumn('bounty_program', [
                'summary' => ['type' => 'TEXT', 'null' => true, 'after' => 'focus_areas'],
            ]);
        }
    }

    public function down(): void
    {
        if ($this->db->fieldExists('summary', 'bounty_program')) {
            $this->forge->dropColumn('bounty_program', 'summary');
        }
    }
}
