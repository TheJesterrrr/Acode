<?php

declare(strict_types=1);

namespace App\Modules\BugBounty\Models;

use CodeIgniter\Model;

final class SubmissionModel extends Model
{
    protected $table         = 'submission';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $useTimestamps = true;
    protected $allowedFields  = [
        'project_id', 'finding_id', 'platform', 'title', 'severity',
        'status', 'bounty_amount', 'external_id', 'note',
    ];

    public const STATUSES = ['draft', 'submitted', 'triaged', 'accepted', 'duplicate', 'na', 'resolved'];

    /** Submission milik satu member (join project untuk scope kepemilikan). */
    public function forCustomer(int $customerId): array
    {
        return $this->db->table('submission s')
            ->select('s.*, p.name AS program')
            ->join('project p', 'p.id = s.project_id')
            ->where('p.customer_id', $customerId)
            ->where('p.mode', 'bounty')
            ->orderBy('s.id', 'DESC')
            ->get(200)->getResultArray();
    }

    public function forProject(int $projectId): array
    {
        return $this->where('project_id', $projectId)->orderBy('id', 'DESC')->findAll();
    }
}
