<?php

declare(strict_types=1);

namespace App\Modules\BugBounty\Models;

use CodeIgniter\Model;

final class BountyProgramModel extends Model
{
    protected $table         = 'bounty_program';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $useTimestamps = true;
    protected $allowedFields  = [
        'project_id', 'platform', 'program_url', 'policy_url',
        'scope_in', 'scope_out', 'excluded_types', 'focus_areas', 'summary', 'allows_automation',
    ];

    public function forProject(int $projectId): ?array
    {
        return $this->where('project_id', $projectId)->first();
    }
}
