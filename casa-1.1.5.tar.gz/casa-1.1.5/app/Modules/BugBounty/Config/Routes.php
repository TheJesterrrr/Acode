<?php

declare(strict_types=1);

use CodeIgniter\Router\RouteCollection;

/** Rute Bug Bounty mode (member). Ditemukan otomatis oleh Config\Modules. */

/** @var RouteCollection $routes */
$routes->group('', ['namespace' => 'App\Modules\BugBounty\Controllers', 'filter' => 'member'], static function (RouteCollection $routes): void {
    // Pindah mode portal (pentest <-> bounty).
    $routes->get('mode/(:segment)', 'ModeController::set/$1');
    // Dashboard Bug Bounty.
    $routes->get('bounty', 'BountyDashboardController::index');

    // Programs (Fase 2).
    $routes->get('bounty/programs', 'ProgramController::index');
    $routes->get('bounty/programs/new', 'ProgramController::newForm');
    $routes->post('bounty/programs', 'ProgramController::create');
    $routes->post('bounty/programs/parse', 'ProgramController::parse');
    $routes->post('bounty/programs/summary', 'ProgramController::aiSummary');
    $routes->get('bounty/programs/(:num)', 'ProgramController::show/$1');
    $routes->post('bounty/programs/(:num)/scan', 'ProgramController::scan/$1');
    $routes->post('bounty/programs/(:num)/delete', 'ProgramController::delete/$1');

    // Recon Monitor (Fase 3).
    $routes->get('bounty/recon', 'ReconController::index');

    // Findings (Fase 3).
    $routes->get('bounty/findings', 'FindingsController::index');
    $routes->post('bounty/findings/(:num)/toggle', 'FindingsController::toggle/$1');

    // Reports (Fase 4).
    $routes->get('bounty/reports', 'ReportController::index');
    $routes->get('bounty/reports/(:num)', 'ReportController::show/$1');
    $routes->get('bounty/reports/(:num)/download', 'ReportController::download/$1');
    $routes->post('bounty/reports/(:num)/submission', 'ReportController::saveSubmission/$1');

    // Submissions (Fase 4).
    $routes->get('bounty/submissions', 'SubmissionController::index');
    $routes->post('bounty/submissions/(:num)', 'SubmissionController::update/$1');

    // Import (Fase 5).
    $routes->get('bounty/import', 'ImportController::index');
    $routes->post('bounty/import/burp', 'ImportController::burp');
    $routes->post('bounty/import/manual', 'ImportController::manual');

    // Bounty Scan dilakukan dari halaman Program → placeholder arahan.
    $routes->get('bounty/scan', 'BountyPlaceholderController::show/scan');
});
