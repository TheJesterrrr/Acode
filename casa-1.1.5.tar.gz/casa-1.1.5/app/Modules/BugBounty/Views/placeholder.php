<?php /** @var string $icon @var string $fase @var string $desc */ ?>
<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<div class="casa-page-head">
  <h1 class="mb-0"><i class="bi <?= esc($icon) ?> me-1"></i><?= esc($title) ?></h1>
</div>
<div class="casa-card p-4 p-lg-5 text-center">
  <i class="bi <?= esc($icon) ?> display-5 text-bounty"></i>
  <h2 class="h5 mt-3"><?= esc($title) ?> <span class="badge text-bg-secondary align-middle"><?= esc($fase) ?></span></h2>
  <p class="text-muted mb-0" style="max-width:600px;margin-inline:auto"><?= esc($desc) ?></p>
  <p class="small text-muted mt-3 mb-0"><i class="bi bi-hourglass-split me-1"></i>Segera hadir — kerangka mode sudah siap, fitur ini dibangun bertahap.</p>
</div>
<?= $this->endSection() ?>
