<?php /** @var array $findings */ ?>
<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<?php $sevMeta = ['crit' => ['Critical', 'danger'], 'high' => ['High', 'warning'], 'med' => ['Medium', 'info'], 'low' => ['Low', 'primary'], 'info' => ['Info', 'secondary']]; ?>
<div class="casa-page-head">
  <div>
    <h1 class="mb-0"><i class="bi bi-file-earmark-text me-1"></i>Reports</h1>
    <div class="small text-muted">Pilih finding → draft report siap-submit (HackerOne / Bugcrowd). Bagian bukti diisi manual.</div>
  </div>
</div>
<div class="casa-card p-0">
  <div class="table-responsive">
    <table class="table align-middle mb-0">
      <thead><tr><th class="ps-3">Severity</th><th>Finding</th><th>Program</th><th class="text-end pe-3">Draft</th></tr></thead>
      <tbody>
        <?php foreach ($findings as $f): [$lbl, $c] = $sevMeta[$f['severity']] ?? ['Info', 'secondary']; ?>
          <tr>
            <td class="ps-3"><span class="badge text-bg-<?= $c ?>"><?= $lbl ?></span></td>
            <td><?= esc($f['title']) ?><div class="small text-muted font-monospace"><?= esc($f['asset'] ?? '') ?></div></td>
            <td class="small"><?= esc($f['program'] ?? '') ?></td>
            <td class="text-end pe-3"><a href="<?= esc(site_url('bounty/reports/' . (int) $f['id'])) ?>" class="btn btn-sm btn-bounty"><i class="bi bi-pencil-square me-1"></i>Draft Report</a></td>
          </tr>
        <?php endforeach; ?>
        <?php if ($findings === []): ?><tr><td colspan="4" class="text-muted small py-3 ps-3">Belum ada finding untuk dilaporkan.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?= $this->endSection() ?>
