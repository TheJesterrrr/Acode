<?php /** @var array $stats */ ?>
<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<div class="casa-page-head">
  <div>
    <h1 class="mb-0"><i class="bi bi-bullseye me-1"></i>Bug Bounty</h1>
    <div class="small text-muted">Kelola program, recon, Submissions, dan report siap-submit (H1 / Bugcrowd).</div>
  </div>
  <a href="<?= esc(site_url('bounty/programs')) ?>" class="btn btn-bounty"><i class="bi bi-plus-lg me-1"></i>Program Baru</a>
</div>

<div class="row g-3 mb-1">
  <div class="col-6 col-lg-3"><div class="casa-stat"><div class="casa-stat__n"><?= (int) $stats['programs'] ?></div><div class="casa-stat__l">Programs</div><i class="bi bi-bullseye"></i></div></div>
  <div class="col-6 col-lg-3"><div class="casa-stat"><div class="casa-stat__n"><?= (int) $stats['submissions'] ?></div><div class="casa-stat__l">Submissions</div><i class="bi bi-send"></i></div></div>
  <div class="col-6 col-lg-3"><div class="casa-stat"><div class="casa-stat__n"><?= (int) $stats['accepted'] ?></div><div class="casa-stat__l">Accepted</div><i class="bi bi-check2-circle"></i></div></div>
  <div class="col-6 col-lg-3"><div class="casa-stat casa-stat--amber"><div class="casa-stat__n">$<?= number_format((int) $stats['bounty'], 0, ',', '.') ?></div><div class="casa-stat__l">Bounty</div><i class="bi bi-cash-coin"></i></div></div>
</div>

<div class="casa-card p-4 p-lg-5 mt-2 text-center">
  <i class="bi bi-bullseye display-5 text-bounty"></i>
  <h2 class="h5 mt-3">Mode Bug Bounty aktif</h2>
  <p class="text-muted mb-3" style="max-width:620px;margin-inline:auto">
    Alur: <b>Programs</b> (tetapkan scope) → <b>Recon &amp; Scan</b> (hormati rate &amp; aturan program) →
    <b>Findings</b> → <b>Submissions</b> (lacak status) → <b>Reports</b> (format H1/Bugcrowd).
    Burp tetap kerja manual Anda — hasilnya di-<b>Import</b>.
  </p>
  <div class="d-flex flex-wrap gap-2 justify-content-center">
    <a href="<?= esc(site_url('bounty/programs')) ?>" class="btn btn-bounty"><i class="bi bi-bullseye me-1"></i>Programs</a>
    <a href="<?= esc(site_url('bounty/submissions')) ?>" class="btn btn-outline-secondary"><i class="bi bi-send me-1"></i>Submissions</a>
    <a href="<?= esc(site_url('bounty/import')) ?>" class="btn btn-outline-secondary"><i class="bi bi-box-arrow-in-down me-1"></i>Import (Burp)</a>
  </div>
  <p class="small text-muted mt-3 mb-0"><i class="bi bi-info-circle me-1"></i>Fitur bertahap: kerangka mode siap; Programs, Submissions &amp; Reports menyusul.</p>
</div>
<?= $this->endSection() ?>
