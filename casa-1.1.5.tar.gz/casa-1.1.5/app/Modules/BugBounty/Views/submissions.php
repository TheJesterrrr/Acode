<?php /** @var array $subs @var array $stats @var array $statuses */ ?>
<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<?php
$plat = ['hackerone' => 'HackerOne', 'bugcrowd' => 'Bugcrowd', 'other' => 'Lainnya'];
$stColor = ['draft' => 'secondary', 'submitted' => 'info', 'triaged' => 'primary', 'accepted' => 'success', 'duplicate' => 'warning', 'na' => 'dark', 'resolved' => 'success'];
?>
<div class="casa-page-head">
  <h1 class="mb-0"><i class="bi bi-send me-1"></i>Submissions</h1>
</div>
<div class="row g-3 mb-1">
  <div class="col-6 col-lg-3"><div class="casa-stat"><div class="casa-stat__n"><?= (int) $stats['total'] ?></div><div class="casa-stat__l">Total</div><i class="bi bi-send"></i></div></div>
  <div class="col-6 col-lg-3"><div class="casa-stat"><div class="casa-stat__n"><?= (int) $stats['accepted'] ?></div><div class="casa-stat__l">Accepted</div><i class="bi bi-check2-circle"></i></div></div>
  <div class="col-6 col-lg-3"><div class="casa-stat"><div class="casa-stat__n"><?= (int) $stats['duplicate'] ?></div><div class="casa-stat__l">Duplicate</div><i class="bi bi-files"></i></div></div>
  <div class="col-6 col-lg-3"><div class="casa-stat casa-stat--amber"><div class="casa-stat__n">$<?= number_format((int) $stats['bounty'], 0, ',', '.') ?></div><div class="casa-stat__l">Bounty</div><i class="bi bi-cash-coin"></i></div></div>
</div>
<div class="casa-card p-0">
  <div class="table-responsive">
    <table class="table align-middle mb-0">
      <thead><tr><th class="ps-3">Report</th><th>Program</th><th style="width:140px">Status</th><th style="width:120px">Bounty ($)</th><th style="width:130px">External ID</th><th style="width:80px"></th></tr></thead>
      <tbody>
        <?php foreach ($subs as $s): ?>
          <tr data-id="<?= (int) $s['id'] ?>">
            <td class="ps-3"><?= esc($s['title']) ?><div class="small text-muted"><?= esc($plat[$s['platform']] ?? '') ?> · <?= esc($s['severity'] ?: '—') ?></div></td>
            <td class="small"><?= esc($s['program'] ?? '') ?></td>
            <td>
              <select class="form-select form-select-sm js-status">
                <?php foreach ($statuses as $st): ?><option value="<?= $st ?>" <?= $s['status'] === $st ? 'selected' : '' ?>><?= ucfirst($st) ?></option><?php endforeach; ?>
              </select>
            </td>
            <td><input type="number" class="form-control form-control-sm js-bounty" value="<?= (int) $s['bounty_amount'] ?>" min="0"></td>
            <td><input class="form-control form-control-sm js-ext" value="<?= esc($s['external_id'] ?? '') ?>" placeholder="#12345"></td>
            <td><button class="btn btn-sm btn-bounty js-save"><i class="bi bi-check-lg"></i></button></td>
          </tr>
        <?php endforeach; ?>
        <?php if ($subs === []): ?><tr><td colspan="6" class="text-muted small py-3 ps-3">Belum ada submission. Buat dari Reports → "Simpan sebagai Submission".</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?= $this->endSection() ?>
<?= $this->section('page_scripts') ?>
<script>
document.querySelectorAll('.js-save').forEach(b=>b.addEventListener('click', async e=>{
  const tr=e.target.closest('tr'); const id=tr.dataset.id;
  const fd=new FormData();
  fd.append('status', tr.querySelector('.js-status').value);
  fd.append('bounty_amount', tr.querySelector('.js-bounty').value||0);
  fd.append('external_id', tr.querySelector('.js-ext').value||'');
  const d=await casaPost('<?= esc(site_url('bounty/submissions')) ?>/'+id, fd);
  const btn=e.target.closest('button'); const o=btn.innerHTML;
  btn.innerHTML = d.ok ? '<i class="bi bi-check2"></i>' : '<i class="bi bi-x"></i>';
  setTimeout(()=>btn.innerHTML=o, 1200);
}));
</script>
<?= $this->endSection() ?>
