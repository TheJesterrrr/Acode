<?php /** @var array $findings */ ?>
<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<?php $sevMeta = ['crit' => ['Critical', 'danger'], 'high' => ['High', 'warning'], 'med' => ['Medium', 'info'], 'low' => ['Low', 'primary'], 'info' => ['Info', 'secondary']]; ?>
<div class="casa-page-head">
  <h1 class="mb-0"><i class="bi bi-bug me-1"></i>Findings</h1>
</div>
<div class="casa-card p-0">
  <div class="table-responsive">
    <table class="table align-middle mb-0">
      <thead><tr><th class="ps-3">Severity</th><th>Finding</th><th>Program</th><th>Tool</th><th class="text-end pe-3">Aksi</th></tr></thead>
      <tbody>
        <?php foreach ($findings as $f): [$lbl, $c] = $sevMeta[$f['severity']] ?? ['Info', 'secondary']; ?>
          <tr data-id="<?= (int) $f['id'] ?>" class="<?= (int) $f['excluded'] === 1 ? 'opacity-50' : '' ?>">
            <td class="ps-3"><span class="badge text-bg-<?= $c ?>"><?= $lbl ?></span></td>
            <td><?= esc($f['title']) ?>
              <?php if ((int) $f['excluded'] === 1): ?><span class="badge text-bg-secondary ms-1">excluded</span><?php endif; ?>
              <div class="small text-muted font-monospace"><?= esc($f['asset'] ?? '') ?></div>
            </td>
            <td class="small"><?= esc($f['program'] ?? '') ?></td>
            <td class="small text-muted"><?= esc($f['tool'] ?? '') ?></td>
            <td class="text-end pe-3">
              <a href="<?= esc(site_url('bounty/reports/' . (int) $f['id'])) ?>" class="btn btn-sm btn-outline-secondary"><i class="bi bi-file-earmark-text me-1"></i>Report</a>
              <button class="btn btn-sm btn-outline-secondary js-excl"><i class="bi bi-slash-circle"></i></button>
            </td>
          </tr>
        <?php endforeach; ?>
        <?php if ($findings === []): ?><tr><td colspan="5" class="text-muted small py-3 ps-3">Belum ada finding. Jalankan Bounty Scan pada Program, atau Import hasil Burp.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?= $this->endSection() ?>
<?= $this->section('page_scripts') ?>
<script>
document.querySelectorAll('.js-excl').forEach(b=>b.addEventListener('click', async e=>{
  const tr=e.target.closest('tr'); const id=tr.dataset.id;
  const d=await casaPost('<?= esc(site_url('bounty/findings')) ?>/'+id+'/toggle', new FormData());
  if(d.ok) location.reload();
}));
</script>
<?= $this->endSection() ?>
