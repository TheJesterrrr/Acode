<?php /** @var array $programs */ ?>
<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<div class="casa-page-head">
  <div>
    <h1 class="mb-0"><i class="bi bi-box-arrow-in-down me-1"></i>Import</h1>
    <div class="small text-muted">Impor hasil <b>Burp Suite</b> (XML) atau tambah temuan manual ke sebuah program.</div>
  </div>
</div>

<?php if ($programs === []): ?>
  <div class="casa-card p-4 text-center">
    <p class="text-muted mb-2">Belum ada program. Buat program dulu untuk menampung finding.</p>
    <a href="<?= esc(site_url('bounty/programs/new')) ?>" class="btn btn-bounty btn-sm">Create Program</a>
  </div>
<?php else: ?>
<div class="row g-3">
  <!-- Burp XML -->
  <div class="col-lg-6">
    <div class="casa-card p-3 p-lg-4 h-100">
      <h2 class="h6"><i class="bi bi-filetype-xml me-1 text-bounty"></i>Import Burp (XML)</h2>
      <p class="small text-muted">Di Burp: <b>Target → kanan-klik → Report issues → XML</b>. Lalu unggah di sini.</p>
      <form id="burpForm">
        <label class="form-label small fw-semibold">Program</label>
        <select name="program_id" class="form-select mb-2"><?php foreach ($programs as $id => $n): ?><option value="<?= (int) $id ?>"><?= esc($n) ?></option><?php endforeach; ?></select>
        <input type="file" name="xml" accept=".xml,text/xml,application/xml" class="form-control mb-2" required>
        <button class="btn btn-bounty w-100"><i class="bi bi-upload me-1"></i>Import</button>
        <div id="burpMsg" class="small mt-2"></div>
      </form>
    </div>
  </div>
  <!-- Manual -->
  <div class="col-lg-6">
    <div class="casa-card p-3 p-lg-4 h-100">
      <h2 class="h6"><i class="bi bi-pencil-square me-1 text-bounty"></i>Add Finding Manual</h2>
      <form id="manForm">
        <div class="row g-2">
          <div class="col-8"><label class="form-label small fw-semibold">Program</label>
            <select name="program_id" class="form-select"><?php foreach ($programs as $id => $n): ?><option value="<?= (int) $id ?>"><?= esc($n) ?></option><?php endforeach; ?></select></div>
          <div class="col-4"><label class="form-label small fw-semibold">Severity</label>
            <select name="severity" class="form-select"><option value="crit">Critical</option><option value="high">High</option><option value="med" selected>Medium</option><option value="low">Low</option><option value="info">Info</option></select></div>
          <div class="col-12"><label class="form-label small fw-semibold">Judul</label><input name="title" class="form-control" placeholder="mis. IDOR pada /api/orders" required></div>
          <div class="col-12"><label class="form-label small fw-semibold">Asset / URL</label><input name="asset" class="form-control font-monospace" placeholder="https://target.com/api/orders/123"></div>
          <div class="col-12"><label class="form-label small fw-semibold">Deskripsi</label><textarea name="description" class="form-control" rows="3"></textarea></div>
        </div>
        <button class="btn btn-bounty w-100 mt-2"><i class="bi bi-plus-lg me-1"></i>Add Finding</button>
        <div id="manMsg" class="small mt-2"></div>
      </form>
    </div>
  </div>
</div>
<?php endif; ?>
<?= $this->endSection() ?>
<?= $this->section('page_scripts') ?>
<script>
const sub=async (form,url,msg)=>{
  const m=document.querySelector(msg);
  const d=await casaPost(url, new FormData(form));
  if(d.ok && d.redirect){ m.className='small mt-2 text-success'; m.textContent='Berhasil'+(d.count?(' ('+d.count+' finding)'):'')+'! Mengalihkan…'; location.href=d.redirect; }
  else { m.className='small mt-2 text-danger'; m.textContent=d.error||'Gagal.'; }
};
const bf=document.getElementById('burpForm'); if(bf) bf.addEventListener('submit', e=>{ e.preventDefault(); sub(bf,'<?= esc(site_url('bounty/import/burp')) ?>','#burpMsg'); });
const mf=document.getElementById('manForm'); if(mf) mf.addEventListener('submit', e=>{ e.preventDefault(); sub(mf,'<?= esc(site_url('bounty/import/manual')) ?>','#manMsg'); });
</script>
<?= $this->endSection() ?>
