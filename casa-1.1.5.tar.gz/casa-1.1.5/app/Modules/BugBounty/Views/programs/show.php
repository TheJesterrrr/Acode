<?php /** @var array $data */ ?>
<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<?php
$p    = $data['project'];
$meta = $data['meta'];
$plat = ['hackerone' => 'HackerOne', 'bugcrowd' => 'Bugcrowd', 'other' => 'Lainnya'];
$auto = (int) ($meta['allows_automation'] ?? 1) === 1;
$sevMeta = ['crit' => ['Critical', 'danger'], 'high' => ['High', 'warning'], 'med' => ['Medium', 'info'], 'low' => ['Low', 'primary'], 'info' => ['Info', 'secondary']];
?>
<div class="casa-page-head">
  <div>
    <a href="<?= esc(site_url('bounty/programs')) ?>" class="small text-decoration-none"><i class="bi bi-arrow-left me-1"></i>Programs</a>
    <h1 class="mb-0"><i class="bi bi-bullseye me-1 text-bounty"></i><?= esc($p['name']) ?>
      <span class="badge text-bg-dark border align-middle"><?= esc($plat[$meta['platform'] ?? 'other'] ?? 'Lainnya') ?></span>
    </h1>
    <?php if (! empty($meta['program_url'])): ?><div class="small"><a href="<?= esc($meta['program_url']) ?>" target="_blank" rel="noopener">Halaman program <i class="bi bi-box-arrow-up-right"></i></a></div><?php endif; ?>
  </div>
  <button id="scanBtn" class="btn btn-bounty"><i class="bi bi-radar me-1"></i>Start Bounty Scan</button>
</div>

<?php if (! $auto): ?>
  <div class="alert alert-warning d-flex gap-2 py-2 px-3 small"><i class="bi bi-exclamation-triangle-fill mt-1"></i>
    <div>Program ini <b>melarang automated scanner</b>. Scan dipaksa mode <b>Light</b> & hanya recon (tanpa mass-scan Nuclei) agar tak kena lockout/ban. Uji vuln lakukan manual (Burp) lalu Import.</div>
  </div>
<?php endif; ?>

<div class="row g-3">
  <div class="col-lg-4">
    <div class="casa-card p-3 p-lg-4 h-100">
      <h2 class="h6 mb-2"><i class="bi bi-check-circle text-success me-1"></i>Scope IN (<?= count($data['scope_in']) ?>)</h2>
      <div class="d-flex flex-wrap gap-1 mb-3">
        <?php foreach ($data['scope_in'] as $s): ?><span class="badge text-bg-light border font-monospace"><?= esc($s) ?></span><?php endforeach; ?>
        <?php if ($data['scope_in'] === []): ?><span class="text-muted small">—</span><?php endif; ?>
      </div>
      <h2 class="h6 mb-2"><i class="bi bi-slash-circle text-danger me-1"></i>Scope OUT (<?= count($data['scope_out']) ?>)</h2>
      <div class="d-flex flex-wrap gap-1">
        <?php foreach ($data['scope_out'] as $s): ?><span class="badge text-bg-light border font-monospace"><?= esc($s) ?></span><?php endforeach; ?>
        <?php if ($data['scope_out'] === []): ?><span class="text-muted small">—</span><?php endif; ?>
      </div>
      <?php if (! empty($data['excluded'])): ?>
        <hr><h2 class="h6 mb-2">Excluded types</h2>
        <ul class="small text-muted mb-0 ps-3"><?php foreach ($data['excluded'] as $e): ?><li><?= esc($e) ?></li><?php endforeach; ?></ul>
      <?php endif; ?>
      <?php if (! empty($meta['focus_areas'])): ?>
        <hr><h2 class="h6 mb-1">Focus areas</h2><p class="small text-muted mb-0"><?= esc($meta['focus_areas']) ?></p>
      <?php endif; ?>
      <?php if (! empty($meta['summary'])): ?>
        <hr><h2 class="h6 mb-1"><i class="bi bi-robot me-1 text-info"></i>Ringkasan <span class="badge text-bg-info">AI</span></h2>
        <p class="small text-muted mb-0" style="white-space:pre-wrap"><?= esc($meta['summary']) ?></p>
      <?php endif; ?>
    </div>
  </div>

  <div class="col-lg-8">
    <div class="casa-card p-3 p-lg-4 h-100">
      <div class="d-flex align-items-baseline justify-content-between mb-2">
        <h2 class="h6 mb-0">Findings (<?= count($data['findings']) ?>)</h2>
        <span class="small text-muted"><?= count($data['targets']) ?> target in-scope</span>
      </div>
      <div class="table-responsive">
        <table class="table table-sm align-middle mb-0">
          <tbody>
            <?php foreach ($data['findings'] as $f): [$lbl, $c] = $sevMeta[$f['severity']] ?? ['Info', 'secondary']; ?>
              <tr>
                <td style="width:84px"><span class="badge text-bg-<?= $c ?>"><?= $lbl ?></span></td>
                <td><?= esc($f['title']) ?>
                  <?php if (! empty($f['excluded'])): ?><span class="badge text-bg-secondary ms-1" title="Falls under the program's excluded types">excluded</span><?php endif; ?>
                  <div class="small text-muted font-monospace"><?= esc($f['asset'] ?? '') ?></div>
                </td>
              </tr>
            <?php endforeach; ?>
            <?php if ($data['findings'] === []): ?>
              <tr><td class="text-muted small py-3">Belum ada finding. Jalankan Bounty Scan (recon), lalu uji manual di Burp &amp; Import hasilnya.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
      <p class="small text-muted mt-3 mb-0"><i class="bi bi-shield-check me-1"></i>Verifikasi manual tetap wajib sebelum submit — scan di sini untuk recon &amp; triase, bukan bukti akhir.</p>
    </div>
  </div>
</div>

<form id="delForm" class="mt-3"><button id="delBtn" class="btn btn-outline-danger btn-sm" type="submit"><i class="bi bi-trash me-1"></i>Delete program</button><span id="delMsg" class="small ms-2"></span></form>

<?= $this->endSection() ?>
<?= $this->section('page_scripts') ?>
<script>
const $ = (s)=>document.querySelector(s);
$('#scanBtn').addEventListener('click', async ()=>{
  const b=$('#scanBtn'); const o=b.innerHTML; b.disabled=true; b.innerHTML='<span class="spinner-border spinner-border-sm"></span> Meluncurkan…';
  const fd=new FormData(); fd.append('depth','<?= $auto ? 'standard' : 'light' ?>');
  const d = await casaPost('<?= esc(site_url('bounty/programs/' . (int) $p['id'] . '/scan')) ?>', fd);
  if(d.ok && d.redirect){ location.href=d.redirect; } else { b.disabled=false; b.innerHTML=o; alert(d.error||'Gagal memulai scan.'); }
});
$('#delForm').addEventListener('submit', async (e)=>{
  e.preventDefault();
  if(!confirm('Delete program ini beserta data scannya?')) return;
  const d = await casaPost('<?= esc(site_url('bounty/programs/' . (int) $p['id'] . '/delete')) ?>', new FormData());
  if(d.ok && d.redirect){ location.href=d.redirect; } else { $('#delMsg').className='small ms-2 text-danger'; $('#delMsg').textContent=d.error||'Gagal.'; }
});
</script>
<?= $this->endSection() ?>
