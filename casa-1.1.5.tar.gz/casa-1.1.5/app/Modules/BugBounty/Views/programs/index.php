<?php /** @var array $programs */ ?>
<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<?php $plat = ['hackerone' => 'HackerOne', 'bugcrowd' => 'Bugcrowd', 'other' => 'Lainnya']; ?>
<div class="casa-page-head">
  <div>
    <h1 class="mb-0"><i class="bi bi-bullseye me-1"></i>Programs</h1>
    <div class="small text-muted">Program bug bounty beserta scope-nya. Scan hanya menyentuh target in-scope.</div>
  </div>
  <a href="<?= esc(site_url('bounty/programs/new')) ?>" class="btn btn-bounty"><i class="bi bi-plus-lg me-1"></i>Program Baru</a>
</div>

<?php if ($programs === []): ?>
  <div class="casa-card p-4 p-lg-5 text-center">
    <i class="bi bi-bullseye display-5 text-bounty"></i>
    <h2 class="h5 mt-3">Belum ada program</h2>
    <p class="text-muted mb-3">Tambahkan program (HackerOne/Bugcrowd), tetapkan scope, lalu jalankan scan terscope.</p>
    <a href="<?= esc(site_url('bounty/programs/new')) ?>" class="btn btn-bounty"><i class="bi bi-plus-lg me-1"></i>Create Program</a>
  </div>
<?php else: ?>
  <div class="row g-3">
    <?php foreach ($programs as $p): ?>
      <div class="col-md-6 col-lg-4">
        <a href="<?= esc(site_url('bounty/programs/' . (int) $p['id'])) ?>" class="text-decoration-none text-body">
          <div class="casa-card p-3 p-lg-4 h-100">
            <div class="d-flex align-items-center gap-2 mb-2">
              <i class="bi bi-bullseye fs-5 text-bounty"></i>
              <h2 class="h6 mb-0 flex-grow-1 text-truncate"><?= esc($p['name']) ?></h2>
              <span class="badge text-bg-dark border"><?= esc($plat[$p['platform']] ?? 'Lainnya') ?></span>
            </div>
            <div class="small text-muted mb-1"><i class="bi bi-diagram-3 me-1"></i><?= (int) $p['target_count'] ?> target in-scope</div>
            <div class="small">
              <?php if ((int) $p['allows_automation'] === 1): ?>
                <span class="badge text-bg-success">Automated scan OK</span>
              <?php else: ?>
                <span class="badge text-bg-warning"><i class="bi bi-exclamation-triangle me-1"></i>No automated scanner</span>
              <?php endif; ?>
            </div>
          </div>
        </a>
      </div>
    <?php endforeach; ?>
  </div>
<?php endif; ?>
<?= $this->endSection() ?>
