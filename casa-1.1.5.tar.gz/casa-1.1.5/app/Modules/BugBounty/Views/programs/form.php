<?php /** @var array $platforms */ ?>
<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<div class="casa-page-head">
  <div>
    <h1 class="mb-0"><i class="bi bi-plus-circle me-1"></i>Program Baru</h1>
    <div class="small text-muted">Isi scope manual, atau tempel policy / URL program lalu <b>Parse</b> untuk mengisi otomatis.</div>
  </div>
  <a href="<?= esc(site_url('bounty/programs')) ?>" class="btn btn-outline-secondary btn-sm"><i class="bi bi-arrow-left me-1"></i>Back</a>
</div>

<form id="pForm" class="row g-3">
  <div class="col-lg-7">
    <div class="casa-card p-3 p-lg-4">
      <div class="row g-3">
        <div class="col-md-8">
          <label class="form-label fw-semibold">Nama program</label>
          <input name="name" class="form-control" placeholder="mis. Gap Inc." required>
        </div>
        <div class="col-md-4">
          <label class="form-label fw-semibold">Platform</label>
          <select name="platform" class="form-select">
            <?php foreach ($platforms as $k => $v): ?><option value="<?= esc($k) ?>"><?= esc($v) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-6">
          <label class="form-label fw-semibold">URL program <span class="text-muted small fw-normal">(opsional)</span></label>
          <input name="program_url" class="form-control" placeholder="https://bugcrowd.com/...">
        </div>
        <div class="col-md-6">
          <label class="form-label fw-semibold">URL policy <span class="text-muted small fw-normal">(opsional)</span></label>
          <input name="policy_url" class="form-control" placeholder="https://.../policy">
        </div>

        <div class="col-md-6">
          <label class="form-label fw-semibold">Scope IN <span class="text-muted small fw-normal">(satu per baris)</span></label>
          <textarea name="scope_in" id="scopeIn" class="form-control font-monospace" rows="6" placeholder="*.example.com&#10;api.example.com&#10;https://shop.example.com" required></textarea>
        </div>
        <div class="col-md-6">
          <label class="form-label fw-semibold">Scope OUT <span class="text-muted small fw-normal">(dikecualikan)</span></label>
          <textarea name="scope_out" id="scopeOut" class="form-control font-monospace" rows="6" placeholder="blog.example.com&#10;*.corp.example.com"></textarea>
        </div>

        <div class="col-12">
          <label class="form-label fw-semibold">Excluded finding types <span class="text-muted small fw-normal">(known-issue program, satu per baris)</span></label>
          <textarea name="excluded_types" class="form-control" rows="3" placeholder="Missing security headers&#10;Clickjacking&#10;SPF/DMARC&#10;Self-XSS"></textarea>
        </div>
        <div class="col-12">
          <label class="form-label fw-semibold">Focus areas <span class="text-muted small fw-normal">(opsional)</span></label>
          <textarea name="focus_areas" class="form-control" rows="2" placeholder="IDOR, Business Logic, Auth…"></textarea>
        </div>
        <div class="col-12">
          <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
            <label class="form-label fw-semibold mb-0">Ringkasan program <span class="badge text-bg-info align-middle">AI</span> <span class="text-muted small fw-normal">(tujuan · boleh · tidak boleh · tak dibayar · uji Burp?)</span></label>
            <?php if ($aiOn ?? false): ?>
              <button type="button" id="sumBtn" class="btn btn-sm btn-outline-info"><i class="bi bi-magic me-1"></i>Ringkas by AI</button>
            <?php endif; ?>
          </div>
          <textarea name="summary" id="summaryBox" class="form-control mt-1" rows="5" placeholder="<?= ($aiOn ?? false) ? 'Klik &quot;Ringkas by AI&quot; untuk analisa dari teks policy di kanan — atau isi manual.' : 'Isi ringkasan program (AI belum konek — aktifkan di AI Settings agar otomatis).' ?>"></textarea>
          <div id="sumMsg" class="small mt-1 text-muted"></div>
        </div>
        <div class="col-12">
          <div class="form-check">
            <input class="form-check-input" type="checkbox" name="allows_automation" id="autoChk" value="1">
            <label class="form-check-label" for="autoChk">Program <b>mengizinkan automated scanner</b> (nuclei dll). Kosongkan bila dilarang — scan dipaksa hemat & tanpa mass-scan.</label>
          </div>
        </div>
      </div>
      <button id="pBtn" class="btn btn-bounty btn-lg w-100 mt-3"><i class="bi bi-check-lg me-1"></i>Save Program</button>
      <div id="pMsg" class="small mt-2 text-center"></div>
    </div>
  </div>

  <!-- Isi scope otomatis -->
  <div class="col-lg-5">
    <div class="casa-card p-3 p-lg-4">
      <h2 class="h6"><i class="bi bi-magic me-1 text-bounty"></i>Isi scope otomatis</h2>
      <p class="small text-muted">Upload screenshot/PDF halaman program → <b>Analisa kelayakan</b> (boleh auto-scan atau tidak) → <b>Parse</b> untuk mengisi scope di kiri.</p>

      <label class="form-label small fw-semibold">1. Upload screenshot (PNG/JPG) atau PDF halaman program</label>
      <div class="d-flex flex-wrap gap-2 align-items-center">
        <label class="btn btn-outline-secondary btn-sm mb-0" for="scopeFile"><i class="bi bi-upload me-1"></i>Pilih file</label>
        <input type="file" id="scopeFile" accept="image/*,application/pdf" hidden>
        <span id="fileName" class="small text-muted">capture full page lalu upload</span>
      </div>
      <div class="small text-muted my-2">— atau tempel URL / teks —</div>

      <label class="form-label small fw-semibold">URL program <span class="text-muted fw-normal">(opsional)</span></label>
      <input id="parseUrl" class="form-control form-control-sm mb-2" placeholder="https://bugcrowd.com/engagements/...">
      <label class="form-label small fw-semibold">Teks policy</label>
      <textarea id="parseText" class="form-control" rows="6" placeholder="Hasil upload muncul di sini — atau tempel bagian Scope / In Scope / Out of Scope…"></textarea>

      <button type="button" id="analyzeBtn" class="btn btn-bounty btn-sm mt-2 w-100"><i class="bi bi-shield-check me-1"></i>2. Analisa kelayakan</button>
      <div id="analyzeMsg" class="small mt-1 text-muted"></div>
      <div id="verdictBox" class="mt-2"></div>

      <button type="button" id="parseBtn" class="btn btn-outline-secondary btn-sm mt-2 w-100" disabled><i class="bi bi-cpu me-1"></i>3. Parse scope → isi kolom kiri</button>
      <div id="parseMsg" class="small mt-2 text-muted"></div>

      <div class="small text-muted mt-2"><i class="bi bi-info-circle me-1"></i>PDF &amp; teks dibaca otomatis; gambar di-OCR di browser (butuh internet sekali muat). Halaman H1/Bugcrowd di balik login → <b>upload screenshot</b> paling andal.</div>
    </div>
  </div>
</form>

<?= $this->endSection() ?>
<?= $this->section('page_scripts') ?>
<script src="https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/build/pdf.min.js"></script>
<script>
const $ = (s)=>document.querySelector(s);
try { if (window.pdfjsLib) pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/build/pdf.worker.min.js'; } catch(e){}

let _file=null, _scope=null, _meta=null, _canParse=false;

$('#scopeFile').addEventListener('change', e => {
  _file = e.target.files[0] || null;
  $('#fileName').textContent = _file ? _file.name : 'capture full page lalu upload';
  if (_file) $('#parseUrl').value = '';
});

async function ocrImage(src, setMsg, tag){
  if (typeof Tesseract === 'undefined') throw new Error('OCR gagal dimuat (butuh internet).');
  const { data } = await Tesseract.recognize(src, 'eng', { logger: p => { if (p.status==='recognizing text') setMsg((tag||'OCR')+' '+Math.round(p.progress*100)+'%'); } });
  return (data && data.text) ? data.text.trim() : '';
}

// OCR sebuah canvas — potong VERTIKAL bila tinggi, supaya screenshot panjang
// (halaman program full) tak terpotong & tak membebani memori. Ini kunci akurasi.
async function ocrCanvas(cv, setMsg, tag){
  const W = cv.width, H = cv.height, TILE = 3000, OVER = 140;
  if (H <= TILE + OVER) return ocrImage(cv, setMsg, tag);
  const n = Math.ceil(H / TILE); let text = '';
  for (let i=0;i<n;i++){
    const y = i*TILE, h = Math.min(TILE+OVER, H-y);
    const tc = document.createElement('canvas'); tc.width = W; tc.height = h;
    tc.getContext('2d').drawImage(cv, 0, y, W, h, 0, 0, W, h);
    text += await ocrImage(tc, setMsg, tag+' ptg '+(i+1)+'/'+n) + '\n';
  }
  return text.trim();
}

function loadImg(file){
  return new Promise((res, rej) => {
    const url = URL.createObjectURL(file); const im = new Image();
    im.onload = () => { URL.revokeObjectURL(url); res(im); };
    im.onerror = () => { URL.revokeObjectURL(url); rej(new Error('Gagal memuat gambar.')); };
    im.src = url;
  });
}

// OCR file gambar: render ke canvas (perbesar gambar kecil) lalu OCR per potongan.
// Penting untuk screenshot PANJANG (mis. halaman Bugcrowd full) agar scope tak terlewat.
async function ocrImageFile(file, setMsg, tag){
  const im = await loadImg(file);
  let scale = Math.min(2, Math.max(1, 1600/im.width));
  if (im.height*scale > 30000) scale = 30000/im.height;
  const W = Math.round(im.width*scale), Hh = Math.round(im.height*scale);
  const cv = document.createElement('canvas'); cv.width = W; cv.height = Hh;
  cv.getContext('2d').drawImage(im, 0, 0, W, Hh);
  return ocrCanvas(cv, setMsg, tag);
}

// Render satu halaman PDF ke canvas (DPI cukup tinggi) lalu OCR per potongan.
async function ocrPdfPage(pg, setMsg, tag){
  let vp = pg.getViewport({scale:1});
  let scale = Math.min(3, Math.max(1.5, 2000/vp.width));
  if (vp.height*scale > 30000) scale = 30000/vp.height; // jaga batas aman kanvas
  vp = pg.getViewport({scale: scale > 0 ? scale : 1});
  const W = Math.ceil(vp.width), H = Math.ceil(vp.height);
  const cv = document.createElement('canvas'); cv.width = W; cv.height = H;
  await pg.render({canvasContext: cv.getContext('2d'), viewport: vp}).promise;
  return ocrCanvas(cv, setMsg, tag);
}

async function extractText(file, setMsg){
  if (file.type === 'application/pdf' || /\.pdf$/i.test(file.name)) {
    if (!window.pdfjsLib) throw new Error('pdf.js gagal dimuat (butuh internet).');
    setMsg('Membaca PDF…');
    const pdf = await pdfjsLib.getDocument({data: await file.arrayBuffer()}).promise;
    let t=''; for (let i=1;i<=pdf.numPages;i++){ const pg=await pdf.getPage(i); const c=await pg.getTextContent(); t += c.items.map(x=>x.str).join(' ')+'\n'; }
    t = t.trim();
    // PDF "screen capture" = gambar tanpa lapisan teks → getTextContent kosong. OCR tiap halaman.
    if (t.replace(/\s/g,'').length < 20) {
      setMsg('PDF tanpa teks (screen-capture) — OCR tiap halaman…');
      t = '';
      for (let i=1;i<=pdf.numPages;i++){ const pg = await pdf.getPage(i); t += await ocrPdfPage(pg, setMsg, 'OCR hal '+i+'/'+pdf.numPages) + '\n'; }
      t = t.trim();
    }
    return t;
  }
  setMsg('OCR gambar… (sekali unduh model)');
  return ocrImageFile(file, setMsg, 'OCR');
}

function renderVerdict(p){
  const vb=$('#verdictBox'), ac=$('#autoChk');
  if(p.verdict==='blocked'){ ac.checked=false; _canParse=false;
    vb.innerHTML='<div class="alert alert-danger py-2 px-3 small mb-0"><b>🚫 Tidak cocok untuk auto-scan.</b> Program ini melarang automated scanner / konten AI — laporan auto-scan CASA akan ditolak. Disarankan <b>cari target lain</b>, atau hanya uji manual (Burp) lalu Import.<br><span class="text-muted">Alasan: '+(p.reasons||[]).map(x=>'"'+x+'"').join('; ')+'</span></div>';
  } else if(p.verdict==='caution'){ ac.checked=false; _canParse=true;
    vb.innerHTML='<div class="alert alert-warning py-2 px-3 small mb-0"><b>⚠️ Boleh, tapi hati-hati.</b> Ada batasan laju/DoS — auto-scan dipaksa hemat (Light, tanpa mass-scan). Hormati rate program.<br><span class="text-muted">'+(p.cautions||[]).join(' · ')+'</span></div>';
  } else { ac.checked=true; _canParse=true;
    vb.innerHTML='<div class="alert alert-success py-2 px-3 small mb-0"><b>✓ Boleh auto-scan.</b> Tak terdeteksi larangan scanner otomatis. Tetap hormati aturan &amp; verifikasi manual sebelum submit.</div>';
  }
  if (p.ai && p.ai.verdict) {
    const col = p.ai.verdict==='blocked'?'danger':(p.ai.verdict==='caution'?'warning':'success');
    vb.insertAdjacentHTML('beforeend', '<div class="small mt-1"><span class="badge text-bg-info">AI</span> nilai: <b class="text-'+col+'">'+p.ai.verdict+'</b>'+(p.ai.reason?(' — '+p.ai.reason.replace(/</g,'&lt;')):'')+' <span class="text-muted">(verdict akhir = paling ketat antara aturan &amp; AI)</span></div>');
  }
  $('#parseBtn').disabled = !_canParse;
}

$('#analyzeBtn').addEventListener('click', async ()=>{
  const b=$('#analyzeBtn'), am=$('#analyzeMsg'); const o=b.innerHTML;
  const setMsg=(t)=>{ am.className='small mt-1 text-muted'; am.textContent=t; };
  b.disabled=true; b.innerHTML='<span class="spinner-border spinner-border-sm"></span> Menganalisa…';
  try {
    // File diprioritaskan: kalau ada file, baca ISI FILE (bukan URL) supaya hasil sesuai yang di-upload.
    if (_file) {
      const t = await extractText(_file, setMsg);
      if (t) $('#parseText').value = t;
      if (!$('#parseText').value.trim()) { b.disabled=false; b.innerHTML=o; am.className='small mt-1 text-danger'; am.textContent='File tak terbaca (tak ada teks). Pakai screenshot PNG yang jelas, atau tempel teks Scope manual.'; $('#parseBtn').disabled=true; return; }
    }
    // URL selalu dikirim: dipakai untuk metadata (URL program). Scope tetap dari
    // teks file bila ada (server hanya fetch URL saat teks kosong).
    setMsg('Menganalisa scope &amp; kelayakan (aturan + AI)… bisa +30–90 dtk bila AI aktif.');
    const d = await casaPost('<?= esc(site_url('bounty/programs/parse')) ?>', { text: $('#parseText').value, url: $('#parseUrl').value });
    b.disabled=false; b.innerHTML=o;
    if(!d.ok){ am.className='small mt-1 text-danger'; am.textContent=d.error||'Gagal menganalisa.'; $('#parseBtn').disabled=true; return; }
    _scope = { in: d.in||[], out: d.out||[] };
    _meta  = d.meta || null;
    renderVerdict(d.policy || {verdict:'ok'});
    const nm = _meta && _meta.name ? ' · Program: '+_meta.name : '';
    setMsg('Terbaca '+_scope.in.length+' in-scope, '+_scope.out.length+' out-scope'+nm+'. '+(_canParse?'Klik "Parse scope" untuk isi kolom kiri.':'Auto-scan tidak disarankan untuk program ini.'));
  } catch(err){ b.disabled=false; b.innerHTML=o; am.className='small mt-1 text-danger'; am.textContent=err.message||'Gagal membaca file.'; }
});

$('#parseBtn').addEventListener('click', ()=>{
  if (!_canParse || !_scope) return;
  const m=$('#parseMsg');
  const fld=(n)=>document.querySelector('[name="'+n+'"]');
  const merge=(el,arr)=>{ if(!el)return; const ex=new Set(el.value.split('\n').map(x=>x.trim()).filter(Boolean)); (arr||[]).forEach(x=>ex.add(x)); el.value=[...ex].join('\n'); };
  const setIfEmpty=(el,v)=>{ if(el && v && !el.value.trim()) el.value=v; };
  const setSel=(el,v)=>{ if(el && v && [...el.options].some(o=>o.value===v)) el.value=v; };

  // Scope.
  merge($('#scopeIn'), _scope.in); merge($('#scopeOut'), _scope.out);

  // Metadata → kolom kiri (tak menimpa yang sudah diisi pengguna).
  let extra='';
  if (_meta){
    setIfEmpty(fld('name'), _meta.name);
    setSel(fld('platform'), _meta.platform);
    setIfEmpty(fld('program_url'), _meta.program_url);
    setIfEmpty(fld('policy_url'), _meta.policy_url);
    merge(fld('excluded_types'), _meta.excluded_types);
    merge(fld('focus_areas'), _meta.focus_areas);
    const bits=[]; if(_meta.name) bits.push('nama'); if(_meta.platform) bits.push('platform'); if(_meta.program_url) bits.push('URL');
    if((_meta.excluded_types||[]).length) bits.push((_meta.excluded_types).length+' excluded'); if((_meta.focus_areas||[]).length) bits.push((_meta.focus_areas).length+' fokus');
    if(bits.length) extra=' + '+bits.join(', ');
  }
  m.className='small mt-2 text-success'; m.textContent=_scope.in.length+' in-scope · '+_scope.out.length+' out-scope'+extra+' diisikan. Tinjau sebelum simpan.';
});

// Ringkasan program via AI (tujuan/boleh/tidak boleh/tak dibayar/uji Burp).
const _sb = $('#sumBtn');
if (_sb) _sb.addEventListener('click', async ()=>{
  const m=$('#sumMsg'), box=$('#summaryBox');
  const text=$('#parseText').value, url=$('#parseUrl').value;
  if (!text.trim() && !url.trim()) { m.className='small mt-1 text-danger'; m.textContent='Isi/tempel teks policy atau URL di panel kanan dulu (bisa dari upload gambar/PDF).'; return; }
  _sb.disabled=true; _sb.innerHTML='<span class="spinner-border spinner-border-sm"></span> Meringkas…';
  m.className='small mt-1 text-muted'; m.textContent='AI menyusun ringkasan (~15–60 detik di CPU)…';
  const d=await casaPost('<?= esc(site_url('bounty/programs/summary')) ?>', { text, url });
  _sb.disabled=false; _sb.innerHTML='<i class="bi bi-magic me-1"></i>Ringkas by AI';
  if (d.ok) { box.value=d.text; m.className='small mt-1 text-success'; m.textContent='Ringkasan AI terisi — tinjau & sunting bila perlu.'; }
  else { m.className='small mt-1 text-danger'; m.textContent=d.error||'Gagal.'; }
});

$('#pForm').addEventListener('submit', async (e)=>{
  e.preventDefault();
  const b=$('#pBtn'), m=$('#pMsg'); const o=b.innerHTML;
  b.disabled=true; b.innerHTML='<span class="spinner-border spinner-border-sm"></span> Menyimpan…';
  const d = await casaPost('<?= esc(site_url('bounty/programs')) ?>', new FormData(e.target));
  if(d.ok && d.redirect){ m.className='small mt-2 text-center text-success'; m.textContent='Tersimpan! Mengalihkan…'; location.href=d.redirect; }
  else { b.disabled=false; b.innerHTML=o; m.className='small mt-2 text-center text-danger'; m.textContent=d.error||'Gagal.'; }
});
</script>
<?= $this->endSection() ?>
