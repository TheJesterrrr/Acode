<?php /** @var array $assets @var array $programs */ ?>
<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<div class="casa-page-head">
  <div>
    <h1 class="mb-0"><i class="bi bi-broadcast-pin me-1"></i>Recon Monitor</h1>
    <div class="small text-muted">Attack surface (aset) hasil recon lintas program. Jalankan recon dari tiap Program.</div>
  </div>
</div>

<div class="row g-3">
  <div class="col-lg-4">
    <div class="casa-card p-3 p-lg-4 h-100">
      <h2 class="h6 mb-2">Program</h2>
      <?php foreach ($programs as $p): ?>
        <a href="<?= esc(site_url('bounty/programs/' . (int) $p['id'])) ?>" class="d-flex align-items-center gap-2 py-2 border-bottom text-decoration-none text-body" style="border-color:var(--casa-card-brd)!important">
          <i class="bi bi-bullseye text-bounty"></i>
          <span class="flex-grow-1 text-truncate"><?= esc($p['name']) ?></span>
          <span class="badge text-bg-dark border"><?= (int) $p['target_count'] ?> target</span>
        </a>
      <?php endforeach; ?>
      <?php if ($programs === []): ?><p class="small text-muted mb-0">Belum ada program.</p><?php endif; ?>
      <p class="small text-muted mt-2 mb-0"><i class="bi bi-info-circle me-1"></i>Buka program → <b>Mulai Bounty Scan</b> untuk recon. Aset baru muncul di sini.</p>
    </div>
  </div>
  <div class="col-lg-8">
    <div class="casa-card p-0 h-100">
      <div class="p-3 pb-0"><h2 class="h6 mb-0">Aset ditemukan (<?= count($assets) ?>)</h2></div>
      <div class="table-responsive">
        <table class="table table-sm align-middle mb-0">
          <thead><tr><th class="ps-3">Aset</th><th>Tipe</th><th>Program</th><th>Sumber</th></tr></thead>
          <tbody>
            <?php foreach ($assets as $a): ?>
              <tr>
                <td class="ps-3 font-monospace small" style="word-break:break-all"><?= esc($a['value'] ?? '') ?></td>
                <td class="small"><?= esc($a['type'] ?? '') ?></td>
                <td class="small"><?= esc($a['program'] ?? '') ?></td>
                <td class="small text-muted"><?= esc($a['source'] ?? '') ?></td>
              </tr>
            <?php endforeach; ?>
            <?php if ($assets === []): ?><tr><td colspan="4" class="text-muted small py-3 ps-3">Belum ada aset. Jalankan Bounty Scan pada sebuah program.</td></tr><?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?= $this->endSection() ?>
