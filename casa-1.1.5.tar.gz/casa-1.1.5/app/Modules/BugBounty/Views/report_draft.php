<?php /** @var array $finding @var string $platform @var string $markdown */ ?>
<?= $this->extend('layouts/member') ?>
<?= $this->section('content') ?>
<?php $fid = (int) $finding['id']; ?>
<div class="casa-page-head">
  <div>
    <a href="<?= esc(site_url('bounty/reports')) ?>" class="small text-decoration-none"><i class="bi bi-arrow-left me-1"></i>Reports</a>
    <h1 class="mb-0"><i class="bi bi-file-earmark-text me-1"></i>Draft Report</h1>
  </div>
  <div class="btn-group" role="group">
    <a href="<?= esc(site_url('bounty/reports/' . $fid . '?platform=hackerone')) ?>" class="btn btn-sm <?= $platform === 'hackerone' ? 'btn-bounty' : 'btn-outline-secondary' ?>">HackerOne</a>
    <a href="<?= esc(site_url('bounty/reports/' . $fid . '?platform=bugcrowd')) ?>" class="btn btn-sm <?= $platform === 'bugcrowd' ? 'btn-bounty' : 'btn-outline-secondary' ?>">Bugcrowd</a>
  </div>
</div>

<div class="alert alert-warning d-flex gap-2 py-2 px-3 small"><i class="bi bi-person-check mt-1"></i>
  <div>Bagian <b>Steps to Reproduce</b> &amp; <b>Proof of Concept</b> ditandai <b>ISI MANUAL</b> — tulis langkah yang Anda lakukan (Burp) + tempel request/response. Report otomatis tanpa bukti manual sering ditolak triager.</div>
</div>

<div class="casa-card p-3 p-lg-4">
  <textarea id="md" class="form-control font-monospace" rows="22" style="font-size:.85rem"><?= esc($markdown) ?></textarea>
  <div class="d-flex flex-wrap gap-2 mt-3">
    <button id="copyBtn" class="btn btn-outline-secondary btn-sm"><i class="bi bi-clipboard me-1"></i>Copy Markdown</button>
    <a href="<?= esc(site_url('bounty/reports/' . $fid . '/download?platform=' . $platform)) ?>" class="btn btn-outline-secondary btn-sm"><i class="bi bi-download me-1"></i>Download .md</a>
    <button id="subBtn" class="btn btn-bounty btn-sm ms-auto"><i class="bi bi-send me-1"></i>Save as Submission</button>
  </div>
  <div id="rMsg" class="small mt-2"></div>
</div>
<?= $this->endSection() ?>
<?= $this->section('page_scripts') ?>
<script>
const $=(s)=>document.querySelector(s);
$('#copyBtn').addEventListener('click', ()=>{ navigator.clipboard.writeText($('#md').value).then(()=>{ $('#rMsg').className='small mt-2 text-success'; $('#rMsg').textContent='Tersalin ke clipboard.'; }); });
$('#subBtn').addEventListener('click', async ()=>{
  const fd=new FormData(); fd.append('platform','<?= esc($platform) ?>');
  const d=await casaPost('<?= esc(site_url('bounty/reports/' . $fid . '/submission')) ?>', fd);
  if(d.ok && d.redirect){ location.href=d.redirect; } else { $('#rMsg').className='small mt-2 text-danger'; $('#rMsg').textContent=d.error||'Gagal.'; }
});
</script>
<?= $this->endSection() ?>
