<?php

declare(strict_types=1);

namespace App\Modules\BugBounty\Services;

/**
 * PolicyAnalyzer — baca teks policy program bug bounty lalu nilai apakah
 * pendekatan CASA (auto-scan) COCOK/legal di program itu. Banyak program
 * melarang automated scanner / high-volume scanning / konten AI → CASA tak boleh
 * dipakai di sana (laporan auto-scan ditolak). Verdict memandu go/no-go.
 */
final class PolicyAnalyzer
{
    /** Pola yang MELARANG auto-scan (blocked). */
    private const BLOCK = [
        '/\bautomated (tool|scanner)[^.]*\b(not be accepted|will not|prohibited|forbidden|reject)/i',
        '/\boutput of automated scanners?\b/i',
        '/\b(high[- ]volume|bulk) scanning\b/i',
        '/\bscanning (is|are)?\s*(prohibited|not allowed|forbidden)/i',
        '/\bno (automated|automatic) (scan|scanning|tools?)/i',
        '/\bdo not (use|run) (automated|scanner)/i',
        '/\bresults? (based )?only on automated (tool|scanner)/i',
        '/\bAI[- ]generated content\b/i',
    ];

    /** Pola HATI-HATI (caution): rate-limit/DoS/throttle + larangan laporan auto. */
    private const CAUTION = [
        '/\bthrottle\b/i',
        '/\brate[- ]?limit/i',
        '/\b(dos|ddos|denial[- ]of[- ]service)\b/i',
        '/\bexcessive request/i',
        '/\bavoid (degrading|disrupt)/i',
        '/\btesting on production\b/i',
        // Banyak program MENGIZINKAN scan tapi MENOLAK laporan mentah hasil scanner
        // / konten AI / low-effort → CASA boleh scan, tapi laporan wajib analisis manusia.
        '/\blow[- ]effort\b/i',
        '/\ba[il][- ]generated content\b/i',                 // "AI-generated" / OCR "Al-generated"
        '/\b(just )?reporting (a )?scan results?\b/i',
        '/\bscan results? of (our )?source code\b/i',
    ];

    /**
     * @return array{verdict:string, allows_automation:bool, reasons:list<string>, cautions:list<string>}
     *   verdict: 'blocked' | 'caution' | 'ok'
     */
    public static function analyze(string $text): array
    {
        if (trim($text) === '') {
            return ['verdict' => 'ok', 'allows_automation' => true, 'reasons' => [], 'cautions' => []];
        }
        $reasons  = [];
        foreach (self::BLOCK as $re) {
            if (preg_match($re, $text, $m)) {
                $reasons[] = trim(mb_substr((string) $m[0], 0, 120));
            }
        }
        $cautions = [];
        foreach (self::CAUTION as $re) {
            if (preg_match($re, $text, $m)) {
                $cautions[] = trim(mb_substr((string) $m[0], 0, 80));
            }
        }
        $reasons  = array_values(array_unique($reasons));
        $cautions = array_values(array_unique($cautions));

        if ($reasons !== []) {
            return ['verdict' => 'blocked', 'allows_automation' => false, 'reasons' => $reasons, 'cautions' => $cautions];
        }
        if ($cautions !== []) {
            return ['verdict' => 'caution', 'allows_automation' => false, 'reasons' => [], 'cautions' => $cautions];
        }

        return ['verdict' => 'ok', 'allows_automation' => true, 'reasons' => [], 'cautions' => []];
    }
}
