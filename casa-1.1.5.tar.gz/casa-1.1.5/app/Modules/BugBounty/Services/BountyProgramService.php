<?php

declare(strict_types=1);

namespace App\Modules\BugBounty\Services;

use App\Modules\BugBounty\Models\BountyProgramModel;
use App\Modules\Finding\Models\FindingModel;
use App\Modules\Finding\Services\FindingService;
use App\Modules\Licensing\Services\EditionService;
use App\Modules\Mission\Services\MissionService;
use App\Modules\Policy\Services\PolicyEngine;
use App\Modules\Project\Models\ProjectModel;
use App\Modules\Project\Models\TargetModel;
use App\Modules\Project\Services\ProjectService;
use Config\Database;
use RuntimeException;

/**
 * BountyProgramService — kelola Program bug bounty (= project mode=bounty +
 * metadata scope) dan luncurkan scan yang MENGHORMATI scope + aturan program.
 */
final class BountyProgramService
{
    public const PLATFORMS = ['hackerone' => 'HackerOne', 'bugcrowd' => 'Bugcrowd', 'other' => 'Lainnya'];

    public function __construct(
        private readonly ProjectService $projects = new ProjectService(),
        private readonly ProjectModel $projectModel = new ProjectModel(),
        private readonly TargetModel $targets = new TargetModel(),
        private readonly BountyProgramModel $programs = new BountyProgramModel(),
        private readonly PolicyEngine $policy = new PolicyEngine(),
        private readonly MissionService $missions = new MissionService(),
        private readonly FindingModel $findings = new FindingModel(),
        private readonly FindingService $findingSvc = new FindingService(),
        private readonly EditionService $edition = new EditionService(),
    ) {
    }

    /** [id => name] program bounty milik member (untuk dropdown). */
    public function programsSelect(int $customerId): array
    {
        $out = [];
        foreach ($this->projectModel->forCustomerMode($customerId, 'bounty') as $p) {
            $out[(int) $p['id']] = (string) $p['name'];
        }

        return $out;
    }

    /** Semua asset (Attack Surface) lintas program bounty milik member. */
    public function allAssets(int $customerId): array
    {
        return $this->findings->db->table('asset a')
            ->select('a.*, p.name AS program')
            ->join('project p', 'p.id = a.project_id')
            ->where('p.customer_id', $customerId)
            ->where('p.mode', 'bounty')
            ->orderBy('a.id', 'DESC')
            ->get(300)->getResultArray();
    }

    /** Semua finding lintas program bounty milik member. */
    public function allFindings(int $customerId): array
    {
        return $this->findings->db->table('finding f')
            ->select('f.*, p.name AS program')
            ->join('project p', 'p.id = f.project_id')
            ->where('p.customer_id', $customerId)
            ->where('p.mode', 'bounty')
            ->orderBy('f.id', 'DESC')
            ->get(300)->getResultArray();
    }

    /** Finding yang dimiliki member di program bounty (null bila bukan). */
    public function ownedFinding(int $findingId, int $customerId): ?array
    {
        $row = $this->findings->db->table('finding f')
            ->select('f.*, p.name AS program, p.id AS pid')
            ->join('project p', 'p.id = f.project_id')
            ->where('f.id', $findingId)
            ->where('p.customer_id', $customerId)
            ->where('p.mode', 'bounty')
            ->get()->getRowArray();

        return $row ?: null;
    }

    /** Tambah finding (manual/import) ke program bounty milik member. @return int */
    public function addFinding(int $projectId, int $customerId, array $f): int
    {
        $this->get($projectId, $customerId); // validasi kepemilikan + mode bounty

        return $this->findingSvc->record([
            'project_id'  => $projectId,
            'mission_id'  => null,
            'title'       => (string) ($f['title'] ?? 'Finding'),
            'severity'    => (string) ($f['severity'] ?? 'info'),
            'asset'       => (string) ($f['asset'] ?? ''),
            'tool'        => (string) ($f['tool'] ?? 'manual'),
            'description' => (string) ($f['description'] ?? ''),
        ]);
    }

    public function toggleExcluded(int $findingId, int $customerId): void
    {
        $f = $this->ownedFinding($findingId, $customerId);
        if ($f === null) {
            throw new RuntimeException('Finding tidak ditemukan.');
        }
        $this->findings->update($findingId, ['excluded' => (int) $f['excluded'] === 1 ? 0 : 1]);
    }

    /** Daftar program (mode=bounty) milik member + ringkasan. */
    public function list(int $customerId): array
    {
        $rows = $this->projectModel->forCustomerMode($customerId, 'bounty');
        foreach ($rows as &$p) {
            $meta           = $this->programs->forProject((int) $p['id']);
            $p['platform']  = $meta['platform'] ?? 'other';
            $p['scope_in']  = $meta ? (json_decode((string) $meta['scope_in'], true) ?: []) : [];
            $p['allows_automation'] = (int) ($meta['allows_automation'] ?? 1);
            $p['target_count']      = count($this->targets->forProject((int) $p['id']));
        }

        return $rows;
    }

    /** Program lengkap + meta + target + findings. @throws RuntimeException 404 */
    public function get(int $projectId, int $customerId): array
    {
        $project = $this->projectModel->where('id', $projectId)->where('customer_id', $customerId)->where('mode', 'bounty')->first();
        if ($project === null) {
            throw new RuntimeException('Program tidak ditemukan.');
        }
        $meta = $this->programs->forProject($projectId) ?? [];

        return [
            'project'  => $project,
            'meta'     => $meta,
            'scope_in' => json_decode((string) ($meta['scope_in'] ?? '[]'), true) ?: [],
            'scope_out' => json_decode((string) ($meta['scope_out'] ?? '[]'), true) ?: [],
            'excluded' => json_decode((string) ($meta['excluded_types'] ?? '[]'), true) ?: [],
            'targets'  => $this->targets->forProject($projectId),
            'findings' => $this->findings->where('project_id', $projectId)->orderBy('id', 'DESC')->findAll(100),
        ];
    }

    /**
     * Buat Program baru. @return int projectId @throws RuntimeException
     * @param array{name:string,platform:string,program_url:string,policy_url:string,scope_in:array,scope_out:array,excluded_types:array,focus_areas:string,allows_automation:bool} $in
     */
    public function create(int $customerId, array $in): int
    {
        $name = trim((string) ($in['name'] ?? ''));
        if ($name === '') {
            throw new RuntimeException('Nama program wajib diisi.');
        }
        $scopeIn = $this->cleanHosts($in['scope_in'] ?? []);
        if ($scopeIn === []) {
            throw new RuntimeException('Minimal satu target in-scope wajib diisi.');
        }
        $scopeOut = $this->cleanHosts($in['scope_out'] ?? []);
        $platform = isset(self::PLATFORMS[$in['platform'] ?? '']) ? $in['platform'] : 'other';

        // Project mode=bounty (kuota bounty ditegakkan di ProjectService).
        $projectId = $this->projects->createProject($customerId, [
            'name'        => $name,
            'mode'        => 'bounty',
            'platform'    => $platform,
            'program_url' => (string) ($in['program_url'] ?? ''),
        ]);

        $this->programs->insert([
            'project_id'        => $projectId,
            'platform'          => $platform,
            'program_url'       => trim((string) ($in['program_url'] ?? '')) ?: null,
            'policy_url'        => trim((string) ($in['policy_url'] ?? '')) ?: null,
            'scope_in'          => json_encode(array_values($scopeIn), JSON_UNESCAPED_SLASHES),
            'scope_out'         => json_encode(array_values($scopeOut), JSON_UNESCAPED_SLASHES),
            'excluded_types'    => json_encode(array_values($this->cleanLines($in['excluded_types'] ?? [])), JSON_UNESCAPED_SLASHES),
            'focus_areas'       => trim((string) ($in['focus_areas'] ?? '')) ?: null,
            'summary'           => trim((string) ($in['summary'] ?? '')) ?: null,
            'allows_automation' => ! empty($in['allows_automation']) ? 1 : 0,
        ]);

        // Materialkan in-scope → target (lewati yang kena scope_out).
        foreach ($scopeIn as $host) {
            if ($this->matchesAny($host, $scopeOut)) {
                continue;
            }
            [$type, $value] = $this->classify($host);
            try {
                $this->projects->addTarget($projectId, $customerId, $type, $value, 'scope');
            } catch (RuntimeException) {
                break; // kuota target tercapai
            }
        }

        // Policy default aman (gerbang wajib sebelum Mission).
        $this->policy->ensureDefault($projectId, $customerId);

        return $projectId;
    }

    public function delete(int $projectId, int $customerId): void
    {
        // Pastikan milik member & mode bounty.
        $this->get($projectId, $customerId);
        $meta = $this->programs->forProject($projectId);
        if ($meta !== null) {
            $this->programs->delete((int) $meta['id']);
        }
        $this->projects->deleteProject($projectId, $customerId);
    }

    /**
     * Luncurkan Bounty Scan terscope. @return int missionId @throws RuntimeException
     * Menghormati scope (target = in-scope saja) + `allows_automation`.
     */
    public function launchScan(int $projectId, int $customerId, string $depth = ''): int
    {
        $data = $this->get($projectId, $customerId);
        if ($data['targets'] === []) {
            throw new RuntimeException('Tak ada target in-scope untuk discan. Tambah scope dulu.');
        }
        // Batas scan harian per edisi.
        $this->edition->requireScanQuota($customerId, $this->scansToday($customerId));

        $allowsAuto = (int) ($data['meta']['allows_automation'] ?? 1) === 1;

        // Scope kapabilitas: recon aman selalu; Vulnerability Assessment (nuclei)
        // HANYA bila program mengizinkan automated scanner. Hindari lockout/ban.
        $caps = ['Subdomain Discovery', 'DNS Resolution', 'HTTP Probing', 'Port Scanning', 'Service Detection', 'Fingerprinting', 'URL Discovery', 'Web Crawling', 'Screenshotting', 'TLS/SSL Assessment'];
        if ($allowsAuto) {
            $caps[] = 'Vulnerability Assessment';
        }
        $depth = in_array($depth, ['light', 'standard', 'deep'], true) ? $depth : ($allowsAuto ? 'standard' : 'light');

        // Header kepatuhan bug bounty — WAJIB di banyak program (mis. Bugcrowd):
        // menandai traffic sebagai aktivitas researcher & menghindari IP-block.
        // X-Request-Purpose nilai tetap; username ninja opsional dari Setting owner.
        $ninja   = trim((string) (new \App\Modules\Setting\Services\SettingService())->get('bugbounty.ninja_user', ''));
        $headers = 'X-Request-Purpose: Research' . ($ninja !== '' ? "\nX-Bugcrowd-Ninja: {$ninja}" : '');

        return $this->missions->launch(
            $projectId,
            $customerId,
            'Bounty scan: ' . ($data['project']['name'] ?? ''),
            $caps,
            $depth,
            'bounty',
            $headers,
        );
    }

    /** Ambil teks policy dari URL (best-effort; program sering di balik login). */
    public function fetchPolicyText(string $url): string
    {
        $url = trim($url);
        if (! preg_match('#^https?://#i', $url)) {
            return '';
        }
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 4,
            CURLOPT_TIMEOUT        => 12,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_USERAGENT      => 'Mozilla/5.0 CASA-ScopeImport',
        ]);
        $html = (string) curl_exec($ch);
        curl_close($ch);
        if ($html === '') {
            return '';
        }
        // HTML → teks kasar.
        $html = preg_replace('#<(script|style)[^>]*>.*?</\1>#is', ' ', $html) ?? $html;
        $text = trim((string) preg_replace('/\s+\n/', "\n", strip_tags($html)));

        return mb_substr($text, 0, 20000);
    }

    /* --------------------------------------------------------------- internal */

    /** @param array<int,string> $hosts @return list<string> */
    private function cleanHosts(array $hosts): array
    {
        $out = [];
        foreach ($hosts as $h) {
            $h = strtolower(trim((string) $h));
            $h = (string) preg_replace('#/+$#', '', $h);
            if ($h !== '' && ! in_array($h, $out, true)) {
                $out[] = $h;
            }
        }

        return $out;
    }

    /** @param array<int,string> $lines @return list<string> */
    private function cleanLines(array $lines): array
    {
        $out = [];
        foreach ($lines as $l) {
            $l = trim((string) $l);
            if ($l !== '') {
                $out[] = $l;
            }
        }

        return $out;
    }

    /** @param list<string> $patterns */
    private function matchesAny(string $host, array $patterns): bool
    {
        foreach ($patterns as $p) {
            $p = strtolower(trim($p));
            if ($p === '') {
                continue;
            }
            // wildcard *.example.com → cocokkan subdomain.
            if (str_starts_with($p, '*.')) {
                $base = substr($p, 2);
                if ($host === $base || str_ends_with($host, '.' . $base)) {
                    return true;
                }
            } elseif ($host === $p || str_contains($host, $p)) {
                return true;
            }
        }

        return false;
    }

    /** @return array{0:string,1:string} [type,value] */
    private function classify(string $host): array
    {
        $host = trim($host);
        if (preg_match('#^https?://#i', $host)) {
            return ['url', $host];
        }
        if (str_contains($host, '/')) {
            return ['url', 'https://' . ltrim($host, '/')];
        }
        // wildcard → pakai base domain.
        if (str_starts_with($host, '*.')) {
            $host = substr($host, 2);
        }

        return ['domain', $host];
    }

    private function scansToday(int $customerId): int
    {
        $db = Database::connect();

        return (int) ($db->query('SELECT COUNT(*) n FROM mission WHERE customer_id=' . (int) $customerId . ' AND DATE(created_at)=CURDATE()')->getRowArray()['n'] ?? 0);
    }
}
