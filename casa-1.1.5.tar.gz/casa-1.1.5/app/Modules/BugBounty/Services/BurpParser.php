<?php

declare(strict_types=1);

namespace App\Modules\BugBounty\Services;

/**
 * BurpParser — baca export XML Burp Suite (Scanner/Target → "Report issues")
 * menjadi daftar finding ternormalisasi. Burp = kerja manual hunter; CASA hanya
 * mengimpor hasilnya, tidak menjalankan Burp.
 */
final class BurpParser
{
    private const SEV = ['critical' => 'crit', 'high' => 'high', 'medium' => 'med', 'low' => 'low', 'information' => 'info', 'info' => 'info'];

    /** @return list<array{title:string,severity:string,asset:string,description:string}> */
    public static function parse(string $xml): array
    {
        $xml = trim($xml);
        if ($xml === '') {
            return [];
        }
        $prev = libxml_use_internal_errors(true);
        $doc  = simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA | LIBXML_NONET);
        libxml_clear_errors();
        libxml_use_internal_errors($prev);
        if ($doc === false) {
            return [];
        }

        $out = [];
        foreach ($doc->issue ?? [] as $i) {
            $name = trim((string) ($i->name ?? 'Burp issue'));
            $host = trim((string) ($i->host ?? ''));
            $path = trim((string) ($i->path ?? ''));
            $sev  = self::SEV[strtolower(trim((string) ($i->severity ?? 'info')))] ?? 'info';
            $bg   = trim(strip_tags((string) ($i->issueBackground ?? '')));
            $det  = trim(strip_tags((string) ($i->issueDetail ?? '')));
            $desc = trim($det . "\n\n" . $bg);
            $out[] = [
                'title'       => mb_substr($name, 0, 200),
                'severity'    => $sev,
                'asset'       => mb_substr(($host . $path) ?: $host, 0, 255),
                'description' => mb_substr($desc !== '' ? $desc : 'Diimpor dari Burp Suite.', 0, 4000),
            ];
        }

        return $out;
    }
}
