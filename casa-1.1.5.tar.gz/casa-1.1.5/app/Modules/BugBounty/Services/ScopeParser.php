<?php

declare(strict_types=1);

namespace App\Modules\BugBounty\Services;

/**
 * ScopeParser — ekstrak scope dari teks policy (paste) atau halaman program.
 *
 * Heuristik best-effort: deteksi bagian "in scope" vs "out of scope", lalu
 * tarik domain/URL/IP dari tiap bagian. Hasil selalu bisa dikoreksi manual di
 * form (parser tak pernah jadi satu-satunya kebenaran).
 */
final class ScopeParser
{
    /**
     * Bersihkan artefak OCR yang umum SEBELUM diproses (dipakai juga oleh
     * PolicyAnalyzer & ProgramExtractor agar seragam).
     */
    public static function clean(string $text): string
    {
        $text = (string) preg_replace('/\r\n?/', "\n", $text);
        // "https: //" / "http : //" / "https ://" → skema rapi.
        $text = (string) preg_replace('#\b(https?)\s*:\s*/\s*/\s*#i', '$1://', $text);

        return $text;
    }

    /** @return array{in:list<string>, out:list<string>} */
    public static function parse(string $text): array
    {
        $text = self::clean($text);
        // Teks dari OCR/PDF sering jadi satu baris panjang (penanda + daftar host
        // menyatu). Pisahkan tiap penanda bagian ke barisnya sendiri agar host
        // SEBELUM & SESUDAH penanda jatuh ke bagian yang benar.
        $text = (string) preg_replace(
            '/(out[\s\-]?of[\s\-]?scope|excluded targets?|not in scope|in[\s\-]?scope|target information|web targets?)/i',
            "\n$0\n",
            $text,
        );
        $lines = explode("\n", $text);

        // Bagian setelah daftar target (panduan, fokus, dsb) sering menyebut host
        // di luar konteks scope — berhenti kumpulkan host begitu masuk ke sana.
        // Frasa panjang aman di mana saja; kata umum (access/credentials) HANYA
        // dianggap heading bila seluruh barisnya kata itu (biar "access token"
        // di prosa in-scope tak memutus pengumpulan).
        $stopRe    = '/\b(engagement guidelines|report guidelines|focus areas?|excluded submission|known issues?|safe harbor|leaked credentials|n-?day|things to know|what\'?s new|crowd highlights|hall of fame)\b/i';
        $stopExact = '/^(access|credentials|scope)\s*:?\s*$/i';

        $section = 'in'; // default: anggap in-scope sampai ketemu penanda out
        $in      = [];
        $out     = [];
        $seen    = false; // sudah pernah lihat penanda scope / host?
        foreach ($lines as $line) {
            $low = strtolower($line);
            // Penanda bagian.
            if (preg_match('/\bout[\s\-]?of[\s\-]?scope\b|\bexcluded targets\b|\bnot in scope\b/', $low)) {
                $section = 'out';
                $seen    = true;
                continue;
            }
            if (preg_match('/\bin[\s\-]?scope\b|\bscope\b.*\btargets?\b|\btarget information\b|\bweb targets?\b/', $low)) {
                $section = 'in';
                $seen    = true;
                continue;
            }
            // Keluar dari wilayah target → stop (hanya kalau sudah masuk scope).
            if ($seen && (preg_match($stopRe, $low) || preg_match($stopExact, trim($low)))) {
                break;
            }
            $hosts = self::extractHosts($line);
            if ($hosts !== []) {
                $seen = true;
            }
            foreach ($hosts as $h) {
                if ($section === 'out') {
                    $out[] = $h;
                } else {
                    $in[] = $h;
                }
            }
        }

        $inU  = self::uniq($in);
        $outU = self::uniq($out);
        // Frekuensi domain-terdaftar (dua label terakhir) di SELURUH hasil — dipakai
        // untuk memilih varian OCR yang benar (mis. launchdarkly.com >> launchdazkly.com).
        $freq = [];
        foreach (array_merge($inU, $outU) as $h) {
            $r = self::regDomain($h);
            $freq[$r] = ($freq[$r] ?? 0) + 1;
        }
        $out = self::dedupeOcr($outU, $freq);
        // Host yang eksplisit OUT menang: jangan biarkan tetap ada di IN (mis.
        // launchdarkly.com OUT, tapi launchdarkly.com/docs IN → host sama).
        $in = array_values(array_diff(self::dedupeOcr($inU, $freq), $out));

        return ['in' => $in, 'out' => $out];
    }

    /**
     * Rapatkan spasi di sekitar titik pada baris PENDEK (daftar target), mis.
     * "events. launchdarkly. com" → "events.launchdarkly.com". Hanya baris pendek
     * agar prosa ("...in production. Ratings") tak ikut jadi host palsu.
     */
    private static function despaceShortLine(string $line): string
    {
        $t = trim($line);
        // Buang penanda bullet/ikon di depan (@, •, «, -, +, *, ©, ®, ●, dsb).
        $t = (string) preg_replace('/^[\s@«•·\-\+\*\x{00a9}\x{00ae}\x{25cf}\x{2022}>]+/u', '', $t);
        if (mb_strlen($t) > 90) {
            return $line; // baris panjang = kemungkinan prosa, jangan diutak-atik
        }
        // Rapatkan spasi di sekitar titik: "events. launchdarkly. com" → "events.launchdarkly.com".
        $t = (string) preg_replace('/\s*\.\s*/', '.', $t);
        // Satukan kata TLD yang terpisah SPASI dari host berdot (titik hilang di OCR):
        // "app.launchdarkly con" → "app.launchdarkly.con".
        $t = (string) preg_replace('/\b([a-z0-9-]+(?:\.[a-z0-9-]+)+)\s+(com|con|cor|corn|net|nel|org)\b/i', '$1.$2', $t);
        // Betulkan TLD yang umum salah-baca OCR (m→n, dll). Hanya di baris pendek
        // (daftar target) agar prosa tak terdampak.
        $t = (string) preg_replace('/\.(con|cor|corn|cont|comn|cornm|cam|coin|ccm)\b/i', '.com', $t);
        $t = (string) preg_replace('/\.(nel|ne1|nez)\b/i', '.net', $t);
        $t = (string) preg_replace('/\.(o1g|orq)\b/i', '.org', $t);

        return $t;
    }

    /** Tarik host/URL/wildcard dari satu baris. @return list<string> */
    private static function extractHosts(string $line): array
    {
        $line = self::despaceShortLine($line);
        $out  = [];
        // URL → ambil HOST saja (buang skema + path) agar tak ada duplikat www vs https.
        if (preg_match_all('#https?://[^\s,"\'<>)\]]+#i', $line, $m)) {
            foreach ($m[0] as $u) {
                $h = (string) parse_url(rtrim($u, '/.,'), PHP_URL_HOST);
                if ($h !== '' && self::okHost($h)) {
                    $out[] = strtolower($h);
                }
            }
        }
        // Domain / wildcard (mis. *.example.com, api.example.com) tanpa skema.
        if (preg_match_all('#(?<![\w./@-])(\*\.)?(?:[a-z0-9-]+\.)+[a-z]{2,}#i', $line, $m2)) {
            foreach ($m2[0] as $d) {
                $d = strtolower(rtrim($d, '.'));
                if (self::okHost($d)) {
                    $out[] = $d;
                }
            }
        }
        // IP / CIDR.
        if (preg_match_all('#(?<![\w.])\d{1,3}(?:\.\d{1,3}){3}(?:/\d{1,2})?#', $line, $m3)) {
            foreach ($m3[0] as $ip) {
                $out[] = $ip;
            }
        }

        return $out;
    }

    /** TLD umum — tolak false-positive dari prosa (mis. "hand-over.handle"). */
    private const TLD = ['com', 'net', 'org', 'io', 'co', 'dev', 'app', 'web', 'id', 'me', 'ai', 'gov', 'edu', 'info', 'biz', 'xyz', 'tech', 'cloud', 'site', 'online', 'store', 'eu', 'us', 'uk', 'de', 'fr', 'nl', 'es', 'it', 'pl', 'se', 'no', 'fi', 'dk', 'ch', 'at', 'be', 'ca', 'au', 'jp', 'cn', 'in', 'br', 'ru', 'sg', 'hk', 'kr', 'tr', 'ua', 'cz', 'pt', 'gr', 'ie', 'ro', 'lt', 'lv', 'ee', 'sk', 'si', 'hu', 'bg', 'hr'];

    /** Host jelas BUKAN target (store/platform/third-party). */
    private const BLOCK_HOST = ['apps.apple.com', 'itunes.apple.com', 'play.google.com', 'bugcrowd.com', 'www.bugcrowd.com', 'bugcrowdninja.com', 'hackerone.com', 'github.com', 'gitlab.com', 'google.com', 'gstatic.com', 'cloudflare.com', 'freshdesk.com'];

    private static function okHost(string $h): bool
    {
        $h    = ltrim(strtolower($h), '.');
        $bare = str_starts_with($h, '*.') ? substr($h, 2) : $h;
        if ($bare === '' || in_array($bare, self::BLOCK_HOST, true) || self::looksLikeFile($bare)) {
            return false;
        }
        $pos = strrpos($bare, '.');

        return $pos !== false && in_array(substr($bare, $pos + 1), self::TLD, true);
    }

    private static function looksLikeFile(string $d): bool
    {
        return (bool) preg_match('/\.(png|jpg|jpeg|gif|svg|css|js|pdf|md|txt|json|xml|yml|yaml)$/i', $d);
    }

    /**
     * Validasi & normalisasi daftar host dari sumber luar (mis. hasil AI): buang
     * skema/path/spasi, loloskan hanya yang valid (okHost). Mencegah sampah AI.
     *
     * @param list<string> $hosts @return list<string>
     */
    public static function keepValidHosts(array $hosts): array
    {
        $ok = [];
        foreach ($hosts as $h) {
            $h = strtolower(trim((string) $h));
            $h = (string) preg_replace('#^[a-z]+://#', '', $h); // buang skema
            $h = (string) preg_replace('#[/?].*$#', '', $h);    // buang path/query
            $h = (string) preg_replace('/\s+/', '', $h);
            $isIp = (bool) preg_match('#^\d{1,3}(\.\d{1,3}){3}$#', $h);
            // Format host wajar: opsional "*." di DEPAN, lalu label.label.tld.
            // Menolak sampah spt "zendeskai*.zendesk.com" (bintang di tengah).
            $validFmt = (bool) preg_match('/^(\*\.)?([a-z0-9]([a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,}$/', $h);
            if ($h !== '' && (($validFmt && self::okHost($h)) || $isIp)) {
                $ok[] = $h;
            }
        }

        return self::uniq($ok);
    }

    /** @param list<string> $a @return list<string> */
    private static function uniq(array $a): array
    {
        return array_values(array_unique(array_filter($a, static fn ($x): bool => $x !== '')));
    }

    /** Domain terdaftar sederhana: dua label terakhir (abaikan wildcard). */
    private static function regDomain(string $h): string
    {
        $h    = str_starts_with($h, '*.') ? substr($h, 2) : $h;
        $p    = explode('.', $h);
        $n    = count($p);

        return $n >= 2 ? $p[$n - 2] . '.' . $p[$n - 1] : $h;
    }

    /**
     * Buang kembaran-OCR: bila dua host hanya beda 1 karakter (mis.
     * "app.launchdazkly.com" vs "app.launchdarkly.com"), buang yang domain
     * terdaftarnya LEBIH JARANG muncul — itu hampir pasti salah-baca. Seri →
     * buang yang mengandung angka nempel huruf (artefak OCR). Host tanpa
     * kembaran dibiarkan (biar pengguna yang koreksi).
     *
     * @param list<string>        $hosts
     * @param array<string,int>   $freq  frekuensi domain-terdaftar di semua hasil
     * @return list<string>
     */
    private static function dedupeOcr(array $hosts, array $freq): array
    {
        $res = [];
        foreach ($hosts as $h) {
            $drop = false;
            foreach ($hosts as $h2) {
                if ($h2 === $h || levenshtein($h, $h2) > 1) {
                    continue;
                }
                $fa = $freq[self::regDomain($h)] ?? 0;
                $fb = $freq[self::regDomain($h2)] ?? 0;
                if ($fa < $fb) {
                    $drop = true;
                    break;
                }
                if ($fa === $fb && preg_match('/[a-z]\d|\d[a-z]/', $h) && ! preg_match('/[a-z]\d|\d[a-z]/', $h2)) {
                    $drop = true;
                    break;
                }
            }
            if (! $drop) {
                $res[] = $h;
            }
        }

        return array_values($res);
    }
}
