<?php

declare(strict_types=1);

namespace App\Modules\BugBounty\Services;

/**
 * BountyReportService — susun DRAFT report siap-submit (HackerOne / Bugcrowd).
 *
 * Prinsip: CASA hanya pra-isi kerangka + boilerplate; bagian bukti (Steps & PoC)
 * SENGAJA ditandai "ISI MANUAL" agar report mencerminkan verifikasi manusia
 * (Burp), bukan output otomatis. Tiap tipe vuln diberi checklist verifikasi.
 */
final class BountyReportService
{
    /** Checklist verifikasi manual per pola tipe vuln (kata kunci → langkah). */
    private const CHECKLIST = [
        'idor'     => ["Login 2 akun (A & B).", "Tangkap request objek milik A di Burp.", "Kirim ke Repeater, ganti id objek → milik B, Forward.", "Response mengembalikan data B → IDOR terkonfirmasi."],
        'bola'     => ["Login 2 akun (A & B).", "Tangkap request objek milik A di Burp.", "Repeater: ganti id objek → milik B, Forward.", "Response data B → BOLA terkonfirmasi."],
        'xss'      => ["Suntik payload pada parameter/sink.", "Konfirmasi eksekusi di browser (alert/DOM).", "Screenshot bukti + catat context & sink."],
        'sql'      => ["Buktikan via Burp (error / boolean / time-based).", "Jangan dump data sensitif — cukup bukti injeksi.", "Catat parameter & teknik."],
        'ssrf'     => ["Pakai interactsh / Burp Collaborator.", "Tunjukkan callback OOB dari server target.", "Catat endpoint & parameter."],
        'auth'     => ["Reproduksi langkah login/sesi di Burp.", "Tunjukkan bypass/takeover konkret.", "Catat kondisi & dampak."],
        'redirect' => ["Tunjukkan request + Location header.", "Buktikan redirect ke domain attacker.", "Catat parameter rentan."],
        'cors'     => ["Tunjukkan request Origin attacker + response header.", "Buktikan kredensial terbaca lintas-origin."],
        'takeover' => ["Tunjukkan CNAME/record menggantung.", "Buktikan klaim resource (sesuai aturan program)."],
    ];

    /** @param array<string,mixed> $f finding  @param array<string,mixed> $program */
    public function draft(array $f, string $platform, array $program = []): string
    {
        $platform = in_array($platform, ['hackerone', 'bugcrowd'], true) ? $platform : 'hackerone';
        $title    = (string) ($f['title'] ?? 'Kerentanan');
        $asset    = (string) ($f['asset'] ?? '-');
        $cwe      = (string) ($f['cwe'] ?? '');
        $desc     = trim((string) ($f['description'] ?? ''));
        $rem      = trim((string) ($f['remediation'] ?? ''));
        $sevLine  = $platform === 'bugcrowd'
            ? 'VRT / Priority: ' . (($f['vrt'] ?? '') ?: '_P? — tentukan via VRT_')
            : 'CVSS 3.1: ' . (($f['cvss'] ?? '') ?: '_tentukan skor_') . ($cwe ? "  ·  CWE: {$cwe}" : '');

        $checklist = $this->checklistFor($title . ' ' . (string) ($f['category'] ?? ''));

        $md  = "# {$title}\n\n";
        $md .= '**Platform:** ' . ($platform === 'bugcrowd' ? 'Bugcrowd' : 'HackerOne');
        if (! empty($program['name'])) {
            $md .= '  ·  **Program:** ' . $program['name'];
        }
        $md .= "\n**Severity:** {$sevLine}\n\n";
        $md .= "## Summary\n" . ($desc !== '' ? $desc : '_Jelaskan kerentanan & dampak bisnis singkat._') . "\n\n";
        $md .= "## Affected Asset\n`{$asset}`\n\n";
        $md .= "## Steps to Reproduce\n> ⚠️ ISI MANUAL — tulis langkah yang ANDA lakukan (verifikasi di Burp), bukan output tool.\n";
        foreach ($checklist as $i => $step) {
            $md .= ($i + 1) . '. ' . $step . "\n";
        }
        $md .= "\n## Proof of Concept\n> ⚠️ ISI MANUAL — tempel HTTP request/response dari Burp Repeater + screenshot.\n\n```http\n# contoh:\nGET /api/orders/124 HTTP/1.1\nHost: target.com\nCookie: session=<user A>\n```\n\n";
        $md .= "## Impact\n_Apa yang didapat attacker secara konkret (data/akses/dana)._\n\n";
        $md .= "## Remediation\n" . ($rem !== '' ? $rem : '_Rekomendasi perbaikan._') . "\n\n";
        $md .= "## References\n" . ($cwe ? "- CWE: {$cwe}\n" : '') . "- OWASP Top-10 / WSTG terkait\n";

        return $md;
    }

    /** @return list<string> */
    private function checklistFor(string $hay): array
    {
        $low = strtolower($hay);
        foreach (self::CHECKLIST as $key => $steps) {
            if (str_contains($low, $key)) {
                return $steps;
            }
        }

        return [
            'Reproduksi kerentanan langkah demi langkah di Burp.',
            'Tangkap request/response yang membuktikan isu.',
            'Catat kondisi/prasyarat agar triager bisa mengulang.',
        ];
    }
}
