<?php

declare(strict_types=1);

namespace App\Modules\BugBounty\Services;

/**
 * ProgramExtractor — tarik METADATA program (nama, platform, URL, excluded
 * types, focus areas) dari teks policy/halaman program. Dipakai tombol "Parse
 * scope" agar seluruh kolom kiri terisi, bukan cuma scope. Best-effort: hasil
 * selalu bisa dikoreksi manual sebelum simpan.
 */
final class ProgramExtractor
{
    /**
     * @return array{name:string, platform:string, program_url:string, policy_url:string, excluded_types:list<string>, focus_areas:list<string>}
     */
    public static function extract(string $text, string $url = ''): array
    {
        $text  = ScopeParser::clean($text);
        $lines = explode("\n", $text);

        return [
            'name'           => self::name($text),
            'platform'       => self::platform($text, $url),
            'program_url'    => self::programUrl($text, $url),
            'policy_url'     => self::programUrl($text, $url), // halaman engagement = policy
            'excluded_types' => self::bulletsUnder($lines, '/\b(excluded submission types?|known issues?|will not be eligible|not be eligible for bounties)\b/i', 40),
            'focus_areas'    => self::bulletsUnder($lines, '/\bfocus areas?\b/i', 20),
        ];
    }

    private static function name(string $text): string
    {
        $pats = [
            '/engagements?\s*[>\x{203a}\x{00bb}\x{2192}\-:]\s*(.+?)\s+(?:managed\s+)?(?:bug\s*bounty|vulnerability\s+disclosure|vdp|security\s+program)/iu',
            '/^\s*(.+?)\s+(?:managed\s+)?bug\s*bounty\s+engagement/mi',
            '/^\s*(.+?)\s+bug\s*bounty\b/mi',
        ];
        foreach ($pats as $re) {
            if (preg_match($re, $text, $m)) {
                $n = self::tidyName((string) $m[1]);
                if ($n !== '') {
                    return $n;
                }
            }
        }

        return '';
    }

    private static function tidyName(string $n): string
    {
        $n = trim((string) preg_replace('/\s+/', ' ', $n));
        // Buang kata navigasi yang sering ikut OCR di depan.
        $n = (string) preg_replace('/^(dashboard|engagements?|invites|work|leaderboard|crowdstream|bug bounty|@|\W)+\s+/i', '', $n);
        // Ambil maksimal 5 kata terakhir yang masuk akal sebagai nama.
        $n = trim($n, " \t\x{00a0}-–—>:·@®©");
        if (mb_strlen($n) > 60) {
            $n = mb_substr($n, 0, 60);
        }

        return $n;
    }

    private static function platform(string $text, string $url): string
    {
        $hay = strtolower($text . ' ' . $url);
        if (str_contains($hay, 'bugcrowd')) {
            return 'bugcrowd';
        }
        if (str_contains($hay, 'hackerone') || preg_match('/\bh1\b/', $hay) || str_contains($hay, 'hacker one')) {
            return 'hackerone';
        }
        // Platform lain (intigriti, yeswehack, dsb) → "other" (opsi yang tersedia).
        if (preg_match('/\b(intigriti|yeswehack|yes we hack|hackenproof|immunefi)\b/i', $hay)) {
            return 'other';
        }

        return '';
    }

    private static function programUrl(string $text, string $url): string
    {
        $url = trim($url);
        if ($url !== '' && preg_match('#^https?://#i', $url)) {
            return rtrim($url, '/.,');
        }
        // Cari URL engagement/program di teks.
        if (preg_match('#https?://(?:www\.)?(?:bugcrowd\.com|hackerone\.com|app\.intigriti\.com|intigriti\.com|yeswehack\.com)/[^\s,"\'<>)\]]+#i', $text, $m)) {
            return rtrim($m[0], '/.,');
        }

        return '';
    }

    /**
     * Kumpulkan butir daftar di bawah sebuah heading sampai heading besar
     * berikutnya. Buang penanda bullet, rapikan, batasi jumlah & panjang.
     *
     * @param list<string> $lines @return list<string>
     */
    private static function bulletsUnder(array $lines, string $startRe, int $max): array
    {
        // Heading besar lain = batas berhenti (frasa panjang aman di mana saja).
        $stopRe = '/\b(safe harbor|report guidelines|engagement guidelines|excluded submission types?|known issues?|leaked credentials|n-?day|things to know|what\'?s new|crowd highlights|hall of fame|ratings?\/rewards?|target overview|in scope|out of scope)\b/i';
        // Heading satu-kata hanya berlaku bila SELURUH barisnya kata itu
        // (biar "access control" di tengah butir tak memutus).
        $stopExact = '/^(access|credentials|scope)\s*:?\s*$/i';

        $res     = [];
        $started = false;
        foreach ($lines as $line) {
            $t = trim($line);
            if ($t === '') {
                continue;
            }
            if (! $started) {
                if (preg_match($startRe, $t)) {
                    $started = true;
                }
                continue;
            }
            // Baris yang sendirinya heading start (mis. "Excluded Submission Types")
            // = judul, bukan butir — lewati, jangan berhenti.
            if (preg_match($startRe, $t)) {
                continue;
            }
            // Sudah mulai: berhenti bila ketemu heading besar lain.
            if (preg_match($stopRe, $t) || preg_match($stopExact, $t)) {
                break;
            }
            // Ambil baris butir: diawali bullet, atau kalimat pendek wajar.
            $item = (string) preg_replace('/^[\s@«•·\x{2022}\x{2013}\x{2014}\-\+\*>]+/u', '', $t);
            $item = trim($item, " \t.;,");
            if ($item === '' || mb_strlen($item) < 3) {
                continue;
            }
            if (mb_strlen($item) > 120) {
                $item = rtrim(mb_substr($item, 0, 120)) . '…';
            }
            $res[] = $item;
            if (count($res) >= $max) {
                break;
            }
        }

        return array_values(array_unique($res));
    }
}
