<?php

declare(strict_types=1);

namespace App\Modules\BugBounty\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\RedirectResponse;

/**
 * ModeController — mengganti mode portal (pentest | bounty). Mode disimpan di
 * session dan menentukan sidebar + dashboard yang tampil. Hanya relevan di
 * instance produk (bukan console owner/hub billing).
 */
final class ModeController extends BaseController
{
    public function set(string $mode): RedirectResponse
    {
        // Portal terpadu instance saja; di hub (owner console) mode tak berlaku.
        if ($this->isOwnerConsole()) {
            return redirect()->to(site_url('member'));
        }

        $mode = $mode === 'bounty' ? 'bounty' : 'pentest';
        $this->session->set('scan_mode', $mode);

        return redirect()->to(site_url($mode === 'bounty' ? 'bounty' : 'member'));
    }
}
