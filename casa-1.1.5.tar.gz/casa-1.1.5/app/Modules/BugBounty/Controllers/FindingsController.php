<?php

declare(strict_types=1);

namespace App\Modules\BugBounty\Controllers;

use App\Controllers\BaseController;
use App\Modules\BugBounty\Services\BountyProgramService;
use CodeIgniter\Exceptions\PageNotFoundException;
use CodeIgniter\HTTP\ResponseInterface;
use RuntimeException;

/** FindingsController — daftar finding bounty + tandai excluded (known-issue). */
final class FindingsController extends BaseController
{
    public function __construct(private readonly BountyProgramService $svc = new BountyProgramService())
    {
    }

    private function guard(): void
    {
        if ($this->isOwnerConsole()) {
            throw PageNotFoundException::forPageNotFound();
        }
        $this->session->set('scan_mode', 'bounty');
    }

    public function index(): string
    {
        $this->guard();

        return $this->memberView('App\Modules\BugBounty\Views\findings', [
            'title'    => 'Findings',
            'findings' => $this->svc->allFindings((int) $this->session->get('member_id')),
        ], 'bb_findings');
    }

    public function toggle(int $id): ResponseInterface
    {
        $this->guard();
        if ($r = $this->denyViewer()) {
            return $r;
        }
        try {
            $this->svc->toggleExcluded($id, (int) $this->session->get('member_id'));
        } catch (RuntimeException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok([]);
    }
}
