<?php

declare(strict_types=1);

namespace App\Modules\BugBounty\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\Exceptions\PageNotFoundException;

/**
 * BountyDashboardController — dasbor mode Bug Bounty (member instance).
 * Fase 1: kerangka + ringkasan. Programs/Submissions/Reports menyusul (Fase 2+).
 */
final class BountyDashboardController extends BaseController
{
    public function index(): string
    {
        if ($this->isOwnerConsole()) {
            throw PageNotFoundException::forPageNotFound();
        }
        // Pastikan mode aktif = bounty saat membuka dasbor ini.
        $this->session->set('scan_mode', 'bounty');

        $customerId = (int) $this->session->get('member_id');

        return $this->memberView('App\Modules\BugBounty\Views\dashboard', [
            'title' => 'Dashboard',
            'stats' => [
                'programs'    => 0, // Fase 2
                'submissions' => 0, // Fase 4
                'accepted'    => 0,
                'bounty'      => 0,
            ],
        ], 'bb_dashboard');
    }
}
