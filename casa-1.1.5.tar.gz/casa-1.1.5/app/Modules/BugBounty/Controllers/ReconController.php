<?php

declare(strict_types=1);

namespace App\Modules\BugBounty\Controllers;

use App\Controllers\BaseController;
use App\Modules\BugBounty\Services\BountyProgramService;
use CodeIgniter\Exceptions\PageNotFoundException;

/** ReconController — Recon Monitor: attack surface lintas program bounty. */
final class ReconController extends BaseController
{
    public function __construct(private readonly BountyProgramService $svc = new BountyProgramService())
    {
    }

    public function index(): string
    {
        if ($this->isOwnerConsole()) {
            throw PageNotFoundException::forPageNotFound();
        }
        $this->session->set('scan_mode', 'bounty');
        $cid = (int) $this->session->get('member_id');

        return $this->memberView('App\Modules\BugBounty\Views\recon', [
            'title'    => 'Recon Monitor',
            'assets'   => $this->svc->allAssets($cid),
            'programs' => $this->svc->list($cid),
        ], 'bb_recon');
    }
}
