<?php

declare(strict_types=1);

namespace App\Modules\BugBounty\Controllers;

use App\Controllers\BaseController;
use App\Modules\BugBounty\Services\BountyProgramService;
use App\Modules\BugBounty\Services\PolicyAnalyzer;
use App\Modules\BugBounty\Services\ProgramExtractor;
use App\Modules\BugBounty\Services\ScopeParser;
use CodeIgniter\Exceptions\PageNotFoundException;
use CodeIgniter\HTTP\ResponseInterface;
use RuntimeException;

/** ProgramController — CRUD Program bug bounty + luncurkan Bounty Scan (member). */
final class ProgramController extends BaseController
{
    public function __construct(
        private readonly BountyProgramService $svc = new BountyProgramService(),
        private readonly \App\Modules\Ai\Services\AiManager $ai = new \App\Modules\Ai\Services\AiManager(),
    ) {
    }

    private function guard(): void
    {
        if ($this->isOwnerConsole()) {
            throw PageNotFoundException::forPageNotFound();
        }
        $this->session->set('scan_mode', 'bounty');
    }

    private function me(): int
    {
        return (int) $this->session->get('member_id');
    }

    public function index(): string
    {
        $this->guard();

        return $this->memberView('App\Modules\BugBounty\Views\programs\index', [
            'title'    => 'Programs',
            'programs' => $this->svc->list($this->me()),
        ], 'bb_programs');
    }

    public function newForm(): string
    {
        $this->guard();

        return $this->memberView('App\Modules\BugBounty\Views\programs\form', [
            'title'     => 'Program Baru',
            'platforms' => BountyProgramService::PLATFORMS,
            'aiOn'      => $this->ai->readyForRole('security_advisor'),
        ], 'bb_programs');
    }

    public function create(): ResponseInterface
    {
        $this->guard();
        if ($r = $this->denyViewer()) {
            return $r;
        }
        $req = $this->request;
        try {
            $pid = $this->svc->create($this->me(), [
                'name'              => (string) $req->getPost('name'),
                'platform'          => (string) $req->getPost('platform'),
                'program_url'       => (string) $req->getPost('program_url'),
                'policy_url'        => (string) $req->getPost('policy_url'),
                'scope_in'          => $this->lines((string) $req->getPost('scope_in')),
                'scope_out'         => $this->lines((string) $req->getPost('scope_out')),
                'excluded_types'    => $this->lines((string) $req->getPost('excluded_types')),
                'focus_areas'       => (string) $req->getPost('focus_areas'),
                'summary'           => (string) $req->getPost('summary'),
                'allows_automation' => $req->getPost('allows_automation') ? true : false,
            ]);
        } catch (RuntimeException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok(['redirect' => site_url('bounty/programs/' . $pid)]);
    }

    public function show(int $id): string
    {
        $this->guard();
        try {
            $data = $this->svc->get($id, $this->me());
        } catch (RuntimeException) {
            throw PageNotFoundException::forPageNotFound();
        }

        return $this->memberView('App\Modules\BugBounty\Views\programs\show', [
            'title' => $data['project']['name'] ?? 'Program',
            'data'  => $data,
        ], 'bb_programs');
    }

    public function scan(int $id): ResponseInterface
    {
        $this->guard();
        if ($r = $this->denyViewer()) {
            return $r;
        }
        try {
            $mid = $this->svc->launchScan($id, $this->me(), (string) $this->request->getPost('depth'));
        } catch (RuntimeException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok(['redirect' => site_url('missions/' . $mid)]);
    }

    public function delete(int $id): ResponseInterface
    {
        $this->guard();
        if ($r = $this->requireOwnerRole()) {
            return $r;
        }
        try {
            $this->svc->delete($id, $this->me());
        } catch (RuntimeException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok(['redirect' => site_url('bounty/programs')]);
    }

    /** AJAX: parse scope dari teks policy / URL → {in:[],out:[]}. */
    public function parse(): ResponseInterface
    {
        $this->guard();
        $text = (string) $this->request->getPost('text');
        $url  = (string) $this->request->getPost('url');
        if ($text === '' && $url !== '') {
            $text = $this->svc->fetchPolicyText($url);
            if ($text === '') {
                return $this->fail('Gagal mengambil halaman program (mungkin perlu login). Salin-tempel teks policy saja.');
            }
        }
        if (trim($text) === '') {
            return $this->fail('Tempel teks policy atau isi URL program.');
        }
        $scope  = ScopeParser::parse($text);
        $policy = PolicyAnalyzer::analyze($text);
        // Lapis kedua AI (bila konek): ekstrak scope TAMBAHAN (supaya tak ada
        // in-scope yang terlewat regex) + nilai ulang kelayakan auto-scan.
        if ($this->ai->readyForRole('rule_parser')) {
            $ai = $this->aiAnalyze($text);
            if ($ai !== null) {
                $aiIn  = ScopeParser::keepValidHosts($ai['in']);
                $aiOut = ScopeParser::keepValidHosts($ai['out']);
                // Model kecil kadang menaruh host yang sama di KEDUA sisi → buang
                // dari out agar tak menghapus in-scope saat digabung.
                $aiOut        = array_values(array_diff($aiOut, $aiIn));
                $scope['out'] = ScopeParser::keepValidHosts(array_merge($scope['out'], $aiOut));
                $scope['in']  = array_values(array_diff(
                    ScopeParser::keepValidHosts(array_merge($scope['in'], $aiIn)),
                    $scope['out'],
                ));
                $policy = $this->mergeVerdict($policy, ['verdict' => $ai['verdict'], 'reason' => $ai['reason']]);
            }
        }
        $meta = ProgramExtractor::extract($text, $url);

        return $this->ok([
            'in'     => $scope['in'],
            'out'    => $scope['out'],
            'policy' => $policy,
            'meta'   => $meta,
        ]);
    }

    /** AJAX: ringkasan program via AI (tujuan/boleh/tidak boleh/tak dibayar/uji Burp). */
    public function aiSummary(): ResponseInterface
    {
        $this->guard();
        $text = trim((string) $this->request->getPost('text'));
        $url  = (string) $this->request->getPost('url');
        if ($text === '' && $url !== '') {
            $text = $this->svc->fetchPolicyText($url);
        }
        if (trim($text) === '') {
            return $this->fail('Tempel teks policy atau isi URL program dulu.');
        }
        $sys = "You are a bug-bounty triage advisor. Read the program policy and write a SHORT summary in Bahasa Indonesia "
            . "with EXACTLY these labeled lines (each 1-2 short lines, keep it tight):\n"
            . "Tujuan: <inti program & aset/target yang diuji>\n"
            . "Boleh: <jenis pengujian yang diizinkan>\n"
            . "Tidak boleh: <yang dilarang, mis. DoS, social engineering, auto-scan bila dilarang>\n"
            . "Tidak dibayar: <temuan out-of-scope / known-issue yang tak diberi reward>\n"
            . "Uji pakai Burp?: <Ya/Tidak> — <1 kalimat: apakah target realistis diuji manual dengan Burp Suite>\n"
            . "No preamble, no markdown headings.";
        try {
            $out = trim($this->ai->chatForRole('security_advisor', $sys, mb_substr($text, 0, 4000)));
        } catch (\Throwable $e) {
            return $this->fail('AI gagal: ' . $e->getMessage());
        }
        if ($out === '') {
            return $this->fail('AI tidak mengembalikan ringkasan. Coba lagi.');
        }

        return $this->ok(['text' => $out]);
    }

    /**
     * Analisa AI 1-panggilan: ekstrak scope in/out + nilai kelayakan auto-scan.
     *
     * @return array{in:list<string>,out:list<string>,verdict:string,reason:string}|null
     */
    private function aiAnalyze(string $text): ?array
    {
        $sys = 'You analyze a bug bounty program policy. Answer STRICT JSON ONLY: '
            . '{"in":["host"],"out":["host"],"verdict":"ok|caution|blocked","reason":"<=120 chars"}. '
            . '1) in/out = IN-SCOPE and OUT-OF-SCOPE targets ONLY: web domains, subdomains, wildcards like *.example.com, or IPs. '
            . 'Exclude app-store links, source-code repos (github/gitlab), and the bug-bounty platform itself (bugcrowd/hackerone). '
            . 'Be THOROUGH on in-scope: include EVERY listed in-scope target host, do not miss any. Use the exact host strings. '
            . 'CRITICAL: "in" and "out" MUST be DISJOINT — each host belongs to EXACTLY ONE list, never both. If unsure, put it in "in". '
            . 'Each host must be a CLEAN domain only (e.g. "*.zendesk.com", "app.zendesk.com") — never glue the target name or label onto it. '
            . '2) verdict for running an AUTOMATED vulnerability scanner: '
            . 'blocked = policy forbids automated scanners / high-volume scanning / scanner output / AI-generated reports; '
            . 'caution = allowed but with rate-limit/DoS/production constraints; ok = no restriction.';
        try {
            $raw = $this->ai->chatForRole('rule_parser', $sys, mb_substr($text, 0, 12000));
            if (preg_match('/\{.*\}/s', $raw, $m)) {
                $j = json_decode($m[0], true);
                if (is_array($j)) {
                    return [
                        'in'      => is_array($j['in'] ?? null) ? array_map('strval', $j['in']) : [],
                        'out'     => is_array($j['out'] ?? null) ? array_map('strval', $j['out']) : [],
                        'verdict' => in_array($j['verdict'] ?? '', ['ok', 'caution', 'blocked'], true) ? (string) $j['verdict'] : 'ok',
                        'reason'  => mb_substr((string) ($j['reason'] ?? ''), 0, 160),
                    ];
                }
            }
        } catch (\Throwable $e) {
            // AI gagal → abaikan, pakai hasil regex saja.
        }

        return null;
    }

    /**
     * Gabung verdict regex & AI secara konservatif (ambil yang lebih ketat).
     *
     * @param array{verdict:string,reasons:list<string>,cautions:list<string>,allows_automation:bool} $regex
     * @param array{verdict:string,reason:string}                                                      $ai
     */
    private function mergeVerdict(array $regex, array $ai): array
    {
        $rank  = ['ok' => 0, 'caution' => 1, 'blocked' => 2];
        $final = ($rank[$regex['verdict']] ?? 0) >= ($rank[$ai['verdict']] ?? 0) ? $regex['verdict'] : $ai['verdict'];
        $regex['verdict']           = $final;
        $regex['allows_automation'] = $final === 'ok';
        $regex['ai']                = $ai; // {verdict, reason} untuk ditampilkan

        return $regex;
    }

    /** @return list<string> */
    private function lines(string $raw): array
    {
        return array_values(array_filter(array_map('trim', preg_split('/[\r\n,]+/', $raw) ?: []), static fn ($x): bool => $x !== ''));
    }
}
