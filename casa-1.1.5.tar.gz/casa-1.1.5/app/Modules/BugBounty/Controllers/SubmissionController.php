<?php

declare(strict_types=1);

namespace App\Modules\BugBounty\Controllers;

use App\Controllers\BaseController;
use App\Modules\BugBounty\Models\SubmissionModel;
use CodeIgniter\Exceptions\PageNotFoundException;
use CodeIgniter\HTTP\ResponseInterface;

/** SubmissionController — tracker submission bug bounty (lifecycle + payout). */
final class SubmissionController extends BaseController
{
    public function __construct(private readonly SubmissionModel $subs = new SubmissionModel())
    {
    }

    private function guard(): void
    {
        if ($this->isOwnerConsole()) {
            throw PageNotFoundException::forPageNotFound();
        }
        $this->session->set('scan_mode', 'bounty');
    }

    public function index(): string
    {
        $this->guard();
        $rows  = $this->subs->forCustomer((int) $this->session->get('member_id'));
        $stats = ['total' => count($rows), 'accepted' => 0, 'duplicate' => 0, 'bounty' => 0];
        foreach ($rows as $r) {
            if ($r['status'] === 'accepted' || $r['status'] === 'resolved') {
                $stats['accepted']++;
            }
            if ($r['status'] === 'duplicate') {
                $stats['duplicate']++;
            }
            $stats['bounty'] += (int) $r['bounty_amount'];
        }

        return $this->memberView('App\Modules\BugBounty\Views\submissions', [
            'title'    => 'Submissions',
            'subs'     => $rows,
            'stats'    => $stats,
            'statuses' => SubmissionModel::STATUSES,
        ], 'bb_submissions');
    }

    /** Update status/payout/external_id/note sebuah submission (milik member). */
    public function update(int $id): ResponseInterface
    {
        $this->guard();
        if ($r = $this->denyViewer()) {
            return $r;
        }
        // Verifikasi kepemilikan lewat daftar member.
        $owned = false;
        foreach ($this->subs->forCustomer((int) $this->session->get('member_id')) as $s) {
            if ((int) $s['id'] === $id) {
                $owned = true;
                break;
            }
        }
        if (! $owned) {
            return $this->fail('Submission tidak ditemukan.', 404);
        }
        $status = (string) $this->request->getPost('status');
        $this->subs->update($id, [
            'status'        => in_array($status, SubmissionModel::STATUSES, true) ? $status : 'draft',
            'bounty_amount' => (int) $this->request->getPost('bounty_amount'),
            'external_id'   => trim((string) $this->request->getPost('external_id')) ?: null,
            'note'          => trim((string) $this->request->getPost('note')) ?: null,
        ]);

        return $this->ok([]);
    }
}
