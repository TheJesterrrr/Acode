<?php

declare(strict_types=1);

namespace App\Modules\BugBounty\Controllers;

use App\Controllers\BaseController;
use App\Modules\BugBounty\Services\BountyProgramService;
use App\Modules\BugBounty\Services\BurpParser;
use CodeIgniter\Exceptions\PageNotFoundException;
use CodeIgniter\HTTP\ResponseInterface;
use RuntimeException;

/** ImportController — impor finding dari Burp (XML) atau tambah manual. */
final class ImportController extends BaseController
{
    public function __construct(private readonly BountyProgramService $svc = new BountyProgramService())
    {
    }

    private function guard(): void
    {
        if ($this->isOwnerConsole()) {
            throw PageNotFoundException::forPageNotFound();
        }
        $this->session->set('scan_mode', 'bounty');
    }

    private function me(): int
    {
        return (int) $this->session->get('member_id');
    }

    public function index(): string
    {
        $this->guard();

        return $this->memberView('App\Modules\BugBounty\Views\import', [
            'title'    => 'Import',
            'programs' => $this->svc->programsSelect($this->me()),
        ], 'bb_import');
    }

    /** Upload XML Burp → buat finding pada program terpilih. */
    public function burp(): ResponseInterface
    {
        $this->guard();
        if ($r = $this->denyViewer()) {
            return $r;
        }
        $pid  = (int) $this->request->getPost('program_id');
        $file = $this->request->getFile('xml');
        if ($file === null || ! $file->isValid()) {
            return $this->fail('Pilih berkas XML Burp yang valid.');
        }
        if ($file->getSize() > 8 * 1024 * 1024) {
            return $this->fail('Berkas terlalu besar (maks 8 MB).');
        }
        $xml   = (string) file_get_contents($file->getTempName());
        $items = BurpParser::parse($xml);
        if ($items === []) {
            \App\Libraries\CasaLog::log('CASA-E014', 'Import Burp XML program #' . $pid . ': 0 issue terbaca dari XML yang diunggah', null, null, 'warning');

            return $this->fail('[CASA-E014] Tak ada issue terbaca dari XML (pastikan ekspor "Report issues" format XML).');
        }
        $n = 0;
        try {
            foreach ($items as $it) {
                $this->svc->addFinding($pid, $this->me(), $it + ['tool' => 'burp']);
                $n++;
            }
        } catch (RuntimeException $e) {
            \App\Libraries\CasaLog::log('CASA-E014', 'Import Burp XML program #' . $pid . ' gagal: ' . mb_substr($e->getMessage(), 0, 150), null, null, 'warning');

            return $this->fail('[CASA-E014] ' . $e->getMessage());
        }

        return $this->ok(['redirect' => site_url('bounty/programs/' . $pid), 'count' => $n]);
    }

    /** Tambah finding manual (temuan hasil hunting sendiri). */
    public function manual(): ResponseInterface
    {
        $this->guard();
        if ($r = $this->denyViewer()) {
            return $r;
        }
        $pid = (int) $this->request->getPost('program_id');
        try {
            $id = $this->svc->addFinding($pid, $this->me(), [
                'title'       => (string) $this->request->getPost('title'),
                'severity'    => (string) $this->request->getPost('severity'),
                'asset'       => (string) $this->request->getPost('asset'),
                'description' => (string) $this->request->getPost('description'),
                'tool'        => 'manual',
            ]);
        } catch (RuntimeException $e) {
            return $this->fail($e->getMessage());
        }

        return $this->ok(['redirect' => site_url('bounty/programs/' . $pid), 'id' => $id]);
    }
}
