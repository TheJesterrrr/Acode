<?php

declare(strict_types=1);

namespace App\Modules\BugBounty\Controllers;

use App\Controllers\BaseController;
use App\Modules\BugBounty\Models\BountyProgramModel;
use App\Modules\BugBounty\Models\SubmissionModel;
use App\Modules\BugBounty\Services\BountyProgramService;
use App\Modules\BugBounty\Services\BountyReportService;
use CodeIgniter\Exceptions\PageNotFoundException;
use CodeIgniter\HTTP\ResponseInterface;

/** ReportController — draft report siap-submit (H1/Bugcrowd) dari sebuah finding. */
final class ReportController extends BaseController
{
    public function __construct(
        private readonly BountyProgramService $svc = new BountyProgramService(),
        private readonly BountyReportService $report = new BountyReportService(),
    ) {
    }

    private function guard(): void
    {
        if ($this->isOwnerConsole()) {
            throw PageNotFoundException::forPageNotFound();
        }
        $this->session->set('scan_mode', 'bounty');
    }

    private function me(): int
    {
        return (int) $this->session->get('member_id');
    }

    /** Daftar finding untuk dipilih → draft report. */
    public function index(): string
    {
        $this->guard();

        return $this->memberView('App\Modules\BugBounty\Views\reports', [
            'title'    => 'Reports',
            'findings' => $this->svc->allFindings($this->me()),
        ], 'bb_reports');
    }

    public function show(int $findingId): string
    {
        $this->guard();
        $f = $this->svc->ownedFinding($findingId, $this->me());
        if ($f === null) {
            throw PageNotFoundException::forPageNotFound();
        }
        $platform = $this->request->getGet('platform') === 'bugcrowd' ? 'bugcrowd' : 'hackerone';
        $program  = (new BountyProgramModel())->forProject((int) $f['pid']) ?? [];
        $program['name'] = $f['program'] ?? '';

        return $this->memberView('App\Modules\BugBounty\Views\report_draft', [
            'title'    => 'Report — ' . ($f['title'] ?? ''),
            'finding'  => $f,
            'platform' => $platform,
            'markdown' => $this->report->draft($f, $platform, $program),
        ], 'bb_reports');
    }

    public function download(int $findingId): ResponseInterface
    {
        $this->guard();
        $f = $this->svc->ownedFinding($findingId, $this->me());
        if ($f === null) {
            throw PageNotFoundException::forPageNotFound();
        }
        $platform = $this->request->getGet('platform') === 'bugcrowd' ? 'bugcrowd' : 'hackerone';
        $program  = (new BountyProgramModel())->forProject((int) $f['pid']) ?? [];
        $program['name'] = $f['program'] ?? '';
        $md = $this->report->draft($f, $platform, $program);
        $name = 'report-' . preg_replace('/[^a-z0-9]+/i', '-', strtolower((string) ($f['ref'] ?? $findingId))) . '.md';

        return $this->response
            ->setHeader('Content-Type', 'text/markdown; charset=UTF-8')
            ->setHeader('Content-Disposition', 'attachment; filename="' . $name . '"')
            ->setBody($md);
    }

    /** Simpan sebagai Submission (draft) untuk dilacak. */
    public function saveSubmission(int $findingId): ResponseInterface
    {
        $this->guard();
        if ($r = $this->denyViewer()) {
            return $r;
        }
        $f = $this->svc->ownedFinding($findingId, $this->me());
        if ($f === null) {
            return $this->fail('Finding tidak ditemukan.', 404);
        }
        $platform = $this->request->getPost('platform') === 'bugcrowd' ? 'bugcrowd' : 'hackerone';
        $id = (new SubmissionModel())->insert([
            'project_id' => (int) $f['pid'],
            'finding_id' => $findingId,
            'platform'   => $platform,
            'title'      => (string) ($f['title'] ?? 'Finding'),
            'severity'   => $platform === 'bugcrowd' ? (string) ($f['vrt'] ?? '') : (string) ($f['cvss'] ?? ''),
            'status'     => 'draft',
        ], true);

        return $this->ok(['redirect' => site_url('bounty/submissions'), 'id' => $id]);
    }
}
