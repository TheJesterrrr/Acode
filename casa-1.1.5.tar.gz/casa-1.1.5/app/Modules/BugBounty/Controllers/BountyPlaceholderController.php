<?php

declare(strict_types=1);

namespace App\Modules\BugBounty\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\Exceptions\PageNotFoundException;

/**
 * BountyPlaceholderController — halaman "segera hadir" untuk menu Bug Bounty
 * yang belum dibangun (Programs/Recon/Scan/Findings/Submissions/Import/Reports).
 * Sementara agar navigasi lengkap & tak 404 selama fitur dikerjakan bertahap.
 */
final class BountyPlaceholderController extends BaseController
{
    /** @var array<string,array{0:string,1:string,2:string,3:string}> key => [judul, ikon, fase, deskripsi] */
    private const PAGES = [
        'programs'    => ['Programs', 'bi-bullseye', 'Fase 2', 'Tetapkan program + scope (in/out), excluded types, rate rules. Input manual, paste-policy, atau parser URL.'],
        'recon'       => ['Recon Monitor', 'bi-broadcast-pin', 'Fase 3', 'Pantau aset baru dalam scope secara berkala.'],
        'scan'        => ['Bounty Scan', 'bi-radar', 'via Program', 'Bounty Scan dijalankan dari halaman Program (tombol "Mulai Bounty Scan") agar terscope ke target in-scope program. Buka Programs → pilih program → scan.'],
        'findings'    => ['Findings', 'bi-bug', 'Fase 3', 'Triase temuan bounty; tandai excluded/known-issue.'],
        'submissions' => ['Submissions', 'bi-send', 'Fase 4', 'Lacak status submission (triaged/duplicate/accepted/resolved) + payout.'],
        'import'      => ['Import', 'bi-box-arrow-in-down', 'Fase 5', 'Impor hasil Burp (XML) / Nuclei / tambah temuan manual.'],
        'reports'     => ['Reports', 'bi-file-earmark-text', 'Fase 4', 'Report siap-submit format HackerOne (CVSS) & Bugcrowd (VRT).'],
    ];

    public function show(string $key): string
    {
        if ($this->isOwnerConsole() || ! isset(self::PAGES[$key])) {
            throw PageNotFoundException::forPageNotFound();
        }
        $this->session->set('scan_mode', 'bounty');
        [$title, $icon, $fase, $desc] = self::PAGES[$key];

        return $this->memberView('App\Modules\BugBounty\Views\placeholder', [
            'title' => $title,
            'icon'  => $icon,
            'fase'  => $fase,
            'desc'  => $desc,
        ], 'bb_' . $key);
    }
}
