<?php

declare(strict_types=1);

namespace App\Modules\Report\Controllers;

use App\Controllers\BaseController;
use App\Libraries\Markdown;
use App\Modules\Licensing\Services\EditionService;
use App\Modules\Project\Models\ProjectModel;
use App\Modules\Report\Models\ReportModel;
use CodeIgniter\Exceptions\PageNotFoundException;
use CodeIgniter\HTTP\ResponseInterface;

/** ReportController — daftar/lihat/unduh laporan milik member (CES 13.2 thin). */
final class ReportController extends BaseController
{
    public function __construct(
        private readonly ReportModel $reports = new ReportModel(),
        private readonly ProjectModel $projects = new ProjectModel(),
        private readonly EditionService $edition = new EditionService(),
        private readonly \App\Modules\Report\Services\ReportService $reportService = new \App\Modules\Report\Services\ReportService(),
        private readonly \App\Modules\Mission\Models\MissionModel $missions = new \App\Modules\Mission\Models\MissionModel(),
    ) {
    }

    private function me(): int
    {
        return (int) $this->session->get('member_id');
    }

    private function owned(int $projectId): array
    {
        $p = $this->projects->ownedBy($projectId, $this->me());
        if ($p === null) {
            throw PageNotFoundException::forPageNotFound('Project tidak ditemukan.');
        }

        return $p;
    }

    public function index(int $projectId): string
    {
        $project = $this->owned($projectId);

        return $this->memberView('App\Modules\Report\Views\index', [
            'title'     => 'Reports — ' . $project['name'],
            'project'   => $project,
            'reports'   => $this->reports->forProject($projectId),
            'templates' => \App\Modules\Report\Services\ReportService::templates(),
        ], 'projects');
    }

    /** Buat laporan baru dari mission terakhir project, dengan template pilihan. */
    public function generate(int $projectId): ResponseInterface
    {
        if ($r = $this->denyViewer()) {
            return $r;
        }
        $this->owned($projectId);
        $template = (string) $this->request->getPost('template');
        $mid      = (int) $this->request->getPost('mission_id');
        if ($mid > 0) {
            $mission = $this->missions->where('project_id', $projectId)->find($mid);
        } else {
            $mission = $this->missions->latestForProject($projectId);
        }
        if ($mission === null) {
            return $this->fail('Belum ada mission pada project ini untuk dijadikan laporan.');
        }
        $id = $this->reportService->generate((int) $mission['id'], $projectId, $template);

        return $this->ok(['redirect' => site_url('reports/' . $id)]);
    }

    private function require(int $id): array
    {
        $r = $this->reports->find($id);
        if ($r === null) {
            throw PageNotFoundException::forPageNotFound('Laporan tidak ditemukan.');
        }
        $this->owned((int) $r['project_id']);

        return $r;
    }

    /** 'id'|'en' bila diminta eksplisit lewat ?lang=, selain itu null (pakai body tersimpan). */
    private function requestedLang(): ?string
    {
        $lang = (string) $this->request->getGet('lang');

        return in_array($lang, ['id', 'en'], true) ? $lang : null;
    }

    /**
     * Severity terfilter dari form filter (?f=1&sev[]=crit&sev[]=...). null = filter
     * tak diajukan sama sekali → tampilkan SEMUA (default, perilaku lama). Array
     * (boleh kosong) = filter eksplisit diajukan — kosong berarti sengaja tak
     * menampilkan apa pun (semua checkbox dilepas pengguna).
     */
    private function requestedSeverities(): ?array
    {
        if ($this->request->getGet('f') !== '1') {
            return null;
        }
        $raw = $this->request->getGet('sev') ?? [];
        $raw = is_array($raw) ? $raw : [$raw];

        return array_values(array_intersect($raw, \App\Modules\Report\Services\ReportService::SEVERITIES));
    }

    /** Sisipkan chart severity (HTML asli, bukan lewat Markdown) ke posisi CHART_TOKEN. */
    private function withChart(string $html, int $missionId, ?array $sev): string
    {
        $chart = $this->reportService->chartHtml($this->reportService->countsForMission($missionId, $sev));

        return $chart === '' ? $html : str_replace('<p>' . \App\Modules\Report\Services\ReportService::CHART_TOKEN . '</p>', $chart, $html);
    }

    public function show(int $id): string
    {
        $r    = $this->require($id);
        $lang = $this->requestedLang();
        $sev  = $this->requestedSeverities();
        // Tanpa ?lang= DAN tanpa filter severity: pakai body tersimpan (perilaku lama, tak berubah).
        // Dengan salah satunya: susun ulang segar dari temuan terkini sesuai pilihan.
        $useStored = $lang === null && $sev === null;
        $body      = $useStored ? (string) $r['body'] : $this->reportService->build((int) $r['mission_id'], (int) $r['project_id'], (string) $r['template'], $lang ?? 'id', $sev);
        $html      = $this->withChart(Markdown::render($body), (int) $r['mission_id'], $sev);

        return $this->memberView('App\Modules\Report\Views\show', [
            'title'  => $r['title'],
            'report' => $r,
            'lang'   => $lang ?? 'id',
            'langs'  => \App\Modules\Report\Services\ReportService::languages(),
            'sev'    => $sev, // null = semua (default, belum difilter); array = severity aktif
            'html'   => $html,
        ], 'projects');
    }

    public function raw(int $id): ResponseInterface
    {
        $r = $this->require($id);

        return $this->response
            ->setHeader('Content-Type', 'text/markdown; charset=UTF-8')
            ->setHeader('Content-Disposition', 'attachment; filename="report-' . $id . '.md"')
            ->setBody((string) $r['body']);
    }

    /** Unduh laporan sebagai PDF (Dompdf). ?lang=id|en, ?f=1&sev[]=... — default pakai body tersimpan. */
    public function pdf(int $id): ResponseInterface
    {
        $r = $this->require($id);
        if (! $this->edition->can($this->me(), 'pdf_report')) {
            return $this->response->setStatusCode(403)
                ->setBody('Ekspor PDF tersedia mulai paket Professional. Hubungi administrator untuk upgrade.');
        }
        $lang    = $this->requestedLang();
        $sev     = $this->requestedSeverities();
        $project = $this->projects->find((int) $r['project_id']);
        // Tanpa ?lang= DAN tanpa filter severity: pakai body tersimpan — identik perilaku lama.
        // Dengan salah satunya: susun ulang segar (bahasa/filter sesuai pilihan), tak pernah disimpan ke DB.
        $useStored = $lang === null && $sev === null;
        $body      = $useStored ? (string) $r['body'] : $this->reportService->build((int) $r['mission_id'], (int) $r['project_id'], (string) $r['template'], $lang ?? 'id', $sev);
        $htmlBody  = $this->withChart(Markdown::render($body), (int) $r['mission_id'], $sev);
        $html = view('App\Modules\Report\Views\pdf', [
            'report'  => $r,
            'project' => $project,
            'html'    => $htmlBody,
            'date'    => date('d M Y H:i'),
            'lang'    => $lang ?? 'id',
        ]);

        // Catatan: fatal murni PHP (OOM "Allowed memory size exhausted") TIDAK
        // tertangkap try/catch — tetap akan jatuh ke halaman error generik
        // "Whoops!" tanpa sempat ter-log di sini (lihat panduan PDF Gagal untuk
        // solusinya: tombol Print). try/catch ini menangkap exception Dompdf
        // LAIN yang sebenarnya bisa ditangkap (HTML tak valid, dll).
        try {
            $options = new \Dompdf\Options();
            $options->set('isRemoteEnabled', false);
            $options->set('defaultFont', 'DejaVu Sans');
            $dompdf = new \Dompdf\Dompdf($options);
            $dompdf->loadHtml($html, 'UTF-8');
            $dompdf->setPaper('A4');
            $dompdf->render();
            $out = $dompdf->output();
        } catch (\Throwable $e) {
            \App\Libraries\CasaLog::log('CASA-E004', 'Gagal membuat PDF report #' . $id . ': ' . mb_substr($e->getMessage(), 0, 150), (int) ($r['mission_id'] ?? 0) ?: null);

            return $this->response->setStatusCode(500)
                ->setBody('[CASA-E004] Gagal membuat PDF — coba tombol Print di halaman laporan sebagai alternatif, atau filter severity dulu untuk memperkecil laporan.');
        }

        return $this->response
            ->setHeader('Content-Type', 'application/pdf')
            ->setHeader('Content-Disposition', 'inline; filename="CASA-report-' . $id . '-' . ($lang ?? 'id') . '.pdf"')
            ->setBody($out);
    }
}
