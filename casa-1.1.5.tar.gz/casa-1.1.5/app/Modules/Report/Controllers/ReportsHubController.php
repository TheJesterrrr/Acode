<?php

declare(strict_types=1);

namespace App\Modules\Report\Controllers;

use App\Controllers\BaseController;
use App\Modules\Report\Models\ReportModel;

/** ReportsHubController — daftar seluruh laporan lintas project (member). */
final class ReportsHubController extends BaseController
{
    public function __construct(private readonly ReportModel $reports = new ReportModel())
    {
    }

    public function index(): string
    {
        return $this->memberView('App\Modules\Report\Views\hub', [
            'title'   => 'Reports',
            'reports' => $this->reports->forCustomer((int) $this->session->get('member_id')),
        ], 'reports');
    }
}
