<?php

declare(strict_types=1);

use CodeIgniter\Router\RouteCollection;

/** Rute modul Report — endpoint MEMBER (CES 13.10). */

/** @var RouteCollection $routes */
$routes->group('', ['namespace' => 'App\Modules\Report\Controllers', 'filter' => 'member'], static function (RouteCollection $routes): void {
    $routes->get('reports', 'ReportsHubController::index');
    $routes->get('projects/(:num)/reports', 'ReportController::index/$1');
    $routes->post('projects/(:num)/reports/generate', 'ReportController::generate/$1', ['filter' => 'audit:REPORT_GENERATE']);
    $routes->get('reports/(:num)',          'ReportController::show/$1');
    $routes->get('reports/(:num)/raw',      'ReportController::raw/$1');
    $routes->get('reports/(:num)/pdf',      'ReportController::pdf/$1');
});
