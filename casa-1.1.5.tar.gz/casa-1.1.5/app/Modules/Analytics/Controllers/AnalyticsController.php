<?php

declare(strict_types=1);

namespace App\Modules\Analytics\Controllers;

use App\Controllers\BaseController;
use App\Modules\Analytics\Services\AnalyticsService;

/** AnalyticsController — dasbor analitik bisnis (OWNER only). */
final class AnalyticsController extends BaseController
{
    public function __construct(private readonly AnalyticsService $svc = new AnalyticsService())
    {
    }

    public function index(): string
    {
        $this->requireOwnerConsole();

        return $this->adminView('App\Modules\Analytics\Views\index', [
            'title' => 'Analytics',
            'a'     => $this->svc->overview(),
        ], 'analytics');
    }
}
