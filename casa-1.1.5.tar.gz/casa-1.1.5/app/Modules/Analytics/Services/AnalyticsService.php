<?php

declare(strict_types=1);

namespace App\Modules\Analytics\Services;

use CodeIgniter\Database\BaseConnection;
use Config\Database;

/**
 * AnalyticsService — agregat bisnis untuk konsol OWNER: pelanggan, instance
 * (phone-home), langganan/lisensi, dan pendapatan koin. Semua kueri ringkas.
 */
final class AnalyticsService
{
    private BaseConnection $db;

    public function __construct(?BaseConnection $db = null)
    {
        $this->db = $db ?? Database::connect();
    }

    /** @return array<string,mixed> */
    public function overview(): array
    {
        return [
            'customers_total'  => $this->one("SELECT COUNT(*) n FROM customers WHERE deleted_at IS NULL"),
            'customers_active' => $this->one("SELECT COUNT(*) n FROM customers WHERE status='active' AND deleted_at IS NULL"),
            'customers_new30'  => $this->one("SELECT COUNT(*) n FROM customers WHERE deleted_at IS NULL AND created_at>=DATE_SUB(NOW(),INTERVAL 30 DAY)"),
            'instances_total'  => $this->one("SELECT COUNT(*) n FROM instance_report"),
            'instances_active' => $this->one("SELECT COUNT(*) n FROM instance_report WHERE last_seen>=DATE_SUB(NOW(),INTERVAL 3 DAY)"),
            'subs_active'      => $this->one("SELECT COUNT(*) n FROM subscription WHERE status='active' AND (expires_at IS NULL OR expires_at>=CURDATE())"),
            'subs_expired'     => $this->one("SELECT COUNT(*) n FROM subscription WHERE expires_at IS NOT NULL AND expires_at<CURDATE()"),
            'revenue_coins'    => $this->one("SELECT COALESCE(SUM(coins_spent),0) n FROM subscription"),
            'tier_instances'   => $this->pairs("SELECT COALESCE(tier,'community') k, COUNT(*) n FROM instance_report GROUP BY tier"),
            'tier_subs'        => $this->pairs("SELECT tier k, COUNT(*) n FROM subscription WHERE status='active' GROUP BY tier"),
            'versions'         => $this->pairs("SELECT COALESCE(version,'?') k, COUNT(*) n FROM instance_report GROUP BY version ORDER BY n DESC LIMIT 6"),
            'recent_subs'      => $this->db->query("SELECT s.tier, s.months, s.method, s.expires_at, s.created_at, c.name FROM subscription s JOIN customers c ON c.id=s.customer_id ORDER BY s.id DESC LIMIT 8")->getResultArray(),
            'instances'        => $this->db->query("SELECT install_id, customer, tier, version, projects, missions, findings, last_seen FROM instance_report ORDER BY last_seen DESC LIMIT 12")->getResultArray(),
        ];
    }

    private function one(string $sql): int
    {
        return (int) ($this->db->query($sql)->getRowArray()['n'] ?? 0);
    }

    /** @return array<string,int> */
    private function pairs(string $sql): array
    {
        $out = [];
        foreach ($this->db->query($sql)->getResultArray() as $r) {
            $out[(string) $r['k']] = (int) $r['n'];
        }

        return $out;
    }
}
