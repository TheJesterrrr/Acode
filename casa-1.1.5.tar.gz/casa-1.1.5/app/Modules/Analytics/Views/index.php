<?= $this->extend('layouts/admin') ?>
<?= $this->section('content') ?>
<?php
/** @var array $a */
$tierColor = ['community' => 'secondary', 'pro' => 'info', 'enterprise' => 'warning'];
$barRow = static function (array $pairs) use ($tierColor): string {
    $tot = array_sum($pairs) ?: 1;
    $h   = '';
    foreach ($pairs as $k => $n) {
        $c = $tierColor[$k] ?? 'primary';
        $h .= '<div class="d-flex justify-content-between small mb-1"><span class="text-capitalize">' . esc($k) . '</span><span class="text-muted">' . (int) $n . '</span></div>';
        $h .= '<div class="progress mb-2" style="height:7px"><div class="progress-bar bg-' . $c . '" style="width:' . round($n / $tot * 100) . '%"></div></div>';
    }

    return $h ?: '<p class="text-muted small mb-0">Belum ada data.</p>';
};
?>
<div class="casa-page-head"><h1 class="h4 mb-0"><i class="bi bi-graph-up me-1"></i>Analytics</h1></div>

<div class="row g-3 mb-1">
  <div class="col-6 col-lg-3"><div class="casa-card p-3"><div class="small text-muted">Pelanggan aktif</div><div class="fs-3 fw-bold"><?= (int) $a['customers_active'] ?></div><div class="small text-success">+<?= (int) $a['customers_new30'] ?> / 30 hari</div></div></div>
  <div class="col-6 col-lg-3"><div class="casa-card p-3"><div class="small text-muted">Instance aktif</div><div class="fs-3 fw-bold"><?= (int) $a['instances_active'] ?><small class="fs-6 text-muted">/<?= (int) $a['instances_total'] ?></small></div><div class="small text-muted">3 hari terakhir</div></div></div>
  <div class="col-6 col-lg-3"><div class="casa-card p-3"><div class="small text-muted">Langganan aktif</div><div class="fs-3 fw-bold"><?= (int) $a['subs_active'] ?></div><div class="small text-danger"><?= (int) $a['subs_expired'] ?> kedaluwarsa</div></div></div>
  <div class="col-6 col-lg-3"><div class="casa-card p-3"><div class="small text-muted">Koin terpakai</div><div class="fs-3 fw-bold text-warning"><i class="bi bi-coin me-1"></i><?= number_format((int) $a['revenue_coins'], 0, ',', '.') ?></div><div class="small text-muted">total langganan</div></div></div>
</div>

<div class="row g-3 mt-0">
  <div class="col-lg-4"><div class="casa-card p-3 p-lg-4 h-100"><h2 class="h6 mb-3">Instance per tier</h2><?= $barRow($a['tier_instances']) ?></div></div>
  <div class="col-lg-4"><div class="casa-card p-3 p-lg-4 h-100"><h2 class="h6 mb-3">Langganan per tier</h2><?= $barRow($a['tier_subs']) ?></div></div>
  <div class="col-lg-4"><div class="casa-card p-3 p-lg-4 h-100"><h2 class="h6 mb-3">Versi terpasang</h2>
    <?php foreach ($a['versions'] as $v => $n): ?>
      <div class="d-flex justify-content-between small mb-1"><span class="font-monospace">v<?= esc($v) ?></span><span class="badge text-bg-light border"><?= (int) $n ?></span></div>
    <?php endforeach; ?>
    <?php if ($a['versions'] === []): ?><p class="text-muted small mb-0">Belum ada laporan instance.</p><?php endif; ?>
  </div></div>
</div>

<div class="row g-3 mt-0">
  <div class="col-lg-6"><div class="casa-card p-0 h-100">
    <div class="p-3 border-bottom" style="border-color:var(--casa-card-brd)!important"><h2 class="h6 mb-0">Langganan terbaru</h2></div>
    <div class="table-responsive"><table class="table table-sm align-middle mb-0">
      <thead><tr><th class="ps-3">Pelanggan</th><th>Tier</th><th>Metode</th><th class="pe-3">s/d</th></tr></thead>
      <tbody>
        <?php foreach ($a['recent_subs'] as $s): ?>
          <tr><td class="ps-3 small"><?= esc($s['name']) ?></td><td><span class="badge text-bg-<?= $tierColor[$s['tier']] ?? 'secondary' ?>"><?= esc(strtoupper($s['tier'])) ?></span></td><td class="small text-muted"><?= esc($s['method']) ?></td><td class="small pe-3"><?= esc($s['expires_at'] ?? '∞') ?></td></tr>
        <?php endforeach; ?>
        <?php if ($a['recent_subs'] === []): ?><tr><td colspan="4" class="text-muted small py-3 text-center">Belum ada langganan.</td></tr><?php endif; ?>
      </tbody>
    </table></div>
  </div></div>
  <div class="col-lg-6"><div class="casa-card p-0 h-100">
    <div class="p-3 border-bottom" style="border-color:var(--casa-card-brd)!important"><h2 class="h6 mb-0">Instance pelanggan</h2></div>
    <div class="table-responsive"><table class="table table-sm align-middle mb-0">
      <thead><tr><th class="ps-3">Instance</th><th>Tier</th><th>Temuan</th><th class="pe-3">Terakhir</th></tr></thead>
      <tbody>
        <?php foreach ($a['instances'] as $it): ?>
          <tr><td class="ps-3 small"><?= esc($it['customer'] ?: substr((string) $it['install_id'], 0, 10)) ?></td><td><span class="badge text-bg-<?= $tierColor[$it['tier']] ?? 'secondary' ?>"><?= esc(strtoupper((string) ($it['tier'] ?: 'community'))) ?></span></td><td class="small"><?= (int) $it['findings'] ?></td><td class="small text-muted pe-3"><?= esc(substr((string) $it['last_seen'], 0, 16)) ?></td></tr>
        <?php endforeach; ?>
        <?php if ($a['instances'] === []): ?><tr><td colspan="4" class="text-muted small py-3 text-center">Belum ada instance melapor.</td></tr><?php endif; ?>
      </tbody>
    </table></div>
  </div></div>
</div>
<?= $this->endSection() ?>
