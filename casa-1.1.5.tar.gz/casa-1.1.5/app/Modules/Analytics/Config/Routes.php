<?php

declare(strict_types=1);

use CodeIgniter\Router\RouteCollection;

/** Rute Analytics — dasbor bisnis owner (admin, owner-console). */

/** @var RouteCollection $routes */
$routes->group('casaadmin/analytics', ['namespace' => 'App\Modules\Analytics\Controllers', 'filter' => 'admin'], static function (RouteCollection $routes): void {
    $routes->get('', 'AnalyticsController::index');
});
