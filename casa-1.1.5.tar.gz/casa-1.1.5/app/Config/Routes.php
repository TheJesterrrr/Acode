<?php

declare(strict_types=1);

use CodeIgniter\Router\RouteCollection;

/**
 * Routes global (CES 13.2). Rute spesifik modul didefinisikan pada
 * app/Modules/<Nama>/Config/Routes.php dan ditemukan otomatis (Config\Modules).
 *
 * Rute dibedakan per endpoint memakai filter 'member'/'admin' — bukan dengan
 * host terpisah di berkas ini — karena kedua host berbagi document root
 * (CES 11.5.2). EndpointContextFilter (global) telah menetapkan konteks.
 */

/** @var RouteCollection $routes */

$routes->setDefaultNamespace('App\\Controllers');
$routes->setAutoRoute(false); // CES 5.4 — auto-route DILARANG.
// CI4 melakukan `echo $override(...)`, sehingga penimpa 404 WAJIB
// mengembalikan STRING. Mengembalikan objek Response memicu
// "Object of class CodeIgniter\\HTTP\\Response could not be converted to string".
// Kode status 404 sudah disetel framework sebelum penimpa dipanggil.
$routes->set404Override(static function (string $message = ''): string {
    return view('errors/html/error_404', ['message' => $message]);
});

// Halaman muka diarahkan sesuai endpoint. Portal publik/landing member dan
// login admin diregistrasi oleh modul masing-masing.
$routes->get('/', 'Home::index');

// Ganti bahasa tampilan (ID/EN) — SENGAJA tanpa filter 'member'/'admin': toggle
// ini harus jalan di halaman manapun (termasuk login), bukan cuma yang sudah
// masuk sesi. Lihat LocaleFilter (global, menata $request->setLocale()).
$routes->get('bahasa/(:segment)', 'LocaleController::set/$1');
