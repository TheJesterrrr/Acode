<?php

declare(strict_types=1);

namespace Config;

use CodeIgniter\Config\BaseConfig;

/**
 * App — konfigurasi inti. Nilai peka lingkungan diambil dari .env
 * (CES 1.6 Zero Hardcode). baseURL member; adminURL dibaca terpisah
 * oleh Cer untuk Multi-Endpoint Runtime (CES 11.5.2).
 */
class App extends BaseConfig
{
    public string $baseURL = 'http://localhost/';
    public array $allowedHostnames = [];
    public string $indexPage = '';
    public string $uriProtocol = 'REQUEST_URI';
    public string $defaultLocale = 'id';
    public bool $negotiateLocale = false;
    public array $supportedLocales = ['id', 'en'];
    public string $appTimezone = 'Asia/Jakarta';
    public string $charset = 'UTF-8';
    public bool $forceGlobalSecureRequests = true;

    // Header keamanan dipasang oleh SecurityHeadersFilter (CES 5.4).

    public string $permittedURIChars = 'a-z 0-9~%.:_\-';
    public array $proxyIPs = [];
    public bool $CSPEnabled = false;

    /**
     * Deteksi baseURL otomatis bila belum dikonfigurasi.
     *
     * Sebelum instalasi belum ada .env, sehingga baseURL masih placeholder dan
     * SELURUH site_url() pada wizard akan menunjuk localhost (form tak bisa
     * dikirim). Deteksi ini HANYA aktif saat nilainya masih placeholder — begitu
     * .env terisi, nilai dari .env yang dipakai. Host disaring ketat agar tidak
     * bisa dipakai untuk host-header injection.
     */
    public function __construct()
    {
        parent::__construct();

        $this->izinkanHostAdmin();

        if ($this->baseURL !== 'http://localhost/') {
            return; // sudah dikonfigurasi (.env atau manual)
        }

        $host = (string) ($_SERVER['HTTP_HOST'] ?? '');
        if ($host === '' || preg_match('/^[A-Za-z0-9.\-]+(?::\d{1,5})?$/', $host) !== 1) {
            return;
        }

        $https = (! empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off')
            || strtolower((string) ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https'
            || (int) ($_SERVER['SERVER_PORT'] ?? 0) === 443;

        $this->baseURL = ($https ? 'https' : 'http') . '://' . $host . '/';
    }

    /**
     * Izinkan host endpoint admin.
     *
     * CodeIgniter hanya mempertahankan host yang sedang diakses bila host itu
     * terdaftar di $allowedHostnames (lihat SiteURIFactory). Tanpa ini, seluruh
     * site_url() pada panel admin dibangun memakai host baseURL (member),
     * sehingga setiap tautan melompat ke portal member lalu ditolak filter —
     * panel tampak "tidak bisa diklik". Host diambil dari app.adminURL agar
     * tidak ada nilai yang perlu disamakan manual di dua tempat.
     */
    private function izinkanHostAdmin(): void
    {
        $adminUrl = (string) (env('app.adminURL') ?: '');
        if ($adminUrl === '') {
            return;
        }

        $adminHost = parse_url($adminUrl, PHP_URL_HOST);
        if (! is_string($adminHost) || $adminHost === '') {
            return;
        }

        if (! in_array($adminHost, $this->allowedHostnames, true)) {
            $this->allowedHostnames[] = $adminHost;
        }
    }
}
