<?php

declare(strict_types=1);

namespace Config;

use CodeIgniter\Database\Config;

/**
 * Database — koneksi tunggal, seluruh kredensial dari .env (CES 1.6, 5.6).
 * Akses data WAJIB via Model/Query Builder CI4 (CES 13.3).
 */
class Database extends Config
{
    /**
     * Lokasi berkas basis data (dipakai CodeIgniter\Database\Seeder untuk
     * memvalidasi folder Seeds/). Seeder CASA sendiri berada di tiap modul
     * (app/Modules/<Nama>/Database/Seeds) dan dipanggil lewat nama kelas penuh,
     * tetapi konstruktor Seeder tetap mewajibkan folder ini ada.
     */
    public string $filesPath = APPPATH . 'Database' . DIRECTORY_SEPARATOR;

    public string $defaultGroup = 'default';

    public array $default = [
        'DSN'          => '',
        'hostname'     => 'localhost',
        'username'     => '',
        'password'     => '',
        'database'     => '',
        'DBDriver'     => 'MySQLi',
        'DBPrefix'     => '',
        'pConnect'     => false,
        'DBDebug'      => false,
        'charset'      => 'utf8mb4',
        'DBCollat'     => 'utf8mb4_unicode_ci',
        'swapPre'      => '',
        'encrypt'      => false,
        'compress'     => false,
        'strictOn'     => true,
        'failover'     => [],
        'port'         => 3306,
        'numberNative' => false,
    ];

    public array $tests = [
        'DSN'      => '',
        'hostname' => '127.0.0.1',
        'username' => '',
        'password' => '',
        'database' => ':memory:',
        'DBDriver' => 'SQLite3',
        'DBPrefix' => 'db_',
        'DBDebug'  => true,
        'charset'  => 'utf8',
        'DBCollat' => '',
        'port'     => 3306,
    ];

    public function __construct()
    {
        parent::__construct();
        if (ENVIRONMENT === 'testing') {
            $this->defaultGroup = 'tests';
        }
    }
}
