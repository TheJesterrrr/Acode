<?php

declare(strict_types=1);

namespace Config;

use CodeIgniter\Config\Filters as BaseFilters;
use CodeIgniter\Filters\Cors;
use CodeIgniter\Filters\DebugToolbar;
use CodeIgniter\Filters\CSRF;
use CodeIgniter\Filters\ForceHTTPS;
use CodeIgniter\Filters\Honeypot;
use CodeIgniter\Filters\InvalidChars;
use CodeIgniter\Filters\PageCache;
use CodeIgniter\Filters\PerformanceMetrics;
use CodeIgniter\Filters\SecureHeaders;
use App\Filters\EndpointContextFilter;
use App\Filters\SecurityHeadersFilter;
use App\Filters\MemberAuthFilter;
use App\Filters\AdminAuthFilter;
use App\Filters\RoleFilter;
use App\Filters\AuditFilter;
use App\Filters\LocaleFilter;

/**
 * Filters — mekanisme resmi seluruh lintas-potong (CES 13.7).
 * DILARANG mengulang autentikasi/otorisasi/audit secara manual di Controller.
 */
class Filters extends BaseFilters
{
    public array $aliases = [
        // Bawaan CodeIgniter — JANGAN dihapus: 'pagecache', 'performance', dan
        // 'toolbar' terdaftar pada $required induk, sehingga tanpa alias ini
        // framework melempar FilterException di setiap request.
        'csrf'            => CSRF::class,
        'toolbar'         => DebugToolbar::class,
        'honeypot'        => Honeypot::class,
        'invalidchars'    => InvalidChars::class,
        'secureheaders'   => SecureHeaders::class,
        'cors'            => Cors::class,
        'forcehttps'      => ForceHTTPS::class,
        'pagecache'       => PageCache::class,
        'performance'     => PerformanceMetrics::class,

        // Filter CoreNet
        'endpoint'        => EndpointContextFilter::class, // CES 11.5.3
        'casaheaders'      => SecurityHeadersFilter::class,  // CES 5.4
        'member'          => MemberAuthFilter::class,       // sesi member
        'admin'           => AdminAuthFilter::class,        // sesi admin
        'role'            => RoleFilter::class,             // RBAC (owner/operator)
        'audit'           => AuditFilter::class,            // catat aksi
        'locale'          => LocaleFilter::class,           // bahasa tampilan ID/EN
    ];

    /**
     * Dijalankan pada SETIAP request. Urutan penting:
     * endpoint (tentukan member/admin + nama cookie sesi) → header keamanan.
     */
    public array $globals = [
        'before' => [
            'endpoint',
            'locale',
            'invalidchars',
            // Perlindungan CSRF untuk SELURUH permintaan yang mengubah data.
            // Endpoint agent CHR dikecualikan: ia bukan browser dan tidak punya
            // cookie — otentikasinya memakai token per-server (AgentAuth).
            'csrf' => ['except' => ['api/*']],
        ],
        'after' => [
            'casaheaders',
        ],
    ];

    public array $methods = [];

    public array $filters = [];
}
