<?php

declare(strict_types=1);

namespace Config;

use CodeIgniter\Modules\Modules as BaseModules;

/**
 * Modules — penemuan otomatis modul (CES 1.6 Extensible, 13.10).
 *
 * autoDiscover aktif agar setiap app/Modules/<Nama>/Config/Routes.php
 * dan Database/Migrations ditemukan tanpa didaftarkan satu per satu.
 */
class Modules extends BaseModules
{
    public $enabled = true;

    public $discoverInComposer = false;

    public bool $composerPackages = false;

    public $aliases = [
        'events',
        'filters',
        'registrars',
        'routes',
        'services',
    ];
}
