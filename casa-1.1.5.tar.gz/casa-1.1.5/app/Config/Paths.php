<?php

declare(strict_types=1);

namespace Config;

/**
 * Paths — lokasi folder inti (CES 2.3, 11.5.1).
 *
 * Nilai path RELATIF terhadap folder ini. CoreNet Environment Resolver
 * (App\Libraries\Cer) membungkus konstanta ROOTPATH/APPPATH/WRITEPATH
 * yang diturunkan dari sini; DILARANG menghitung path secara manual di
 * tempat lain (butir 11.5.1).
 */
class Paths
{
    /** Folder aplikasi. */
    public string $appDirectory = __DIR__ . '/..';

    /**
     * Lokasi berkas .env — akar proyek (di LUAR document root).
     */
    public string $envDirectory = __DIR__ . '/../../';

    /**
     * Inti framework. Mode tanpa Composer (DIUTAMAKAN shared hosting, CES 7.6):
     * ekstrak `system/` sejajar `app/`. Mode Composer: arahkan ke vendor.
     */
    public string $systemDirectory = __DIR__ . '/../../vendor/codeigniter4/framework/system';

    /** Folder yang dapat ditulis (cache, log, sesi, unggahan). */
    public string $writableDirectory = __DIR__ . '/../../writable';

    /** Folder pengujian. */
    public string $testsDirectory = __DIR__ . '/../../tests';

    /** View (bila memakai lokasi khusus). Kosong = default APPPATH/Views. */
    public string $viewDirectory = __DIR__ . '/../Views';
}
