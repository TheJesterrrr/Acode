<?php

declare(strict_types=1);

namespace Config;

use CodeIgniter\Config\AutoloadConfig;

/**
 * Autoload — pemetaan namespace PSR-4 (CES 13.1).
 *
 * Modul bisnis (CES 13.10) hidup di app/Modules/<Nama> dengan namespace
 * App\Modules\<Nama>. Satu aturan PSR-4 memetakan seluruhnya; menambah
 * modul baru TIDAK memerlukan perubahan konfigurasi (butir 1.6 Extensible).
 */
class Autoload extends AutoloadConfig
{
    public $psr4 = [
        APP_NAMESPACE            => APPPATH,          // App\
        'App\\Modules'           => APPPATH . 'Modules',
    ];

    public $classmap = [];

    public $files = [];

    public array $helpers = ['casa'];

    /**
     * Daftarkan SETIAP modul sebagai namespace tersendiri.
     *
     * CodeIgniter menemukan berkas modul (Config/Routes.php, Config/Filters.php,
     * Language/, Views/, migrasi) dengan mencari di tiap namespace TERDAFTAR:
     * `<path-namespace>/Config/Routes.php`. Mendaftarkan hanya 'App\Modules'
     * membuat CI4 mencari app/Modules/Config/Routes.php — yang tidak ada —
     * sehingga SELURUH rute modul tak pernah dimuat (semua URL jadi 404).
     *
     * Pemindaian otomatis ini menjaga aturan "tambah modul tanpa ubah konfigurasi"
     * (CES 13.10): cukup buat folder app/Modules/<Nama>, langsung terdaftar.
     */
    public function __construct()
    {
        $modulesPath = APPPATH . 'Modules' . DIRECTORY_SEPARATOR;

        foreach ((array) @scandir($modulesPath) ?: [] as $entry) {
            if ($entry === '.' || $entry === '..') {
                continue;
            }
            $dir = $modulesPath . $entry;
            if (is_dir($dir)) {
                $this->psr4['App\\Modules\\' . $entry] = $dir;
            }
        }

        parent::__construct();
    }
}
