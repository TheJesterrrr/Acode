<?php

declare(strict_types=1);

use App\Libraries\Cer;
use App\Modules\Setting\Services\SettingService;

/**
 * casa_helper — fungsi pembantu lintas modul (CES 2.3 Helpers).
 * DILARANG menaruh logika bisnis di sini; hanya pembantu presentasi/format.
 */

if (! function_exists('setting_value')) {
    /**
     * Baca satu setelan dari tabel `settings` melalui SettingService
     * (CES 1.6 Zero Hardcode, 1.7 "satu cara untuk satu hal").
     */
    function setting_value(string $key, mixed $default = null): mixed
    {
        if (class_exists(SettingService::class)) {
            return (new SettingService())->get($key, $default);
        }

        return $default;
    }
}

if (! function_exists('casa_version')) {
    /** Versi aplikasi — satu-satunya sumber (footer, wizard, release notes). */
    function casa_version(): string
    {
        return (string) (setting_value('app.version') ?? '1.0.0');
    }
}

if (! function_exists('rupiah')) {
    /** Format angka menjadi Rupiah tanpa desimal. 1 CoreNet Koin = Rp1. */
    function rupiah(int|float $value): string
    {
        return 'Rp' . number_format((float) $value, 0, ',', '.');
    }
}

if (! function_exists('endpoint_base')) {
    /** URL dasar endpoint aktif (member/admin). */
    function endpoint_base(string $path = ''): string
    {
        return Cer::currentBaseUrl() . ltrim($path, '/');
    }
}

if (! function_exists('scan_mode')) {
    /** Mode portal aktif: 'pentest' (default) | 'bounty'. Disimpan di session. */
    function scan_mode(): string
    {
        $m = (string) (session()->get('scan_mode') ?: 'pentest');

        return $m === 'bounty' ? 'bounty' : 'pentest';
    }
}

