<?php

declare(strict_types=1);

use App\Modules\Licensing\Config\Edition;
use App\Modules\Licensing\Services\EditionService;

/**
 * edition_helper — util view untuk gating edisi (Community/Pro/Enterprise).
 * Dipakai agar fitur Pro/Enterprise TETAP TERLIHAT oleh Community namun bertanda
 * gembok (discoverability + upsell), bukan disembunyikan.
 */
if (! function_exists('is_owner_console')) {
    /**
     * Apakah instance ini adalah CONSOLE OWNER (memegang private key lisensi).
     * True hanya di server owner (env license.privateKey terisi) → memunculkan
     * fitur owner-only (generator lisensi, daftar pelanggan, monitoring). Instance
     * pelanggan (produk) tak memilikinya → hanya Admin Member lokal.
     */
    function is_owner_console(): bool
    {
        return (string) (env('license.privateKey') ?: '') !== '';
    }
}

if (! function_exists('edition_service')) {
    function edition_service(): EditionService
    {
        static $svc = null;

        return $svc ??= new EditionService();
    }
}

if (! function_exists('edition_can')) {
    /** Apakah member aktif boleh memakai fitur ini pada edisinya. */
    function edition_can(string $feature): bool
    {
        $cid = (int) session()->get('member_id');

        return $cid > 0 && edition_service()->can($cid, $feature);
    }
}

if (! function_exists('edition_min_tier_label')) {
    /** Label tier minimum yang membuka fitur (untuk badge gembok). */
    function edition_min_tier_label(string $feature): string
    {
        $cfg = config(Edition::class);
        foreach (['community', 'pro', 'enterprise'] as $tier) {
            if (! empty($cfg->tiers[$tier]['features'][$feature] ?? false)) {
                return (string) ($cfg->tiers[$tier]['label'] ?? ucfirst($tier));
            }
        }

        return 'Professional';
    }
}

if (! function_exists('edition_lock_badge')) {
    /** HTML badge gembok untuk fitur terkunci ('' bila boleh dipakai). */
    function edition_lock_badge(string $feature): string
    {
        if (edition_can($feature)) {
            return '';
        }
        $tier = esc(edition_min_tier_label($feature));

        return '<span class="badge text-bg-warning ms-1" title="Perlu paket ' . $tier
            . '"><i class="bi bi-lock-fill"></i> ' . $tier . '</span>';
    }
}
