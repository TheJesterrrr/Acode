<?php

declare(strict_types=1);

/**
 * casa_log_helper — render pesan error/task jadi badge kode CASA-Exxx yang
 * ngelink ke artikel Panduan yang cocok (dipakai di Engine Health & Mission).
 */
if (! function_exists('casaCodeBadge')) {
    function casaCodeBadge(string $text): string
    {
        if (! preg_match('/\[(CASA-E\d{3})\]\s*/', $text, $m)) {
            return esc(mb_substr($text, 0, 90));
        }
        $code  = $m[1];
        $rest  = esc(mb_substr(trim(str_replace($m[0], '', $text)), 0, 70));
        $slug  = \App\Libraries\CasaLog::guideSlug($code);
        $badge = '<span class="badge text-bg-dark font-monospace">' . esc($code) . '</span>';
        if ($slug !== null) {
            $badge = '<a href="' . esc(site_url('panduan/' . $slug)) . '" target="_blank" class="text-decoration-none">' . $badge . '</a>';
        }

        return $badge . ' ' . $rest;
    }
}
